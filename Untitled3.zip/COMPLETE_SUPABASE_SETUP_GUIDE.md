# 🎯 完成WeDesign Supabase项目配置
## 获取Service Role密钥 + 数据库设置 + 验证测试

---

## ✅ **当前配置状态**

**已完成配置：**
- ✅ **项目URL**: `https://awmngaikrnjcftlfasxy.supabase.co`
- ✅ **Anon Key**: 已添加到 `.env.local`
- ⚠️ **Service Role Key**: 需要获取（后端功能必需）

---

## 🔑 **步骤1: 获取Service Role密钥 (2分钟)**

### **1.1 访问API设置**

1. **打开Supabase控制台**
   ```
   访问: https://supabase.com/dashboard
   登录: Javen1984@gmail.com
   ```

2. **选择wedesign-production项目**
   - 确认项目名称显示为 `wedesign-production`

3. **进入API设置页面**
   - 点击左侧菜单 **"Settings"**
   - 点击子菜单 **"API"**

### **1.2 获取Service Role密钥**

在API页面找到：

```bash
# 确认已有的配置
Project URL: https://awmngaikrnjcftlfasxy.supabase.co ✅
anon public: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9... ✅

# 需要获取的密钥
service_role: [点击 "Reveal" 按钮显示密钥]
```

**重要步骤：**
1. 找到 **"service_role"** 行
2. **点击 "Reveal" 按钮**（密钥默认隐藏）
3. **复制完整密钥**（通常以 `eyJhbGciOiJIUzI1NiIs...` 开头）

### **1.3 更新配置文件**

**将获取的service_role密钥替换到 `.env.local` 文件中：**

```bash
# 找到这一行：
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key_here

# 替换为您复制的密钥：
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.您的完整service_role密钥...
```

---

## 🗃️ **步骤2: 设置数据库结构 (3分钟)**

### **2.1 打开SQL编辑器**

1. **在wedesign-production项目中**
2. **点击左侧菜单 "SQL Editor"**
3. **点击 "New query" 创建新查询**

### **2.2 执行数据库设置SQL**

**复制以下完整SQL脚本并执行：**

```sql
-- ========================================
-- WeDesign数据库结构设置
-- 项目: wedesign-production
-- ========================================

-- 1. 创建用户配置文件表
CREATE TABLE IF NOT EXISTS profiles (
  id UUID REFERENCES auth.users ON DELETE CASCADE PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  full_name TEXT,
  avatar_url TEXT,
  phone TEXT,
  company TEXT,
  subscription_type TEXT DEFAULT 'free' CHECK (subscription_type IN ('free', 'premium', 'enterprise')),
  credits_remaining INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. 创建项目表
CREATE TABLE IF NOT EXISTS projects (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  package_type TEXT NOT NULL CHECK (package_type IN ('economy', 'business', 'private-jet')),
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'in_progress', 'review', 'revision', 'completed', 'cancelled')),
  
  -- 项目详细信息
  industry TEXT,
  color_preferences TEXT[],
  style_preferences TEXT[],
  additional_notes TEXT,
  
  -- 项目管理
  timeline_days INTEGER DEFAULT 5,
  priority TEXT DEFAULT 'normal' CHECK (priority IN ('low', 'normal', 'high', 'urgent')),
  designer_id UUID,
  designer_name TEXT,
  designer_notes TEXT,
  
  -- 修订管理
  revision_count INTEGER DEFAULT 0,
  max_revisions INTEGER DEFAULT 3,
  
  -- 项目价格
  package_price DECIMAL(10,2),
  final_price DECIMAL(10,2),
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. 创建订单表
CREATE TABLE IF NOT EXISTS orders (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
  
  -- 订单金额
  amount DECIMAL(10,2) NOT NULL,
  currency TEXT DEFAULT 'USD',
  
  -- 订单状态
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'failed', 'refunded', 'cancelled')),
  
  -- Stripe集成
  stripe_payment_intent_id TEXT UNIQUE,
  stripe_session_id TEXT,
  stripe_customer_id TEXT,
  payment_method TEXT,
  payment_status TEXT,
  
  -- 订单详情
  order_notes TEXT,
  refund_reason TEXT,
  refund_amount DECIMAL(10,2),
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 4. 创建项目文件表
CREATE TABLE IF NOT EXISTS project_files (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
  
  -- 文件信息
  file_name TEXT NOT NULL,
  file_type TEXT NOT NULL,
  file_size INTEGER,
  storage_path TEXT NOT NULL,
  
  -- 文件分类
  upload_type TEXT CHECK (upload_type IN ('reference', 'logo_draft', 'logo_revision', 'logo_final', 'brand_guide', 'vector_file')),
  file_category TEXT CHECK (file_category IN ('input', 'work_in_progress', 'deliverable')),
  
  -- 文件状态
  is_final BOOLEAN DEFAULT FALSE,
  is_approved BOOLEAN DEFAULT FALSE,
  version_number INTEGER DEFAULT 1,
  
  -- 上传信息
  uploaded_by UUID REFERENCES auth.users(id),
  upload_notes TEXT,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 5. 创建项目通信表
CREATE TABLE IF NOT EXISTS project_communications (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
  sender_id UUID REFERENCES auth.users(id),
  
  -- 消息内容
  message_type TEXT CHECK (message_type IN ('message', 'status_update', 'file_upload', 'revision_request')),
  subject TEXT,
  message TEXT NOT NULL,
  
  -- 消息状态
  is_read BOOLEAN DEFAULT FALSE,
  is_internal BOOLEAN DEFAULT FALSE,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 6. 创建博客文章表
CREATE TABLE IF NOT EXISTS blog_posts (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  slug TEXT UNIQUE NOT NULL,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  excerpt TEXT,
  
  -- 分类和标签
  category TEXT,
  tags TEXT[],
  
  -- 媒体
  featured_image TEXT,
  
  -- 作者信息
  author_id UUID REFERENCES auth.users(id),
  author_name TEXT,
  author_avatar TEXT,
  
  -- SEO和元数据
  meta_title TEXT,
  meta_description TEXT,
  
  -- 发布状态
  status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'published', 'archived')),
  published_at TIMESTAMP WITH TIME ZONE,
  
  -- 统计
  views INTEGER DEFAULT 0,
  likes INTEGER DEFAULT 0,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 7. 启用行级安全 (RLS)
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE project_files ENABLE ROW LEVEL SECURITY;
ALTER TABLE project_communications ENABLE ROW LEVEL SECURITY;
ALTER TABLE blog_posts ENABLE ROW LEVEL SECURITY;

-- 8. 创建安全策略

-- 用户配置文件策略
CREATE POLICY "Users can view own profile" ON profiles
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update own profile" ON profiles
  FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile" ON profiles
  FOR INSERT WITH CHECK (auth.uid() = id);

-- 项目策略
CREATE POLICY "Users can view own projects" ON projects
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can create own projects" ON projects
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own projects" ON projects
  FOR UPDATE USING (auth.uid() = user_id);

-- 订单策略
CREATE POLICY "Users can view own orders" ON orders
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can create own orders" ON orders
  FOR INSERT WITH CHECK (auth.uid() = user_id);

-- 项目文件策略
CREATE POLICY "Users can view own project files" ON project_files
  FOR SELECT USING (
    auth.uid() IN (
      SELECT user_id FROM projects WHERE id = project_files.project_id
    )
  );

CREATE POLICY "Users can upload project files" ON project_files
  FOR INSERT WITH CHECK (
    auth.uid() IN (
      SELECT user_id FROM projects WHERE id = project_files.project_id
    )
  );

-- 项目通信策略
CREATE POLICY "Users can view own project communications" ON project_communications
  FOR SELECT USING (
    auth.uid() IN (
      SELECT user_id FROM projects WHERE id = project_communications.project_id
    )
  );

CREATE POLICY "Users can send project communications" ON project_communications
  FOR INSERT WITH CHECK (
    auth.uid() IN (
      SELECT user_id FROM projects WHERE id = project_communications.project_id
    ) OR auth.uid() = sender_id
  );

-- 博客文章策略 (公开阅读)
CREATE POLICY "Anyone can view published blog posts" ON blog_posts
  FOR SELECT USING (status = 'published');

-- 9. 创建存储桶
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types) 
VALUES (
  'project-files', 
  'project-files', 
  false,
  104857600, -- 100MB limit
  ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/svg+xml', 'application/pdf', 'application/zip', 'image/gif']
) ON CONFLICT (id) DO NOTHING;

-- 10. 存储策略
CREATE POLICY "Users can upload to own folder" ON storage.objects
  FOR INSERT WITH CHECK (
    bucket_id = 'project-files' AND
    auth.uid()::text = (storage.foldername(name))[1]
  );

CREATE POLICY "Users can view own files" ON storage.objects
  FOR SELECT USING (
    bucket_id = 'project-files' AND
    auth.uid()::text = (storage.foldername(name))[1]
  );

CREATE POLICY "Users can delete own files" ON storage.objects
  FOR DELETE USING (
    bucket_id = 'project-files' AND
    auth.uid()::text = (storage.foldername(name))[1]
  );

-- 11. 创建有用的函数和触发器

-- 自动更新updated_at字段的函数
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- 为需要的表添加updated_at触发器
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON profiles
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_projects_updated_at BEFORE UPDATE ON projects
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_orders_updated_at BEFORE UPDATE ON orders
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_blog_posts_updated_at BEFORE UPDATE ON blog_posts
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- 12. 插入示例博客数据
INSERT INTO blog_posts (
  slug, title, content, excerpt, category, tags, featured_image, 
  author_name, author_avatar, status, published_at
) VALUES (
  'logo-design-trends-2024',
  'Logo Design Trends That Will Define 2024',
  '<h2>Modern Logo Design Trends</h2><p>Discover the latest trends in professional logo design that are shaping brands worldwide...</p><h3>Minimalist Approach</h3><p>Clean, simple designs continue to dominate the logo design landscape...</p>',
  'Explore the cutting-edge logo design trends that are defining 2024, from minimalist approaches to bold color choices.',
  'design-tips',
  ARRAY['trends', 'logo design', '2024', 'branding'],
  'https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=800&h=600&fit=crop',
  'Sarah Chen',
  'https://images.unsplash.com/photo-1494790108755-2616b612b789?w=150&h=150&fit=crop',
  'published',
  NOW()
) ON CONFLICT (slug) DO NOTHING;

-- ========================================
-- 数据库设置完成
-- ========================================
```

### **2.3 执行SQL**

1. **粘贴完整SQL脚本**到编辑器
2. **点击 "Run" 按钮**执行
3. **等待执行完成**（应该看到 "Success" 消息）

---

## 🔄 **步骤3: 验证配置 (3分钟)**

### **3.1 重启开发服务器**

```bash
# 停止当前服务器 (Ctrl+C)
# 重新启动
npm run dev
```

### **3.2 检查配置状态**

**开发服务器启动时应该看到：**
```
✅ "使用环境变量配置Supabase客户端"
```

**如果看到以下内容说明配置未生效：**
```
❌ "使用默认配置Supabase客户端"
```

### **3.3 测试用户注册功能**

1. **访问登录页面**
   ```
   http://localhost:3000/login
   ```

2. **注册测试用户**
   ```
   姓名: Test WeDesign User
   邮箱: test@wedesign.test
   密码: testpass123
   ```

3. **检查注册结果**
   - 成功：看到成功消息或跳转
   - 失败：查看浏览器控制台错误信息

### **3.4 验证Supabase控制台数据**

**在您的wedesign-production项目中检查：**

1. **用户数据**
   - 路径：Authentication → Users
   - 应该看到：test@wedesign.test 用户

2. **数据库表**
   - 路径：Database → Tables
   - 应该看到：profiles, projects, orders, project_files, project_communications, blog_posts

3. **存储桶**
   - 路径：Storage → Buckets
   - 应该看到：project-files 桶

---

## ✅ **步骤4: 配置成功确认**

### **所有配置正确的标志：**

1. **环境变量加载成功** ✅
   ```
   控制台显示: "使用环境变量配置Supabase客户端"
   ```

2. **数据库连接正常** ✅
   - 用户注册功能正常
   - 无数据库连接错误

3. **Supabase控制台有数据** ✅
   - Authentication中显示测试用户
   - Database中显示所有表
   - Storage中显示项目文件桶

4. **无错误信息** ✅
   - 浏览器控制台无Supabase错误
   - 服务器终端无连接错误

---

## 🚀 **下一步：配置Stripe支付**

**Supabase配置完成后，我们需要：**

1. **获取Stripe API密钥**
   - 访问：https://dashboard.stripe.com
   - 获取测试环境密钥

2. **更新.env.local中的Stripe配置**
   ```bash
   NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_...
   STRIPE_SECRET_KEY=sk_test_...
   ```

3. **测试支付功能**

4. **准备域名绑定和部署**

---

## 📞 **需要帮助？请提供以下信息：**

### **如果遇到问题，请告诉我：**

1. **Service Role密钥获取情况**
   - 是否成功复制了密钥？
   - 密钥格式是否正确？

2. **SQL执行结果**
   - 是否看到 "Success" 消息？
   - 有任何错误信息吗？

3. **开发服务器状态**
   ```
   控制台显示什么信息？
   "使用环境变量配置" 还是 "使用默认配置"？
   ```

4. **用户注册测试结果**
   - 是否能成功注册？
   - 有什么错误信息？

5. **Supabase控制台检查**
   - 是否看到测试用户？
   - 数据库表是否都存在？

### **配置成功后请告诉我：**
> "✅ Supabase配置完成！Service role密钥已添加，数据库设置成功，用户注册测试通过，控制台显示'使用环境变量配置'"

**然后我们立即开始Stripe支付配置和最终部署！** 🎉

---

## 🎯 **重要提醒**

**安全注意事项：**
- ⚠️ **Service Role密钥拥有数据库完全访问权限，绝对保密**
- ⚠️ **不要将.env.local文件提交到Git仓库**
- ⚠️ **部署时使用环境变量而不是硬编码密钥**

**配置验证清单：**
- [ ] Service Role密钥已获取并添加到.env.local
- [ ] 数据库SQL脚本执行成功
- [ ] 开发服务器显示"使用环境变量配置"
- [ ] 用户注册功能正常工作
- [ ] Supabase控制台显示数据

**完成所有验证后，您的WeDesign网站将完全连接到您的个人Supabase账户！** ✨