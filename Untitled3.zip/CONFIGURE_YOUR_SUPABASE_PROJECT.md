# 🎉 配置您的WeDesign Supabase项目
## 已创建wedesign-production项目 - 现在获取密钥并完成配置

---

## ✅ **当前状态确认**

**您已完成：**
- ✅ **Supabase账户**: `Javen1984@gmail.com`
- ✅ **项目已创建**: `wedesign-production`
- 🎯 **下一步**: 获取API密钥并更新项目配置

---

## 🔑 **步骤1: 获取您的项目API密钥 (3分钟)**

### **1.1 访问项目设置**

1. **打开Supabase控制台**
   ```
   访问: https://supabase.com/dashboard
   确认登录: Javen1984@gmail.com
   ```

2. **选择wedesign-production项目**
   - 在项目列表中点击 `wedesign-production`
   - 确认进入项目控制台

3. **进入API设置**
   - 点击左侧菜单 **"Settings"**
   - 点击子菜单 **"API"**

### **1.2 复制必需的信息**

**请复制以下信息：**

```bash
# 在API设置页面找到以下信息：

1. Project URL: https://[您的项目ID].supabase.co
2. anon public: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9... (点击复制)
3. service_role: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9... (点击"Reveal"然后复制)
```

**⚠️ 重要提醒：**
- `service_role` 密钥非常敏感，请妥善保管
- 确保复制完整的密钥，不要遗漏任何字符

---

## ⚙️ **步骤2: 更新项目配置 (2分钟)**

### **2.1 更新.env.local文件**

**请将您刚获取的信息填入以下模板，然后更新您的`.env.local`文件：**

```bash
# ===== WeDesign生产环境配置 =====
# 基于您的个人Supabase项目 wedesign-production

# ===== Supabase 配置 (您的真实项目) =====
NEXT_PUBLIC_SUPABASE_URL=https://[您的项目ID].supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=[您复制的anon密钥]
SUPABASE_SERVICE_ROLE_KEY=[您复制的service_role密钥]

# ===== Stripe 配置 (如果您已有密钥) =====
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_您的发布密钥
STRIPE_SECRET_KEY=sk_test_您的私密密钥

# ===== 网站配置 =====
NEXT_PUBLIC_SITE_URL=https://www.wedesign.design
NEXT_PUBLIC_SITE_NAME="WeDesign - Worldwide Design Best Delivered"
NODE_ENV=production

# ===== 可选配置 =====
MAX_FILE_SIZE=10485760
JWT_SECRET=generate-a-secure-random-string-here
```

### **2.2 替换示例**

**假设您的项目ID是 `abcdefghijk12345678`，那么配置应该是：**

```bash
NEXT_PUBLIC_SUPABASE_URL=https://abcdefghijk12345678.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.您的完整anon密钥...
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.您的完整service_role密钥...
```

---

## 🗃️ **步骤3: 设置数据库结构 (5分钟)**

### **3.1 在Supabase中执行SQL**

1. **打开SQL编辑器**
   - 在您的wedesign-production项目中
   - 点击左侧菜单 **"SQL Editor"**
   - 点击 **"New query"**

2. **执行以下SQL代码**

```sql
-- ===== WeDesign数据库结构 =====
-- 为wedesign-production项目创建完整数据库结构

-- 1. 创建用户配置文件表
CREATE TABLE IF NOT EXISTS profiles (
  id UUID REFERENCES auth.users ON DELETE CASCADE PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  full_name TEXT,
  avatar_url TEXT,
  phone TEXT,
  company TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. 创建项目表
CREATE TABLE IF NOT EXISTS projects (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  package_type TEXT NOT NULL CHECK (package_type IN ('economy', 'business', 'private-jet')),
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'in_progress', 'review', 'completed', 'cancelled')),
  industry TEXT,
  color_preferences TEXT[],
  style_preferences TEXT[],
  additional_notes TEXT,
  timeline_days INTEGER DEFAULT 5,
  designer_id UUID,
  designer_name TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. 创建订单表
CREATE TABLE IF NOT EXISTS orders (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
  amount DECIMAL(10,2) NOT NULL,
  currency TEXT DEFAULT 'USD',
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'failed', 'refunded')),
  stripe_payment_intent_id TEXT UNIQUE,
  stripe_session_id TEXT,
  payment_method TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 4. 创建项目文件表
CREATE TABLE IF NOT EXISTS project_files (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
  file_name TEXT NOT NULL,
  file_type TEXT NOT NULL,
  file_size INTEGER,
  storage_path TEXT NOT NULL,
  upload_type TEXT CHECK (upload_type IN ('logo', 'revision', 'final', 'reference')),
  uploaded_by UUID REFERENCES auth.users(id),
  is_final BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 5. 创建博客文章表
CREATE TABLE IF NOT EXISTS blog_posts (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  slug TEXT UNIQUE NOT NULL,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  excerpt TEXT,
  category TEXT,
  tags TEXT[],
  featured_image TEXT,
  author_id UUID REFERENCES auth.users(id),
  author_name TEXT,
  author_avatar TEXT,
  status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'published', 'archived')),
  views INTEGER DEFAULT 0,
  likes INTEGER DEFAULT 0,
  published_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 6. 启用行级安全 (RLS)
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE project_files ENABLE ROW LEVEL SECURITY;
ALTER TABLE blog_posts ENABLE ROW LEVEL SECURITY;

-- 7. 创建安全策略
-- 用户配置文件策略
CREATE POLICY "Users can view own profile" ON profiles
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update own profile" ON profiles
  FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile" ON profiles
  FOR INSERT WITH CHECK (auth.uid() = id);

-- 项目策略
CREATE POLICY "Users can view own projects" ON projects
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can create own projects" ON projects
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own projects" ON projects
  FOR UPDATE USING (auth.uid() = user_id);

-- 订单策略
CREATE POLICY "Users can view own orders" ON orders
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can create own orders" ON orders
  FOR INSERT WITH CHECK (auth.uid() = user_id);

-- 项目文件策略
CREATE POLICY "Users can view own project files" ON project_files
  FOR SELECT USING (
    auth.uid() IN (
      SELECT user_id FROM projects WHERE id = project_files.project_id
    )
  );

CREATE POLICY "Users can upload project files" ON project_files
  FOR INSERT WITH CHECK (
    auth.uid() IN (
      SELECT user_id FROM projects WHERE id = project_files.project_id
    )
  );

-- 博客文章策略 (公开阅读，管理员编辑)
CREATE POLICY "Anyone can view published blog posts" ON blog_posts
  FOR SELECT USING (status = 'published');

-- 8. 创建存储桶
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types) 
VALUES (
  'project-files', 
  'project-files', 
  false,
  52428800, -- 50MB limit
  ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/svg+xml', 'application/pdf']
) ON CONFLICT (id) DO NOTHING;

-- 9. 存储策略
CREATE POLICY "Users can upload to own folder" ON storage.objects
  FOR INSERT WITH CHECK (
    bucket_id = 'project-files' AND
    auth.uid()::text = (storage.foldername(name))[1]
  );

CREATE POLICY "Users can view own files" ON storage.objects
  FOR SELECT USING (
    bucket_id = 'project-files' AND
    auth.uid()::text = (storage.foldername(name))[1]
  );

CREATE POLICY "Users can delete own files" ON storage.objects
  FOR DELETE USING (
    bucket_id = 'project-files' AND
    auth.uid()::text = (storage.foldername(name))[1]
  );
```

### **3.2 执行SQL**

1. **粘贴上述SQL代码**到编辑器中
2. **点击 "Run" 按钮**执行
3. **确认看到 "Success" 消息**

---

## 🔄 **步骤4: 测试新配置 (3分钟)**

### **4.1 重启开发服务器**

```bash
# 在您的项目目录中
# 停止当前服务器 (Ctrl+C 或 Cmd+C)

# 重新启动
npm run dev
```

### **4.2 检查控制台输出**

**启动时应该看到：**
```
✅ "使用环境变量配置Supabase客户端" - 表示成功使用您的项目
❌ "使用默认配置Supabase客户端" - 表示仍在使用测试项目
```

### **4.3 测试用户注册**

1. **访问**: http://localhost:3000/login
2. **点击注册**，创建测试账户
3. **检查Supabase控制台**:
   - 点击 **"Authentication"** → **"Users"**
   - 应该看到新注册的用户

### **4.4 验证数据库**

**在Supabase控制台中：**
- 点击 **"Database"** → **"Tables"**
- 应该看到创建的所有表：
  - `profiles`
  - `projects`  
  - `orders`
  - `project_files`
  - `blog_posts`

---

## ✅ **步骤5: 确认配置成功**

### **成功指标：**

1. **环境变量生效**
   - 开发服务器控制台显示使用环境变量配置
   - 无相关错误信息

2. **数据库连接正常**
   - 可以成功注册用户
   - Supabase控制台中看到用户数据

3. **表结构正确**
   - 所有表都已创建
   - RLS策略启用
   - 存储桶已设置

4. **项目功能**
   - 用户注册/登录正常
   - 项目创建功能正常
   - 文件上传准备就绪

---

## 🚀 **下一步：Stripe支付配置**

**完成Supabase配置后，如果您还没有Stripe密钥：**

1. **访问**: https://dashboard.stripe.com
2. **注册或登录Stripe账户**
3. **进入**: Developers → API keys
4. **复制测试密钥**:
   - Publishable key (pk_test_...)
   - Secret key (sk_test_...)
5. **更新.env.local文件**中的Stripe配置

---

## 📞 **需要帮助？**

### **请告诉我：**

1. **您的新项目URL**
   - 格式：https://[项目ID].supabase.co

2. **配置过程中遇到的任何问题**
   - 错误消息
   - 具体步骤中的困难

3. **当前状态**
   - SQL是否成功执行
   - 用户注册是否正常
   - 开发服务器是否显示正确信息

### **完成后告诉我：**

> "✅ Supabase配置完成，项目URL: https://[您的项目ID].supabase.co，用户注册测试成功"

**然后我们继续配置Stripe支付和域名绑定！** 🎉

---

## 🎯 **快速配置检查清单**

**完成每项后打勾：**

- [ ] 获取项目URL和API密钥
- [ ] 更新.env.local文件
- [ ] 执行数据库SQL设置
- [ ] 重启开发服务器
- [ ] 测试用户注册功能
- [ ] 确认Supabase控制台中看到数据
- [ ] 配置Stripe密钥（如果需要）

**所有项目完成后，您的WeDesign项目就完全连接到您的个人Supabase账户了！** ✨