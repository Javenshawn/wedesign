# 🏗️ 为WeDesign创建Supabase项目 - 完整设置指南
## 从零开始为您的Logo设计服务网站创建后端数据库

---

## 🎯 **为什么需要创建新项目**

您的WeDesign网站需要Supabase来提供：
- ✅ **用户认证** - 客户注册、登录、密码管理
- ✅ **项目管理** - Logo设计项目的存储和跟踪
- ✅ **文件存储** - 设计文件、Logo、图片上传
- ✅ **支付记录** - Stripe支付历史和订单管理
- ✅ **管理员功能** - 后台管理和数据分析
- ✅ **博客系统** - 设计相关内容管理

---

## 📋 **预计用时：15-20分钟**

### **您将完成：**
1. 创建新的Supabase项目
2. 设置基础数据库表
3. 配置用户认证
4. 创建文件存储桶
5. 获取API密钥
6. 测试项目连接

---

## 🚀 **第1步：创建新的Supabase项目 (5分钟)**

### **1.1 访问Supabase Dashboard**

1. **打开浏览器**
   - 访问: https://supabase.com/dashboard
   - 确认您已登录正确的账户

2. **创建新项目**
   - 点击右上角的 "New Project" 按钮
   - 或点击页面中央的 "Start your project" 按钮

### **1.2 配置项目基本信息**

**在创建项目页面填入：**

```
Project Name: WeDesign Logo Service
Description: Professional logo design service with worldwide delivery
Organization: [选择您的组织，通常是您的个人账户]
```

**数据库设置：**
```
Database Password: 创建一个强密码 (至少8个字符，包含字母、数字、特殊字符)
Region: 选择离您客户最近的区域 (推荐: East US, Europe West, 或 Southeast Asia)
Pricing Plan: Free (足够开始使用)
```

### **1.3 创建项目**

1. **点击 "Create new project"**
   - 系统将开始创建您的项目
   - 这个过程通常需要2-3分钟

2. **等待完成**
   - 您会看到项目创建进度
   - 完成后会自动跳转到项目Dashboard

---

## 📊 **第2步：设置数据库表结构 (8-10分钟)**

### **2.1 进入SQL Editor**

1. **在项目Dashboard中**
   - 点击左侧菜单中的 "SQL Editor"
   - 您会看到SQL查询界面

### **2.2 创建WeDesign核心数据表**

**复制以下SQL并执行 (点击Run按钮)：**

```sql
-- WeDesign核心数据表创建脚本
-- 这将创建支持整个WeDesign网站所需的数据库结构

-- 1. 启用RLS (行级安全)
ALTER DEFAULT PRIVILEGES GRANT ALL ON TABLES TO service_role;
ALTER DEFAULT PRIVILEGES GRANT ALL ON FUNCTIONS TO service_role;
ALTER DEFAULT PRIVILEGES GRANT ALL ON SEQUENCES TO service_role;

-- 2. 用户配置表 (扩展auth.users)
CREATE TABLE IF NOT EXISTS public.user_profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT UNIQUE NOT NULL,
    full_name TEXT,
    company_name TEXT,
    phone TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- 3. Logo设计项目表
CREATE TABLE IF NOT EXISTS public.design_projects (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    project_name TEXT NOT NULL,
    company_name TEXT NOT NULL,
    industry TEXT,
    style_preferences TEXT,
    color_preferences TEXT,
    description TEXT,
    status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'in_progress', 'review', 'completed', 'cancelled')),
    package_type TEXT NOT NULL CHECK (package_type IN ('basic', 'standard', 'premium')),
    price_paid DECIMAL(10,2),
    stripe_payment_intent_id TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    due_date TIMESTAMP WITH TIME ZONE,
    completed_at TIMESTAMP WITH TIME ZONE
);

-- 4. 设计文件表
CREATE TABLE IF NOT EXISTS public.design_files (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id UUID REFERENCES public.design_projects(id) ON DELETE CASCADE NOT NULL,
    file_name TEXT NOT NULL,
    file_path TEXT NOT NULL,
    file_type TEXT NOT NULL,
    file_size INTEGER,
    is_final BOOLEAN DEFAULT FALSE,
    version INTEGER DEFAULT 1,
    uploaded_by UUID REFERENCES auth.users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- 5. 支付记录表
CREATE TABLE IF NOT EXISTS public.payments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    project_id UUID REFERENCES public.design_projects(id) ON DELETE CASCADE,
    stripe_payment_intent_id TEXT UNIQUE NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    currency TEXT DEFAULT 'usd',
    status TEXT NOT NULL CHECK (status IN ('pending', 'succeeded', 'failed', 'cancelled')),
    payment_method TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- 6. 博客文章表
CREATE TABLE IF NOT EXISTS public.blog_posts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    slug TEXT UNIQUE NOT NULL,
    content TEXT NOT NULL,
    excerpt TEXT,
    author_id UUID REFERENCES auth.users(id),
    published BOOLEAN DEFAULT FALSE,
    featured_image_url TEXT,
    tags TEXT[],
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    published_at TIMESTAMP WITH TIME ZONE
);

-- 7. 项目消息/沟通记录表
CREATE TABLE IF NOT EXISTS public.project_messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id UUID REFERENCES public.design_projects(id) ON DELETE CASCADE NOT NULL,
    sender_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    message TEXT NOT NULL,
    is_admin BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- 8. 系统配置表 (用于网站设置)
CREATE TABLE IF NOT EXISTS public.site_settings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    key TEXT UNIQUE NOT NULL,
    value TEXT,
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- 9. KV存储表 (用于应用程序缓存和临时数据)
CREATE TABLE IF NOT EXISTS public.kv_store_d0d1e627 (
    key TEXT PRIMARY KEY,
    value JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    expires_at TIMESTAMP WITH TIME ZONE
);

-- 创建索引以提高查询性能
CREATE INDEX IF NOT EXISTS idx_design_projects_user_id ON public.design_projects(user_id);
CREATE INDEX IF NOT EXISTS idx_design_projects_status ON public.design_projects(status);
CREATE INDEX IF NOT EXISTS idx_design_files_project_id ON public.design_files(project_id);
CREATE INDEX IF NOT EXISTS idx_payments_user_id ON public.payments(user_id);
CREATE INDEX IF NOT EXISTS idx_payments_stripe_id ON public.payments(stripe_payment_intent_id);
CREATE INDEX IF NOT EXISTS idx_blog_posts_published ON public.blog_posts(published);
CREATE INDEX IF NOT EXISTS idx_blog_posts_slug ON public.blog_posts(slug);
CREATE INDEX IF NOT EXISTS idx_project_messages_project_id ON public.project_messages(project_id);
CREATE INDEX IF NOT EXISTS idx_kv_store_expires_at ON public.kv_store_d0d1e627(expires_at);

-- 插入默认网站设置
INSERT INTO public.site_settings (key, value, description) VALUES
('site_name', 'WeDesign', 'Website name'),
('site_description', 'Professional logo design services with worldwide delivery', 'Website description'),
('contact_email', 'hello@wedesign.design', 'Main contact email'),
('packages_basic_price', '299', 'Basic package price in USD'),
('packages_standard_price', '599', 'Standard package price in USD'),
('packages_premium_price', '999', 'Premium package price in USD')
ON CONFLICT (key) DO NOTHING;
```

### **2.3 执行SQL脚本**

1. **复制整个SQL脚本**
2. **粘贴到SQL Editor中**
3. **点击 "Run" 按钮**
4. **确认成功执行** - 您应该看到成功消息

---

## 🔐 **第3步：配置用户认证 (3分钟)**

### **3.1 启用认证提供商**

1. **进入Authentication设置**
   - 点击左侧菜单中的 "Authentication"
   - 点击 "Settings" 选项卡

2. **配置Site URL**
   ```
   Site URL: https://www.wedesign.design
   ```

3. **添加重定向URLs**
   ```
   Redirect URLs:
   https://www.wedesign.design/login
   https://www.wedesign.design/user-portal
   https://www.wedesign.design/admin-dashboard
   http://localhost:3000/login (用于开发测试)
   ```

### **3.2 启用Email认证**

1. **在Auth Providers中**
   - 确保 "Email" 是启用状态
   - 这允许用户使用邮箱注册和登录

2. **配置邮件模板 (可选)**
   - 点击 "Email Templates"
   - 可以自定义注册确认邮件等

---

## 📁 **第4步：设置文件存储 (3分钟)**

### **4.1 创建存储桶**

1. **进入Storage**
   - 点击左侧菜单中的 "Storage"
   - 点击 "Create a new bucket"

2. **创建设计文件存储桶**
   ```
   Bucket Name: wedesign-files
   Public: No (私有存储，需要认证访问)
   ```

3. **创建公开资源存储桶**
   ```
   Bucket Name: wedesign-public
   Public: Yes (用于Logo展示、博客图片等)
   ```

### **4.2 配置存储政策**

**在SQL Editor中执行以下存储策略：**

```sql
-- 设计文件存储策略 (用户只能访问自己的文件)
CREATE POLICY "Users can upload their own design files" ON storage.objects
FOR INSERT WITH CHECK (bucket_id = 'wedesign-files' AND auth.uid() = (storage.foldername(name))[1]::uuid);

CREATE POLICY "Users can view their own design files" ON storage.objects
FOR SELECT USING (bucket_id = 'wedesign-files' AND auth.uid() = (storage.foldername(name))[1]::uuid);

-- 公开资源策略 (任何人都可以查看)
CREATE POLICY "Anyone can view public files" ON storage.objects
FOR SELECT USING (bucket_id = 'wedesign-public');

-- 管理员可以上传公开资源
CREATE POLICY "Admins can upload public files" ON storage.objects
FOR INSERT WITH CHECK (bucket_id = 'wedesign-public' AND auth.email() LIKE '%admin%');
```

---

## 🔑 **第5步：获取API密钥 (2分钟)**

### **5.1 进入API设置**

1. **点击左侧菜单中的 "Settings"**
2. **点击 "API" 选项卡**

### **5.2 复制必要的密钥**

**您需要复制以下信息到记事本：**

```
Project URL: https://你的项目ID.supabase.co
anon public key: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
service_role key: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

**保存格式：**
```
=== WeDesign Supabase项目信息 ===

SUPABASE_URL=https://你的项目ID.supabase.co
SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

---

## 🧪 **第6步：测试项目连接 (2分钟)**

### **6.1 测试数据库连接**

**在SQL Editor中执行测试查询：**

```sql
-- 测试基础表是否创建成功
SELECT table_name FROM information_schema.tables 
WHERE table_schema = 'public' 
AND table_name IN ('user_profiles', 'design_projects', 'payments');

-- 检查默认设置是否插入成功
SELECT * FROM public.site_settings LIMIT 5;
```

### **6.2 验证存储桶**

1. **进入Storage**
2. **确认看到两个存储桶：**
   - `wedesign-files` (私有)
   - `wedesign-public` (公开)

---

## ✅ **第7步：完成确认**

### **确认您已完成以下所有项目：**

- [ ] ✅ 创建了名为 "WeDesign Logo Service" 的Supabase项目
- [ ] ✅ 成功执行了数据库表创建脚本
- [ ] ✅ 配置了用户认证系统
- [ ] ✅ 创建了两个存储桶 (wedesign-files, wedesign-public)
- [ ] ✅ 获取了所有必要的API密钥
- [ ] ✅ 测试了数据库连接

### **您的记事本应该包含：**

```
=== WeDesign Supabase项目信息 ===

项目名称: WeDesign Logo Service
项目URL: https://你的项目ID.supabase.co

API密钥:
SUPABASE_URL=https://你的项目ID.supabase.co
SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...

数据库密码: [您设置的密码]
区域: [您选择的区域]
```

---

## 🎯 **接下来的步骤**

### **恭喜！您已成功创建WeDesign的Supabase项目**

**现在您可以继续：**

1. **获取Stripe API密钥** - 下一步是配置支付系统
2. **继续域名绑定流程** - 完成www.wedesign.design的配置
3. **测试完整功能** - 确保所有系统正常工作

### **告诉我：**
> "我已经成功创建了WeDesign的Supabase项目并获取了API密钥，准备继续获取Stripe密钥"

**我将继续指导您完成Stripe配置和域名绑定的其余步骤！**

---

## 🛠️ **故障排除**

### **常见问题解决：**

**问题1: SQL脚本执行失败**
- 确保您有正确的权限
- 尝试分段执行SQL脚本
- 检查错误信息中的具体问题

**问题2: 存储桶创建失败**
- 确认桶名称是唯一的
- 检查您的项目限制

**问题3: API密钥看不到**
- 确认项目创建完全完成
- 刷新页面重试
- 确保您有项目管理员权限

**问题4: 认证配置问题**
- 确认Site URL格式正确
- 检查重定向URL是否有效

### **需要帮助？**
如遇到问题，请提供：
1. 具体的错误信息
2. 您执行到哪一步
3. 项目创建时的设置截图

---

**🚀 现在开始创建您的WeDesign Supabase项目！这是构建完整Logo设计服务网站的关键基础设施！** ✨