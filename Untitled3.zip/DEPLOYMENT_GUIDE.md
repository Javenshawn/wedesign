# WeDesign 项目部署指南

## 🚀 快速部署

WeDesign 项目现在支持多种部署方式，推荐使用**完整部署**方式。

### 方法 1: 完整自动部署 (推荐)

```bash
npm run deploy:complete
```

这个命令会自动执行：
- ✅ 修复所有 figma:asset 引用
- ✅ 重组项目结构到标准 Vite 格式
- ✅ 清理重复和过时文件
- ✅ 验证项目结构完整性
- ✅ 安装项目依赖
- ✅ 测试构建流程
- ✅ 检查环境变量配置
- ✅ 部署到 Vercel

### 方法 2: 分步部署

如果你想更细致的控制部署过程：

```bash
# 1. 修复 Figma Asset 引用
npm run fix:assets

# 2. 重新打包项目结构
npm run repackage

# 3. 安装依赖并构建
npm install
npm run build

# 4. 部署到 Vercel
vercel --prod
```

### 方法 3: 传统部署

```bash
npm install
npm run build
vercel --prod
```

## 🔧 主要修复内容

### Figma Asset 引用修复

项目中所有的 `figma:asset` 引用已被替换为高质量的 Unsplash 占位图：

- **Logo 图片**: 品牌设计相关
- **案例展示**: 设计作品预览
- **背景图片**: 高质量渐变背景
- **图标图片**: 设计和品牌图标
- **博客图片**: 内容营销相关

### 项目结构标准化

```
wedesign/
├── index.html          # HTML 入口
├── src/
│   ├── main.tsx        # React 入口点
│   ├── App.tsx         # 主应用组件
│   ├── styles/         # 样式文件
│   ├── components/     # React 组件
│   ├── utils/          # 工具函数
│   ├── types/          # TypeScript 类型
│   └── supabase/       # 数据库函数
├── package.json        # 项目配置
├── vite.config.ts      # Vite 配置
└── vercel.json         # 部署配置
```

## 🌐 部署后配置

### 1. 环境变量配置

在 Vercel 控制台中配置以下环境变量：

**Supabase 配置:**
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`
- `SUPABASE_SERVICE_ROLE_KEY`

**Stripe 配置:**
- `VITE_STRIPE_PUBLISHABLE_KEY`
- `STRIPE_SECRET_KEY`

**应用配置:**
- `VITE_APP_URL`
- `VITE_GA_MEASUREMENT_ID` (可选)

### 2. 域名绑定 (可选)

1. 在 Vercel 控制台选择项目
2. 进入 Settings → Domains
3. 添加自定义域名
4. 配置 DNS 解析

### 3. 网站访问地址

- **主网站**: `https://your-domain.vercel.app/`
- **管理员后台**: `https://your-domain.vercel.app/admin-login`
- **用户登录**: `https://your-domain.vercel.app/login`

## 🔍 故障排除

### 构建失败

如果构建失败，请检查：

```bash
# 查看详细错误信息
npm run build

# 本地开发模式查看错误
npm run dev
```

常见问题：
- TypeScript 类型错误
- 导入路径错误
- 图片 URL 无效
- 环境变量缺失

### 部署失败

如果部署失败，请检查：

```bash
# 确保已登录 Vercel
vercel login

# 手动部署
vercel --prod

# 检查项目设置
vercel inspect
```

### 图片显示问题

如果图片不显示：
1. 检查占位图 URL 是否有效
2. 确认网络可以访问 Unsplash
3. 考虑替换为本地图片资源

## 📊 项目特性

### 已保留的功能

- ✅ 完整的 WeDesign 设计系统（毛玻璃+金色渐变）
- ✅ 响应式设计（Mobile-first）
- ✅ 管理员后台系统
- ✅ SEO 优化系统（1000+ 关键词数据库）
- ✅ 用户认证和权限管理
- ✅ Stripe 支付集成
- ✅ Supabase 数据库集成
- ✅ Google Analytics 追踪
- ✅ 全英文内容
- ✅ 苹果风格毛玻璃效果

### 技术栈

- **前端**: React 18 + TypeScript + Vite
- **样式**: Tailwind CSS v4 + 自定义设计系统
- **UI**: Radix UI + ShadCN 组件
- **后端**: Supabase (数据库 + 认证 + 存储)
- **支付**: Stripe
- **部署**: Vercel
- **分析**: Google Analytics

## 🎯 下一步建议

1. **测试所有功能** - 确保页面正常加载
2. **配置 API 密钥** - 激活后端功能
3. **自定义图片** - 替换占位图为实际内容
4. **SEO 优化** - 更新元数据和关键词
5. **性能优化** - 监控加载速度
6. **用户测试** - 验证用户体验

---

WeDesign 现在已经完全准备好部署！使用 `npm run deploy:complete` 开始部署吧！ 🚀