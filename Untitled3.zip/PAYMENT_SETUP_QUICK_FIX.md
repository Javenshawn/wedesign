# Payment System Quick Fix Guide

If you're seeing "Failed to fetch" errors when trying to process payments, here's how to quickly fix it:

## 🚨 Quick Fix for Development Mode

### Option 1: Enable Development Mode (Immediate Solution)
The app automatically detects development mode and will simulate payments if the backend isn't configured.

**What happens in dev mode:**
- ✅ Payment forms work normally
- ✅ Simulated successful payments
- ✅ Complete user flow testing
- ⚠️ No real payments processed

### Option 2: Configure Environment Variables (Production Ready)

#### Step 1: Create Environment File
Create a `.env.local` file in your project root:

```bash
# Vite Environment Variables (for current setup)
VITE_STRIPE_PUBLISHABLE_KEY=pk_test_51...your_stripe_key
VITE_SUPABASE_URL=https://znmqppppruhlzhqvwtyp.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...your_key

# For backward compatibility
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_51...your_stripe_key
NEXT_PUBLIC_SUPABASE_URL=https://znmqppppruhlzhqvwtyp.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...your_key
```

#### Step 2: Get Stripe Test Keys
1. Go to [Stripe Dashboard](https://dashboard.stripe.com/test/apikeys)
2. Copy your **Publishable key** (starts with `pk_test_`)
3. Add it to your `.env.local` file

#### Step 3: Configure Supabase (Optional for Testing)
The current app uses hardcoded Supabase credentials that work for basic testing.

## 🔍 Error Diagnosis

### Common Error Messages and Solutions:

**"Failed to fetch"**
- ✅ **Solution**: App will use development mode simulation
- 🔧 **Fix**: Add `VITE_STRIPE_PUBLISHABLE_KEY` to environment

**"Stripe not configured"**
- ✅ **Solution**: Get Stripe test key from dashboard
- 🔧 **Fix**: Add publishable key to `.env.local`

**"Backend not available"**
- ✅ **Solution**: App automatically falls back to simulation
- 🔧 **Fix**: Deploy Supabase Edge Functions (advanced)

## 🧪 Test Payment Flow

With development mode active, you can test the complete flow:

1. **Select Package**: Economy ($199), Business ($399), or Private Jet ($799)
2. **Fill Project Info**: Company details and design preferences
3. **Create Account**: Uses company name as username, password: 888888
4. **Simulate Payment**: Uses test payment with successful result
5. **Success Page**: Shows account details and next steps

## 🎯 Next Steps

### For Development/Testing:
- The app works fully in simulation mode
- All features can be tested
- No real payments are processed

### For Production:
1. Get real Stripe keys from [Stripe Dashboard](https://dashboard.stripe.com)
2. Deploy Supabase Edge Functions with `STRIPE_SECRET_KEY`
3. Configure webhook endpoints for payment confirmations

## 🛠 Environment Variable Priority

The app checks for environment variables in this order:
1. `VITE_STRIPE_PUBLISHABLE_KEY` (current setup)
2. `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY` (fallback)
3. Development mode simulation (if none found)

## 📋 Current Status Check

Run this in your browser console to check configuration:
```javascript
console.log('Stripe Key:', import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY ? 'Configured' : 'Missing');
console.log('Development Mode:', import.meta.env.DEV ? 'Active' : 'Production');
```

## 🎉 Success Indicators

When working correctly, you'll see:
- ✅ Payment form loads without errors
- ✅ Test card numbers are shown
- ✅ "Development mode active" message appears
- ✅ Payments complete successfully (simulated)

The system is designed to work out-of-the-box in development mode, so you can test the complete user experience immediately!