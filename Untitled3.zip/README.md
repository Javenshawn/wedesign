# WeDesign - Premium Logo Design Service

A sophisticated web application for high-end logo design services, built with React, TypeScript, Tailwind CSS, and Supabase.

## ✨ Features

- **Premium Logo Design Service** - Three-tier service packages (Economy, Business, Private Jet)
- **User Authentication** - Secure sign-up/sign-in with Supabase Auth
- **Project Management** - Complete project lifecycle tracking
- **Stripe Payments** - Integrated payment processing
- **Admin Dashboard** - Comprehensive admin management interface
- **Responsive Design** - Mobile-first approach optimized for all devices
- **Glass Morphism UI** - Modern luxury design system with glass effects
- **Portfolio Gallery** - Dynamic showcase of design cases

## 🎨 Design System

### Typography
- **Headings**: Playfair Display (elegant serif for luxury branding)
- **Body Text**: Inter (clean, highly legible sans-serif)
- **Responsive scaling** from mobile to desktop
- **Luxury color palette** with rich gold gradients

### Colors
- **Primary**: `#B6652E` (Terra/Gold)
- **Secondary**: `#FFB84D` (Bright Gold)
- **Background**: `#FAFAF8` (Light Ivory)
- **Text**: `#4a3f36` (Deep Brown)
- **Glass effects** with backdrop blur

## 🛠️ Tech Stack

- **Frontend**: React 18, TypeScript, Vite
- **Styling**: Tailwind CSS v4, Custom CSS variables
- **Backend**: Supabase (Database, Auth, Storage)
- **Payments**: Stripe
- **Animations**: Motion (Framer Motion)
- **Icons**: Lucide React
- **Charts**: Recharts
- **Deployment**: Vercel-ready

## 🚀 Quick Start

### Prerequisites
- Node.js 18+
- npm or yarn
- Supabase account
- Stripe account

### Installation

1. **Clone the repository**
   ```bash
   git clone <your-repo-url>
   cd wedesign
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Environment Setup**
   
   Copy `.env.example` to `.env.local` and configure:
   ```env
   VITE_SUPABASE_URL=your_supabase_url
   VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
   VITE_STRIPE_PUBLISHABLE_KEY=your_stripe_publishable_key
   SUPABASE_SERVICE_ROLE_KEY=your_supabase_service_role_key
   STRIPE_SECRET_KEY=your_stripe_secret_key
   ```

4. **Start development server**
   ```bash
   npm run dev
   ```

## 📁 Project Structure

```
wedesign/
├── components/           # React components
│   ├── layout/          # Header, Footer
│   ├── pages/           # Page components
│   ├── sections/        # Section components
│   ├── modals/          # Modal components
│   ├── design-system/   # Custom design components
│   └── ui/              # Reusable UI components (shadcn/ui)
├── styles/              # Global CSS and Tailwind config
├── utils/               # Utility functions and services
├── supabase/            # Supabase Edge Functions
├── guidelines/          # Development guidelines
└── public/              # Static assets
```

## 🎯 Key Components

### Pages
- **HomePage** - Landing page with hero, pricing, and features
- **LogosDesignPage** - Service packages and project initiation
- **DesignHallPage** - Portfolio gallery
- **UserPortalPage** - Client dashboard
- **AdminDashboard** - Admin management interface

### Services
- **Supabase Integration** - Database and authentication
- **Stripe Integration** - Payment processing
- **SEO Utils** - Search engine optimization
- **Analytics** - User behavior tracking

## 🔧 Development Guidelines

### Component Naming
- **Pages**: `Page_[Name]` (e.g., `Page_Home`)
- **Sections**: `Section_[Name]` (e.g., `Section_Hero`)
- **Layout**: `Container_[Type]` (e.g., `Container_Desktop`)

### Responsive Design
- **Mobile-first** approach (min-width breakpoints)
- **Touch-friendly** interactions (44px minimum touch targets)
- **Glass morphism** effects with backdrop blur
- **Progressive enhancement** for larger screens

### Code Quality
- **TypeScript** for type safety
- **Component composition** over inheritance
- **Custom hooks** for reusable logic
- **Tailwind CSS** for styling consistency

## 🚀 Deployment

### Environment Variables
Set these in your deployment platform:
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`
- `VITE_STRIPE_PUBLISHABLE_KEY`
- `SUPABASE_SERVICE_ROLE_KEY`
- `STRIPE_SECRET_KEY`

### Vercel Deployment (Recommended)
1. Connect your GitHub repository to Vercel
2. Configure environment variables
3. Deploy with automatic builds

See `DEPLOY_TO_GITHUB_VERCEL.md` for detailed deployment instructions.

## 🎨 Design Principles

- **Luxury Branding** - Premium feel with gold accents
- **Glass Morphism** - Modern UI with backdrop blur effects
- **Mobile-First** - Optimized for all screen sizes
- **Accessibility** - WCAG compliant design patterns
- **Performance** - Optimized loading and interactions

## 📱 Features Overview

### Client Experience
- **Service Selection** - Choose from three premium packages
- **Project Briefing** - Detailed project requirements form
- **Progress Tracking** - Real-time project status updates
- **File Downloads** - Access completed designs
- **Revision Requests** - Request changes within package limits

### Admin Experience
- **Project Management** - Overview of all client projects
- **Status Updates** - Update project progress and milestones
- **File Management** - Upload and organize design files
- **Client Communication** - Notes and status updates

## 🔒 Security

- **Environment Variables** - Secure API key management
- **HTTPS Only** - Secure data transmission
- **Input Validation** - Protected against common vulnerabilities
- **Authentication** - Supabase Auth integration
- **CORS Configuration** - Proper cross-origin resource sharing

## 📄 License

This project is proprietary software. All rights reserved.

## 🤝 Support

For technical support or questions about setup, please refer to the deployment guide or contact the development team.

---

**WeDesign** - Crafting premium brand identities through exceptional logo design.