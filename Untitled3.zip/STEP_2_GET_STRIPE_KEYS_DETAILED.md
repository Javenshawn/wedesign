# 💳 第2步：获取Stripe API密钥 - 详细操作指导
## 配置WeDesign网站的支付系统

---

## 📋 **预计用时：7-10分钟**

### **您将获取的Stripe密钥：**
- ✅ **Publishable Key** - 前端支付表单使用 (安全公开)
- ✅ **Secret Key** - 后端支付处理使用 (绝对保密)

---

## 💳 **步骤A：访问和登录Stripe (1-2分钟)**

### **A1. 访问Stripe Dashboard**

1. **打开新浏览器标签页**
   - 在地址栏输入: https://dashboard.stripe.com
   - 按 Enter 键访问

2. **登录您的Stripe账户**
   - 如果未登录，点击 "Sign in" 按钮
   - 输入您的Stripe账户邮箱和密码
   - 完成登录验证 (可能需要2FA验证)

### **A2. 确认账户状态**

1. **检查账户设置**
   - 确认您已完成基本的账户设置
   - 如果是新账户，可能需要提供一些基本信息

2. **准备记事本**
   - 打开您之前保存Supabase密钥的记事本
   - 准备添加Stripe密钥信息

---

## 🔧 **步骤B：进入API密钥设置 (1分钟)**

### **B1. 导航到开发者设置**

1. **点击左侧菜单中的 "Developers"**
   - 在Stripe Dashboard左侧导航栏找到 "Developers" 选项
   - 点击展开开发者菜单

2. **点击 "API keys"**
   - 在Developers子菜单中点击 "API keys"
   - 这会打开API密钥管理页面

### **B2. 了解页面布局**

**您将看到：**
- **环境切换器** (右上角) - Test mode / Live mode
- **Publishable key** 部分 - 用于前端
- **Secret key** 部分 - 用于后端
- **可能的 Webhook secrets** - 用于高级集成

---

## 🌟 **步骤C：选择合适的环境 (1分钟)**

### **C1. 理解测试vs生产环境**

**Test Mode (测试模式):**
- ✅ **推荐用于开始** - 安全测试所有功能
- ✅ **无真实收费** - 可以测试支付流程
- ✅ **完整功能** - 与生产环境功能相同
- 🔑 **密钥格式**: `pk_test_...` 和 `sk_test_...`

**Live Mode (生产模式):**
- ⚠️ **用于真实业务** - 处理真实支付
- 💰 **真实收费** - 客户会被实际收费
- 📋 **需要完整验证** - 可能需要更多账户信息
- 🔑 **密钥格式**: `pk_live_...` 和 `sk_live_...`

### **C2. 选择环境**

**对于初始设置，建议选择 "Test mode":**

1. **点击右上角的环境切换器**
2. **确保选择了 "Test mode"**
3. **页面会显示测试环境的密钥**

---

## 🔑 **步骤D：获取Publishable Key (2分钟)**

### **D1. 找到Publishable Key**

1. **在API keys页面中找到 "Publishable key" 部分**
   - 这通常在页面上方
   - 标题显示为 "Publishable key"

2. **查看密钥格式**
   - Test mode: 以 `pk_test_` 开头
   - Live mode: 以 `pk_live_` 开头
   - 密钥很长，包含随机字符

### **D2. 复制Publishable Key**

1. **显示完整密钥**
   - 密钥可能被部分隐藏
   - 点击 "Reveal" 或眼睛图标显示完整密钥

2. **复制密钥**
   - 点击密钥右侧的复制图标
   - 或者手动选择整个密钥文本并复制

3. **保存到记事本**
   ```
   === WeDesign API密钥 ===
   
   [之前的Supabase密钥...]
   
   STRIPE_PUBLISHABLE_KEY=pk_test_你复制的完整发布密钥
   ```

---

## 🔐 **步骤E：获取Secret Key (2分钟)**

### **E1. 找到Secret Key**

1. **在同一页面中向下滚动找到 "Secret key" 部分**
   - 这通常在Publishable key下方
   - 标题显示为 "Secret key" 或 "Restricted keys"

2. **查看密钥格式**
   - Test mode: 以 `sk_test_` 开头
   - Live mode: 以 `sk_live_` 开头
   - 这个密钥通常是隐藏的

### **E2. 复制Secret Key**

1. **显示Secret Key**
   - 点击 "Reveal live key" 或类似按钮
   - 可能需要再次输入密码确认

2. **复制完整密钥**
   - 选择完整的密钥文本
   - 点击复制图标或使用 Ctrl+C (Cmd+C)

3. **保存到记事本**
   ```
   === WeDesign API密钥 ===
   
   [Supabase密钥...]
   
   STRIPE_PUBLISHABLE_KEY=pk_test_你的发布密钥
   STRIPE_SECRET_KEY=sk_test_你复制的完整私密密钥
   ```

---

## ✅ **步骤F：验证密钥格式 (1分钟)**

### **F1. 检查格式正确性**

**您的Stripe密钥应该看起来像这样：**

**测试环境密钥：**
```
STRIPE_PUBLISHABLE_KEY=pk_test_51xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
STRIPE_SECRET_KEY=sk_test_51xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

**生产环境密钥：**
```
STRIPE_PUBLISHABLE_KEY=pk_live_51xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
STRIPE_SECRET_KEY=sk_live_51xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

### **F2. 格式验证清单**

- [ ] **Publishable key** 以正确前缀开头 (`pk_test_` 或 `pk_live_`)
- [ ] **Secret key** 以正确前缀开头 (`sk_test_` 或 `sk_live_`)
- [ ] **两个密钥都很长** (通常70+ 字符)
- [ ] **没有多余的空格** 或换行符
- [ ] **密钥完整** 没有被截断

---

## 🌟 **步骤G：理解密钥用途和安全性 (1分钟)**

### **G1. 密钥安全等级**

**Publishable Key (可以安全暴露):**
- ✅ **前端使用** - 在网站JavaScript中使用
- ✅ **公开安全** - 可以在源代码中看到
- ✅ **功能限制** - 只能创建支付意图，不能完成支付
- ✅ **设计安全** - 即使被看到也无法造成损失

**Secret Key (绝对保密):**
- ⚠️ **后端使用** - 只在服务器端使用
- ⚠️ **严格保密** - 绝不能暴露在前端代码中
- ⚠️ **完全权限** - 可以处理所有支付操作
- ⚠️ **高度敏感** - 泄露可能导致财务损失

### **G2. WeDesign中的使用方式**

**Publishable Key用于:**
- ✅ 前端支付表单初始化
- ✅ 创建支付意图
- ✅ 处理客户端支付流程

**Secret Key用于:**
- ✅ 服务器端支付确认
- ✅ 创建和管理客户
- ✅ 处理订阅和发票
- ✅ 验证支付状态

---

## 📝 **完整密钥清单验证**

### **确认您现在拥有所有5个必需密钥：**

```bash
=== WeDesign完整API密钥配置 ===

# Supabase配置
SUPABASE_URL=https://你的项目ID.supabase.co
SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIs...
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIs...

# Stripe配置
STRIPE_PUBLISHABLE_KEY=pk_test_51xxxxxxxx...
STRIPE_SECRET_KEY=sk_test_51xxxxxxxx...
```

### **最终检查清单：**
- [ ] **总共5个密钥** - 3个Supabase + 2个Stripe
- [ ] **Supabase URL** 正确格式 (.supabase.co结尾)
- [ ] **Supabase密钥** 正确格式 (eyJhbGciOiJIUzI1NiIs开头)
- [ ] **Stripe密钥** 正确格式 (pk_test_/sk_test_开头)
- [ ] **所有密钥完整** 没有截断或多余空格
- [ ] **安全保存** 在安全的地方保存备份

---

## 🎯 **完成第2步后的下一步**

### **恭喜！您已成功获取所有API密钥**

**您现在准备好进行：**

1. **创建环境变量文件** - 配置.env.local
2. **设置Vercel项目** - 准备部署
3. **配置GoDaddy DNS** - 绑定域名
4. **完成www.wedesign.design绑定**

### **告诉我：**
> "我已获取所有5个API密钥(Supabase + Stripe)，准备创建环境变量文件"

**我将立即为您提供第3步指导：创建和配置.env.local文件**

---

## 🆘 **如果遇到问题**

### **常见问题解决：**

**问题1: 找不到API keys页面**
- 确认您在正确的Stripe账户中
- 检查左侧菜单是否完全展开
- 尝试刷新页面

**问题2: Secret key无法显示**
- 确认您有管理员权限
- 可能需要重新输入密码
- 检查账户是否需要完善信息

**问题3: 密钥格式看起来不对**
- 确保复制了完整的密钥
- 检查是否包含额外的空格
- 确认选择的环境正确 (Test vs Live)

**问题4: 想要切换到Live mode**
- 确保账户已完全验证
- 了解Live mode会处理真实支付
- 可以随时从Test mode开始

**问题5: 担心密钥安全**
- Publishable key可以安全暴露
- Secret key必须严格保密
- 可以随时在Stripe中重新生成密钥

### **需要帮助时请提供：**
1. 您看到的错误信息
2. 执行到哪一步遇到问题
3. 您的账户状态和环境选择

---

**💳 现在开始获取您的Stripe API密钥！这是WeDesign支付系统的关键组件！** 🔐✨