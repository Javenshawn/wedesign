# 🚀 **WeDesign Stripe支付系统完整配置指导**
## 获取API密钥 + 环境配置 + 集成测试

---

## 📋 **当前配置状态**

**已准备就绪的组件：**
- ✅ **StripePaymentForm组件** - 完整的支付表单界面
- ✅ **环境变量模板** - 已在 `.env.local` 中预配置
- ✅ **Supabase集成** - 后端订单管理系统
- ⚠️ **Stripe API密钥** - 需要获取并配置

---

## 🔑 **第1步：获取Stripe API密钥 (5分钟)**

### **1.1 创建或访问Stripe账户**

1. **访问Stripe控制台**
   ```
   网址: https://dashboard.stripe.com
   ```

2. **登录或注册Stripe账户**
   - 如果没有账户，请注册新账户
   - 建议使用与您的WeDesign项目相关的邮箱

3. **完成账户验证**
   - 添加公司信息（可以先填写基本信息）
   - 添加银行账户信息（测试模式下可以稍后完成）

### **1.2 获取测试环境API密钥**

**在Stripe控制台中：**

1. **确认测试模式**
   - 在页面顶部找到 **"测试数据"** 或 **"Test Mode"** 开关
   - 确保开关是 **ON**（蓝色状态）
   - ⚠️ **重要：先使用测试模式，避免真实交易**

2. **进入API密钥页面**
   ```
   路径: 左侧菜单 → "开发人员" (Developers) → "API密钥" (API keys)
   ```

3. **获取发布密钥 (Publishable Key)**
   - 找到 **"发布密钥"** 或 **"Publishable key"** 部分
   - 点击 **"显示"** 或直接复制按钮
   - 密钥格式：`pk_test_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`
   - ✅ **这个密钥是安全的，可以在前端使用**

4. **获取私密密钥 (Secret Key)**
   - 找到 **"私密密钥"** 或 **"Secret key"** 部分  
   - 点击 **"显示"** 按钮（可能需要确认身份）
   - 密钥格式：`sk_test_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`
   - ⚠️ **这个密钥严格保密，只能在后端使用**

### **1.3 可选：获取Webhook密钥**

**如果需要支付验证功能：**

1. **创建Webhook端点**
   ```
   路径: 开发人员 → Webhooks → "添加端点"
   端点URL: https://your-vercel-app.vercel.app/api/stripe/webhook
   ```

2. **选择事件**
   - `payment_intent.succeeded`
   - `payment_intent.payment_failed` 
   - `checkout.session.completed`

3. **获取Webhook密钥**
   - 创建后点击该Webhook
   - 找到 **"签名密钥"** 部分
   - 格式：`whsec_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`

---

## 🔧 **第2步：配置环境变量 (2分钟)**

### **2.1 更新 `.env.local` 文件**

**将获取的Stripe密钥填入配置文件：**

```bash
# ===== Stripe 配置 - 测试环境 =====

# Stripe发布密钥 (前端使用 - 可以公开)
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_您复制的发布密钥

# Stripe私密密钥 (后端使用 - 严格保密) 
STRIPE_SECRET_KEY=sk_test_您复制的私密密钥

# Stripe Webhook密钥 (可选 - 用于支付验证)
STRIPE_WEBHOOK_SECRET=whsec_您的webhook密钥
```

### **2.2 配置示例**

**正确配置应该看起来像这样：**

```bash
# ===== Stripe 配置示例 =====
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_51Xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
STRIPE_SECRET_KEY=sk_test_51Xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
STRIPE_WEBHOOK_SECRET=whsec_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

---

## 🧪 **第3步：测试支付功能 (5分钟)**

### **3.1 重启开发服务器**

```bash
# 停止当前服务器 (Ctrl+C)
npm run dev
```

### **3.2 访问支付页面**

1. **打开WeDesign网站**
   ```
   访问: http://localhost:3000
   ```

2. **进入Logo设计页面**
   ```
   导航: 首页 → "Logo Design Services" 或直接访问 /logos-design
   ```

3. **选择套餐并开始项目**
   - 选择任意设计套餐
   - 点击 "Start Your Project" 
   - 填写项目信息

### **3.3 使用Stripe测试卡**

**在支付表单中使用以下测试卡号：**

```
✅ 成功支付测试卡:
卡号: 4242 4242 4242 4242
过期日期: 任意未来日期 (例如: 12/25)
CVV: 任意3位数字 (例如: 123)
持卡人姓名: Test User
邮箱: test@example.com

❌ 失败支付测试卡:
卡号: 4000 0000 0000 0002 (通用拒绝)
卡号: 4000 0000 0000 9995 (资金不足)
```

### **3.4 验证支付结果**

**支付成功后应该看到：**
1. **支付成功页面** - 显示订单信息
2. **Stripe控制台** - 在"支付"页面看到测试交易
3. **Supabase数据库** - 在orders表中看到订单记录

---

## 🔍 **第4步：验证配置正确性**

### **4.1 检查控制台信息**

**开发服务器启动时应该看到：**
```
✅ "Stripe配置已加载: pk_test_..."
✅ "Supabase配置已加载"
```

**如果看到错误：**
```
❌ "Stripe配置未找到，使用模拟模式"
❌ "环境变量未加载"
```

### **4.2 检查浏览器网络面板**

1. **打开浏览器开发者工具** (F12)
2. **进入Network面板**
3. **尝试支付时应该看到：**
   ```
   ✅ POST /api/create-payment-intent (200 OK)
   ✅ POST /api/confirm-payment (200 OK)
   ```

### **4.3 检查Stripe控制台**

**在Stripe控制台中验证：**
1. **访问 "支付" 页面** - 应该看到测试交易记录
2. **检查交易状态** - 应该显示 "成功" 或 "Succeeded"
3. **查看交易详情** - 金额、货币、客户信息应该正确

---

## 💾 **第5步：集成Supabase订单管理**

### **5.1 订单数据流程**

```
用户提交支付 → Stripe处理支付 → 创建Supabase订单记录 → 发送确认邮件
```

### **5.2 验证数据库集成**

**在Supabase控制台中检查：**
1. **访问您的wedesign-production项目**
2. **进入Database → Tables → orders**
3. **应该看到测试支付创建的订单记录**

---

## 🚀 **第6步：生产环境准备 (部署前)**

### **6.1 激活Stripe账户**

**在部署到生产环境前：**
1. **完善Stripe账户信息**
   - 添加详细的公司信息
   - 上传身份验证文档
   - 添加银行账户信息

2. **申请生产环境访问**
   - 提交激活申请
   - 等待Stripe审核通过

### **6.2 获取生产环境密钥**

**账户激活后：**
1. **关闭测试模式** - 在控制台顶部切换
2. **获取生产密钥**
   ```
   发布密钥: pk_live_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
   私密密钥: sk_live_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
   ```

### **6.3 部署时环境变量配置**

**在Vercel/其他部署平台中配置：**
```bash
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_您的生产发布密钥
STRIPE_SECRET_KEY=sk_live_您的生产私密密钥
```

---

## 🛠️ **故障排除指南**

### **常见问题及解决方案**

**1. 支付表单无法显示**
```
原因: Stripe发布密钥未正确配置
解决: 检查NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY是否正确填写
```

**2. 支付提交后无响应**
```
原因: Stripe私密密钥未配置或后端API错误
解决: 检查STRIPE_SECRET_KEY配置，查看服务器日志
```

**3. 支付成功但订单未创建**
```
原因: Supabase连接问题或数据库权限错误
解决: 检查Supabase配置，确认orders表权限设置
```

**4. Webhook验证失败**
```
原因: Webhook密钥不匹配或端点URL错误
解决: 重新检查STRIPE_WEBHOOK_SECRET配置
```

---

## 📞 **获得帮助**

### **如果遇到问题，请提供以下信息：**

**环境配置状态：**
- [ ] Stripe账户是否已创建？
- [ ] API密钥是否已获取？
- [ ] 环境变量是否已配置？
- [ ] 开发服务器是否显示正确加载信息？

**测试结果：**
- [ ] 支付表单是否正常显示？
- [ ] 测试卡支付是否成功？
- [ ] Stripe控制台是否显示交易？
- [ ] 订单是否在Supabase中创建？

**错误信息：**
- 浏览器控制台的错误信息
- 服务器终端的错误日志
- Stripe控制台的错误提示

---

## 🎯 **配置完成标志**

### **所有配置正确时应该看到：**

1. **开发服务器启动**
   ```
   ✅ "Stripe配置已加载: pk_test_..."
   ✅ "支付系统初始化成功"
   ```

2. **支付流程测试成功**
   ```
   ✅ 支付表单正常显示
   ✅ 测试卡支付成功
   ✅ 支付成功页面显示
   ✅ Stripe控制台显示交易
   ✅ Supabase订单数据创建
   ```

3. **准备生产部署**
   ```
   ✅ Stripe账户已激活
   ✅ 生产密钥已获取
   ✅ 部署环境变量已配置
   ```

### **配置成功后请告诉我：**
> "✅ Stripe配置完成！测试支付成功，控制台显示交易记录，订单数据正确创建"

**然后我们立即开始Vercel部署和域名绑定，让您的WeDesign网站在 www.wedesign.design 正式上线！** 🎉

---

## 🎯 **重要提醒**

**安全注意事项：**
- ⚠️ **私密密钥 (sk_) 严格保密，只在服务器端使用**
- ⚠️ **不要将 .env.local 文件提交到Git仓库**
- ⚠️ **生产环境必须使用 pk_live_ 和 sk_live_ 密钥**

**测试环境规则：**
- ✅ **测试密钥 (pk_test_, sk_test_) 不会产生真实费用**
- ✅ **使用Stripe提供的测试卡号进行测试**
- ✅ **测试交易不会影响真实银行账户**

**配置验证清单：**
- [ ] 已获取Stripe发布密钥并填入NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY
- [ ] 已获取Stripe私密密钥并填入STRIPE_SECRET_KEY  
- [ ] 开发服务器重启后显示Stripe配置加载成功
- [ ] 使用测试卡进行支付测试成功
- [ ] Stripe控制台显示测试交易记录
- [ ] Supabase数据库显示订单记录

**完成所有配置后，您的WeDesign网站将拥有完整的支付功能，可以处理真实的Logo设计服务订单！** ✨