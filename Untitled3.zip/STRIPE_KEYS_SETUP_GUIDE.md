# 💳 WeDesign Stripe API密钥设置指南
## 基于现有项目的真实配置步骤

---

## 📊 **当前项目状态确认**

### **✅ 已存在的配置:**
- ✅ **Supabase项目**: 已配置项目ID `znmqppppruhlzhqvwtyp`
- ✅ **Supabase密钥**: 已有 `publicAnonKey` 在 `/utils/supabase/info.tsx`
- ✅ **支付组件**: `StripePaymentForm.tsx` 已完整实现
- ✅ **环境变量模板**: `.env.example` 已提供完整配置

### **🎯 需要完成的步骤:**
1. **获取Stripe API密钥** (本指南)
2. **创建.env.local文件**
3. **配置环境变量**
4. **Vercel部署设置**

---

## 💳 **步骤1: 获取Stripe API密钥 (7-10分钟)**

### **1.1 访问Stripe Dashboard**

1. **打开浏览器**
   - 访问: https://dashboard.stripe.com
   - 登录您的Stripe账户

2. **确认账户状态**
   - 如果没有Stripe账户，需要先注册
   - 确认账户基本信息已完善

### **1.2 进入API密钥页面**

1. **点击左侧菜单 "Developers"**
2. **点击 "API keys" 子菜单**
3. **确认页面显示API密钥列表**

### **1.3 选择环境模式**

**建议开始使用 "Test mode":**
- ✅ 安全测试所有功能
- ✅ 无真实收费
- ✅ 与生产环境功能相同

1. **点击右上角环境切换器**
2. **选择 "Test mode"**
3. **确认页面显示测试密钥**

### **1.4 复制API密钥**

**需要复制两个密钥:**

**A. Publishable Key (可公开)**
```
格式: pk_test_51xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
用途: 前端支付表单使用
```

**B. Secret Key (严格保密)**
```
格式: sk_test_51xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
用途: 后端支付处理使用
```

1. **复制Publishable Key**: 点击复制按钮
2. **复制Secret Key**: 点击 "Reveal" 然后复制

---

## ⚙️ **步骤2: 创建环境配置文件**

### **2.1 基于现有Supabase配置**

**当前项目已有的Supabase信息:**
```javascript
// /utils/supabase/info.tsx
export const projectId = "znmqppppruhlzhqvwtyp"
export const publicAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
```

### **2.2 创建.env.local文件**

**在项目根目录创建 `.env.local` 文件，内容如下:**

```bash
# ===== WeDesign生产环境配置 =====
# 基于现有项目结构的真实配置

# ===== Supabase 配置 (基于现有项目) =====
NEXT_PUBLIC_SUPABASE_URL=https://znmqppppruhlzhqvwtyp.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InpubXFwcHBwcnVobHpocXZ3dHlwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTUwODY5OTksImV4cCI6MjA3MDY2Mjk5OX0.FXImlNblzbkvzreSyIzJQWeZnK7tLiFbZdu6xw9vAwo

# Service Role Key - 需要从Supabase获取
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key_here
SUPABASE_DB_URL=postgresql://postgres:[password]@db.znmqppppruhlzhqvwtyp.supabase.co:5432/postgres

# ===== Stripe 配置 (您刚获取的密钥) =====
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_您刚复制的发布密钥
STRIPE_SECRET_KEY=sk_test_您刚复制的私密密钥

# ===== 网站配置 =====
NEXT_PUBLIC_SITE_URL=https://www.wedesign.design
NEXT_PUBLIC_SITE_NAME="WeDesign - Worldwide Design Best Delivered"

# ===== 可选配置 =====
NODE_ENV=production
```

---

## 🔑 **步骤3: 获取缺失的Supabase Service Role Key**

### **3.1 在Supabase Dashboard中获取**

1. **访问**: https://supabase.com/dashboard
2. **选择项目**: znmqppppruhlzhqvwtyp
3. **进入Settings → API**
4. **复制 "service_role" 密钥**

### **3.2 更新.env.local文件**

**将获取的service_role密钥填入:**
```bash
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.你的service_role密钥...
```

---

## ✅ **步骤4: 验证配置**

### **4.1 检查文件格式**

**您的.env.local文件应该包含:**
- ✅ NEXT_PUBLIC_SUPABASE_URL (以https://开头)
- ✅ NEXT_PUBLIC_SUPABASE_ANON_KEY (以eyJhbGciOiJI开头)
- ✅ SUPABASE_SERVICE_ROLE_KEY (以eyJhbGciOiJI开头)
- ✅ NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY (以pk_test_开头)
- ✅ STRIPE_SECRET_KEY (以sk_test_开头)

### **4.2 安全检查**

**⚠️ 严格保密的密钥:**
- `SUPABASE_SERVICE_ROLE_KEY`
- `STRIPE_SECRET_KEY`

**✅ 可以公开的密钥:**
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY`

---

## 🚀 **步骤5: 本地测试**

### **5.1 在本地测试项目**

```bash
# 确保.env.local文件在项目根目录
# 启动开发服务器
npm run dev
```

### **5.2 测试Stripe支付功能**

1. **访问**: http://localhost:3000
2. **进入Logo设计页面**
3. **选择套餐并测试支付流程**
4. **确认Stripe测试支付正常工作**

---

## 📁 **完整的.env.local示例**

```bash
# ===== WeDesign完整生产环境配置 =====

# Supabase配置 (基于现有项目)
NEXT_PUBLIC_SUPABASE_URL=https://znmqppppruhlzhqvwtyp.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InpubXFwcHBwcnVobHpocXZ3dHlwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTUwODY5OTksImV4cCI6MjA3MDY2Mjk5OX0.FXImlNblzbkvzreSyIzJQWeZnK7tLiFbZdu6xw9vAwo
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.您的service_role密钥
SUPABASE_DB_URL=postgresql://postgres:[your-password]@db.znmqppppruhlzhqvwtyp.supabase.co:5432/postgres

# Stripe配置 (您的测试密钥)
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_您的发布密钥
STRIPE_SECRET_KEY=sk_test_您的私密密钥

# 网站配置
NEXT_PUBLIC_SITE_URL=https://www.wedesign.design
NEXT_PUBLIC_SITE_NAME="WeDesign - Worldwide Design Best Delivered"

# 其他配置
NODE_ENV=production
NEXT_PUBLIC_GA_MEASUREMENT_ID=G-XXXXXXXXXX
```

---

## 🎯 **下一步: Vercel部署配置**

### **完成此步骤后告诉我:**
> "我已完成Stripe密钥配置并创建了.env.local文件，准备Vercel部署"

### **我将为您提供:**
1. **Vercel项目创建和导入**
2. **Vercel环境变量配置**
3. **域名绑定设置**
4. **GoDaddy DNS配置**

---

## 🆘 **常见问题解决**

### **问题1: Stripe密钥不可见**
- 确认您有Stripe账户管理权限
- 尝试切换到Test mode
- 刷新页面后重试

### **问题2: Supabase Service Role Key找不到**
- 确认您在正确的Supabase项目中
- 检查项目ID是否为 `znmqppppruhlzhqvwtyp`
- 确认您有项目管理员权限

### **问题3: .env.local文件不生效**
- 确认文件在项目根目录
- 确认文件名为 `.env.local`
- 重启开发服务器

### **问题4: 支付测试失败**
- 确认使用的是Test mode密钥
- 检查浏览器控制台错误信息
- 验证所有环境变量格式正确

---

## 🔒 **安全最佳实践**

### **环境变量安全:**
- ✅ `.env.local` 已在 `.gitignore` 中
- ✅ 绝不提交敏感密钥到Git仓库
- ✅ 在Vercel中单独配置生产环境变量
- ✅ 定期轮换敏感密钥

### **支付安全:**
- ✅ 使用Stripe推荐的安全实践
- ✅ 客户端永远不处理敏感支付信息
- ✅ 所有支付处理在服务器端完成

---

**💳 现在开始按照此指南配置您的Stripe密钥和环境变量！这是基于您现有项目结构的真实可行配置！** 🚀