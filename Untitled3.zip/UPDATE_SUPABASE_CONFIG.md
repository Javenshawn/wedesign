# 🔄 快速更新Supabase配置指南
## 将WeDesign项目连接到您的个人Supabase账户

---

## 🎯 **快速解决方案：使用您的Supabase项目**

### **当前状态：**
- ❌ **问题**: 项目使用测试项目 `znmqppppruhlzhqvwtyp`
- ✅ **您的账户**: `Javen1984@gmail.com`
- 🎯 **目标**: 连接到您的个人Supabase项目

---

## 🚀 **方案A：立即创建并配置新项目 (推荐)**

### **步骤1: 在您的Supabase账户创建项目**

1. **访问Supabase控制台**
   ```
   网址: https://supabase.com/dashboard
   登录: Javen1984@gmail.com
   ```

2. **创建新项目**
   ```
   点击: "New Project"
   
   配置:
   Organization: 选择您的组织
   Name: wedesign-production
   Database Password: [创建强密码]
   Region: Southeast Asia (Singapore)
   Pricing plan: Free
   ```

3. **等待项目创建完成** (1-2分钟)

### **步骤2: 获取您的项目信息**

**项目创建完成后，在Settings → API页面复制：**

```bash
# 您的项目信息
Project URL: https://[您的项目ID].supabase.co
anon public: eyJhbGciOiJIUzI1NiIs... (复制完整密钥)
service_role: eyJhbGciOiJIUzI1NiIs... (复制完整密钥)
```

### **步骤3: 更新项目配置**

**A. 更新 `.env.local` 文件：**

```bash
# 替换为您的真实项目信息
NEXT_PUBLIC_SUPABASE_URL=https://[您的项目ID].supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=[您的anon密钥]
SUPABASE_SERVICE_ROLE_KEY=[您的service_role密钥]

# 保持其他配置不变
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_您的Stripe密钥
STRIPE_SECRET_KEY=sk_test_您的Stripe密钥
NEXT_PUBLIC_SITE_URL=https://www.wedesign.design
NODE_ENV=production
```

**B. 重启开发服务器：**

```bash
# 停止当前服务器 (Ctrl+C)
# 重新启动
npm run dev
```

---

## 🛠️ **方案B：继续使用测试项目 (临时解决方案)**

### **如果您暂时无法创建新项目，可以继续使用当前配置：**

1. **项目功能正常**
   - ✅ 所有功能都能正常工作
   - ✅ 支付系统正常
   - ✅ 用户认证正常

2. **限制说明**
   - ⚠️ 这是测试项目，数据可能不稳定
   - ⚠️ 生产部署时需要切换到您的项目
   - ⚠️ 无法在您的Supabase控制台管理

3. **何时必须切换**
   - 部署到生产环境时
   - 需要查看用户数据时
   - 需要自定义数据库结构时

---

## 📋 **数据库结构设置 (使用您的项目时必需)**

### **在您的新Supabase项目中执行以下SQL：**

```sql
-- 创建用户配置文件表
CREATE TABLE profiles (
  id UUID REFERENCES auth.users ON DELETE CASCADE PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  full_name TEXT,
  avatar_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 创建项目表
CREATE TABLE projects (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  package_type TEXT NOT NULL CHECK (package_type IN ('economy', 'business', 'private-jet')),
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'in_progress', 'review', 'completed', 'cancelled')),
  industry TEXT,
  color_preferences TEXT[],
  style_preferences TEXT[],
  additional_notes TEXT,
  timeline_days INTEGER DEFAULT 5,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 创建订单表
CREATE TABLE orders (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
  amount DECIMAL(10,2) NOT NULL,
  currency TEXT DEFAULT 'USD',
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'failed', 'refunded')),
  stripe_payment_intent_id TEXT UNIQUE,
  stripe_session_id TEXT,
  payment_method TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 创建项目文件表
CREATE TABLE project_files (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
  file_name TEXT NOT NULL,
  file_type TEXT NOT NULL,
  file_size INTEGER,
  storage_path TEXT NOT NULL,
  upload_type TEXT CHECK (upload_type IN ('logo', 'revision', 'final', 'reference')),
  uploaded_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 启用行级安全
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE project_files ENABLE ROW LEVEL SECURITY;

-- 创建安全策略
CREATE POLICY "Users can view own profile" ON profiles
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update own profile" ON profiles
  FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile" ON profiles
  FOR INSERT WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can view own projects" ON projects
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can create own projects" ON projects
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own projects" ON projects
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can view own orders" ON orders
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can create own orders" ON orders
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view own project files" ON project_files
  FOR SELECT USING (
    auth.uid() IN (
      SELECT user_id FROM projects WHERE id = project_files.project_id
    )
  );

-- 创建存储桶
INSERT INTO storage.buckets (id, name, public) VALUES ('project-files', 'project-files', false);

-- 存储策略
CREATE POLICY "Users can upload project files" ON storage.objects
  FOR INSERT WITH CHECK (
    bucket_id = 'project-files' AND
    auth.uid()::text = (storage.foldername(name))[1]
  );

CREATE POLICY "Users can view project files" ON storage.objects
  FOR SELECT USING (
    bucket_id = 'project-files' AND
    auth.uid()::text = (storage.foldername(name))[1]
  );
```

---

## ✅ **验证配置是否成功**

### **完成配置后测试：**

1. **重启开发服务器**
   ```bash
   npm run dev
   ```

2. **检查控制台输出**
   - 看到 "使用环境变量配置Supabase客户端" = ✅ 成功
   - 看到 "使用默认配置Supabase客户端" = ⚠️ 仍使用测试项目

3. **测试用户注册**
   - 访问 `/login` 页面
   - 尝试注册新用户
   - 检查您的Supabase控制台中是否出现新用户

4. **检查Supabase控制台**
   - Authentication → Users (查看注册用户)
   - Database → Tables (查看数据表)
   - Storage → Buckets (查看文件存储)

---

## 🔧 **故障排除**

### **常见问题：**

**问题1: 环境变量未生效**
```bash
# 确认.env.local文件在根目录
# 确认文件名正确 (.env.local)
# 重启开发服务器
```

**问题2: 无法连接到新项目**
```bash
# 检查项目URL格式是否正确
# 确认密钥完整且无多余空格
# 验证项目是否创建成功
```

**问题3: 数据库表不存在**
```bash
# 在Supabase SQL编辑器中执行上述SQL
# 确认所有表都创建成功
# 检查RLS策略是否启用
```

---

## 📞 **获取帮助**

### **请告诉我以下信息：**

1. **您选择的方案**
   - 方案A：创建新项目
   - 方案B：继续使用测试项目

2. **如果选择方案A，请提供：**
   - 新项目的URL
   - 是否成功创建数据库表
   - 遇到的任何错误信息

3. **当前状态**
   - 是否能在您的Supabase控制台看到新项目
   - 本地开发服务器是否正常工作
   - 有任何错误消息吗

---

## 🎯 **推荐行动**

### **立即执行：**

1. **登录您的Supabase账户** (Javen1984@gmail.com)
2. **创建 `wedesign-production` 项目**
3. **复制新项目的API密钥**
4. **更新 `.env.local` 文件**
5. **运行数据库设置SQL**
6. **测试本地开发环境**

### **完成后告诉我：**
> "我已创建新的Supabase项目，项目ID是：[您的项目ID]，配置已更新"

**这样我就能确认配置正确，并指导您完成后续的部署步骤！** 🚀