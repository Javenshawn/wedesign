# WeDesign Website Manual Modification Guide

## 🗂️ Project Structure Overview

Your WeDesign website is a React/TypeScript single-page application with:
- **Client-side routing** in `App.tsx`
- **Component-based architecture** with design system
- **Luxury branding** with glass effects and gold gradients
- **Mobile-first responsive design**
- **Supabase backend integration**

---

## 1. 🧭 Navigation & Page Management

### Adding New Pages

**Step 1: Create the page component**
```bash
# Create new page file
/components/pages/YourNewPage.tsx
```

**Step 2: Update App.tsx routing**
```typescript
// In App.tsx, add import
import { Page_YourNew } from './components/pages/YourNewPage';

// Add route mapping
const routeMap: { [key: string]: string } = {
  // ... existing routes
  'your-new-page': 'your-new-page'
};

// Add case in renderPage()
case 'your-new-page':
  return <Page_YourNew onNavigate={navigateTo} />;
```

**Step 3: Update Header navigation**
```typescript
// In /components/layout/Header.tsx
const navigation = [
  // ... existing items
  { name: 'Your New Page', href: 'your-new-page' }
];
```

### Modifying Existing Pages

**Page Components Location:**
- Home: `/components/pages/HomePage.tsx`
- Logo Design: `/components/pages/LogosDesignPage.tsx`
- Design Hall: `/components/pages/DesignHallPage.tsx`
- About Us: `/components/pages/AboutUsPage.tsx`
- Blog: `/components/pages/Page_Blog.tsx`

**Page Structure Pattern:**
```typescript
export function Page_YourPage({ onNavigate }: { onNavigate?: (page: string) => void }) {
  return (
    <div className="Page_YourPage">
      <div className="Container_Desktop max-w-screen-2xl mx-auto">
        <div className="Container_Tablet">
          <div className="Container_Mobile">
            {/* Your sections here */}
          </div>
        </div>
      </div>
    </div>
  );
}
```

---

## 2. 🎨 Design System Customization

### Color Scheme Modifications

**Location:** `/styles/globals.css`

**Brand Colors:**
```css
:root {
  /* Primary brand colors */
  --accent-terra: #B6652E;          /* Main terra cotta */
  --accent-gold-start: #B6652E;     /* Gradient start */
  --accent-gold-end: #FFB84D;       /* Gradient end */
  
  /* Background colors */
  --bg-light-ivory: #FAFAF8;        /* Main background */
  --ink-deep-brown: #4a3f36;        /* Primary text */
  --ink-soft-brown: #6b5b4f;        /* Secondary text */
}
```

**To change brand colors:**
1. Update the CSS variables in `:root`
2. The changes automatically apply to all gradient and color utilities
3. Test across all pages to ensure contrast ratios remain accessible

### Typography Modifications

**Font Changes:**
```css
/* In :root */
--font-heading: 'Your-New-Font', serif;
--font-body: 'Your-Body-Font', sans-serif;
```

**Font Size Adjustments:**
```css
/* Modify base layer typography */
@layer base {
  h1 {
    font-size: 2.25rem; /* Modify this */
    /* ... */
  }
}
```

### Component Styling

**WeDesign Components Location:** `/components/design-system/`
- `WeDesignButton.tsx` - Custom buttons
- `WeDesignPricingCard.tsx` - Pricing cards
- `WeDesignCaseCard.tsx` - Case study cards

**Utility Classes:** 
Available in `globals.css`:
- `.glass-effect` - Glass morphism
- `.gradient-gold` - Brand gradients
- `.shadow-luxury` - Premium shadows

---

## 3. 📝 Content Management

### Text Content Updates

**Section Components Location:** `/components/sections/`

**Main Hero Section:**
```typescript
// File: /components/sections/CompactCarouselSection.tsx
// Look for text content in JSX and update directly
<h1 className="mb-6">Your New Headline</h1>
<p className="text-xl text-ink-soft-brown max-w-3xl mx-auto">
  Your new description text
</p>
```

**Pricing Content:**
```typescript
// File: /components/sections/PricingSection.tsx
const packages = [
  {
    name: "Economy",
    price: 199,                    // Update pricing
    features: [                    // Update feature lists
      "Your new feature 1",
      "Your new feature 2"
    ]
  }
];
```

### Image Management

**Using External Images:**
```typescript
// For external images (Unsplash, etc.)
<ImageWithFallback
  src="https://images.unsplash.com/your-image-url"
  alt="Description"
  className="w-full h-full object-cover"
/>
```

**Logo Updates:**
```typescript
// In Header.tsx, update logo
<img src="/your-logo.svg" alt="Your Brand" className="h-8" />
```

### Data Updates

**Blog Content:**
```typescript
// File: /utils/sample-blog-data.ts
export const blogPosts = [
  {
    id: '1',
    title: 'Your Blog Post Title',
    excerpt: 'Your excerpt...',
    content: 'Your full content...',
    // ... other fields
  }
];
```

---

## 4. 🔧 Component Modification

### Modal Customization

**Location:** `/components/modals/`

**Modifying StartProjectModal:**
```typescript
// File: /components/modals/StartProjectModal.tsx
// Update form fields, package options, or flow logic

const packages: PackageData[] = [
  {
    name: 'Your Package Name',
    price: '$299',
    features: ['Your feature 1', 'Your feature 2']
  }
];
```

### Section Customization

**Adding New Sections:**
```typescript
// Create: /components/sections/YourNewSection.tsx
export function Section_YourNew() {
  return (
    <section className="Section_YourNew section-mobile">
      <div className="Container_Content max-w-7xl mx-auto responsive-padding">
        {/* Your content */}
      </div>
    </section>
  );
}

// Then import and use in your page
import { Section_YourNew } from '../sections/YourNewSection';
```

### Button Customization

**WeDesignButton Variants:**
```typescript
// File: /components/design-system/WeDesignButton.tsx
// Add new variants to the variants object
const variants = {
  // ... existing variants
  'your-custom': 'your-custom-classes-here'
};
```

---

## 5. 🎯 Styling Adjustments

### Responsive Design Changes

**Mobile-First Approach:**
```css
/* Default mobile styles */
.your-element {
  padding: 1rem;
}

/* Tablet and up */
@media (min-width: 640px) {
  .your-element {
    padding: 1.5rem;
  }
}

/* Desktop and up */
@media (min-width: 1024px) {
  .your-element {
    padding: 2rem;
  }
}
```

**Using Tailwind Responsive Classes:**
```typescript
<div className="p-4 md:p-6 lg:p-8">
  {/* Responsive padding: 1rem -> 1.5rem -> 2rem */}
</div>
```

### Glass Effect Customization

**Modifying Glass Effects:**
```css
/* In globals.css */
.your-custom-glass {
  background: rgba(255, 255, 255, 0.9); /* Adjust opacity */
  backdrop-filter: blur(20px);           /* Adjust blur */
  border: 1px solid rgba(75, 63, 54, 0.1); /* Adjust border */
}
```

### Animation Adjustments

**Hover Effects:**
```css
.your-hover-effect:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 24px rgba(182, 101, 46, 0.3);
  transition: all 0.3s ease; /* Adjust timing */
}
```

---

## 6. ⚡ Feature Enhancement

### Adding New Routes

**Complex Route Example:**
```typescript
// In App.tsx
const routeMap: { [key: string]: string } = {
  'services/logo-design': 'logo-design',
  'services/branding': 'branding'
};

// Handle URL parameters
useEffect(() => {
  const path = window.location.pathname;
  const segments = path.split('/').filter(Boolean);
  
  if (segments[0] === 'services') {
    setCurrentPage(`services-${segments[1]}`);
  }
}, []);
```

### State Management

**Adding Global State:**
```typescript
// In App.tsx
const [globalSettings, setGlobalSettings] = useState({
  theme: 'light',
  language: 'en',
  currency: 'USD'
});

// Pass to components
<Page_Home 
  onNavigate={navigateTo} 
  settings={globalSettings}
  onUpdateSettings={setGlobalSettings}
/>
```

### API Integration

**Adding New API Calls:**
```typescript
// Create: /utils/api.ts
export const apiClient = {
  async getPortfolio() {
    const response = await fetch('/api/portfolio');
    return response.json();
  },
  
  async submitProject(data: any) {
    const response = await fetch('/api/projects', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    return response.json();
  }
};
```

---

## 7. 🗃️ Database & Backend

### Supabase Configuration

**Location:** `/utils/supabase/`

**Adding New Tables:**
```typescript
// In your component
import { createClient } from '../utils/supabase/client';

const supabase = createClient();

// Example: Adding portfolio items
const { data, error } = await supabase
  .from('portfolio')
  .insert([
    { title: 'New Logo', client: 'Client Name', image_url: 'url' }
  ]);
```

### Server Functions

**Location:** `/supabase/functions/server/`

**Adding New Endpoints:**
```typescript
// File: /supabase/functions/server/index.tsx
app.post('/api/your-endpoint', async (c) => {
  const body = await c.req.json();
  
  // Your logic here
  
  return c.json({ success: true, data: result });
});
```

---

## 8. 🚀 Deployment & Testing

### Local Development

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

### Testing Changes

**Browser Testing:**
1. Test on mobile (375px), tablet (768px), desktop (1440px+)
2. Check all interactive elements meet 44px touch targets
3. Verify glass effects work across browsers
4. Test all navigation routes

**Performance Checks:**
1. Image optimization (use WebP when possible)
2. Bundle size (use `npm run build` to check)
3. Accessibility (use browser dev tools)

---

## 9. 📋 Common Modification Patterns

### Quick Content Updates
1. **Headlines:** Search for `<h1>`, `<h2>` in section files
2. **Descriptions:** Look for `<p className="text-xl">` patterns
3. **Buttons:** Find `WeDesignButton` components
4. **Links:** Update `onNavigate` function calls

### Design Tweaks
1. **Colors:** Modify CSS variables in `globals.css`
2. **Spacing:** Use responsive utilities: `p-4 md:p-6 lg:p-8`
3. **Typography:** Add utility classes: `text-lg md:text-xl`
4. **Effects:** Combine existing glass and gradient classes

### Layout Changes
1. **Grid:** Modify `grid-cols-1 md:grid-cols-2 lg:grid-cols-3`
2. **Flex:** Use `flex-col md:flex-row` for responsive layouts
3. **Containers:** Adjust max-width: `max-w-4xl`, `max-w-6xl`, `max-w-7xl`

---

## 🔗 Quick Reference

**Key Files:**
- **Main App:** `App.tsx` (routing)
- **Styling:** `styles/globals.css` (design system)
- **Components:** `components/design-system/` (reusable UI)
- **Pages:** `components/pages/` (main pages)
- **Sections:** `components/sections/` (page sections)

**Design System Classes:**
- **Glass:** `.glass-card`, `.glass-effect`, `.glass-modal`
- **Gradients:** `.gradient-gold`, `.gradient-gold-soft`
- **Shadows:** `.shadow-luxury`, `.shadow-glass`
- **Responsive:** `.responsive-padding`, `.section-mobile`
- **Touch:** `.touch-target`, `.touch-area`

**Common Patterns:**
- **Page Structure:** Container_Desktop → Container_Tablet → Container_Mobile
- **Section Pattern:** `section-mobile` + `Container_Content` + `max-w-7xl mx-auto responsive-padding`
- **Component Naming:** Use descriptive prefixes like `Card_`, `Button_`, `Section_`

This guide covers the main areas you'll likely want to modify. Each change should be tested across different screen sizes and browsers to ensure consistency with the luxury WeDesign brand experience.