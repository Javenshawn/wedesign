// WeDesign 自动部署脚本
const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

console.log('🚀 WeDesign 自动部署开始');
console.log('================================');

// 部署步骤
const deploySteps = [
  {
    name: '验证项目结构',
    action: () => {
      const requiredFiles = [
        'index.html',
        'src/main.tsx', 
        'src/App.tsx',
        'package.json',
        'vite.config.ts'
      ];
      
      const missing = requiredFiles.filter(file => 
        !fs.existsSync(path.join(__dirname, file))
      );
      
      if (missing.length > 0) {
        throw new Error(`缺失文件: ${missing.join(', ')}`);
      }
      
      console.log('✅ 项目结构验证通过');
    }
  },
  {
    name: '安装依赖',
    action: () => {
      console.log('📦 正在安装 npm 依赖...');
      execSync('npm install', { stdio: 'inherit' });
      console.log('✅ 依赖安装完成');
    }
  },
  {
    name: '构建项目',
    action: () => {
      console.log('🔨 正在构建项目...');
      execSync('npm run build', { stdio: 'inherit' });
      console.log('✅ 项目构建完成');
    }
  },
  {
    name: '验证构建结果',
    action: () => {
      const distExists = fs.existsSync(path.join(__dirname, 'dist'));
      if (!distExists) {
        throw new Error('dist 目录不存在，构建可能失败');
      }
      
      const indexExists = fs.existsSync(path.join(__dirname, 'dist/index.html'));
      if (!indexExists) {
        throw new Error('dist/index.html 不存在，构建不完整');
      }
      
      console.log('✅ 构建结果验证通过');
    }
  },
  {
    name: '初始化 Git (如果需要)',
    action: () => {
      try {
        execSync('git status', { stdio: 'ignore' });
        console.log('✅ Git 仓库已存在');
      } catch {
        console.log('🔧 初始化 Git 仓库...');
        execSync('git init', { stdio: 'inherit' });
        execSync('git add .', { stdio: 'inherit' });
        execSync('git commit -m "Initial WeDesign deployment"', { stdio: 'inherit' });
        console.log('✅ Git 仓库初始化完成');
      }
    }
  },
  {
    name: '部署到 Vercel',
    action: () => {
      console.log('🚀 正在部署到 Vercel...');
      
      // 检查是否已安装 Vercel CLI
      try {
        execSync('vercel --version', { stdio: 'ignore' });
      } catch {
        console.log('📦 安装 Vercel CLI...');
        execSync('npm install -g vercel', { stdio: 'inherit' });
      }
      
      // 部署到 Vercel
      execSync('vercel --prod --yes', { stdio: 'inherit' });
      console.log('✅ Vercel 部署完成');
    }
  }
];

// 执行部署步骤
async function deploy() {
  let currentStep = 0;
  
  try {
    for (const step of deploySteps) {
      currentStep++;
      console.log(`\n[${currentStep}/${deploySteps.length}] ${step.name}`);
      console.log('─'.repeat(50));
      
      await step.action();
    }
    
    console.log('\n🎉 WeDesign 部署成功！');
    console.log('================================');
    console.log('🌐 你的网站已经部署完成！');
    console.log('');
    console.log('📝 接下来你可以:');
    console.log('• 在 Vercel 控制台查看部署状态');
    console.log('• 绑定自定义域名');
    console.log('• 配置环境变量');
    console.log('• 设置 Supabase 连接');
    console.log('• 配置 Stripe 支付');
    
  } catch (error) {
    console.log(`\n❌ 部署失败 (步骤 ${currentStep}): ${error.message}`);
    console.log('');
    console.log('🔧 修复建议:');
    
    if (currentStep === 1) {
      console.log('• 确保所有必需文件都存在');
      console.log('• 运行 node deploy-restructure.js 重组项目');
    } else if (currentStep === 2) {
      console.log('• 检查 package.json 依赖配置');
      console.log('• 确保 Node.js 版本兼容 (推荐 18+)');
    } else if (currentStep === 3) {
      console.log('• 检查 vite.config.ts 配置');
      console.log('• 修复 TypeScript 错误');
      console.log('• 检查导入路径是否正确');
    } else if (currentStep === 6) {
      console.log('• 确保已登录 Vercel: vercel login');
      console.log('• 检查网络连接');
    }
    
    process.exit(1);
  }
}

// 开始部署
deploy().catch(console.error);