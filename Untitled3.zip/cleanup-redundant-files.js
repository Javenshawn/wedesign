// 清理冗余文件的脚本
const fs = require('fs');
const path = require('path');

// 需要删除的冗余文件
const redundantFiles = [
  'components/pages/Page_AdminLogin.tsx',
  'components/pages/Page_AdminDashboard.tsx', 
  'components/pages/Page_AdminCustomers.tsx',
  'components/pages/Page_AdminSEO.tsx',
  'components/pages/BlogPage.tsx',
  'components/pages/LoginPage.tsx',
  'components/pages/PluginsPage.tsx',
  'components/pages/UXAuditBoard.tsx',
  'components/pages/UserPortalClientPage.tsx'
];

// 需要删除的文档文件
const docFiles = [
  'API_KEYS_CHECKLIST.md',
  'COMPLETE_DEPLOYMENT_STEPS.md',
  'COMPLETE_SUPABASE_SETUP_GUIDE.md',
  'CONFIGURE_YOUR_SUPABASE_PROJECT.md',
  'CONTINUE_STRIPE_AND_DEPLOYMENT.md',
  'CREATE_SUPABASE_PROJECT_FOR_WEDESIGN.md',
  'DEPLOYMENT_EXECUTION_GUIDE.md',
  'DEPLOY_TO_GITHUB_VERCEL.md',
  'DOMAIN_BINDING_GUIDE.md',
  'EXPORT_CHECKLIST.md',
  'EXPORT_EXECUTION_GUIDE.md',
  'EXPORT_READY_REPORT.md',
  'FIGMA_MAKE_EXPORT_GUIDE.md',
  'GODADDY_DOMAIN_BINDING_GUIDE.md',
  'PAYMENT_SETUP_QUICK_FIX.md',
  'PREPARATION_CHECKLIST.md',
  'QUICK_CONFIG_TEST.md',
  'START_DOMAIN_BINDING_NOW.md',
  'STEP_1_GET_API_KEYS_DETAILED.md',
  'STEP_2_GET_STRIPE_KEYS_DETAILED.md',
  'STRIPE_ACTUAL_CONSOLE_API_KEY_GUIDE.md',
  'STRIPE_COMPLETE_SETUP_GUIDE.md',
  'STRIPE_CONFIG_VERIFICATION.md',
  'STRIPE_CORRECT_KEYS_GUIDE.md',
  'STRIPE_FINAL_VERIFICATION.md',
  'STRIPE_KEYS_CONFIGURATION_GUIDE.md',
  'STRIPE_KEYS_SETUP_GUIDE.md',
  'STRIPE_KEY_FORMAT_VALIDATOR.md',
  'STRIPE_LIVE_KEY_CONFIGURATION_GUIDE.md',
  'STRIPE_LIVE_VERIFICATION_CHECKLIST.md',
  'STRIPE_MODE_SWITCHER_DETAILED_LOCATION_GUIDE.md',
  'STRIPE_MODE_SWITCHER_VISUAL_CHECKLIST.md',
  'STRIPE_PUBLISHABLE_KEY_STEP_BY_STEP_GUIDE.md',
  'STRIPE_QUICK_TEST_GUIDE.md',
  'STRIPE_SANDBOX_MODE_LOCATION_GUIDE.md',
  'STRIPE_SANDBOX_QUICK_CHECKLIST.md',
  'STRIPE_SCREENSHOT_SPECIFIC_GUIDE.md',
  'STRIPE_VISUAL_NAVIGATION_GUIDE.md',
  'STRUCTURE_AUDIT_REPORT.md',
  'SUPABASE_ACCOUNT_VERIFICATION_AND_SETUP.md',
  'SUPABASE_PROJECT_CREATION_CHECKLIST.md',
  'UPDATE_SUPABASE_CONFIG.md',
  'VERCEL_CONSOLE_SPECIFIC_GUIDE.md',
  'VERCEL_DEPLOYMENT_EXECUTION.md',
  'VERCEL_DEPLOYMENT_GUIDE.md',
  'VERCEL_VISUAL_NEXT_JS_SELECTION.md',
  'VISUAL_EXPORT_LOCATION_GUIDE.md',
  'WEBSITE_MODIFICATION_GUIDE.md',
  'WIX_STUDIO_EXPORT_GUIDE.md'
];

console.log('开始清理冗余文件...');

// 删除冗余的页面组件
redundantFiles.forEach(file => {
  const filePath = path.join(__dirname, file);
  try {
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
      console.log(`✅ 删除冗余文件: ${file}`);
    }
  } catch (error) {
    console.log(`❌ 删除失败: ${file} - ${error.message}`);
  }
});

// 删除过多的文档文件
docFiles.forEach(file => {
  const filePath = path.join(__dirname, file);
  try {
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
      console.log(`✅ 删除文档文件: ${file}`);
    }
  } catch (error) {
    console.log(`❌ 删除失败: ${file} - ${error.message}`);
  }
});

console.log('文件清理完成！');