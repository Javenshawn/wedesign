import { Plugin } from "../types/plugin";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "./ui/card";
import { Star, Download, Check, Crown, Zap } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface PluginCardProps {
  plugin: Plugin;
  onInstall: (plugin: Plugin) => void;
  onUninstall: (plugin: Plugin) => void;
}

export function PluginCard({ plugin, onInstall, onUninstall }: PluginCardProps) {
  const formatDownloads = (downloads: number) => {
    if (downloads >= 1000000) {
      return `${(downloads / 1000000).toFixed(1)}M`;
    } else if (downloads >= 1000) {
      return `${(downloads / 1000).toFixed(1)}K`;
    }
    return downloads.toString();
  };

  const isWixPlugin = plugin.developer.toLowerCase().includes('wix') || 
                     plugin.tags.some(tag => tag.toLowerCase().includes('wix'));

  return (
    <Card className="h-full flex flex-col glass-card border-glass-border hover-glass shadow-glass transition-all duration-300">
      <CardHeader className="responsive-padding">
        <div className="flex items-start gap-4">
          <div className="relative">
            <ImageWithFallback
              src={plugin.icon}
              alt={plugin.name}
              className="w-14 h-14 rounded-xl border border-glass-border object-cover shadow-glass"
            />
            {plugin.isFeatured && (
              <div className="absolute -top-2 -right-2">
                <div className="gradient-gold rounded-full w-6 h-6 flex items-center justify-center shadow-gold">
                  <Crown className="w-3 h-3 text-white" />
                </div>
              </div>
            )}
          </div>
          
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-2">
              <CardTitle className="text-lg truncate text-accent-terra font-heading">
                {plugin.name}
              </CardTitle>
              {isWixPlugin && (
                <Badge className="gradient-gold text-white border-none text-xs px-2 py-1">
                  <Zap className="w-3 h-3 mr-1" />
                  Wix
                </Badge>
              )}
            </div>
            
            <p className="text-sm text-muted-foreground font-medium">
              {plugin.developer}
            </p>
          </div>
        </div>
        
        <CardDescription className="text-sm leading-relaxed text-ink-soft-brown mt-3">
          {plugin.description}
        </CardDescription>
      </CardHeader>

      <CardContent className="flex-1 space-y-4 responsive-padding pt-0">
        
        {/* 评分和下载量 */}
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1">
              <Star className="w-4 h-4 fill-accent-gold-rich text-accent-gold-rich" />
              <span className="font-medium text-accent-terra">{plugin.rating}</span>
            </div>
            <div className="flex items-center gap-1 text-muted-foreground">
              <Download className="w-4 h-4" />
              <span>{formatDownloads(plugin.downloads)}</span>
            </div>
          </div>
          <span className="text-xs text-muted-foreground bg-glass-ivory px-2 py-1 rounded-full">
            v{plugin.version}
          </span>
        </div>

        {/* 标签 */}
        <div className="flex flex-wrap gap-2">
          {plugin.tags.slice(0, 3).map((tag) => (
            <Badge 
              key={tag} 
              variant="outline" 
              className="text-xs border-glass-border bg-glass-ivory/50 text-ink-soft-brown hover:bg-glass-ivory"
            >
              {tag}
            </Badge>
          ))}
          {plugin.tags.length > 3 && (
            <Badge 
              variant="outline" 
              className="text-xs border-glass-border bg-glass-ivory/30 text-muted-foreground"
            >
              +{plugin.tags.length - 3}
            </Badge>
          )}
        </div>

        {/* 价格 */}
        {plugin.price > 0 && (
          <div className="glass-effect-ivory rounded-lg p-3">
            <div className="text-xl font-bold text-accent-terra">
              ¥{plugin.price}
            </div>
            <div className="text-xs text-muted-foreground">
              一次性购买
            </div>
          </div>
        )}
      </CardContent>

      <CardFooter className="responsive-padding pt-0">
        {plugin.isInstalled ? (
          <div className="w-full space-y-3">
            <div className="flex items-center justify-center gap-2 text-sm glass-effect-ivory rounded-lg py-2 px-3">
              <Check className="w-4 h-4 text-green-600" />
              <span className="text-green-600 font-medium">已安装</span>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="w-full button-glass hover-glass text-muted-foreground border-glass-border touch-target"
              onClick={() => onUninstall(plugin)}
            >
              卸载插件
            </Button>
          </div>
        ) : (
          <Button
            className={`w-full touch-target ${
              plugin.price > 0 
                ? 'button-glass-primary shadow-gold' 
                : 'button-glass-secondary hover-gold'
            }`}
            onClick={() => onInstall(plugin)}
          >
            {plugin.price > 0 ? (
              <>
                购买插件 ¥{plugin.price}
              </>
            ) : (
              <>
                免费安装
                <Zap className="w-4 h-4 ml-2" />
              </>
            )}
          </Button>
        )}
      </CardFooter>
    </Card>
  );
}