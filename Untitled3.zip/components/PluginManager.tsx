import { useState } from "react";
import { Plugin, mockPlugins, categories } from "../types/plugin";
import { PluginCard } from "./PluginCard";
import { PluginFilters } from "./PluginFilters";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Separator } from "./ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { toast } from "sonner@2.0.3";
import { Package, Sparkles, TrendingUp } from "lucide-react";

export function PluginManager() {
  const [plugins, setPlugins] = useState<Plugin[]>(mockPlugins);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("全部");
  const [showInstalledOnly, setShowInstalledOnly] = useState(false);
  const [activeTab, setActiveTab] = useState("discover");

  const handleInstall = (plugin: Plugin) => {
    setPlugins(prev => prev.map(p => 
      p.id === plugin.id ? { ...p, isInstalled: true } : p
    ));
    toast.success(`${plugin.name} 安装成功！`);
  };

  const handleUninstall = (plugin: Plugin) => {
    setPlugins(prev => prev.map(p => 
      p.id === plugin.id ? { ...p, isInstalled: false } : p
    ));
    toast.success(`${plugin.name} 已卸载`);
  };

  const filteredPlugins = plugins.filter(plugin => {
    const matchesSearch = plugin.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         plugin.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         plugin.developer.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         plugin.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesCategory = selectedCategory === "全部" || plugin.category === selectedCategory;
    const matchesInstalled = !showInstalledOnly || plugin.isInstalled;
    
    return matchesSearch && matchesCategory && matchesInstalled;
  });

  const featuredPlugins = plugins.filter(plugin => plugin.isFeatured);
  const wixPlugins = plugins.filter(plugin => 
    plugin.developer.toLowerCase().includes('wix') || 
    plugin.tags.some(tag => tag.toLowerCase().includes('wix'))
  );
  const installedPlugins = plugins.filter(plugin => plugin.isInstalled);

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div className="mb-8">
        <h1 className="mb-2">Figma 插件管理器</h1>
        <p className="text-muted-foreground">
          发现、安装和管理你的 Figma 插件
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="discover" className="flex items-center gap-2">
            <Sparkles className="w-4 h-4" />
            发现
          </TabsTrigger>
          <TabsTrigger value="wix" className="flex items-center gap-2">
            <Package className="w-4 h-4" />
            Wix 插件
          </TabsTrigger>
          <TabsTrigger value="installed" className="flex items-center gap-2">
            <Package className="w-4 h-4" />
            已安装 ({installedPlugins.length})
          </TabsTrigger>
          <TabsTrigger value="trending" className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4" />
            热门
          </TabsTrigger>
        </TabsList>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* 侧边栏筛选 */}
          <div className="lg:col-span-1">
            <div className="sticky top-6">
              <PluginFilters
                searchQuery={searchQuery}
                onSearchChange={setSearchQuery}
                selectedCategory={selectedCategory}
                onCategoryChange={setSelectedCategory}
                showInstalledOnly={showInstalledOnly}
                onShowInstalledChange={setShowInstalledOnly}
              />
            </div>
          </div>

          {/* 主内容区域 */}
          <div className="lg:col-span-3">
            <TabsContent value="discover" className="space-y-6">
              {/* Wix 插件特别推荐 */}
              {wixPlugins.length > 0 && (
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <h2>Wix 插件推荐</h2>
                    <Badge variant="secondary">特别推荐</Badge>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {wixPlugins.map((plugin) => (
                      <PluginCard
                        key={plugin.id}
                        plugin={plugin}
                        onInstall={handleInstall}
                        onUninstall={handleUninstall}
                      />
                    ))}
                  </div>
                  <Separator />
                </div>
              )}

              {/* 精选插件 */}
              {featuredPlugins.length > 0 && (
                <div className="space-y-4">
                  <h2>精选插件</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                    {featuredPlugins.slice(0, 6).map((plugin) => (
                      <PluginCard
                        key={plugin.id}
                        plugin={plugin}
                        onInstall={handleInstall}
                        onUninstall={handleUninstall}
                      />
                    ))}
                  </div>
                  <Separator />
                </div>
              )}

              {/* 所有插件 */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h2>所有插件</h2>
                  <span className="text-sm text-muted-foreground">
                    {filteredPlugins.length} 个插件
                  </span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                  {filteredPlugins.map((plugin) => (
                    <PluginCard
                      key={plugin.id}
                      plugin={plugin}
                      onInstall={handleInstall}
                      onUninstall={handleUninstall}
                    />
                  ))}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="wix" className="space-y-4">
              <h2>Wix 插件</h2>
              <p className="text-muted-foreground">
                Wix 官方和第三方插件，帮你将 Figma 设计无缝转换为 Wix 网站。
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                {wixPlugins.map((plugin) => (
                  <PluginCard
                    key={plugin.id}
                    plugin={plugin}
                    onInstall={handleInstall}
                    onUninstall={handleUninstall}
                  />
                ))}
              </div>
            </TabsContent>

            <TabsContent value="installed" className="space-y-4">
              <h2>已安装插件</h2>
              {installedPlugins.length === 0 ? (
                <div className="text-center py-12 text-muted-foreground">
                  <Package className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>你还没有安装任何插件</p>
                  <Button 
                    variant="outline" 
                    className="mt-4"
                    onClick={() => setActiveTab("discover")}
                  >
                    浏览插件
                  </Button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                  {installedPlugins.map((plugin) => (
                    <PluginCard
                      key={plugin.id}
                      plugin={plugin}
                      onInstall={handleInstall}
                      onUninstall={handleUninstall}
                    />
                  ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="trending" className="space-y-4">
              <h2>热门插件</h2>
              <p className="text-muted-foreground">
                根据下载量和评分排序的热门插件。
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                {[...plugins]
                  .sort((a, b) => b.downloads - a.downloads)
                  .map((plugin) => (
                    <PluginCard
                      key={plugin.id}
                      plugin={plugin}
                      onInstall={handleInstall}
                      onUninstall={handleUninstall}
                    />
                  ))}
              </div>
            </TabsContent>
          </div>
        </div>
      </Tabs>
    </div>
  );
}