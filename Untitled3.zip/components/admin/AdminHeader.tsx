import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Bell, Search, Settings, User, LogOut, Moon, Sun, 
  MessageSquare, Shield, AlertTriangle, CheckCircle
} from 'lucide-react';
import { Input } from '../ui/input';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Avatar, AvatarImage, AvatarFallback } from '../ui/avatar';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger 
} from '../ui/dropdown-menu';
import { ImageWithFallback } from '../figma/ImageWithFallback';

interface AdminHeaderProps {
  user: {
    name: string;
    role: string;
    avatar: string;
  };
  onNavigate: (page: string) => void;
}

export function AdminHeader({ user, onNavigate }: AdminHeaderProps) {
  const [darkMode, setDarkMode] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const notifications = [
    { id: 1, type: 'alert', title: 'High priority ticket opened', time: '2m ago', unread: true },
    { id: 2, type: 'success', title: 'Payment processed successfully', time: '15m ago', unread: true },
    { id: 3, type: 'info', title: 'New customer registered', time: '1h ago', unread: false },
    { id: 4, type: 'warning', title: 'Server maintenance scheduled', time: '2h ago', unread: false }
  ];

  const unreadCount = notifications.filter(n => n.unread).length;

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'alert': return <AlertTriangle className="w-4 h-4 text-red-500" />;
      case 'success': return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'warning': return <AlertTriangle className="w-4 h-4 text-orange-500" />;
      default: return <MessageSquare className="w-4 h-4 text-blue-500" />;
    }
  };

  return (
    <header className="glass-navigation border-b border-glass-border px-6 py-4">
      <div className="flex items-center justify-between">
        {/* Search Bar */}
        <div className="flex-1 max-w-lg">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-ink-soft-brown" />
            <Input
              type="text"
              placeholder="Search customers, orders, tickets..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="input-glass pl-10 pr-4 h-10 bg-glass-white border-0 focus:ring-2 focus:ring-accent-terra/20"
            />
          </div>
        </div>

        {/* Header Actions */}
        <div className="flex items-center gap-4">
          {/* Theme Toggle */}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setDarkMode(!darkMode)}
            className="w-10 h-10 glass-effect hover:shadow-glass"
          >
            {darkMode ? (
              <Sun className="w-4 h-4 text-accent-terra" />
            ) : (
              <Moon className="w-4 h-4 text-accent-terra" />
            )}
          </Button>

          {/* Notifications */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                className="w-10 h-10 glass-effect hover:shadow-glass relative"
              >
                <Bell className="w-4 h-4 text-accent-terra" />
                {unreadCount > 0 && (
                  <Badge className="absolute -top-1 -right-1 w-5 h-5 p-0 bg-red-500 text-white text-xs flex items-center justify-center rounded-full">
                    {unreadCount}
                  </Badge>
                )}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent 
              align="end" 
              className="w-80 glass-modal border border-glass-border shadow-luxury-lg"
            >
              <DropdownMenuLabel className="font-heading font-semibold text-ink-deep-brown">
                Notifications
              </DropdownMenuLabel>
              <DropdownMenuSeparator className="bg-glass-border" />
              
              <div className="max-h-64 overflow-y-auto">
                {notifications.map((notification) => (
                  <DropdownMenuItem 
                    key={notification.id}
                    className={`p-3 cursor-pointer ${notification.unread ? 'bg-accent-terra/5' : ''}`}
                  >
                    <div className="flex items-start gap-3 w-full">
                      {getNotificationIcon(notification.type)}
                      <div className="flex-1 min-w-0">
                        <p className={`text-sm ${notification.unread ? 'font-medium text-ink-deep-brown' : 'text-ink-soft-brown'}`}>
                          {notification.title}
                        </p>
                        <p className="text-xs text-ink-soft-brown">{notification.time}</p>
                      </div>
                      {notification.unread && (
                        <div className="w-2 h-2 bg-accent-terra rounded-full"></div>
                      )}
                    </div>
                  </DropdownMenuItem>
                ))}
              </div>
              
              <DropdownMenuSeparator className="bg-glass-border" />
              <DropdownMenuItem className="p-3 text-center text-accent-terra hover:text-accent-gold-rich">
                View all notifications
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* User Menu */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="flex items-center gap-3 p-2 glass-effect hover:shadow-glass">
                <Avatar className="w-8 h-8">
                  <AvatarImage src={user.avatar} alt={user.name} />
                  <AvatarFallback className="gradient-gold text-white text-sm">
                    {user.name.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                <div className="text-left">
                  <p className="text-sm font-medium text-ink-deep-brown">{user.name}</p>
                  <p className="text-xs text-ink-soft-brown">{user.role}</p>
                </div>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent 
              align="end" 
              className="w-56 glass-modal border border-glass-border shadow-luxury-lg"
            >
              <DropdownMenuLabel>
                <div className="flex items-center gap-3">
                  <Avatar className="w-12 h-12">
                    <AvatarImage src={user.avatar} alt={user.name} />
                    <AvatarFallback className="gradient-gold text-white">
                      {user.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium text-ink-deep-brown">{user.name}</p>
                    <p className="text-xs text-ink-soft-brown flex items-center gap-1">
                      <Shield className="w-3 h-3" />
                      {user.role}
                    </p>
                  </div>
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator className="bg-glass-border" />
              
              <DropdownMenuItem 
                onClick={() => onNavigate('admin-profile')}
                className="cursor-pointer"
              >
                <User className="w-4 h-4 mr-2" />
                Edit Profile
              </DropdownMenuItem>
              
              <DropdownMenuItem 
                onClick={() => onNavigate('admin-settings')}
                className="cursor-pointer"
              >
                <Settings className="w-4 h-4 mr-2" />
                Account Settings
              </DropdownMenuItem>
              
              <DropdownMenuSeparator className="bg-glass-border" />
              
              <DropdownMenuItem 
                onClick={() => onNavigate('home')}
                className="cursor-pointer"
              >
                <User className="w-4 h-4 mr-2" />
                Back to Website
              </DropdownMenuItem>
              
              <DropdownMenuItem 
                onClick={() => onNavigate('login')}
                className="cursor-pointer text-destructive focus:text-destructive"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Sign Out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}