import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  ShoppingCart, Eye, Edit, Download, Clock, CheckCircle, AlertCircle,
  User, Calendar, DollarSign, Package, Filter, Search, Plus,
  MoreHorizontal, FileText, MessageSquare, Star, Zap
} from 'lucide-react';
import { WeDesignButton } from '../design-system/WeDesignButton';
import { Input } from '../ui/input';
import { Badge } from '../ui/badge';
import { Card } from '../ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../ui/table';
import { Avatar, AvatarImage, AvatarFallback } from '../ui/avatar';
import { Progress } from '../ui/progress';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from '../ui/dropdown-menu';
import { AdminSidebar } from './AdminSidebar';
import { AdminHeader } from './AdminHeader';

interface Order {
  id: string;
  orderNumber: string;
  customer: {
    name: string;
    company: string;
    avatar: string;
  };
  packageType: 'Economy' | 'Business' | 'Private Jet';
  designer: string;
  status: 'pending' | 'in-progress' | 'review' | 'revision' | 'completed' | 'delivered';
  progress: number;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  deadline: string;
  createdAt: string;
  amount: number;
  comments: number;
  logoName: string;
}

interface AdminOrdersProps {
  onNavigate: (page: string) => void;
}

export function AdminOrders({ onNavigate }: AdminOrdersProps) {
  const [currentUser] = useState({ name: 'Sarah Chen', role: 'Super Admin', avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop' });
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [packageFilter, setPackageFilter] = useState('all');
  const [priorityFilter, setPriorityFilter] = useState('all');
  const [viewMode, setViewMode] = useState<'table' | 'kanban'>('table');

  useEffect(() => {
    // Simulate API call
    const timer = setTimeout(() => {
      setOrders([
        {
          id: '1',
          orderNumber: 'WD-2024-0847',
          customer: {
            name: 'Alex Johnson',
            company: 'TechFlow Solutions',
            avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop'
          },
          packageType: 'Business',
          designer: 'Sarah Chen',
          status: 'in-progress',
          progress: 75,
          priority: 'high',
          deadline: '2024-01-25T15:00:00Z',
          createdAt: '2024-01-20T10:30:00Z',
          amount: 599,
          comments: 8,
          logoName: 'TechFlow Professional Logo'
        },
        {
          id: '2',
          orderNumber: 'WD-2024-0848',
          customer: {
            name: 'Maria Rodriguez',
            company: 'Green Garden Cafe',
            avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop'
          },
          packageType: 'Economy',
          designer: 'Marcus Rodriguez',
          status: 'review',
          progress: 95,
          priority: 'medium',
          deadline: '2024-01-24T12:00:00Z',
          createdAt: '2024-01-18T14:20:00Z',
          amount: 299,
          comments: 4,
          logoName: 'Organic Cafe Brand Identity'
        },
        {
          id: '3',
          orderNumber: 'WD-2024-0849',
          customer: {
            name: 'David Kim',
            company: 'Urban Fashion Co',
            avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop'
          },
          packageType: 'Private Jet',
          designer: 'Emily Thompson',
          status: 'completed',
          progress: 100,
          priority: 'urgent',
          deadline: '2024-01-22T18:00:00Z',
          createdAt: '2024-01-15T09:15:00Z',
          amount: 1299,
          comments: 12,
          logoName: 'Fashion House Premium Brand'
        },
        {
          id: '4',
          orderNumber: 'WD-2024-0850',
          customer: {
            name: 'Jennifer Chen',
            company: 'MedCare Plus',
            avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop'
          },
          packageType: 'Business',
          designer: 'David Kim',
          status: 'revision',
          progress: 60,
          priority: 'medium',
          deadline: '2024-01-26T16:00:00Z',
          createdAt: '2024-01-19T11:45:00Z',
          amount: 599,
          comments: 6,
          logoName: 'Healthcare Professional Identity'
        }
      ]);
      setLoading(false);
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-gray-100 text-gray-800 border-gray-200';
      case 'in-progress': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'review': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'revision': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'completed': return 'bg-green-100 text-green-800 border-green-200';
      case 'delivered': return 'bg-purple-100 text-purple-800 border-purple-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending': return <Clock className="w-4 h-4" />;
      case 'in-progress': return <Zap className="w-4 h-4" />;
      case 'review': return <Eye className="w-4 h-4" />;
      case 'revision': return <Edit className="w-4 h-4" />;
      case 'completed': return <CheckCircle className="w-4 h-4" />;
      case 'delivered': return <Download className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'bg-red-100 text-red-800 border-red-200';
      case 'high': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getPackageColor = (packageType: string) => {
    switch (packageType) {
      case 'Private Jet': return 'gradient-gold text-white';
      case 'Business': return 'bg-accent-terra text-white';
      case 'Economy': return 'bg-green-600 text-white';
      default: return 'bg-gray-500 text-white';
    }
  };

  const filteredOrders = orders.filter(order => {
    const matchesSearch = order.orderNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         order.customer.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         order.customer.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         order.logoName.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || order.status === statusFilter;
    const matchesPackage = packageFilter === 'all' || order.packageType === packageFilter;
    const matchesPriority = priorityFilter === 'all' || order.priority === priorityFilter;
    
    return matchesSearch && matchesStatus && matchesPackage && matchesPriority;
  });

  const stats = {
    total: orders.length,
    pending: orders.filter(o => o.status === 'pending').length,
    inProgress: orders.filter(o => o.status === 'in-progress').length,
    completed: orders.filter(o => o.status === 'completed').length,
    revenue: orders.reduce((sum, o) => sum + o.amount, 0)
  };

  return (
    <div className="Page_AdminOrders min-h-screen bg-gradient-to-br from-bg-light-ivory to-bg-light-ivory/50">
      <div className="flex h-screen">
        <AdminSidebar 
          collapsed={sidebarCollapsed}
          onToggle={() => setSidebarCollapsed(!sidebarCollapsed)}
          currentPage="orders"
          onNavigate={onNavigate}
        />

        <div className={`flex-1 flex flex-col overflow-hidden transition-all duration-300 ${sidebarCollapsed ? 'ml-20' : 'ml-80'}`}>
          <AdminHeader user={currentUser} onNavigate={onNavigate} />

          <main className="flex-1 overflow-y-auto p-6 space-y-6">
            {/* Page Header */}
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
              <div>
                <h1 className="text-3xl font-heading font-bold text-gradient-gold-rich mb-2">
                  Design Orders
                </h1>
                <p className="text-ink-soft-brown">
                  Manage logo design orders and track progress
                </p>
              </div>
              
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1 bg-glass-white rounded-lg p-1">
                  <button
                    onClick={() => setViewMode('table')}
                    className={`px-3 py-2 rounded-md text-sm font-medium transition-all ${
                      viewMode === 'table' 
                        ? 'gradient-gold text-white shadow-gold' 
                        : 'text-ink-deep-brown hover:bg-glass-white'
                    }`}
                  >
                    Table
                  </button>
                  <button
                    onClick={() => setViewMode('kanban')}
                    className={`px-3 py-2 rounded-md text-sm font-medium transition-all ${
                      viewMode === 'kanban' 
                        ? 'gradient-gold text-white shadow-gold' 
                        : 'text-ink-deep-brown hover:bg-glass-white'
                    }`}
                  >
                    Kanban
                  </button>
                </div>
                
                <WeDesignButton variant="primary-gold" size="sm">
                  <Plus className="w-4 h-4 mr-2" />
                  New Order
                </WeDesignButton>
              </div>
            </div>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
              <Card className="glass-card p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 gradient-gold rounded-xl flex items-center justify-center">
                    <ShoppingCart className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-ink-deep-brown">{stats.total}</p>
                    <p className="text-ink-soft-brown text-sm">Total Orders</p>
                  </div>
                </div>
              </Card>

              <Card className="glass-card p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-gray-500 rounded-xl flex items-center justify-center">
                    <Clock className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-ink-deep-brown">{stats.pending}</p>
                    <p className="text-ink-soft-brown text-sm">Pending</p>
                  </div>
                </div>
              </Card>

              <Card className="glass-card p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-blue-500 rounded-xl flex items-center justify-center">
                    <Zap className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-ink-deep-brown">{stats.inProgress}</p>
                    <p className="text-ink-soft-brown text-sm">In Progress</p>
                  </div>
                </div>
              </Card>

              <Card className="glass-card p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-green-500 rounded-xl flex items-center justify-center">
                    <CheckCircle className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-ink-deep-brown">{stats.completed}</p>
                    <p className="text-ink-soft-brown text-sm">Completed</p>
                  </div>
                </div>
              </Card>

              <Card className="glass-card p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-purple-500 rounded-xl flex items-center justify-center">
                    <DollarSign className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-ink-deep-brown">{formatCurrency(stats.revenue)}</p>
                    <p className="text-ink-soft-brown text-sm">Total Revenue</p>
                  </div>
                </div>
              </Card>
            </div>

            {/* Filters */}
            <Card className="glass-card p-6">
              <div className="flex flex-col lg:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-ink-soft-brown" />
                    <Input
                      placeholder="Search orders..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="input-glass pl-10"
                    />
                  </div>
                </div>

                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-40 glass-effect border-0">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent className="glass-modal">
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="in-progress">In Progress</SelectItem>
                    <SelectItem value="review">Review</SelectItem>
                    <SelectItem value="revision">Revision</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                    <SelectItem value="delivered">Delivered</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={packageFilter} onValueChange={setPackageFilter}>
                  <SelectTrigger className="w-40 glass-effect border-0">
                    <SelectValue placeholder="Package" />
                  </SelectTrigger>
                  <SelectContent className="glass-modal">
                    <SelectItem value="all">All Packages</SelectItem>
                    <SelectItem value="Economy">Economy</SelectItem>
                    <SelectItem value="Business">Business</SelectItem>
                    <SelectItem value="Private Jet">Private Jet</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={priorityFilter} onValueChange={setPriorityFilter}>
                  <SelectTrigger className="w-40 glass-effect border-0">
                    <SelectValue placeholder="Priority" />
                  </SelectTrigger>
                  <SelectContent className="glass-modal">
                    <SelectItem value="all">All Priority</SelectItem>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="urgent">Urgent</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </Card>

            {/* Orders Table */}
            <Card className="glass-card p-6">
              {loading ? (
                <div className="space-y-4">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className="flex items-center gap-4 p-4">
                      <div className="w-10 h-10 bg-muted/30 rounded-full animate-pulse"></div>
                      <div className="flex-1 space-y-2">
                        <div className="w-40 h-4 bg-muted/30 rounded animate-pulse"></div>
                        <div className="w-64 h-3 bg-muted/30 rounded animate-pulse"></div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className="border-glass-border">
                        <TableHead>Order</TableHead>
                        <TableHead>Customer</TableHead>
                        <TableHead>Package</TableHead>
                        <TableHead>Designer</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Progress</TableHead>
                        <TableHead>Priority</TableHead>
                        <TableHead>Deadline</TableHead>
                        <TableHead>Amount</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredOrders.map((order, index) => (
                        <motion.tr
                          key={order.id}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: index * 0.05 }}
                          className="border-glass-border hover:bg-glass-white/50 transition-colors"
                        >
                          <TableCell>
                            <div>
                              <p className="font-medium text-ink-deep-brown">{order.orderNumber}</p>
                              <p className="text-sm text-ink-soft-brown truncate max-w-32">{order.logoName}</p>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-3">
                              <Avatar className="w-8 h-8">
                                <AvatarImage src={order.customer.avatar} alt={order.customer.name} />
                                <AvatarFallback className="gradient-gold text-white text-xs">
                                  {order.customer.name.split(' ').map(n => n[0]).join('')}
                                </AvatarFallback>
                              </Avatar>
                              <div>
                                <p className="font-medium text-ink-deep-brown text-sm">{order.customer.name}</p>
                                <p className="text-xs text-ink-soft-brown">{order.customer.company}</p>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge className={`${getPackageColor(order.packageType)} border-0 text-xs`}>
                              {order.packageType}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <p className="text-ink-deep-brown text-sm">{order.designer}</p>
                          </TableCell>
                          <TableCell>
                            <Badge className={`${getStatusColor(order.status)} border text-xs flex items-center gap-1 w-fit`}>
                              {getStatusIcon(order.status)}
                              {order.status.replace('-', ' ')}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="space-y-1">
                              <div className="flex items-center justify-between">
                                <span className="text-xs text-ink-soft-brown">{order.progress}%</span>
                              </div>
                              <Progress value={order.progress} className="h-2 w-20" />
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge className={`${getPriorityColor(order.priority)} border text-xs capitalize`}>
                              {order.priority}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <p className="text-ink-deep-brown text-sm">{formatDate(order.deadline)}</p>
                          </TableCell>
                          <TableCell>
                            <span className="font-medium text-ink-deep-brown">
                              {formatCurrency(order.amount)}
                            </span>
                          </TableCell>
                          <TableCell>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <button className="w-8 h-8 glass-effect rounded-lg flex items-center justify-center hover:shadow-glass transition-all">
                                  <MoreHorizontal className="w-4 h-4 text-ink-soft-brown" />
                                </button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end" className="glass-modal">
                                <DropdownMenuItem>
                                  <Eye className="w-4 h-4 mr-2" />
                                  View Details
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <Edit className="w-4 h-4 mr-2" />
                                  Edit Order
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <MessageSquare className="w-4 h-4 mr-2" />
                                  Add Comment
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <Download className="w-4 h-4 mr-2" />
                                  Download Files
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </motion.tr>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </Card>
          </main>
        </div>
      </div>
    </div>
  );
}