import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Search, TrendingUp, TrendingDown, Minus, Eye, Edit, Download, Upload,
  Filter, Plus, MoreHorizontal, BarChart3, Target, Globe, Settings,
  FileText, Link, Code, ExternalLink, Trash2, Copy, RefreshCw
} from 'lucide-react';
import { WeDesignButton } from '../design-system/WeDesignButton';
import { Input } from '../ui/input';
import { Badge } from '../ui/badge';
import { Card } from '../ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Textarea } from '../ui/textarea';
import { Switch } from '../ui/switch';
import { Progress } from '../ui/progress';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from '../ui/dropdown-menu';
import { AdminSidebar } from './AdminSidebar';
import { AdminHeader } from './AdminHeader';
import { 
  keywordCategories, 
  generateKeywordData, 
  samplePageOptimizations,
  defaultSEOSettings,
  type Keyword,
  type PageOptimization,
  type SEOSettings
} from '../../utils/seo-keywords-data';

interface AdminSEOProps {
  onNavigate: (page: string) => void;
}

export function AdminSEO({ onNavigate }: AdminSEOProps) {
  const [currentUser] = useState({ name: 'Sarah Chen', role: 'Super Admin', avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop' });
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [keywords, setKeywords] = useState<Keyword[]>([]);
  const [pageOptimizations, setPageOptimizations] = useState<PageOptimization[]>(samplePageOptimizations);
  const [seoSettings, setSeoSettings] = useState<SEOSettings>(defaultSEOSettings);
  const [loading, setLoading] = useState(true);
  
  // Filter states
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedKeyword, setSelectedKeyword] = useState<Keyword | null>(null);

  useEffect(() => {
    // Initialize keyword data
    const timer = setTimeout(() => {
      setKeywords(generateKeywordData());
      setLoading(false);
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  const filteredKeywords = keywords.filter(keyword => {
    const matchesSearch = keyword.keyword.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || keyword.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const stats = {
    totalKeywords: keywords.length,
    rankedKeywords: keywords.filter(k => k.currentRanking !== null).length,
    avgRanking: keywords.filter(k => k.currentRanking !== null).reduce((sum, k) => sum + (k.currentRanking || 0), 0) / keywords.filter(k => k.currentRanking !== null).length,
    topKeywords: keywords.filter(k => k.currentRanking && k.currentRanking <= 10).length,
    totalTraffic: keywords.reduce((sum, k) => sum + (k.searchVolume * (k.ctr / 100)), 0)
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toFixed(0);
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up': return <TrendingUp className="w-4 h-4 text-green-500" />;
      case 'down': return <TrendingDown className="w-4 h-4 text-red-500" />;
      default: return <Minus className="w-4 h-4 text-gray-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'optimized': return 'bg-green-100 text-green-800 border-green-200';
      case 'needs-attention': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'poor': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const CategoryTag = ({ categoryId, count }: { categoryId: string; count: number }) => {
    const category = keywordCategories.find(c => c.id === categoryId);
    if (!category) return null;

    return (
      <button
        onClick={() => setSelectedCategory(categoryId)}
        className={`flex items-center gap-2 px-4 py-2 rounded-xl transition-all ${
          selectedCategory === categoryId
            ? 'gradient-gold text-white shadow-gold'
            : 'glass-effect hover:shadow-glass'
        }`}
      >
        <div className={`w-3 h-3 rounded-full ${category.color}`}></div>
        <span className="font-medium">{category.name}</span>
        <Badge className="bg-glass-white border-0 text-xs">{count}</Badge>
      </button>
    );
  };

  return (
    <div className="Page_AdminSEO min-h-screen bg-gradient-to-br from-bg-light-ivory to-bg-light-ivory/50">
      <div className="flex h-screen">
        <AdminSidebar 
          collapsed={sidebarCollapsed}
          onToggle={() => setSidebarCollapsed(!sidebarCollapsed)}
          currentPage="seo"
          onNavigate={onNavigate}
        />

        <div className={`flex-1 flex flex-col overflow-hidden transition-all duration-300 ${sidebarCollapsed ? 'ml-20' : 'ml-80'}`}>
          <AdminHeader user={currentUser} onNavigate={onNavigate} />

          <main className="flex-1 overflow-y-auto p-6">
            {/* Page Header */}
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 mb-6">
              <div>
                <h1 className="text-3xl font-heading font-bold text-gradient-gold-rich mb-2">
                  SEO Management
                </h1>
                <p className="text-ink-soft-brown">
                  Optimize your website's search engine performance
                </p>
              </div>
              
              <div className="flex items-center gap-3">
                <WeDesignButton variant="secondary-outline" size="sm">
                  <Upload className="w-4 h-4 mr-2" />
                  Import Keywords
                </WeDesignButton>
                <WeDesignButton variant="primary-gold" size="sm">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Keyword
                </WeDesignButton>
              </div>
            </div>

            {/* SEO Tabs */}
            <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
              <TabsList className="glass-effect p-2 w-fit">
                <TabsTrigger value="dashboard" className="px-6 py-3">Dashboard</TabsTrigger>
                <TabsTrigger value="keywords" className="px-6 py-3">Keywords</TabsTrigger>
                <TabsTrigger value="pages" className="px-6 py-3">Page Optimization</TabsTrigger>
                <TabsTrigger value="settings" className="px-6 py-3">Settings</TabsTrigger>
              </TabsList>

              {/* Dashboard Tab */}
              <TabsContent value="dashboard" className="space-y-6">
                {/* Stats Cards */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <Card className="glass-card p-6">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 gradient-gold rounded-xl flex items-center justify-center">
                        <Target className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <p className="text-2xl font-bold text-ink-deep-brown">{formatNumber(stats.totalKeywords)}</p>
                        <p className="text-ink-soft-brown text-sm">Total Keywords</p>
                      </div>
                    </div>
                  </Card>

                  <Card className="glass-card p-6">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-green-500 rounded-xl flex items-center justify-center">
                        <BarChart3 className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <p className="text-2xl font-bold text-ink-deep-brown">{stats.rankedKeywords}</p>
                        <p className="text-ink-soft-brown text-sm">Ranked Keywords</p>
                      </div>
                    </div>
                  </Card>

                  <Card className="glass-card p-6">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-blue-500 rounded-xl flex items-center justify-center">
                        <TrendingUp className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <p className="text-2xl font-bold text-ink-deep-brown">{stats.avgRanking.toFixed(1)}</p>
                        <p className="text-ink-soft-brown text-sm">Avg. Ranking</p>
                      </div>
                    </div>
                  </Card>

                  <Card className="glass-card p-6">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-purple-500 rounded-xl flex items-center justify-center">
                        <Eye className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <p className="text-2xl font-bold text-ink-deep-brown">{formatNumber(stats.totalTraffic)}</p>
                        <p className="text-ink-soft-brown text-sm">Est. Traffic</p>
                      </div>
                    </div>
                  </Card>
                </div>

                {/* Category Overview */}
                <Card className="glass-card p-6">
                  <h3 className="text-xl font-heading font-semibold text-ink-deep-brown mb-6">
                    Keyword Categories
                  </h3>
                  
                  <div className="flex flex-wrap gap-3 mb-6">
                    <button
                      onClick={() => setSelectedCategory('all')}
                      className={`px-4 py-2 rounded-xl transition-all ${
                        selectedCategory === 'all'
                          ? 'gradient-gold text-white shadow-gold'
                          : 'glass-effect hover:shadow-glass'
                      }`}
                    >
                      All Categories ({keywords.length})
                    </button>
                    
                    {keywordCategories.map(category => {
                      const count = keywords.filter(k => k.category === category.id).length;
                      return (
                        <CategoryTag key={category.id} categoryId={category.id} count={count} />
                      );
                    })}
                  </div>

                  {/* Top Keywords Table */}
                  <div className="space-y-4">
                    <h4 className="font-semibold text-ink-deep-brown">Top Performing Keywords</h4>
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow className="border-glass-border">
                            <TableHead>Keyword</TableHead>
                            <TableHead>Category</TableHead>
                            <TableHead>Search Volume</TableHead>
                            <TableHead>Ranking</TableHead>
                            <TableHead>CTR</TableHead>
                            <TableHead>Trend</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {filteredKeywords.slice(0, 10).map((keyword, index) => (
                            <motion.tr
                              key={keyword.id}
                              initial={{ opacity: 0, y: 20 }}
                              animate={{ opacity: 1, y: 0 }}
                              transition={{ delay: index * 0.05 }}
                              className="border-glass-border hover:bg-glass-white/50 transition-colors cursor-pointer"
                              onClick={() => setSelectedKeyword(keyword)}
                            >
                              <TableCell>
                                <span className="font-medium text-ink-deep-brown">{keyword.keyword}</span>
                              </TableCell>
                              <TableCell>
                                <Badge className="bg-accent-terra/10 text-accent-terra border-accent-terra/20 capitalize">
                                  {keywordCategories.find(c => c.id === keyword.category)?.name}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                <span className="text-ink-deep-brown">{formatNumber(keyword.searchVolume)}</span>
                              </TableCell>
                              <TableCell>
                                <span className={`font-medium ${keyword.currentRanking && keyword.currentRanking <= 10 ? 'text-green-600' : 'text-ink-deep-brown'}`}>
                                  {keyword.currentRanking || '—'}
                                </span>
                              </TableCell>
                              <TableCell>
                                <span className="text-ink-deep-brown">{keyword.ctr.toFixed(2)}%</span>
                              </TableCell>
                              <TableCell>
                                {getTrendIcon(keyword.trend)}
                              </TableCell>
                            </motion.tr>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  </div>
                </Card>
              </TabsContent>

              {/* Keywords Tab */}
              <TabsContent value="keywords" className="space-y-6">
                {/* Filters */}
                <Card className="glass-card p-6">
                  <div className="flex flex-col lg:flex-row gap-4">
                    <div className="flex-1">
                      <div className="relative">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-ink-soft-brown" />
                        <Input
                          placeholder="Search keywords..."
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          className="input-glass pl-10"
                        />
                      </div>
                    </div>

                    <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                      <SelectTrigger className="w-48 glass-effect border-0">
                        <SelectValue placeholder="Select Category" />
                      </SelectTrigger>
                      <SelectContent className="glass-modal">
                        <SelectItem value="all">All Categories</SelectItem>
                        {keywordCategories.map(category => (
                          <SelectItem key={category.id} value={category.id}>
                            {category.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>

                    <WeDesignButton variant="secondary-outline" size="sm">
                      <Download className="w-4 h-4 mr-2" />
                      Export
                    </WeDesignButton>
                  </div>
                </Card>

                {/* Keywords Table */}
                <Card className="glass-card p-6">
                  {loading ? (
                    <div className="space-y-4">
                      {[...Array(10)].map((_, i) => (
                        <div key={i} className="flex items-center gap-4 p-4">
                          <div className="flex-1 space-y-2">
                            <div className="w-60 h-4 bg-muted/30 rounded animate-pulse"></div>
                            <div className="w-32 h-3 bg-muted/30 rounded animate-pulse"></div>
                          </div>
                          <div className="w-16 h-6 bg-muted/30 rounded animate-pulse"></div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow className="border-glass-border">
                            <TableHead>Keyword</TableHead>
                            <TableHead>Category</TableHead>
                            <TableHead>Search Volume</TableHead>
                            <TableHead>Difficulty</TableHead>
                            <TableHead>CTR</TableHead>
                            <TableHead>Ranking</TableHead>
                            <TableHead>Target URL</TableHead>
                            <TableHead>Actions</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {filteredKeywords.slice(0, 50).map((keyword, index) => (
                            <motion.tr
                              key={keyword.id}
                              initial={{ opacity: 0, y: 20 }}
                              animate={{ opacity: 1, y: 0 }}
                              transition={{ delay: index * 0.02 }}
                              className="border-glass-border hover:bg-glass-white/50 transition-colors"
                            >
                              <TableCell>
                                <div>
                                  <span className="font-medium text-ink-deep-brown">{keyword.keyword}</span>
                                  <div className="flex items-center gap-1 mt-1">
                                    {getTrendIcon(keyword.trend)}
                                  </div>
                                </div>
                              </TableCell>
                              <TableCell>
                                <Badge className="bg-accent-terra/10 text-accent-terra border-accent-terra/20 capitalize text-xs">
                                  {keywordCategories.find(c => c.id === keyword.category)?.name}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                <span className="font-medium text-ink-deep-brown">{formatNumber(keyword.searchVolume)}</span>
                              </TableCell>
                              <TableCell>
                                <div className="flex items-center gap-2">
                                  <span className="text-sm text-ink-deep-brown">{keyword.difficulty}</span>
                                  <div className="w-16 h-2 bg-gray-200 rounded-full overflow-hidden">
                                    <div 
                                      className={`h-full ${
                                        keyword.difficulty > 70 ? 'bg-red-500' :
                                        keyword.difficulty > 40 ? 'bg-yellow-500' : 'bg-green-500'
                                      }`}
                                      style={{ width: `${keyword.difficulty}%` }}
                                    ></div>
                                  </div>
                                </div>
                              </TableCell>
                              <TableCell>
                                <span className="text-ink-deep-brown">{keyword.ctr.toFixed(2)}%</span>
                              </TableCell>
                              <TableCell>
                                <span className={`font-medium ${
                                  keyword.currentRanking && keyword.currentRanking <= 10 ? 'text-green-600' :
                                  keyword.currentRanking && keyword.currentRanking <= 50 ? 'text-yellow-600' :
                                  keyword.currentRanking ? 'text-red-600' : 'text-gray-400'
                                }`}>
                                  {keyword.currentRanking || 'Not ranked'}
                                </span>
                              </TableCell>
                              <TableCell>
                                <a 
                                  href={keyword.targetUrl}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="text-accent-terra hover:text-accent-gold-rich text-sm flex items-center gap-1"
                                >
                                  <span className="truncate max-w-32">{keyword.targetUrl.replace('https://wedesign.com', '')}</span>
                                  <ExternalLink className="w-3 h-3" />
                                </a>
                              </TableCell>
                              <TableCell>
                                <DropdownMenu>
                                  <DropdownMenuTrigger asChild>
                                    <button className="w-8 h-8 glass-effect rounded-lg flex items-center justify-center hover:shadow-glass transition-all">
                                      <MoreHorizontal className="w-4 h-4 text-ink-soft-brown" />
                                    </button>
                                  </DropdownMenuTrigger>
                                  <DropdownMenuContent align="end" className="glass-modal">
                                    <DropdownMenuItem onClick={() => setSelectedKeyword(keyword)}>
                                      <Eye className="w-4 h-4 mr-2" />
                                      View Details
                                    </DropdownMenuItem>
                                    <DropdownMenuItem>
                                      <Edit className="w-4 h-4 mr-2" />
                                      Edit Keyword
                                    </DropdownMenuItem>
                                    <DropdownMenuItem>
                                      <Copy className="w-4 h-4 mr-2" />
                                      Copy URL
                                    </DropdownMenuItem>
                                    <DropdownMenuItem className="text-destructive">
                                      <Trash2 className="w-4 h-4 mr-2" />
                                      Delete
                                    </DropdownMenuItem>
                                  </DropdownMenuContent>
                                </DropdownMenu>
                              </TableCell>
                            </motion.tr>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  )}
                </Card>
              </TabsContent>

              {/* Page Optimization Tab */}
              <TabsContent value="pages" className="space-y-6">
                <Card className="glass-card p-6">
                  <h3 className="text-xl font-heading font-semibold text-ink-deep-brown mb-6">
                    Page SEO Analysis
                  </h3>
                  
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow className="border-glass-border">
                          <TableHead>Page URL</TableHead>
                          <TableHead>Title</TableHead>
                          <TableHead>Meta Description</TableHead>
                          <TableHead>Keywords</TableHead>
                          <TableHead>Schema</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {pageOptimizations.map((page, index) => (
                          <motion.tr
                            key={page.id}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: index * 0.1 }}
                            className="border-glass-border hover:bg-glass-white/50 transition-colors"
                          >
                            <TableCell>
                              <a 
                                href={page.url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-accent-terra hover:text-accent-gold-rich flex items-center gap-1"
                              >
                                <span className="truncate max-w-48">{page.url}</span>
                                <ExternalLink className="w-3 h-3" />
                              </a>
                            </TableCell>
                            <TableCell>
                              <span className="font-medium text-ink-deep-brown truncate max-w-64 block">
                                {page.title}
                              </span>
                            </TableCell>
                            <TableCell>
                              <span className="text-ink-soft-brown text-sm truncate max-w-64 block">
                                {page.metaDescription}
                              </span>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <span className="font-medium text-ink-deep-brown">{page.keywordCount}</span>
                                <div className="flex flex-wrap gap-1 max-w-32">
                                  {page.targetKeywords.slice(0, 2).map((keyword, i) => (
                                    <Badge key={i} className="bg-accent-terra/10 text-accent-terra text-xs">
                                      {keyword}
                                    </Badge>
                                  ))}
                                  {page.targetKeywords.length > 2 && (
                                    <Badge className="bg-gray-100 text-gray-600 text-xs">
                                      +{page.targetKeywords.length - 2}
                                    </Badge>
                                  )}
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge className="bg-blue-100 text-blue-800 border-blue-200 text-xs">
                                {page.schemaType}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <Badge className={`${getStatusColor(page.status)} border text-xs capitalize`}>
                                {page.status.replace('-', ' ')}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <WeDesignButton variant="secondary-outline" size="sm">
                                  <Edit className="w-4 h-4 mr-1" />
                                  Edit
                                </WeDesignButton>
                              </div>
                            </TableCell>
                          </motion.tr>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </Card>
              </TabsContent>

              {/* Settings Tab */}
              <TabsContent value="settings" className="space-y-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Sitemap & Robots */}
                  <Card className="glass-card p-6">
                    <h3 className="text-xl font-heading font-semibold text-ink-deep-brown mb-6">
                      Sitemap & Robots
                    </h3>
                    
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-ink-deep-brown mb-2">
                          Sitemap URL
                        </label>
                        <div className="flex gap-2">
                          <Input 
                            value={seoSettings.sitemapUrl}
                            onChange={(e) => setSeoSettings(prev => ({ ...prev, sitemapUrl: e.target.value }))}
                            className="input-glass"
                          />
                          <WeDesignButton variant="secondary-outline" size="sm">
                            <RefreshCw className="w-4 h-4" />
                          </WeDesignButton>
                        </div>
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-ink-deep-brown mb-2">
                          Robots.txt
                        </label>
                        <Textarea 
                          value={seoSettings.robotsTxt}
                          onChange={(e) => setSeoSettings(prev => ({ ...prev, robotsTxt: e.target.value }))}
                          className="input-glass min-h-32"
                          placeholder="Enter robots.txt content..."
                        />
                      </div>
                    </div>
                  </Card>

                  {/* Analytics */}
                  <Card className="glass-card p-6">
                    <h3 className="text-xl font-heading font-semibold text-ink-deep-brown mb-6">
                      Analytics & Tracking
                    </h3>
                    
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-ink-deep-brown mb-2">
                          Google Analytics ID
                        </label>
                        <Input 
                          value={seoSettings.analytics.googleAnalyticsId}
                          onChange={(e) => setSeoSettings(prev => ({ 
                            ...prev, 
                            analytics: { ...prev.analytics, googleAnalyticsId: e.target.value }
                          }))}
                          className="input-glass"
                          placeholder="GA-XXXXX-X"
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <label className="text-sm font-medium text-ink-deep-brown">
                          Google Search Console
                        </label>
                        <Badge className="bg-green-100 text-green-800">
                          Verified
                        </Badge>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <label className="text-sm font-medium text-ink-deep-brown">
                          Bing Webmaster
                        </label>
                        <Badge className="bg-green-100 text-green-800">
                          Verified
                        </Badge>
                      </div>
                    </div>
                  </Card>

                  {/* Redirects */}
                  <Card className="glass-card p-6 lg:col-span-2">
                    <div className="flex items-center justify-between mb-6">
                      <h3 className="text-xl font-heading font-semibold text-ink-deep-brown">
                        URL Redirects
                      </h3>
                      <WeDesignButton variant="primary-gold" size="sm">
                        <Plus className="w-4 h-4 mr-2" />
                        Add Redirect
                      </WeDesignButton>
                    </div>
                    
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow className="border-glass-border">
                            <TableHead>From URL</TableHead>
                            <TableHead>To URL</TableHead>
                            <TableHead>Type</TableHead>
                            <TableHead>Actions</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {seoSettings.redirects.map((redirect, index) => (
                            <TableRow key={index} className="border-glass-border">
                              <TableCell>
                                <code className="bg-gray-100 px-2 py-1 rounded text-sm">
                                  {redirect.from}
                                </code>
                              </TableCell>
                              <TableCell>
                                <code className="bg-gray-100 px-2 py-1 rounded text-sm">
                                  {redirect.to}
                                </code>
                              </TableCell>
                              <TableCell>
                                <Badge className={`${redirect.type === '301' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'} border-0`}>
                                  {redirect.type}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                <div className="flex items-center gap-2">
                                  <button className="text-accent-terra hover:text-accent-gold-rich">
                                    <Edit className="w-4 h-4" />
                                  </button>
                                  <button className="text-destructive hover:text-destructive/80">
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                </div>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  </Card>
                </div>

                <div className="flex justify-end">
                  <WeDesignButton variant="primary-gold">
                    Save SEO Settings
                  </WeDesignButton>
                </div>
              </TabsContent>
            </Tabs>
          </main>
        </div>
      </div>
    </div>
  );
}