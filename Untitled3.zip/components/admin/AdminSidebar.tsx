import React from 'react';
import { motion } from 'motion/react';
import { 
  LayoutDashboard, Users, MessageSquare, ShoppingCart, CreditCard, 
  FileText, Briefcase, Upload, Search, Settings, Shield, FileCheck,
  ChevronLeft, ChevronRight, Home, LogOut, Bell
} from 'lucide-react';
import { WeDesignButton } from '../design-system/WeDesignButton';
import { Badge } from '../ui/badge';

interface AdminSidebarProps {
  collapsed: boolean;
  onToggle: () => void;
  currentPage: string;
  onNavigate: (page: string) => void;
}

export function AdminSidebar({ collapsed, onToggle, currentPage, onNavigate }: AdminSidebarProps) {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, page: 'admin-dashboard', badge: null },
    { id: 'customers', label: 'Customers', icon: Users, page: 'admin-customers', badge: '2,847' },
    { id: 'interactions', label: 'Interactions', icon: MessageSquare, page: 'admin-interactions', badge: null },
    { id: 'tickets', label: 'Support Tickets', icon: MessageSquare, page: 'admin-tickets', badge: '43' },
    { id: 'orders', label: 'Design Orders', icon: ShoppingCart, page: 'admin-orders', badge: '127' },
    { id: 'finance', label: 'Finance', icon: CreditCard, page: 'admin-finance', badge: null },
    { id: 'blog', label: 'Blog Posts', icon: FileText, page: 'admin-blog', badge: null },
    { id: 'cases', label: 'Case Studies', icon: Briefcase, page: 'admin-cases', badge: null },
    { id: 'seo', label: 'SEO Management', icon: Search, page: 'admin-seo', badge: '1.2K' },
    { id: 'settings', label: 'Settings', icon: Settings, page: 'admin-settings', badge: null },
    { id: 'roles', label: 'Roles & Permissions', icon: Shield, page: 'admin-roles', badge: null },
    { id: 'audit', label: 'Audit Logs', icon: FileCheck, page: 'admin-audit', badge: null }
  ];

  const MenuItem = ({ item, isActive }: { item: any; isActive: boolean }) => (
    <motion.button
      whileHover={{ x: collapsed ? 0 : 4 }}
      whileTap={{ scale: 0.98 }}
      onClick={() => onNavigate(item.page)}
      className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all relative group ${
        isActive 
          ? 'gradient-gold text-white shadow-gold' 
          : 'text-ink-deep-brown hover:bg-glass-white hover:shadow-glass'
      }`}
    >
      <item.icon className={`w-5 h-5 flex-shrink-0 ${isActive ? 'text-white' : 'text-accent-terra'}`} />
      
      {!collapsed && (
        <>
          <span className="font-medium text-sm truncate">{item.label}</span>
          {item.badge && (
            <Badge className={`ml-auto text-xs ${
              isActive 
                ? 'bg-white/20 text-white border-white/30' 
                : 'bg-accent-terra/10 text-accent-terra border-accent-terra/20'
            }`}>
              {item.badge}
            </Badge>
          )}
        </>
      )}

      {/* Tooltip for collapsed state */}
      {collapsed && (
        <div className="absolute left-16 bg-glass-white-strong backdrop-blur-lg border border-glass-border rounded-lg px-3 py-2 text-sm font-medium text-ink-deep-brown shadow-luxury opacity-0 pointer-events-none group-hover:opacity-100 group-hover:pointer-events-auto transition-all duration-200 whitespace-nowrap z-50">
          {item.label}
          {item.badge && (
            <Badge className="ml-2 bg-accent-terra/10 text-accent-terra border-accent-terra/20 text-xs">
              {item.badge}
            </Badge>
          )}
        </div>
      )}
    </motion.button>
  );

  return (
    <motion.div
      initial={{ x: -100 }}
      animate={{ x: 0, width: collapsed ? 80 : 320 }}
      transition={{ duration: 0.3, ease: "easeInOut" }}
      className="fixed left-0 top-0 h-screen glass-navigation border-r border-glass-border z-40 flex flex-col"
    >
      {/* Header */}
      <div className="p-6 border-b border-glass-border">
        <div className="flex items-center justify-between">
          {!collapsed && (
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 gradient-gold rounded-xl flex items-center justify-center shadow-gold">
                <LayoutDashboard className="w-5 h-5 text-white" />
              </div>
              <div>
                <h2 className="font-heading font-bold text-gradient-gold-rich">WeDesign</h2>
                <p className="text-xs text-ink-soft-brown">Admin Console</p>
              </div>
            </div>
          )}
          
          <button
            onClick={onToggle}
            className="w-8 h-8 glass-effect rounded-lg flex items-center justify-center hover:shadow-glass transition-all"
          >
            {collapsed ? (
              <ChevronRight className="w-4 h-4 text-accent-terra" />
            ) : (
              <ChevronLeft className="w-4 h-4 text-accent-terra" />
            )}
          </button>
        </div>
      </div>

      {/* Navigation Menu */}
      <div className="flex-1 overflow-y-auto p-4 space-y-2">
        {menuItems.map((item) => (
          <MenuItem
            key={item.id}
            item={item}
            isActive={currentPage === item.id}
          />
        ))}
      </div>

      {/* Footer Actions */}
      <div className="p-4 border-t border-glass-border space-y-2">
        <button
          onClick={() => onNavigate('home')}
          className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-ink-deep-brown hover:bg-glass-white hover:shadow-glass transition-all"
        >
          <Home className="w-5 h-5 text-accent-terra" />
          {!collapsed && <span className="font-medium text-sm">Back to Website</span>}
        </button>
        
        <button
          onClick={() => onNavigate('login')}
          className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-destructive hover:bg-destructive/10 transition-all"
        >
          <LogOut className="w-5 h-5" />
          {!collapsed && <span className="font-medium text-sm">Sign Out</span>}
        </button>
      </div>
    </motion.div>
  );
}