import { ImageWithFallback } from "../figma/ImageWithFallback";
import { Badge } from "../ui/badge";
import { ExternalLink, Calendar } from "lucide-react";

interface WeDesignCaseCardProps {
  title: string;
  client: string;
  industry: string;
  year: string;
  imageUrl: string;
  description?: string;
  tags?: string[];
  onClick?: () => void;
  className?: string;
}

export function WeDesignCaseCard({
  title,
  client,
  industry,
  year,
  imageUrl,
  description,
  tags = [],
  onClick,
  className = ""
}: WeDesignCaseCardProps) {
  return (
    <div 
      className={`Card_Case group cursor-pointer transition-all duration-300 hover:scale-105 ${className}`}
      onClick={onClick}
    >
      <div className="glass-card rounded-2xl overflow-hidden hover:shadow-glass-lg">
        {/* Image Container */}
        <div className="Container_CaseImage relative aspect-square overflow-hidden">
          <ImageWithFallback
            src={imageUrl}
            alt={`${title} - ${client}`}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
          />
          
          {/* Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <div className="absolute bottom-4 left-4 right-4">
              <div className="glass-effect-strong rounded-xl p-3">
                <div className="flex items-center gap-2 text-white text-sm">
                  <ExternalLink className="w-4 h-4" />
                  View Details
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="Container_CaseContent p-6">
          <div className="mb-3">
            <h3 className="Text_CaseTitle text-lg font-semibold text-ink-deep-brown mb-1 leading-tight">
              {title}
            </h3>
            <p className="Text_ClientName text-muted-foreground text-sm">
              {client}
            </p>
          </div>

          {description && (
            <p className="Text_CaseDescription text-sm text-ink-soft-brown mb-4 line-clamp-2 leading-relaxed">
              {description}
            </p>
          )}

          {/* Meta Information */}
          <div className="Container_CaseMeta flex items-center justify-between">
            <Badge className="Badge_Industry glass-effect text-xs px-2 py-1 border border-glass-border text-accent-terra">
              {industry}
            </Badge>
            
            <div className="flex items-center gap-1 text-xs text-muted-foreground">
              <Calendar className="w-3 h-3" />
              <span className="Text_Year">{year}</span>
            </div>
          </div>

          {/* Tags */}
          {tags.length > 0 && (
            <div className="Container_Tags flex flex-wrap gap-2 mt-4">
              {tags.slice(0, 3).map((tag, index) => (
                <Badge 
                  key={index}
                  className="Badge_Tag glass-effect text-xs bg-accent-terra/5 text-accent-terra-soft border-accent-terra/10"
                >
                  {tag}
                </Badge>
              ))}
              {tags.length > 3 && (
                <Badge className="Badge_More glass-effect text-xs bg-muted/50 text-muted-foreground">
                  +{tags.length - 3}
                </Badge>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}