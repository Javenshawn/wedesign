import { Checkbox } from "../ui/checkbox";
import { Label } from "../ui/label";
import { cn } from "../ui/utils";

interface WeDesignMultiSelectProps {
  label: string;
  options: { value: string; label: string }[];
  selectedValues: string[];
  onSelectionChange: (values: string[]) => void;
  className?: string;
}

export function WeDesignMultiSelect({
  label,
  options,
  selectedValues,
  onSelectionChange,
  className
}: WeDesignMultiSelectProps) {
  const handleToggle = (value: string) => {
    const newSelection = selectedValues.includes(value)
      ? selectedValues.filter(v => v !== value)
      : [...selectedValues, value];
    onSelectionChange(newSelection);
  };

  return (
    <div className={cn("space-y-2", className)}>
      <Label className="text-ink-deep-brown flex items-center gap-1">
        {label.includes('*') ? (
          <>
            {label.replace(' *', '')} 
            <span className="text-accent-terra">*</span>
          </>
        ) : label}
      </Label>
      <div className="grid grid-cols-2 gap-2">
        {options.map((option) => (
          <div 
            key={option.value} 
            className={cn(
              "flex items-center space-x-2 p-2 bg-white rounded-lg border cursor-pointer transition-all duration-200 hover:border-accent-terra/50",
              selectedValues.includes(option.value) 
                ? "border-accent-terra bg-accent-terra/5" 
                : "border-border"
            )}
            onClick={() => handleToggle(option.value)}
          >
            <Checkbox
              id={option.value}
              checked={selectedValues.includes(option.value)}
              onCheckedChange={() => handleToggle(option.value)}
              className="border-border data-[state=checked]:bg-accent-terra data-[state=checked]:border-accent-terra"
            />
            <Label
              htmlFor={option.value}
              className="text-sm text-ink-deep-brown cursor-pointer flex-1"
            >
              {option.label}
            </Label>
          </div>
        ))}
      </div>
      {selectedValues.length > 0 && (
        <div className="flex flex-wrap gap-1 pt-1">
          {selectedValues.map(value => {
            const option = options.find(opt => opt.value === value);
            return option ? (
              <span 
                key={value}
                className="px-2 py-0.5 bg-accent-terra/10 text-accent-terra text-xs rounded border border-accent-terra/20"
              >
                {option.label}
              </span>
            ) : null;
          })}
        </div>
      )}
    </div>
  );
}