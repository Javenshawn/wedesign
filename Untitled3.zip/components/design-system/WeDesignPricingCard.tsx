import { WeDesignButton } from "./WeDesignButton";
import { Check, Star } from "lucide-react";

interface WeDesignPricingCardProps {
  packageName: string;
  price: number;
  originalPrice?: number;
  features: string[];
  isPopular?: boolean;
  onSelect: () => void;
  className?: string;
}

export function WeDesignPricingCard({
  packageName,
  price,
  originalPrice,
  features,
  isPopular = false,
  onSelect,
  className = ""
}: WeDesignPricingCardProps) {
  return (
    <div className={`Card_Pricing relative ${className}`}>
      {isPopular && (
        <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 z-10">
          <div className="gradient-gold-soft px-4 py-2 rounded-full text-white text-sm font-medium flex items-center gap-2 shadow-glass">
            <Star className="w-4 h-4 fill-current" />
            Most Popular
          </div>
        </div>
      )}
      
      <div className={`glass-card rounded-2xl p-8 h-full flex flex-col transition-all duration-300 hover:shadow-glass-lg hover:scale-105 ${
        isPopular ? 'border-2 border-accent-terra/20' : ''
      }`}>
        {/* Package Header */}
        <div className="text-center mb-8">
          <h3 className="text-2xl font-bold text-ink-deep-brown mb-2">
            {packageName}
          </h3>
          
          <div className="flex items-center justify-center gap-2 mb-4">
            {originalPrice && (
              <span className="text-lg text-muted-foreground line-through">
                ${originalPrice}
              </span>
            )}
            <span className="text-4xl font-extrabold text-gradient-gold">
              ${price}
            </span>
          </div>
          
          {originalPrice && (
            <div className="inline-flex items-center gap-1 px-3 py-1 bg-accent-terra/10 text-accent-terra rounded-full text-sm font-medium">
              Save ${originalPrice - price}
            </div>
          )}
        </div>

        {/* Features List */}
        <div className="flex-1 mb-8">
          <ul className="space-y-4">
            {features.map((feature, index) => (
              <li key={index} className="flex items-start gap-3">
                <div className="flex-shrink-0 w-5 h-5 rounded-full gradient-gold-soft flex items-center justify-center mt-0.5">
                  <Check className="w-3 h-3 text-white" />
                </div>
                <span className="text-ink-soft-brown leading-relaxed">
                  {feature}
                </span>
              </li>
            ))}
          </ul>
        </div>

        {/* CTA Button */}
        <WeDesignButton
          variant={isPopular ? "primary-gold" : "secondary-outline"}
          size="lg"
          onClick={onSelect}
          className="w-full"
        >
          Choose {packageName}
        </WeDesignButton>
      </div>
    </div>
  );
}