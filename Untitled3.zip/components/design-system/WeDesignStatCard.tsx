import { Card, CardContent } from "../ui/card";
import { cn } from "../ui/utils";

interface WeDesignStatCardProps {
  number: string;
  label: string;
  icon?: React.ReactNode;
  className?: string;
}

export function WeDesignStatCard({ number, label, icon, className }: WeDesignStatCardProps) {
  return (
    <Card className={cn("border-0 shadow-luxury bg-white", className)}>
      <CardContent className="p-6 text-center">
        {icon && (
          <div className="flex justify-center mb-3 text-accent-terra">
            {icon}
          </div>
        )}
        <div className="text-3xl font-bold text-gradient-gold mb-2" style={{ fontFamily: 'var(--font-heading)' }}>
          {number}
        </div>
        <div className="text-sm text-muted-foreground font-medium">
          {label}
        </div>
      </CardContent>
    </Card>
  );
}