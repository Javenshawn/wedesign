import { Badge } from "../ui/badge";
import { Progress } from "../ui/progress";
import { Clock, Package2 } from "lucide-react";

interface WeDesignTaskCardProps {
  orderNumber: string;
  packageName: string;
  packageType: "Economy" | "Business" | "Private Jet";
  progress: number;
  timeRemaining: string;
  status: "In Progress" | "Review" | "Completed" | "Pending";
  className?: string;
}

export function WeDesignTaskCard({
  orderNumber,
  packageName,
  packageType,
  progress,
  timeRemaining,
  status,
  className = ""
}: WeDesignTaskCardProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "In Progress":
        return "bg-blue-500/10 text-blue-600 border-blue-200/20";
      case "Review":
        return "bg-amber-500/10 text-amber-600 border-amber-200/20";
      case "Completed":
        return "bg-green-500/10 text-green-600 border-green-200/20";
      case "Pending":
        return "bg-muted text-muted-foreground border-border";
      default:
        return "bg-muted text-muted-foreground border-border";
    }
  };

  const getPackageTypeColor = (type: string) => {
    switch (type) {
      case "Economy":
        return "bg-blue-500/10 text-blue-600";
      case "Business":
        return "bg-purple-500/10 text-purple-600";
      case "Private Jet":
        return "bg-gradient-gold-soft text-white";
      default:
        return "bg-muted text-muted-foreground";
    }
  };

  return (
    <div className={`Card_Task glass-card rounded-2xl p-6 hover:shadow-glass-lg hover:scale-105 transition-all duration-300 ${className}`}>
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-2">
          <Package2 className="w-5 h-5 text-accent-terra" />
          <span className="text-sm font-medium text-muted-foreground">
            {orderNumber}
          </span>
        </div>
        <Badge className={`glass-effect text-xs font-medium border ${getStatusColor(status)}`}>
          {status}
        </Badge>
      </div>

      {/* Package Info */}
      <div className="mb-4">
        <h4 className="font-semibold text-ink-deep-brown mb-2 leading-tight">
          {packageName}
        </h4>
        <Badge className={`text-xs font-medium rounded-full ${getPackageTypeColor(packageType)}`}>
          {packageType}
        </Badge>
      </div>

      {/* Progress */}
      <div className="mb-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm text-muted-foreground">Progress</span>
          <span className="text-sm font-medium text-accent-terra">
            {progress}%
          </span>
        </div>
        <Progress 
          value={progress} 
          className="h-2 bg-muted/50 rounded-full overflow-hidden"
        />
      </div>

      {/* Time Remaining */}
      {timeRemaining && (
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Clock className="w-4 h-4" />
          <span>{timeRemaining} remaining</span>
        </div>
      )}
    </div>
  );
}