import { useState } from "react";
import { HelpCircle } from "lucide-react";
import { cn } from "../ui/utils";

interface WeDesignTooltipProps {
  content: string;
  className?: string;
}

export function WeDesignTooltip({ content, className }: WeDesignTooltipProps) {
  const [isVisible, setIsVisible] = useState(false);

  return (
    <div className="relative inline-block">
      <button
        type="button"
        className={cn(
          "w-4 h-4 rounded-full bg-muted text-muted-foreground hover:bg-accent-terra hover:text-white transition-colors duration-200 flex items-center justify-center ml-1",
          className
        )}
        onMouseEnter={() => setIsVisible(true)}
        onMouseLeave={() => setIsVisible(false)}
        onClick={(e) => {
          e.preventDefault();
          setIsVisible(!isVisible);
        }}
      >
        <HelpCircle className="w-3 h-3" />
      </button>
      
      {isVisible && (
        <>
          {/* Backdrop for mobile */}
          <div 
            className="fixed inset-0 z-40 md:hidden" 
            onClick={() => setIsVisible(false)}
          />
          
          {/* Tooltip */}
          <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 z-50">
            <div className="bg-ink-deep-brown text-white text-xs rounded-lg px-3 py-2 max-w-64 shadow-luxury">
              <p className="leading-relaxed">{content}</p>
              {/* Arrow */}
              <div className="absolute top-full left-1/2 transform -translate-x-1/2">
                <div className="border-4 border-transparent border-t-ink-deep-brown"></div>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}