import React, { useState } from 'react';
import { Menu, X, User, LogOut, Settings, ChevronDown } from 'lucide-react';
import weDesignLogo from 'figma:asset/8c46f7864dc2c42f443da12ca2dd22f48b86a8cf.png';

interface HeaderProps {
  currentPage: string;
  onNavigate: (page: string) => void;
  user?: any;
  onSignOut?: () => void;
  onGetStarted?: () => void;
}

export function Header({ currentPage, onNavigate, user, onSignOut, onGetStarted }: HeaderProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);

  const navigation = [
    { name: 'Home', href: 'home' },
    { name: 'Logo Design', href: 'logos-design' },
    { name: 'Design Hall', href: 'design-hall' },
    { name: 'About Us', href: 'about-us' },
    { name: 'Blog', href: 'blog' },
  ];

  const handleNavigation = (page: string) => {
    onNavigate(page);
    setIsOpen(false);
    setShowUserMenu(false);
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 backdrop-blur-xl bg-white/80 border-b border-white/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Logo */}
          <div 
            className="flex items-center cursor-pointer group"
            onClick={() => handleNavigation('home')}
          >
            <img 
              src={weDesignLogo} 
              alt="WeDesign - Worldwide Design, Well Delivered" 
              className="h-10 sm:h-12 md:h-14 w-auto object-contain group-hover:scale-105 transition-transform duration-300"
            />
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-8">
            {navigation.map((item) => (
              <button
                key={item.name}
                onClick={() => handleNavigation(item.href)}
                className={`relative px-4 py-2 rounded-lg font-medium transition-all duration-300 ${
                  currentPage === item.href
                    ? 'text-[#B6652E] bg-white/50 shadow-sm'
                    : 'text-gray-700 hover:text-[#B6652E] hover:bg-white/30'
                }`}
              >
                {item.name}
              </button>
            ))}
          </nav>

          {/* Desktop User Section */}
          <div className="hidden lg:flex items-center space-x-4">
            {user ? (
              <div className="relative">
                <button
                  onClick={() => setShowUserMenu(!showUserMenu)}
                  className="flex items-center space-x-3 px-4 py-2 rounded-xl bg-white/50 hover:bg-white/70 transition-all duration-300 border border-white/20"
                >
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#B6652E] to-[#FFB84D] flex items-center justify-center">
                    <User className="w-4 h-4 text-white" />
                  </div>
                  <span className="font-medium text-gray-900">{user.fullName}</span>
                  <ChevronDown className="w-4 h-4 text-gray-600" />
                </button>

                {/* User Dropdown Menu */}
                {showUserMenu && (
                  <div className="absolute right-0 mt-2 w-56 rounded-xl backdrop-blur-xl bg-white/90 border border-white/20 shadow-xl z-10">
                    <div className="p-4 border-b border-gray-100">
                      <p className="font-medium text-gray-900">{user.fullName}</p>
                      <p className="text-sm text-gray-500">{user.email}</p>
                    </div>
                    <div className="py-2">
                      <button
                        onClick={() => {
                          handleNavigation('user-portal');
                          setShowUserMenu(false);
                        }}
                        className="flex items-center space-x-3 w-full px-4 py-2 text-left text-gray-700 hover:bg-white/50 transition-colors"
                      >
                        <User className="w-4 h-4" />
                        <span>Dashboard</span>
                      </button>
                      <button
                        onClick={() => {
                          handleNavigation('payment-settings');
                          setShowUserMenu(false);
                        }}
                        className="flex items-center space-x-3 w-full px-4 py-2 text-left text-gray-700 hover:bg-white/50 transition-colors"
                      >
                        <Settings className="w-4 h-4" />
                        <span>Settings</span>
                      </button>
                      <hr className="my-2 border-gray-100" />
                      <button
                        onClick={() => {
                          onSignOut?.();
                          setShowUserMenu(false);
                        }}
                        className="flex items-center space-x-3 w-full px-4 py-2 text-left text-red-600 hover:bg-red-50 transition-colors"
                      >
                        <LogOut className="w-4 h-4" />
                        <span>Sign Out</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center space-x-3">
                <button
                  onClick={() => handleNavigation('login')}
                  className="px-6 py-2 text-gray-700 hover:text-[#B6652E] font-medium transition-colors"
                >
                  Sign In
                </button>
                <button
                  onClick={onGetStarted || (() => handleNavigation('login'))}
                  className="px-6 py-2 bg-gradient-to-r from-[#B6652E] to-[#FFB84D] text-white rounded-xl font-medium hover:shadow-lg transform hover:-translate-y-0.5 transition-all duration-300"
                >
                  Get Started
                </button>
              </div>
            )}
          </div>

          {/* Mobile menu button - Enhanced touch target */}
          <div className="lg:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="touch-target p-3 rounded-lg bg-white/50 hover:bg-white/70 transition-all duration-300 min-w-[44px] min-h-[44px] flex items-center justify-center"
            >
              {isOpen ? (
                <X className="w-6 h-6 text-gray-600" />
              ) : (
                <Menu className="w-6 h-6 text-gray-600" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="lg:hidden py-4 border-t border-white/20 mobile-compact">
            {/* Mobile Logo */}
            <div className="mb-6 flex justify-center">
              <img 
                src={weDesignLogo} 
                alt="WeDesign - Worldwide Design, Well Delivered" 
                className="h-10 w-auto object-contain"
              />
            </div>
            
            <nav className="space-y-2">
              {navigation.map((item) => (
                <button
                  key={item.name}
                  onClick={() => handleNavigation(item.href)}
                  className={`touch-target block w-full text-left px-4 py-4 rounded-lg font-medium transition-all duration-300 min-h-[48px] ${
                    currentPage === item.href
                      ? 'text-[#B6652E] bg-white/50 shadow-sm'
                      : 'text-gray-700 hover:text-[#B6652E] hover:bg-white/30'
                  }`}
                >
                  {item.name}
                </button>
              ))}
              
              {/* Mobile User Section */}
              <div className="pt-4 border-t border-white/20 mt-4">
                {user ? (
                  <div className="space-y-2">
                    <div className="px-4 py-2">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#B6652E] to-[#FFB84D] flex items-center justify-center">
                          <User className="w-4 h-4 text-white" />
                        </div>
                        <div>
                          <p className="font-medium text-gray-900">{user.fullName}</p>
                          <p className="text-sm text-gray-500">{user.email}</p>
                        </div>
                      </div>
                    </div>
                    <button
                      onClick={() => handleNavigation('user-portal')}
                      className="touch-target flex items-center space-x-3 w-full px-4 py-4 text-left text-gray-700 hover:bg-white/50 rounded-lg transition-colors min-h-[48px]"
                    >
                      <User className="w-4 h-4" />
                      <span>Dashboard</span>
                    </button>
                    <button
                      onClick={() => handleNavigation('payment-settings')}
                      className="touch-target flex items-center space-x-3 w-full px-4 py-4 text-left text-gray-700 hover:bg-white/50 rounded-lg transition-colors min-h-[48px]"
                    >
                      <Settings className="w-4 h-4" />
                      <span>Settings</span>
                    </button>
                    <button
                      onClick={() => onSignOut?.()}
                      className="touch-target flex items-center space-x-3 w-full px-4 py-4 text-left text-red-600 hover:bg-red-50 rounded-lg transition-colors min-h-[48px]"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>Sign Out</span>
                    </button>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <button
                      onClick={() => handleNavigation('login')}
                      className="touch-target block w-full px-4 py-4 text-center text-gray-700 hover:text-[#B6652E] font-medium transition-colors min-h-[48px] rounded-lg"
                    >
                      Sign In
                    </button>
                    <button
                      onClick={onGetStarted || (() => handleNavigation('login'))}
                      className="touch-target block w-full px-4 py-4 bg-gradient-to-r from-[#B6652E] to-[#FFB84D] text-white rounded-lg font-medium text-center min-h-[48px]"
                    >
                      Get Started
                    </button>
                  </div>
                )}
              </div>
            </nav>
          </div>
        )}
      </div>

      {/* Click outside to close user menu */}
      {showUserMenu && (
        <div 
          className="fixed inset-0 z-0" 
          onClick={() => setShowUserMenu(false)}
        />
      )}
    </header>
  );
}