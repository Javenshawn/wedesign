import { useState } from "react";
import { X, ArrowRight } from "lucide-react";
import { WeDesignButton } from "../design-system/WeDesignButton";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Textarea } from "../ui/textarea";

interface OptimizedRequestModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedPackage?: {
    type: string;
    name: string;
    price: string;
  };
}

export function OptimizedRequestModal({ isOpen, onClose, selectedPackage }: OptimizedRequestModalProps) {
  const [formData, setFormData] = useState({
    logoName: "",
    industry: "",
    email: "",
    colorPreferences: "",
    description: "",
    timeline: ""
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Form submitted:", formData);
    // TODO: Handle form submission
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="Overlay_BlurBackground fixed inset-0 z-50 flex items-center justify-center">
      {/* Background Overlay with Blur */}
      <div 
        className="absolute inset-0 bg-black/40"
        style={{ backdropFilter: 'blur(8px)' }}
        onClick={onClose}
      />
      
      {/* Modal Container */}
      <div className="Modal_RequestBrief_Optimized relative w-[720px] max-w-[90vw] bg-bg-light-ivory rounded-2xl shadow-luxury-lg mx-4">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-6 right-6 w-8 h-8 rounded-full bg-white/80 hover:bg-white flex items-center justify-center transition-colors duration-200 z-10"
        >
          <X className="w-4 h-4 text-ink-deep-brown" />
        </button>

        {/* Modal Content */}
        <div className="px-10 py-8">
          {/* Header */}
          <div className="text-center mb-8">
            <h2 
              className="text-3xl mb-4"
              style={{ fontFamily: 'var(--font-heading)' }}
            >
              Start Your Design Journey
            </h2>
            <div className="w-16 h-1 gradient-gold mx-auto rounded-full mb-4"></div>
            <p className="text-muted-foreground max-w-md mx-auto">
              Tell us about your brand vision and we'll create the perfect logo design for you
            </p>
          </div>

          {/* Selected Package Display */}
          {selectedPackage && (
            <div className="bg-white/50 p-4 rounded-lg border border-accent-terra/20 mb-6">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-semibold text-ink-deep-brown">{selectedPackage.name}</h4>
                  <p className="text-sm text-muted-foreground">Selected Package</p>
                </div>
                <div className="text-2xl font-bold text-gradient-gold">{selectedPackage.price}</div>
              </div>
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Logo Name Field */}
            <div className="flex flex-col items-center">
              <Label htmlFor="Input_LogoName" className="self-start mb-2 text-ink-deep-brown">
                Logo Name <span className="text-accent-terra">*</span>
              </Label>
              <Input
                id="Input_LogoName"
                className="w-4/5 h-12 bg-white border border-border rounded-lg focus:border-accent-terra focus:ring-2 focus:ring-accent-terra/20"
                placeholder="Enter your company/brand name"
                value={formData.logoName}
                onChange={(e) => setFormData(prev => ({ ...prev, logoName: e.target.value }))}
                required
              />
            </div>

            {/* Industry Field */}
            <div className="flex flex-col items-center">
              <Label className="self-start mb-2 text-ink-deep-brown">
                Industry <span className="text-accent-terra">*</span>
              </Label>
              <Select value={formData.industry} onValueChange={(value) => setFormData(prev => ({ ...prev, industry: value }))}>
                <SelectTrigger className="Select_Industry w-4/5 h-12 bg-white border border-border rounded-lg focus:border-accent-terra">
                  <SelectValue placeholder="Select your industry" />
                </SelectTrigger>
                <SelectContent className="bg-white border border-border shadow-luxury">
                  <SelectItem value="technology">Technology</SelectItem>
                  <SelectItem value="healthcare">Healthcare</SelectItem>
                  <SelectItem value="finance">Finance</SelectItem>
                  <SelectItem value="retail">Retail</SelectItem>
                  <SelectItem value="food-beverage">Food & Beverage</SelectItem>
                  <SelectItem value="fashion">Fashion</SelectItem>
                  <SelectItem value="education">Education</SelectItem>
                  <SelectItem value="real-estate">Real Estate</SelectItem>
                  <SelectItem value="consulting">Consulting</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Email Field */}
            <div className="flex flex-col items-center">
              <Label htmlFor="Input_Email" className="self-start mb-2 text-ink-deep-brown">
                Email Address <span className="text-accent-terra">*</span>
              </Label>
              <Input
                id="Input_Email"
                type="email"
                className="w-4/5 h-12 bg-white border border-border rounded-lg focus:border-accent-terra focus:ring-2 focus:ring-accent-terra/20"
                placeholder="your@email.com"
                value={formData.email}
                onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                required
              />
            </div>

            {/* Color Preferences Field */}
            <div className="flex flex-col items-center">
              <Label className="self-start mb-2 text-ink-deep-brown">
                Color Preferences
              </Label>
              <Select value={formData.colorPreferences} onValueChange={(value) => setFormData(prev => ({ ...prev, colorPreferences: value }))}>
                <SelectTrigger className="Select_ColorPreferences w-4/5 h-12 bg-white border border-border rounded-lg focus:border-accent-terra">
                  <SelectValue placeholder="Choose your preferred color palette" />
                </SelectTrigger>
                <SelectContent className="bg-white border border-border shadow-luxury">
                  <SelectItem value="blue">Blue Tones</SelectItem>
                  <SelectItem value="green">Green Tones</SelectItem>
                  <SelectItem value="red">Red Tones</SelectItem>
                  <SelectItem value="purple">Purple Tones</SelectItem>
                  <SelectItem value="orange">Orange Tones</SelectItem>
                  <SelectItem value="black-white">Black & White</SelectItem>
                  <SelectItem value="earth">Earth Tones</SelectItem>
                  <SelectItem value="rainbow">Colorful/Rainbow</SelectItem>
                  <SelectItem value="no-preference">No Preference</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Timeline Field */}
            <div className="flex flex-col items-center">
              <Label className="self-start mb-2 text-ink-deep-brown">
                Project Timeline
              </Label>
              <Select value={formData.timeline} onValueChange={(value) => setFormData(prev => ({ ...prev, timeline: value }))}>
                <SelectTrigger className="Select_Timeline w-4/5 h-12 bg-white border border-border rounded-lg focus:border-accent-terra">
                  <SelectValue placeholder="When do you need your logo?" />
                </SelectTrigger>
                <SelectContent className="bg-white border border-border shadow-luxury">
                  <SelectItem value="asap">ASAP (Rush Order)</SelectItem>
                  <SelectItem value="1-week">Within 1 Week</SelectItem>
                  <SelectItem value="2-weeks">Within 2 Weeks</SelectItem>
                  <SelectItem value="1-month">Within 1 Month</SelectItem>
                  <SelectItem value="flexible">I'm Flexible</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Description Field */}
            <div className="flex flex-col items-center">
              <Label htmlFor="Textarea_Description" className="self-start mb-2 text-ink-deep-brown">
                Design Description
              </Label>
              <Textarea
                id="Textarea_Description"
                className="w-4/5 min-h-[120px] bg-white border border-border rounded-lg focus:border-accent-terra focus:ring-2 focus:ring-accent-terra/20 resize-none"
                placeholder="Describe your vision, target audience, brand values, and any specific requirements..."
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              />
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-5 pt-6">
              <WeDesignButton
                type="button"
                variant="secondary-outline"
                size="lg"
                onClick={onClose}
                className="w-full sm:w-auto px-8 py-3.5 border-ink-deep-brown text-ink-deep-brown hover:bg-ink-deep-brown hover:text-white"
              >
                Cancel
              </WeDesignButton>
              <WeDesignButton
                type="submit"
                variant="primary-gold"
                size="lg"
                className="w-full sm:w-auto px-8 py-3.5 gradient-gold text-white"
              >
                Submit Brief <ArrowRight className="w-4 h-4 ml-2" />
              </WeDesignButton>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}