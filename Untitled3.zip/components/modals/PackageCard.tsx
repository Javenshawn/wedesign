import React from 'react';
import { Check, Star, LucideIcon } from 'lucide-react';
import { WeDesignButton } from '../design-system/WeDesignButton';

interface PackageCardProps {
  name: string;
  icon: LucideIcon;
  price: number;
  originalPrice?: number;
  features: string[];
  isPopular?: boolean;
  description: string;
  onSelect: () => void;
  className?: string;
}

export function PackageCard({
  name,
  icon: Icon,
  price,
  originalPrice,
  features,
  isPopular = false,
  description,
  onSelect,
  className = ""
}: PackageCardProps) {
  return (
    <div className={`relative ${className}`}>
      {isPopular && (
        <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 z-10">
          <div className="gradient-gold px-4 py-2 rounded-full text-white text-sm font-semibold flex items-center gap-2 shadow-luxury">
            <Star className="w-4 h-4 fill-current" />
            Most Popular
          </div>
        </div>
      )}
      
      <div className={`glass-card rounded-2xl p-6 h-full flex flex-col transition-all duration-300 hover:shadow-luxury-lg hover:scale-[1.02] ${
        isPopular ? 'border-2 border-accent-terra/30' : ''
      }`}>
        {/* Package Header */}
        <div className="text-center mb-6">
          <div className="flex items-center justify-center mb-3">
            <div className="gradient-gold-soft p-3 rounded-xl">
              <Icon className="w-5 h-5 text-white" />
            </div>
          </div>
          
          <h3 className="font-heading text-xl font-bold text-ink-deep-brown mb-2">
            {name}
          </h3>
          
          <p className="font-body text-sm text-ink-soft-brown mb-4">
            {description}
          </p>
          
          <div className="flex items-center justify-center gap-2 mb-3">
            {originalPrice && (
              <span className="text-lg text-muted-foreground line-through">
                ${originalPrice}
              </span>
            )}
            <span className="font-heading text-3xl font-extrabold text-gradient-gold-rich">
              ${price}
            </span>
          </div>
          
          {originalPrice && (
            <div className="inline-flex items-center gap-1 px-3 py-1 bg-accent-terra/10 text-accent-terra rounded-full text-sm font-semibold">
              Save ${originalPrice - price}
            </div>
          )}
        </div>

        {/* Features List */}
        <div className="flex-1 mb-6">
          <ul className="space-y-3">
            {features.map((feature, index) => (
              <li key={index} className="flex items-start gap-3">
                <div className="flex-shrink-0 w-5 h-5 rounded-full gradient-gold flex items-center justify-center mt-0.5">
                  <Check className="w-3 h-3 text-white" />
                </div>
                <span className="font-body text-sm text-ink-soft-brown leading-relaxed">
                  {feature}
                </span>
              </li>
            ))}
          </ul>
        </div>

        {/* CTA Button */}
        <WeDesignButton
          variant={isPopular ? "primary-gold" : "secondary-outline"}
          size="lg"
          onClick={onSelect}
          className="w-full touch-target"
        >
          Choose {name}
        </WeDesignButton>
      </div>
    </div>
  );
}