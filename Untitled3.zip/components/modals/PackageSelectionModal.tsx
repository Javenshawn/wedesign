import React from 'react';
import { X, Sparkles } from 'lucide-react';
import { PackageCard } from './PackageCard';
import { packages } from './package-constants';

interface PackageSelectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectPackage: (packageName: string, price: number) => void;
}

export function PackageSelectionModal({ isOpen, onClose, onSelectPackage }: PackageSelectionModalProps) {
  if (!isOpen) return null;

  const handlePackageSelect = (packageName: string, price: number) => {
    onSelectPackage(packageName, price);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/40 backdrop-blur-sm"
        onClick={onClose}
      />
      
      {/* Modal Content */}
      <div className="relative w-full max-w-7xl mx-4 max-h-[90vh] overflow-hidden">
        <div className="glass-modal rounded-3xl p-8 overflow-y-auto max-h-[90vh]">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 gradient-gold rounded-2xl flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="font-heading text-2xl md:text-3xl font-bold text-gradient-gold-rich">
                  Choose Your Design Package
                </h2>
                <p className="font-body text-ink-soft-brown mt-1">
                  Professional logo design with unlimited revisions
                </p>
              </div>
            </div>
            
            <button
              onClick={onClose}
              className="p-2 rounded-xl glass-effect hover:glass-effect-strong transition-all duration-300 group"
            >
              <X className="w-5 h-5 text-ink-deep-brown group-hover:text-accent-terra transition-colors" />
            </button>
          </div>

          {/* Trust Indicators */}
          <div className="flex items-center justify-center gap-6 mb-8 flex-wrap">
            <div className="glass-effect px-4 py-2 rounded-xl">
              <span className="font-body text-sm text-ink-soft-brown">✨ 5,000+ businesses</span>
            </div>
            <div className="glass-effect px-4 py-2 rounded-xl">
              <span className="font-body text-sm text-ink-soft-brown">⭐ 4.9/5 rating</span>
            </div>
            <div className="glass-effect px-4 py-2 rounded-xl">
              <span className="font-body text-sm text-ink-soft-brown">⚡ 2 hour response</span>
            </div>
          </div>

          {/* Package Cards */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {packages.map((pkg, index) => (
              <PackageCard
                key={pkg.name}
                name={pkg.name}
                icon={pkg.icon}
                price={pkg.price}
                originalPrice={pkg.originalPrice}
                features={pkg.features}
                isPopular={pkg.isPopular}
                description={pkg.description}
                onSelect={() => handlePackageSelect(pkg.name, pkg.price)}
                className={index === 1 ? 'lg:scale-105' : ''}
              />
            ))}
          </div>

          {/* Footer */}
          <div className="mt-8 text-center">
            <div className="glass-effect rounded-xl p-4">
              <p className="font-body text-sm text-ink-soft-brown">
                🔒 <strong>100% Money-Back Guarantee</strong> • All packages include unlimited revisions until you're completely satisfied
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}