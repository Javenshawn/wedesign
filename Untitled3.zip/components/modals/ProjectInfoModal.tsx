import React, { useState } from 'react';
import { X, ArrowRight, ArrowLeft, Building2, Briefcase, Palette, CreditCard, Check, User } from 'lucide-react';
import { WeDesignButton } from '../design-system/WeDesignButton';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Checkbox } from '../ui/checkbox';

interface ProjectInfoModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedPackage: {
    name: string;
    price: number;
  } | null;
  onProceedToPayment: (projectInfo: any) => void;
}

interface ProjectInfo {
  // Company Info
  companyName: string;
  contactName: string;
  email: string;
  phone: string;
  
  // Project Details
  projectType: string;
  industry: string;
  projectDescription: string;
  timeline: string;
  
  // Design Preferences
  designStyle: string[];
  colorPreferences: string;
  inspiration: string;
  
  // Additional Info
  targetAudience: string;
  specialRequirements: string;
}

const steps = [
  {
    title: "Company Information",
    icon: Building2,
    description: "Tell us about your business"
  },
  {
    title: "Project Details", 
    icon: Briefcase,
    description: "Describe your design needs"
  },
  {
    title: "Design Preferences",
    icon: Palette,
    description: "Share your style preferences"
  },
  {
    title: "Review & Payment",
    icon: CreditCard,
    description: "Confirm details and proceed"
  }
];

const designStyles = [
  "Modern & Minimalist",
  "Classic & Traditional", 
  "Bold & Creative",
  "Elegant & Luxury",
  "Tech & Digital",
  "Organic & Natural",
  "Playful & Fun",
  "Corporate & Professional"
];

const industries = [
  "Technology", "Healthcare", "Finance", "Education", "Retail", 
  "Food & Beverage", "Real Estate", "Consulting", "Manufacturing", 
  "Entertainment", "Non-Profit", "Other"
];

const projectTypes = [
  "New Brand Identity", "Logo Redesign", "Brand Refresh", 
  "Startup Branding", "Sub-brand Creation", "Event Branding"
];

export function ProjectInfoModal({ isOpen, onClose, selectedPackage, onProceedToPayment }: ProjectInfoModalProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [projectInfo, setProjectInfo] = useState<ProjectInfo>({
    companyName: '',
    contactName: '',
    email: '',
    phone: '',
    projectType: '',
    industry: '',
    projectDescription: '',
    timeline: '',
    designStyle: [],
    colorPreferences: '',
    inspiration: '',
    targetAudience: '',
    specialRequirements: ''
  });

  if (!isOpen || !selectedPackage) return null;

  const updateProjectInfo = (field: keyof ProjectInfo, value: any) => {
    setProjectInfo(prev => ({ ...prev, [field]: value }));
  };

  const toggleDesignStyle = (style: string) => {
    setProjectInfo(prev => ({
      ...prev,
      designStyle: prev.designStyle.includes(style) 
        ? prev.designStyle.filter(s => s !== style)
        : [...prev.designStyle, style]
    }));
  };

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSubmit = () => {
    onProceedToPayment(projectInfo);
    onClose();
  };

  const isStepValid = () => {
    switch (currentStep) {
      case 0:
        return projectInfo.companyName && projectInfo.contactName && projectInfo.email;
      case 1:
        return projectInfo.projectType && projectInfo.industry && projectInfo.projectDescription;
      case 2:
        return projectInfo.designStyle.length > 0;
      case 3:
        return true;
      default:
        return false;
    }
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 0:
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block font-body text-sm font-semibold text-ink-deep-brown mb-2">
                  Company Name *
                </label>
                <Input
                  placeholder="Enter your company name"
                  value={projectInfo.companyName}
                  onChange={(e) => updateProjectInfo('companyName', e.target.value)}
                  className="input-glass"
                />
              </div>
              <div>
                <label className="block font-body text-sm font-semibold text-ink-deep-brown mb-2">
                  Contact Name *
                </label>
                <Input
                  placeholder="Your full name"
                  value={projectInfo.contactName}
                  onChange={(e) => updateProjectInfo('contactName', e.target.value)}
                  className="input-glass"
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block font-body text-sm font-semibold text-ink-deep-brown mb-2">
                  Email Address *
                </label>
                <Input
                  type="email"
                  placeholder="your@email.com"
                  value={projectInfo.email}
                  onChange={(e) => updateProjectInfo('email', e.target.value)}
                  className="input-glass"
                />
              </div>
              <div>
                <label className="block font-body text-sm font-semibold text-ink-deep-brown mb-2">
                  Phone Number
                </label>
                <Input
                  placeholder="+1 (555) 123-4567"
                  value={projectInfo.phone}
                  onChange={(e) => updateProjectInfo('phone', e.target.value)}
                  className="input-glass"
                />
              </div>
            </div>
          </div>
        );

      case 1:
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block font-body text-sm font-semibold text-ink-deep-brown mb-2">
                  Project Type *
                </label>
                <Select value={projectInfo.projectType} onValueChange={(value) => updateProjectInfo('projectType', value)}>
                  <SelectTrigger className="input-glass">
                    <SelectValue placeholder="Select project type" />
                  </SelectTrigger>
                  <SelectContent>
                    {projectTypes.map((type) => (
                      <SelectItem key={type} value={type}>{type}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="block font-body text-sm font-semibold text-ink-deep-brown mb-2">
                  Industry *
                </label>
                <Select value={projectInfo.industry} onValueChange={(value) => updateProjectInfo('industry', value)}>
                  <SelectTrigger className="input-glass">
                    <SelectValue placeholder="Select your industry" />
                  </SelectTrigger>
                  <SelectContent>
                    {industries.map((industry) => (
                      <SelectItem key={industry} value={industry}>{industry}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <label className="block font-body text-sm font-semibold text-ink-deep-brown mb-2">
                Project Description *
              </label>
              <Textarea
                placeholder="Describe your project, goals, and what success looks like to you..."
                value={projectInfo.projectDescription}
                onChange={(e) => updateProjectInfo('projectDescription', e.target.value)}
                className="input-glass min-h-[100px]"
              />
            </div>

            <div>
              <label className="block font-body text-sm font-semibold text-ink-deep-brown mb-2">
                Timeline
              </label>
              <Select value={projectInfo.timeline} onValueChange={(value) => updateProjectInfo('timeline', value)}>
                <SelectTrigger className="input-glass">
                  <SelectValue placeholder="When do you need this completed?" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="asap">ASAP (Rush delivery)</SelectItem>
                  <SelectItem value="1-week">Within 1 week</SelectItem>
                  <SelectItem value="2-weeks">Within 2 weeks</SelectItem>
                  <SelectItem value="1-month">Within 1 month</SelectItem>
                  <SelectItem value="flexible">Flexible timeline</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <div>
              <label className="block font-body text-sm font-semibold text-ink-deep-brown mb-4">
                Design Style Preferences * (Select all that apply)
              </label>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {designStyles.map((style) => (
                  <div key={style} className="flex items-center space-x-2">
                    <Checkbox
                      id={style}
                      checked={projectInfo.designStyle.includes(style)}
                      onCheckedChange={() => toggleDesignStyle(style)}
                    />
                    <label htmlFor={style} className="font-body text-sm text-ink-soft-brown cursor-pointer">
                      {style}
                    </label>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <label className="block font-body text-sm font-semibold text-ink-deep-brown mb-2">
                Color Preferences
              </label>
              <Input
                placeholder="e.g., Blue and gold, warm earth tones, bright and energetic..."
                value={projectInfo.colorPreferences}
                onChange={(e) => updateProjectInfo('colorPreferences', e.target.value)}
                className="input-glass"
              />
            </div>

            <div>
              <label className="block font-body text-sm font-semibold text-ink-deep-brown mb-2">
                Inspiration & References
              </label>
              <Textarea
                placeholder="Share any logos, brands, or designs you admire. Include URLs if possible..."
                value={projectInfo.inspiration}
                onChange={(e) => updateProjectInfo('inspiration', e.target.value)}
                className="input-glass min-h-[80px]"
              />
            </div>

            <div>
              <label className="block font-body text-sm font-semibold text-ink-deep-brown mb-2">
                Target Audience
              </label>
              <Input
                placeholder="Who is your target customer? Age, demographics, interests..."
                value={projectInfo.targetAudience}
                onChange={(e) => updateProjectInfo('targetAudience', e.target.value)}
                className="input-glass"
              />
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            {/* Order Summary */}
            <div className="glass-card rounded-2xl p-6">
              <h3 className="font-heading text-xl font-bold text-ink-deep-brown mb-4">Order Summary</h3>
              <div className="flex justify-between items-center mb-4">
                <span className="font-body text-ink-soft-brown">{selectedPackage.name} Package</span>
                <span className="font-heading text-2xl font-bold text-gradient-gold-rich">${selectedPackage.price}</span>
              </div>
              <div className="border-t border-glass-border pt-4">
                <div className="flex justify-between items-center">
                  <span className="font-body font-semibold text-ink-deep-brown">Total</span>
                  <span className="font-heading text-2xl font-bold text-gradient-gold-rich">${selectedPackage.price}</span>
                </div>
              </div>
            </div>

            {/* Project Summary */}
            <div className="glass-effect rounded-xl p-4">
              <h4 className="font-heading font-semibold text-ink-deep-brown mb-3">Project Summary</h4>
              <div className="space-y-2 text-sm">
                <div><strong>Company:</strong> {projectInfo.companyName}</div>
                <div><strong>Project:</strong> {projectInfo.projectType} for {projectInfo.industry}</div>
                <div><strong>Style:</strong> {projectInfo.designStyle.join(', ')}</div>
                {projectInfo.timeline && <div><strong>Timeline:</strong> {projectInfo.timeline}</div>}
              </div>
            </div>

            {/* Account Creation Info */}
            <div className="glass-effect rounded-xl p-4">
              <div className="flex items-start space-x-2">
                <div className="w-5 h-5 gradient-gold rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                  <User className="w-3 h-3 text-white" />
                </div>
                <div>
                  <h4 className="font-body font-semibold text-ink-deep-brown mb-1">Account Creation</h4>
                  <p className="font-body text-sm text-ink-soft-brown">
                    We'll create a project management account for <strong>{projectInfo.companyName}</strong> with initial password <strong>888888</strong>. 
                    You can change this after your first login.
                  </p>
                </div>
              </div>
            </div>

            {/* Terms */}
            <div className="glass-effect rounded-xl p-4">
              <div className="flex items-start space-x-2">
                <Checkbox id="terms" className="mt-1" />
                <label htmlFor="terms" className="font-body text-sm text-ink-soft-brown">
                  I agree to the <span className="text-accent-terra hover:underline cursor-pointer">Terms of Service</span> and 
                  <span className="text-accent-terra hover:underline cursor-pointer"> Privacy Policy</span>. 
                  I understand that all packages include unlimited revisions until complete satisfaction.
                </label>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/40 backdrop-blur-sm"
        onClick={onClose}
      />
      
      {/* Modal Content */}
      <div className="relative w-full max-w-4xl max-h-[90vh] overflow-hidden">
        <div className="glass-modal rounded-3xl p-8 overflow-y-auto max-h-[90vh]">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 gradient-gold rounded-2xl flex items-center justify-center">
                {React.createElement(steps[currentStep].icon, { className: "w-6 h-6 text-white" })}
              </div>
              <div>
                <h2 className="font-heading text-2xl font-bold text-gradient-gold-rich">
                  {steps[currentStep].title}
                </h2>
                <p className="font-body text-ink-soft-brown">
                  {steps[currentStep].description}
                </p>
              </div>
            </div>
            
            <button
              onClick={onClose}
              className="p-2 rounded-xl glass-effect hover:glass-effect-strong transition-all duration-300 group"
            >
              <X className="w-5 h-5 text-ink-deep-brown group-hover:text-accent-terra transition-colors" />
            </button>
          </div>

          {/* Progress Steps */}
          <div className="flex justify-between items-center mb-8">
            {steps.map((step, index) => (
              <div key={index} className="flex items-center">
                <div className={`flex items-center justify-center w-8 h-8 rounded-full border-2 transition-all duration-300 ${
                  index <= currentStep 
                    ? 'border-accent-terra bg-accent-terra text-white' 
                    : 'border-glass-border bg-glass-white text-ink-soft-brown'
                }`}>
                  {index < currentStep ? (
                    <Check className="w-4 h-4" />
                  ) : (
                    <span>{index + 1}</span>
                  )}
                </div>
                {index < steps.length - 1 && (
                  <div className={`w-16 h-0.5 mx-2 transition-all duration-300 ${
                    index < currentStep ? 'bg-accent-terra' : 'bg-glass-border'
                  }`} />
                )}
              </div>
            ))}
          </div>

          {/* Step Content */}
          <div className="mb-8">
            {renderStepContent()}
          </div>

          {/* Footer */}
          <div className="flex justify-between items-center">
            <div>
              {currentStep > 0 && (
                <WeDesignButton
                  variant="secondary-outline"
                  onClick={prevStep}
                  className="flex items-center gap-2"
                >
                  <ArrowLeft className="w-4 h-4" />
                  Previous
                </WeDesignButton>
              )}
            </div>
            
            <div className="flex items-center gap-3">
              <span className="font-body text-sm text-ink-soft-brown">
                Step {currentStep + 1} of {steps.length}
              </span>
              
              {currentStep < steps.length - 1 ? (
                <WeDesignButton
                  variant="primary-gold"
                  onClick={nextStep}
                  disabled={!isStepValid()}
                  className="flex items-center gap-2"
                >
                  Next
                  <ArrowRight className="w-4 h-4" />
                </WeDesignButton>
              ) : (
                <WeDesignButton
                  variant="primary-gold"
                  onClick={handleSubmit}
                  className="flex items-center gap-2"
                >
                  Create Account & Checkout
                  <ArrowRight className="w-4 h-4" />
                </WeDesignButton>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}