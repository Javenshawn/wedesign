import exampleImage from 'figma:asset/3a56065e92c972a28f00ff7bf6b87e5139253246.png';
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "../ui/dialog";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Textarea } from "../ui/textarea";
import { WeDesignButton } from "../design-system/WeDesignButton";
import { WeDesignMultiSelect } from "../design-system/WeDesignMultiSelect";
import { WeDesignFileUpload } from "../design-system/WeDesignFileUpload";
import { Badge } from "../ui/badge";
import { CheckCircle, CreditCard, ArrowRight, ArrowLeft } from "lucide-react";

interface RequestBriefModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedPackage?: {
    type: string;
    name: string;
    price: string;
  };
}

export function RequestBriefModal({ isOpen, onClose, selectedPackage }: RequestBriefModalProps) {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    logoName: "",
    industry: "",
    email: "",
    designStyles: [] as string[],
    colorPreferences: "",
    description: "",
    referenceFile: null as File | null
  });

  const designStyleOptions = [
    { value: "minimalist", label: "Minimalist" },
    { value: "modern", label: "Modern" },
    { value: "classic", label: "Classic" },
    { value: "playful", label: "Playful" },
    { value: "elegant", label: "Elegant" },
    { value: "bold", label: "Bold" }
  ];

  const handleNext = (e: React.MouseEvent) => {
    e.preventDefault();
    if (currentStep === 1 && isStep1Valid) {
      setCurrentStep(2);
    }
  };

  const handleBack = (e: React.MouseEvent) => {
    e.preventDefault();
    if (currentStep === 2) {
      setCurrentStep(1);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Form submitted:", formData);
    // TODO: Handle form submission and payment
  };

  const isStep1Valid = formData.logoName.trim() !== "" && formData.industry !== "" && formData.email.trim() !== "";

  const StepIndicator = ({ step, label, isActive, isCompleted }: { 
    step: number; 
    label: string; 
    isActive: boolean; 
    isCompleted: boolean; 
  }) => (
    <div className="flex items-center gap-2">
      <div className={`relative w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium transition-all duration-300 ${
        isCompleted 
          ? 'gradient-gold text-white' 
          : isActive 
            ? 'gradient-gold text-white' 
            : 'bg-muted text-muted-foreground'
      }`}>
        {isCompleted ? <CheckCircle className="w-4 h-4" /> : step}
      </div>
      <span className={`text-sm font-medium ${isActive ? 'text-ink-deep-brown' : 'text-muted-foreground'}`}>
        {label}
      </span>
    </div>
  );

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl w-[90vw] bg-white border border-border shadow-luxury-lg overflow-hidden">
        {/* Header Section */}
        <div className="relative bg-white border-b border-border -mx-6 -mt-6 px-6 pt-6 pb-6">
          <DialogHeader className="text-center">
            {/* Step Indicator */}
            <div className="flex items-center justify-center gap-6 mb-6">
              <StepIndicator step={1} label="Select Package" isActive={false} isCompleted={true} />
              <div className="w-12 h-px gradient-gold"></div>
              <StepIndicator step={2} label="Basic Info" isActive={currentStep === 1} isCompleted={currentStep > 1} />
              <div className={`w-12 h-px ${currentStep > 1 ? 'gradient-gold' : 'bg-muted'}`}></div>
              <StepIndicator step={3} label="Design Brief" isActive={currentStep === 2} isCompleted={false} />
              <div className="w-12 h-px bg-muted"></div>
              <StepIndicator step={4} label="Payment" isActive={false} isCompleted={false} />
            </div>
            
            <DialogTitle className="text-2xl text-ink-deep-brown mb-2" style={{ fontFamily: 'var(--font-heading)' }}>
              {currentStep === 1 ? "Basic Information" : "Design Brief"}
            </DialogTitle>
            <DialogDescription className="text-muted-foreground text-sm">
              {currentStep === 1 
                ? "Let's start with some basic information about your brand"
                : "Now tell us about your design preferences and vision"
              }
            </DialogDescription>
          </DialogHeader>
        </div>

        {/* Form Content */}
        <div className="bg-white -mx-6 px-6 py-5">
          <form onSubmit={handleSubmit} className="Container_Form">
            {currentStep === 1 ? (
              // Step 1: Basic Information
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="logoName" className="text-ink-deep-brown flex items-center gap-1">
                    Logo Name 
                    <span className="text-accent-terra">*</span>
                  </Label>
                  <Input
                    id="logoName"
                    className="bg-white border border-border focus:border-accent-terra focus:ring-1 focus:ring-accent-terra/20 h-10 rounded-lg"
                    placeholder="Enter your company/brand name"
                    value={formData.logoName}
                    onChange={(e) => setFormData(prev => ({ ...prev, logoName: e.target.value }))}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-ink-deep-brown flex items-center gap-1">
                    Industry 
                    <span className="text-accent-terra">*</span>
                  </Label>
                  <Select value={formData.industry} onValueChange={(value) => setFormData(prev => ({ ...prev, industry: value }))}>
                    <SelectTrigger className="bg-white border border-border focus:border-accent-terra h-10 rounded-lg">
                      <SelectValue placeholder="Select your industry" />
                    </SelectTrigger>
                    <SelectContent className="bg-white border border-border shadow-luxury">
                      <SelectItem value="technology">Technology</SelectItem>
                      <SelectItem value="healthcare">Healthcare</SelectItem>
                      <SelectItem value="finance">Finance</SelectItem>
                      <SelectItem value="retail">Retail</SelectItem>
                      <SelectItem value="food-beverage">Food & Beverage</SelectItem>
                      <SelectItem value="fashion">Fashion</SelectItem>
                      <SelectItem value="education">Education</SelectItem>
                      <SelectItem value="real-estate">Real Estate</SelectItem>
                      <SelectItem value="consulting">Consulting</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email" className="text-ink-deep-brown flex items-center gap-1">
                    Email Address 
                    <span className="text-accent-terra">*</span>
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    className="bg-white border border-border focus:border-accent-terra focus:ring-1 focus:ring-accent-terra/20 h-10 rounded-lg"
                    placeholder="your@email.com"
                    value={formData.email}
                    onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                    required
                  />
                </div>

                {/* Selected Package Summary for Step 1 */}
                {selectedPackage && (
                  <div className="bg-muted/30 p-4 rounded-lg border border-border mt-6">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-8 h-8 gradient-gold rounded-lg flex items-center justify-center">
                        <CreditCard className="w-4 h-4 text-white" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-ink-deep-brown">Selected Package</h4>
                        <p className="text-xs text-muted-foreground">Ready to start your design journey</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between p-4 bg-white rounded-lg border border-border">
                      <div>
                        <h5 className="font-semibold text-ink-deep-brown">{selectedPackage.name}</h5>
                        <p className="text-sm text-muted-foreground">Complete logo design package</p>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-gradient-gold">{selectedPackage.price}</div>
                        <Badge className="gradient-gold text-white border-0 mt-1">
                          {selectedPackage.type}
                        </Badge>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              // Step 2: Design Brief
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <WeDesignMultiSelect
                      label="Design Style *"
                      options={designStyleOptions}
                      selectedValues={formData.designStyles}
                      onSelectionChange={(values) => setFormData(prev => ({ ...prev, designStyles: values }))}
                      className="MultiSelect_Checkbox"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label className="text-ink-deep-brown">Color Preferences</Label>
                    <Select value={formData.colorPreferences} onValueChange={(value) => setFormData(prev => ({ ...prev, colorPreferences: value }))}>
                      <SelectTrigger className="bg-white border border-border focus:border-accent-terra h-10 rounded-lg">
                        <SelectValue placeholder="Choose color theme" />
                      </SelectTrigger>
                      <SelectContent className="bg-white border border-border shadow-luxury">
                        <SelectItem value="blue">Blue Tones</SelectItem>
                        <SelectItem value="green">Green Tones</SelectItem>
                        <SelectItem value="red">Red Tones</SelectItem>
                        <SelectItem value="purple">Purple Tones</SelectItem>
                        <SelectItem value="orange">Orange Tones</SelectItem>
                        <SelectItem value="black-white">Black & White</SelectItem>
                        <SelectItem value="earth">Earth Tones</SelectItem>
                        <SelectItem value="rainbow">Colorful/Rainbow</SelectItem>
                        <SelectItem value="no-preference">No Preference</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description" className="text-ink-deep-brown">Design Description</Label>
                  <Textarea
                    id="description"
                    className="bg-white border border-border focus:border-accent-terra focus:ring-1 focus:ring-accent-terra/20 min-h-[80px] rounded-lg resize-none"
                    placeholder="Describe your vision, target audience, brand values..."
                    value={formData.description}
                    onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                  />
                </div>

                <div className="Row_Upload">
                  <WeDesignFileUpload
                    label="Upload Reference File (Optional)"
                    onFileSelect={(file) => setFormData(prev => ({ ...prev, referenceFile: file }))}
                  />
                </div>
              </div>
            )}
          </form>
        </div>

        {/* Footer */}
        <div className="bg-muted/20 border-t border-border -mx-6 -mb-6 px-6 py-4">
          <div className="flex justify-between items-center">
            <button 
              onClick={currentStep === 1 ? onClose : handleBack}
              className="text-muted-foreground hover:text-ink-deep-brown transition-colors flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              {currentStep === 1 ? "Back to packages" : "Previous"}
            </button>
            
            {currentStep === 1 ? (
              <WeDesignButton
                variant="primary-gold"
                size="lg"
                className="min-w-40 h-11"
                onClick={handleNext}
                disabled={!isStep1Valid}
              >
                Next Step <ArrowRight className="w-4 h-4 ml-2" />
              </WeDesignButton>
            ) : (
              <WeDesignButton
                type="submit"
                variant="primary-gold"
                size="lg"
                className="min-w-56 h-11"
                onClick={handleSubmit}
              >
                Submit & Go to Payment →
              </WeDesignButton>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}