import { useState } from 'react';
import { Calendar, User, ArrowRight, Search, Tag } from 'lucide-react';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { Input } from '../ui/input';
import { Badge } from '../ui/badge';
import { WeDesignButton } from '../design-system/WeDesignButton';

interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  author: string;
  authorAvatar: string;
  publishDate: string;
  category: string;
  tags: string[];
  imageUrl: string;
  readTime: string;
}

const samplePosts: BlogPost[] = [
  {
    id: '1',
    title: 'The Psychology Behind Memorable Logo Design',
    excerpt: 'Discover how colors, shapes, and typography influence customer perception and brand recognition in logo design.',
    content: 'Full article content would go here...',
    author: 'Sarah Chen',
    authorAvatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=100&h=100&fit=crop&face',
    publishDate: '2024-01-15',
    category: 'Design Psychology',
    tags: ['Psychology', 'Branding', 'Design Theory'],
    imageUrl: 'https://images.unsplash.com/photo-1561070791-2526d30994b5?w=800&h=400&fit=crop',
    readTime: '5 min read'
  },
  {
    id: '2',
    title: '2024 Logo Design Trends: What\'s Hot This Year',
    excerpt: 'Explore the latest logo design trends that are shaping brand identities in 2024, from minimalism to bold gradients.',
    content: 'Full article content would go here...',
    author: 'Marcus Rodriguez',
    authorAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&face',
    publishDate: '2024-01-10',
    category: 'Trends',
    tags: ['Trends', '2024', 'Modern Design'],
    imageUrl: 'https://images.unsplash.com/photo-1558655146-9f40138edfeb?w=800&h=400&fit=crop',
    readTime: '7 min read'
  },
  {
    id: '3',
    title: 'Building a Brand Identity: Beyond Just a Logo',
    excerpt: 'Learn why successful brands need more than just a logo and how to create a cohesive brand identity system.',
    content: 'Full article content would go here...',
    author: 'Emily Thompson',
    authorAvatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&face',
    publishDate: '2024-01-05',
    category: 'Brand Strategy',
    tags: ['Brand Identity', 'Strategy', 'Business'],
    imageUrl: 'https://images.unsplash.com/photo-1542744173-8e7e53415bb0?w=800&h=400&fit=crop',
    readTime: '8 min read'
  },
  {
    id: '4',
    title: 'The ROI of Professional Logo Design for Small Businesses',
    excerpt: 'Data-driven insights on how professional logo design impacts small business growth and customer trust.',
    content: 'Full article content would go here...',
    author: 'David Kim',
    authorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&face',
    publishDate: '2023-12-28',
    category: 'Business',
    tags: ['ROI', 'Small Business', 'Growth'],
    imageUrl: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&h=400&fit=crop',
    readTime: '6 min read'
  },
  {
    id: '5',
    title: 'Case Study: Rebranding TechStart Inc.',
    excerpt: 'A detailed look at our complete rebranding process for TechStart Inc., from concept to final delivery.',
    content: 'Full article content would go here...',
    author: 'Lisa Wang',
    authorAvatar: 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=100&h=100&fit=crop&face',
    publishDate: '2023-12-20',
    category: 'Case Study',
    tags: ['Case Study', 'Rebranding', 'Technology'],
    imageUrl: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&h=400&fit=crop',
    readTime: '10 min read'
  }
];

const categories = ['All', 'Design Psychology', 'Trends', 'Brand Strategy', 'Business', 'Case Study'];

export function Page_Blog() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedPost, setSelectedPost] = useState<BlogPost | null>(null);

  const filteredPosts = samplePosts.filter(post => {
    const matchesSearch = post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         post.excerpt.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || post.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  if (selectedPost) {
    return (
      <div className="Page_BlogDetail">
        <div className="max-w-4xl mx-auto px-6 py-12">
          <button
            onClick={() => setSelectedPost(null)}
            className="mb-8 text-accent-terra hover:text-accent-terra/80 transition-colors flex items-center gap-2"
          >
            ← Back to Blog
          </button>

          <article className="bg-white rounded-2xl shadow-luxury-lg overflow-hidden">
            <div className="h-64 md:h-80 overflow-hidden">
              <ImageWithFallback
                src={selectedPost.imageUrl}
                alt={selectedPost.title}
                className="w-full h-full object-cover"
              />
            </div>

            <div className="p-8 md:p-12">
              <div className="flex items-center gap-4 mb-6">
                <Badge className="gradient-gold text-white border-0">
                  {selectedPost.category}
                </Badge>
                <span className="text-sm text-muted-foreground">{selectedPost.readTime}</span>
              </div>

              <h1 className="mb-6">{selectedPost.title}</h1>

              <div className="flex items-center gap-4 mb-8 pb-8 border-b border-border">
                <ImageWithFallback
                  src={selectedPost.authorAvatar}
                  alt={selectedPost.author}
                  className="w-12 h-12 rounded-full"
                />
                <div>
                  <div className="font-medium text-ink-deep-brown">{selectedPost.author}</div>
                  <div className="text-sm text-muted-foreground flex items-center gap-4">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      {formatDate(selectedPost.publishDate)}
                    </span>
                  </div>
                </div>
              </div>

              <div className="prose prose-lg max-w-none">
                <p className="text-xl text-muted-foreground mb-8">{selectedPost.excerpt}</p>
                <p>
                  This is where the full blog post content would appear. In a real implementation, 
                  this would contain the complete article with proper formatting, images, and structured content.
                </p>
                <p>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor 
                  incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud 
                  exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                </p>
              </div>

              <div className="mt-8 pt-8 border-t border-border">
                <div className="flex flex-wrap gap-2">
                  {selectedPost.tags.map((tag) => (
                    <span key={tag} className="text-xs px-3 py-1 bg-muted text-muted-foreground rounded-full">
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </article>
        </div>
      </div>
    );
  }

  return (
    <div className="Page_Blog">
      {/* Hero Section */}
      <section className="Section_Hero bg-gradient-to-b from-bg-light-ivory to-white py-20">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <h1 className="mb-6">Design Insights & Resources</h1>
          <p className="text-lead text-muted-foreground max-w-3xl mx-auto">
            Stay updated with the latest design trends, brand strategy insights, and creative inspiration 
            from our team of expert designers and strategists.
          </p>
        </div>
      </section>

      {/* Search and Filter */}
      <section className="Section_Filters py-12 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex flex-col lg:flex-row gap-6">
            {/* Search */}
            <div className="flex-1">
              <div className="relative max-w-md">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  type="text"
                  placeholder="Search articles..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 bg-muted/30 border border-border focus:border-accent-terra"
                />
              </div>
            </div>

            {/* Categories */}
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                    selectedCategory === category
                      ? 'gradient-gold text-white'
                      : 'bg-muted text-muted-foreground hover:bg-accent-terra/10 hover:text-accent-terra'
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Blog Posts */}
      <section className="Section_BlogPosts py-12">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-8">
              {filteredPosts.map((post, index) => (
                <article
                  key={post.id}
                  className={`Card_Blog bg-white rounded-2xl shadow-luxury hover:shadow-luxury-lg transition-all duration-300 overflow-hidden cursor-pointer group ${
                    index === 0 ? 'lg:flex lg:gap-8' : ''
                  }`}
                  onClick={() => setSelectedPost(post)}
                >
                  <div className={index === 0 ? 'lg:flex-1' : ''}>
                    <ImageWithFallback
                      src={post.imageUrl}
                      alt={post.title}
                      className={`w-full object-cover group-hover:scale-105 transition-transform duration-300 ${
                        index === 0 ? 'h-48 lg:h-full' : 'h-48'
                      }`}
                    />
                  </div>

                  <div className={`p-6 ${index === 0 ? 'lg:flex-1' : ''}`}>
                    <div className="flex items-center gap-4 mb-4">
                      <Badge className="bg-accent-terra/10 text-accent-terra border-0">
                        {post.category}
                      </Badge>
                      <span className="text-sm text-muted-foreground">{post.readTime}</span>
                    </div>

                    <h2 className={`font-bold text-ink-deep-brown mb-3 group-hover:text-accent-terra transition-colors ${
                      index === 0 ? 'text-2xl' : 'text-xl'
                    }`}>
                      {post.title}
                    </h2>

                    <p className="text-muted-foreground mb-4 line-clamp-3">
                      {post.excerpt}
                    </p>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <ImageWithFallback
                          src={post.authorAvatar}
                          alt={post.author}
                          className="w-8 h-8 rounded-full"
                        />
                        <div>
                          <div className="text-sm font-medium text-ink-deep-brown">{post.author}</div>
                          <div className="text-xs text-muted-foreground">
                            {formatDate(post.publishDate)}
                          </div>
                        </div>
                      </div>

                      <div className="text-accent-terra group-hover:text-accent-terra/80 transition-colors">
                        <ArrowRight className="w-4 h-4" />
                      </div>
                    </div>
                  </div>
                </article>
              ))}

              {filteredPosts.length === 0 && (
                <div className="text-center py-16">
                  <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                    <Search className="w-6 h-6 text-muted-foreground" />
                  </div>
                  <h3 className="font-semibold text-ink-deep-brown mb-2">No articles found</h3>
                  <p className="text-muted-foreground">Try adjusting your search or filter criteria</p>
                </div>
              )}
            </div>

            {/* Sidebar */}
            <aside className="space-y-8">
              {/* Recent Posts */}
              <div className="bg-white p-6 rounded-2xl shadow-luxury">
                <h3 className="font-semibold text-ink-deep-brown mb-4 flex items-center gap-2">
                  <Tag className="w-4 h-4" />
                  Recent Posts
                </h3>
                <div className="space-y-4">
                  {samplePosts.slice(0, 3).map((post) => (
                    <div key={post.id} className="group cursor-pointer" onClick={() => setSelectedPost(post)}>
                      <h4 className="text-sm font-medium text-ink-deep-brown group-hover:text-accent-terra transition-colors mb-1">
                        {post.title}
                      </h4>
                      <p className="text-xs text-muted-foreground">{formatDate(post.publishDate)}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Categories */}
              <div className="bg-white p-6 rounded-2xl shadow-luxury">
                <h3 className="font-semibold text-ink-deep-brown mb-4">Categories</h3>
                <div className="space-y-2">
                  {categories.slice(1).map((category) => (
                    <button
                      key={category}
                      onClick={() => setSelectedCategory(category)}
                      className="block w-full text-left text-sm text-muted-foreground hover:text-accent-terra transition-colors"
                    >
                      {category}
                    </button>
                  ))}
                </div>
              </div>

              {/* Newsletter */}
              <div className="bg-gradient-to-br from-accent-terra to-accent-gold-end text-white p-6 rounded-2xl">
                <h3 className="font-semibold mb-2">Stay Updated</h3>
                <p className="text-sm text-white/90 mb-4">
                  Get the latest design insights delivered to your inbox.
                </p>
                <div className="space-y-2">
                  <Input
                    type="email"
                    placeholder="your@email.com"
                    className="bg-white/20 border-white/30 text-white placeholder:text-white/70"
                  />
                  <WeDesignButton
                    variant="secondary-outline"
                    size="sm"
                    className="w-full bg-white text-accent-terra border-white hover:bg-white/90"
                  >
                    Subscribe
                  </WeDesignButton>
                </div>
              </div>
            </aside>
          </div>
        </div>
      </section>
    </div>
  );
}