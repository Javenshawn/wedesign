import { useState } from 'react';
import { Download, Upload, Clock, CheckCircle, AlertCircle } from 'lucide-react';
import { WeDesignButton } from '../design-system/WeDesignButton';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';

interface ProjectCard {
  id: string;
  orderNumber: string;
  clientName: string;
  designStyle: string;
  status: 'in-progress' | 'review' | 'completed' | 'revision';
  progress: number;
  timeLeft: string;
  description: string;
  isClientView?: boolean;
  fileUrl?: string;
  lastUpdate: string;
}

const sampleProjects: ProjectCard[] = [
  {
    id: '1',
    orderNumber: 'WD-2024-001',
    clientName: 'TechStart Inc.',
    designStyle: 'Modern Minimalist',
    status: 'in-progress',
    progress: 75,
    timeLeft: '18h',
    description: 'Creating a clean, modern logo for a tech startup focusing on AI solutions.',
    isClientView: false,
    lastUpdate: '2 hours ago'
  },
  {
    id: '2',
    orderNumber: 'WD-2024-002',
    clientName: 'Green Garden Cafe',
    designStyle: 'Organic Natural',
    status: 'review',
    progress: 90,
    timeLeft: '6h',
    description: 'Eco-friendly cafe logo with natural elements and earth tones.',
    isClientView: true,
    fileUrl: '#sample-file',
    lastUpdate: '30 minutes ago'
  },
  {
    id: '3',
    orderNumber: 'WD-2024-003',
    clientName: 'Urban Fashion',
    designStyle: 'Bold Contemporary',
    status: 'completed',
    progress: 100,
    timeLeft: 'Delivered',
    description: 'Fashion brand logo with bold typography and contemporary aesthetics.',
    isClientView: true,
    fileUrl: '#sample-file',
    lastUpdate: '1 day ago'
  },
  {
    id: '4',
    orderNumber: 'WD-2024-004',
    clientName: 'MedCare Clinic',
    designStyle: 'Professional Trust',
    status: 'revision',
    progress: 60,
    timeLeft: '24h',
    description: 'Healthcare logo design emphasizing trust, care, and professionalism.',
    isClientView: false,
    lastUpdate: '4 hours ago'
  },
  {
    id: '5',
    orderNumber: 'WD-2024-005',
    clientName: 'FitLife Gym',
    designStyle: 'Dynamic Energy',
    status: 'in-progress',
    progress: 40,
    timeLeft: '36h',
    description: 'Fitness center logo with dynamic elements representing strength and energy.',
    isClientView: false,
    lastUpdate: '1 hour ago'
  },
  {
    id: '6',
    orderNumber: 'WD-2024-006',
    clientName: 'EduBright Academy',
    designStyle: 'Academic Excellence',
    status: 'in-progress',
    progress: 25,
    timeLeft: '48h',
    description: 'Educational institution logo promoting learning and academic achievement.',
    isClientView: false,
    lastUpdate: '6 hours ago'
  }
];

export function Page_DesignHall() {
  const [projects] = useState<ProjectCard[]>(sampleProjects);
  const [viewMode, setViewMode] = useState<'all' | 'client'>('all');

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'in-progress':
        return 'bg-blue-100 text-blue-800';
      case 'review':
        return 'bg-yellow-100 text-yellow-800';
      case 'revision':
        return 'bg-orange-100 text-orange-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-4 h-4" />;
      case 'in-progress':
        return <Clock className="w-4 h-4" />;
      case 'review':
        return <AlertCircle className="w-4 h-4" />;
      case 'revision':
        return <AlertCircle className="w-4 h-4" />;
      default:
        return <Clock className="w-4 h-4" />;
    }
  };

  const handleFileDownload = (projectId: string) => {
    console.log('Downloading file for project:', projectId);
    // TODO: Implement file download
  };

  const handleFileUpload = (projectId: string) => {
    console.log('Uploading file for project:', projectId);
    // TODO: Implement file upload
  };

  const filteredProjects = viewMode === 'client' 
    ? projects.filter(p => p.isClientView) 
    : projects;

  return (
    <div className="Page_DesignHall">
      {/* Hero Section */}
      <section className="Section_Hero bg-gradient-to-b from-bg-light-ivory to-white py-20">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <h1 className="text-4xl font-bold text-ink-deep-brown mb-4">Live Design Hall</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
            Track your logo design projects in real-time. See progress updates, delivery timelines, 
            and download your completed designs.
          </p>

          {/* View Mode Toggle */}
          <div className="flex items-center justify-center gap-4">
            <WeDesignButton
              variant={viewMode === 'all' ? 'primary-gold' : 'secondary-outline'}
              onClick={() => setViewMode('all')}
            >
              All Projects ({projects.length})
            </WeDesignButton>
            <WeDesignButton
              variant={viewMode === 'client' ? 'primary-gold' : 'secondary-outline'}
              onClick={() => setViewMode('client')}
            >
              Client View ({projects.filter(p => p.isClientView).length})
            </WeDesignButton>
          </div>
        </div>
      </section>

      {/* Projects Grid */}
      <section className="Section_Projects py-12">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProjects.map((project) => (
              <div 
                key={project.id}
                className="Card_Project bg-white rounded-2xl p-6 shadow-luxury hover:shadow-luxury-lg transition-all duration-300"
              >
                {/* Project Header */}
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="font-semibold text-ink-deep-brown mb-1">
                      {project.orderNumber}
                    </h3>
                    <p className="text-sm text-muted-foreground">{project.clientName}</p>
                  </div>
                  
                  <Badge className={`${getStatusColor(project.status)} border-0 flex items-center gap-1`}>
                    {getStatusIcon(project.status)}
                    {project.status.replace('-', ' ')}
                  </Badge>
                </div>

                {/* Design Style */}
                <div className="mb-4">
                  <p className="text-sm font-medium text-accent-terra mb-1">Design Style</p>
                  <p className="text-sm text-ink-deep-brown">{project.designStyle}</p>
                </div>

                {/* Description */}
                <div className="mb-4">
                  <p className="text-sm text-muted-foreground">{project.description}</p>
                </div>

                {/* Progress */}
                <div className="mb-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-ink-deep-brown">Progress</span>
                    <span className="text-sm text-muted-foreground">{project.progress}%</span>
                  </div>
                  <Progress 
                    value={project.progress} 
                    className="h-2 bg-muted"
                  />
                </div>

                {/* Time Left */}
                <div className="mb-4">
                  <div className="flex items-center gap-2 text-sm">
                    <Clock className="w-4 h-4 text-muted-foreground" />
                    <span className="text-muted-foreground">
                      {project.status === 'completed' ? 'Completed' : `${project.timeLeft} remaining`}
                    </span>
                  </div>
                </div>

                {/* Last Update */}
                <div className="mb-6">
                  <p className="text-xs text-muted-foreground">
                    Last updated: {project.lastUpdate}
                  </p>
                </div>

                {/* Actions */}
                <div className="space-y-2">
                  {project.isClientView && project.fileUrl && project.status === 'completed' && (
                    <WeDesignButton
                      variant="primary-gold"
                      size="sm"
                      className="w-full"
                      onClick={() => handleFileDownload(project.id)}
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Download Files
                    </WeDesignButton>
                  )}
                  
                  {project.isClientView && project.status === 'review' && (
                    <WeDesignButton
                      variant="primary-gold"
                      size="sm"
                      className="w-full"
                      onClick={() => handleFileDownload(project.id)}
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Review & Download
                    </WeDesignButton>
                  )}

                  {!project.isClientView && project.status !== 'completed' && (
                    <WeDesignButton
                      variant="secondary-outline"
                      size="sm"
                      className="w-full"
                      onClick={() => handleFileUpload(project.id)}
                    >
                      <Upload className="w-4 h-4 mr-2" />
                      Upload Progress
                    </WeDesignButton>
                  )}

                  {project.status === 'in-progress' && (
                    <p className="text-xs text-center text-muted-foreground pt-2">
                      Our designers are working on your project
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>

          {filteredProjects.length === 0 && (
            <div className="text-center py-16">
              <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="w-6 h-6 text-muted-foreground" />
              </div>
              <h3 className="font-semibold text-ink-deep-brown mb-2">No projects found</h3>
              <p className="text-muted-foreground">Projects will appear here once you place an order</p>
            </div>
          )}
        </div>
      </section>

      {/* Stats Section */}
      <section className="Section_Stats py-12 bg-muted/20">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-gradient-gold mb-2">
                {projects.filter(p => p.status === 'in-progress').length}
              </div>
              <p className="text-sm text-muted-foreground">Active Projects</p>
            </div>
            
            <div className="text-center">
              <div className="text-3xl font-bold text-gradient-gold mb-2">
                {projects.filter(p => p.status === 'completed').length}
              </div>
              <p className="text-sm text-muted-foreground">Completed Today</p>
            </div>
            
            <div className="text-center">
              <div className="text-3xl font-bold text-gradient-gold mb-2">
                {Math.round(projects.reduce((acc, p) => acc + p.progress, 0) / projects.length)}%
              </div>
              <p className="text-sm text-muted-foreground">Average Progress</p>
            </div>
            
            <div className="text-center">
              <div className="text-3xl font-bold text-gradient-gold mb-2">24h</div>
              <p className="text-sm text-muted-foreground">Average Delivery</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}