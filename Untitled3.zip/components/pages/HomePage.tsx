import { useState } from "react";
import { Section_Hero } from "../sections/CompactCarouselSection";
import { Section_Stats } from "../sections/StatsSection";
import { Section_DesignHall } from "../sections/EnhancedLiveDesignHallSection";
import { Section_CasePreview } from "../sections/CasePreviewSection";
import { Section_CompactPortfolio } from "../sections/CompactPortfolioSection";
import { Section_OptimizedPortfolio } from "../sections/OptimizedPortfolioSection";
import { Modal_StartProject } from "../modals/StartProjectModal";

interface HomePageProps {
  onNavigate?: (page: string) => void;
}

export function Page_Home({ onNavigate }: HomePageProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleStartProject = () => {
    setIsModalOpen(true);
  };

  const handleViewWork = () => {
    onNavigate?.('logos-design');
  };

  const handleSubmitProject = (data: any) => {
    console.log('Project submitted:', data);
    // TODO: Implement project submission logic
    // This would typically send data to your backend or payment processor
  };

  const handleSubmitChanges = () => {
    console.log('Submit changes clicked');
    // TODO: Implement submit changes functionality
  };

  const handleViewAllProjects = () => {
    onNavigate?.('design-hall');
  };

  return (
    <div className="Page_Home">
      {/* Container_Desktop (Desktop: 1440px max-width) */}
      <div className="Container_Desktop max-w-screen-2xl mx-auto">
        
        {/* Container_Tablet (Tablet: 768px responsive) */}
        <div className="Container_Tablet">
          
          {/* Container_Mobile (Mobile: 375px responsive) */}
          <div className="Container_Mobile">
            
            {/* Section_Hero - Main carousel with intro and process */}
            <Section_Hero
              onStartProject={handleStartProject}
              onViewWork={handleViewWork}
            />

            {/* Section_Stats */}
            <Section_Stats />

            {/* Section_DesignHall - Live Design Hall */}
            <Section_DesignHall
              onStartProject={handleStartProject}
              onSubmitChanges={handleSubmitChanges}
              onViewAllProjects={handleViewAllProjects}
            />

            {/* Section_OptimizedPortfolio - Optimized 230px height with gradient titles */}
            <Section_OptimizedPortfolio />
            
            {/* Other portfolio sections - Keep for reference */}
            {/* <Section_CompactPortfolio /> */}
            {/* <Section_CasePreview /> */}
            
          </div>
        </div>
      </div>

      {/* Modal_StartProject */}
      <Modal_StartProject
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSubmit={handleSubmitProject}
      />
    </div>
  );
}