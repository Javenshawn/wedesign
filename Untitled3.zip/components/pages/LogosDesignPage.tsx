import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../ui/dialog';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { Section_Pricing } from '../sections/PricingSection';
import { Section_OptimizedPortfolio } from '../sections/OptimizedPortfolioSection';
import { Modal_StartProject } from '../modals/StartProjectModal';

interface LogoItem {
  id: string;
  title: string;
  client: string;
  industry: string;
  color: string;
  imageUrl: string;
  description: string;
  year: string;
}

interface SelectedPackageData {
  name: string;
  price: string;
  priceValue: number;
  type: string;
}

const sampleLogos: LogoItem[] = [
  {
    id: '1',
    title: 'TechFlow Logo',
    client: 'TechFlow Solutions',
    industry: 'Technology',
    color: 'Blue',
    imageUrl: 'https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=400&h=400&fit=crop',
    description: 'Modern technology company logo featuring clean lines and dynamic flow elements.',
    year: '2024'
  },
  {
    id: '2',
    title: 'GreenLeaf Organics',
    client: 'GreenLeaf Organics',
    industry: 'Food & Beverage',
    color: 'Green',
    imageUrl: 'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=400&h=400&fit=crop',
    description: 'Organic food brand logo emphasizing natural, sustainable values.',
    year: '2024'
  },
  {
    id: '3',
    title: 'Luxe Boutique',
    client: 'Luxe Fashion',
    industry: 'Fashion',
    color: 'Black',
    imageUrl: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&h=400&fit=crop',
    description: 'Elegant fashion boutique logo with sophisticated typography and minimal design.',
    year: '2024'
  },
  {
    id: '4',
    title: 'MedCare Plus',
    client: 'MedCare Plus',
    industry: 'Healthcare',
    color: 'Blue',
    imageUrl: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1f?w=400&h=400&fit=crop',
    description: 'Healthcare services logo conveying trust, care, and medical expertise.',
    year: '2024'
  },
  {
    id: '5',
    title: 'Urban Fitness',
    client: 'Urban Fitness',
    industry: 'Health & Fitness',
    color: 'Orange',
    imageUrl: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400&h=400&fit=crop',
    description: 'Dynamic fitness brand logo representing strength, energy, and urban lifestyle.',
    year: '2023'
  },
  {
    id: '6',
    title: 'EduLearn Academy',
    client: 'EduLearn Academy',
    industry: 'Education',
    color: 'Purple',
    imageUrl: 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=400&h=400&fit=crop',
    description: 'Educational institution logo promoting knowledge, growth, and academic excellence.',
    year: '2023'
  }
];

// Package mapping to ensure consistency with modal
const packagePriceMap: { [key: string]: SelectedPackageData } = {
  'Economy': {
    name: 'Economy Class',
    price: '$199',
    priceValue: 199,
    type: 'economy'
  },
  'Business': {
    name: 'Business Class',
    price: '$399',
    priceValue: 399,
    type: 'business'
  },
  'Private Jet': {
    name: 'Private Jet',
    price: '$999',
    priceValue: 999,
    type: 'private'
  }
};

export function Page_LogosDesign() {
  const [selectedLogo, setSelectedLogo] = useState<LogoItem | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedPackageData, setSelectedPackageData] = useState<SelectedPackageData | null>(null);

  const handleSelectPackage = (packageName: string) => {
    // Map the package name to the proper data structure
    const packageData = packagePriceMap[packageName];
    if (packageData) {
      setSelectedPackageData(packageData);
      setIsModalOpen(true);
    } else {
      console.warn('Unknown package selected:', packageName);
      // Fallback - still open modal but let it handle the unknown package
      setSelectedPackageData({
        name: packageName,
        price: '$399',
        priceValue: 399,
        type: packageName.toLowerCase().replace(/\s+/g, '-')
      });
      setIsModalOpen(true);
    }
  };

  const handleSubmitProject = (data: any) => {
    console.log('Project submitted:', data);
    // TODO: Implement project submission logic
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedPackageData(null);
  };

  return (
    <div className="Page_LogosDesign">
      {/* Container_Desktop */}
      <div className="Container_Desktop max-w-screen-2xl mx-auto">
        
        {/* Container_Tablet */}
        <div className="Container_Tablet">
          
          {/* Container_Mobile */}
          <div className="Container_Mobile">
            
            {/* Section_Pricing - Package selection */}
            <Section_Pricing onSelectPackage={handleSelectPackage} />

            {/* Section_OptimizedPortfolio - Using the same component as homepage */}
            <Section_OptimizedPortfolio />

            {/* Section_CallToAction - Additional service info */}
            <section className="Section_CallToAction section-mobile bg-gradient-to-r from-accent-terra/5 to-accent-gold-end/5">
              <div className="Container_Content max-w-7xl mx-auto responsive-padding text-center">
                <h2 className="text-gradient-gold-rich font-heading mb-4">
                  Ready to Create Your Perfect Logo?
                </h2>
                <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8 leading-relaxed">
                  Our experienced design team is ready to bring your brand vision to life. Choose from our 
                  flexible packages and get started on your logo design journey today.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <button
                    onClick={() => handleSelectPackage('Business')}
                    className="button-glass-primary px-8 py-4 rounded-xl font-medium text-white transition-all duration-300 hover:scale-105"
                  >
                    Start Your Logo Design
                  </button>
                  <button className="button-glass-secondary px-8 py-4 rounded-xl font-medium transition-all duration-300 hover:scale-105">
                    View All Packages
                  </button>
                </div>
              </div>
            </section>

          </div>
        </div>
      </div>

      {/* Modal_LogoDetail - Logo detail popup */}
      <Dialog open={!!selectedLogo} onOpenChange={() => setSelectedLogo(null)}>
        <DialogContent className="Modal_LogoDetail max-w-4xl bg-white border border-border shadow-luxury-lg">
          {selectedLogo && (
            <>
              <DialogHeader>
                <DialogTitle className="Text_ModalTitle text-2xl font-bold text-ink-deep-brown">
                  {selectedLogo.title}
                </DialogTitle>
              </DialogHeader>
              
              <div className="Container_ModalContent grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="Container_LogoImage">
                  <ImageWithFallback
                    src={selectedLogo.imageUrl}
                    alt={selectedLogo.title}
                    className="w-full aspect-square object-cover rounded-xl"
                  />
                </div>
                
                <div className="Container_LogoDetails space-y-4">
                  <div className="Field_Client">
                    <h4 className="Label_Field font-semibold text-ink-deep-brown mb-2">Client</h4>
                    <p className="Text_FieldValue text-muted-foreground">{selectedLogo.client}</p>
                  </div>
                  
                  <div className="Field_Industry">
                    <h4 className="Label_Field font-semibold text-ink-deep-brown mb-2">Industry</h4>
                    <p className="Text_FieldValue text-muted-foreground">{selectedLogo.industry}</p>
                  </div>
                  
                  <div className="Field_Year">
                    <h4 className="Label_Field font-semibold text-ink-deep-brown mb-2">Year</h4>
                    <p className="Text_FieldValue text-muted-foreground">{selectedLogo.year}</p>
                  </div>
                  
                  <div className="Field_Description">
                    <h4 className="Label_Field font-semibold text-ink-deep-brown mb-2">Description</h4>
                    <p className="Text_FieldValue text-muted-foreground">{selectedLogo.description}</p>
                  </div>
                  
                  <div className="Container_Copyright pt-4">
                    <p className="Text_Copyright text-xs text-muted-foreground">
                      © WeDesign. All rights reserved. This logo is the property of {selectedLogo.client}.
                    </p>
                  </div>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Modal_StartProject with selected package data */}
      <Modal_StartProject
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        onSubmit={handleSubmitProject}
        selectedPackage={selectedPackageData}
      />
    </div>
  );
}