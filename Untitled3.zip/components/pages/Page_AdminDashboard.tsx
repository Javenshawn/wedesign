import { AdminDashboard } from '../admin/AdminDashboard';

interface PageAdminDashboardProps {
  onNavigate: (page: string) => void;
}

export function Page_AdminDashboard({ onNavigate }: PageAdminDashboardProps) {
  return <AdminDashboard onNavigate={onNavigate} />;
}