import { AdminSEO } from '../admin/AdminSEO';

interface PageAdminSEOProps {
  onNavigate: (page: string) => void;
}

export function Page_AdminSEO({ onNavigate }: PageAdminSEOProps) {
  return <AdminSEO onNavigate={onNavigate} />;
}