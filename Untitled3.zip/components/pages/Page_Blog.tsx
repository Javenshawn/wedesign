import React, { useState, useEffect } from 'react';
import { Search, Calendar, Clock, Eye, ChevronLeft, ChevronRight, User, Tag } from 'lucide-react';
import { blogAPI, handleApiError } from '../../utils/supabase/client';
import { ImageWithFallback } from '../figma/ImageWithFallback';

interface BlogPost {
  id: string;
  slug: string;
  title: string;
  content: string;
  excerpt: string;
  category: string;
  tags: string[];
  featuredImage: string;
  author: {
    id: string;
    name: string;
    avatar: string;
  };
  status: string;
  createdAt: string;
  publishedAt: string;
  updatedAt: string;
  views: number;
  likes: number;
}

interface BlogResponse {
  posts: BlogPost[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}

// Utility functions
const formatDate = (dateString: string) => {
  return new Date(dateString).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
};

const formatReadTime = (content: string) => {
  const wordsPerMinute = 200;
  const wordCount = content.split(' ').length;
  return Math.ceil(wordCount / wordsPerMinute);
};

export function Page_Blog() {
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [pagination, setPagination] = useState({
    page: 1,
    limit: 9,
    total: 0,
    totalPages: 1
  });

  const categories = [
    { id: 'all', name: 'All Articles', count: 0 },
    { id: 'design-tips', name: 'Design Tips', count: 0 },
    { id: 'branding', name: 'Branding', count: 0 },
    { id: 'case-studies', name: 'Case Studies', count: 0 },
    { id: 'industry-news', name: 'Industry News', count: 0 },
    { id: 'tutorials', name: 'Tutorials', count: 0 }
  ];

  useEffect(() => {
    loadBlogPosts();
  }, [currentPage, selectedCategory]);

  const loadBlogPosts = async () => {
    setLoading(true);
    try {
      const response: BlogResponse = await blogAPI.getPosts(
        currentPage, 
        9, 
        selectedCategory === 'all' ? undefined : selectedCategory
      );
      
      setPosts(response.posts);
      setPagination(response.pagination);
    } catch (error) {
      console.error('Failed to load blog posts:', error);
      // 如果API调用失败，使用示例数据
      loadSamplePosts();
    } finally {
      setLoading(false);
    }
  };

  const loadSamplePosts = () => {
    const samplePosts: BlogPost[] = [
      {
        id: '1',
        slug: 'logo-design-trends-2024',
        title: 'Logo Design Trends That Will Define 2024',
        content: 'Discover the cutting-edge logo design trends that are shaping the visual identity landscape in 2024...',
        excerpt: 'Explore the latest logo design trends including minimalism, geometric shapes, and sustainable branding approaches.',
        category: 'design-tips',
        tags: ['trends', 'logo design', '2024'],
        featuredImage: 'https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=800&h=600&fit=crop',
        author: {
          id: '1',
          name: 'Sarah Chen',
          avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b789?w=150&h=150&fit=crop'
        },
        status: 'published',
        createdAt: '2024-01-15T10:00:00Z',
        publishedAt: '2024-01-15T10:00:00Z',
        updatedAt: '2024-01-15T10:00:00Z',
        views: 1247,
        likes: 89
      },
      {
        id: '2',
        slug: 'psychology-of-color-in-branding',
        title: 'The Psychology of Color in Brand Identity',
        content: 'Understanding how colors influence consumer behavior and brand perception...',
        excerpt: 'Learn how different colors evoke emotions and influence purchasing decisions in brand design.',
        category: 'branding',
        tags: ['color psychology', 'branding', 'marketing'],
        featuredImage: 'https://images.unsplash.com/photo-1561070791-2526d30994b5?w=800&h=600&fit=crop',
        author: {
          id: '2',
          name: 'Marcus Rodriguez',
          avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop'
        },
        status: 'published',
        createdAt: '2024-01-12T14:30:00Z',
        publishedAt: '2024-01-12T14:30:00Z',
        updatedAt: '2024-01-12T14:30:00Z',
        views: 2156,
        likes: 134
      },
      {
        id: '3',
        slug: 'startup-logo-case-study',
        title: 'Case Study: Rebranding a Tech Startup',
        content: 'A comprehensive look at how we transformed a tech startup\'s visual identity...',
        excerpt: 'Follow our complete process of rebranding a fintech startup, from research to final implementation.',
        category: 'case-studies',
        tags: ['case study', 'startup', 'rebranding'],
        featuredImage: 'https://images.unsplash.com/photo-1552664730-d307ca884978?w=800&h=600&fit=crop',
        author: {
          id: '3',
          name: 'Jennifer Kim',
          avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop'
        },
        status: 'published',
        createdAt: '2024-01-10T09:15:00Z',
        publishedAt: '2024-01-10T09:15:00Z',
        updatedAt: '2024-01-10T09:15:00Z',
        views: 892,
        likes: 67
      },
      {
        id: '4',
        slug: 'logo-design-process-guide',
        title: 'Complete Guide to Our Logo Design Process',
        content: 'An in-depth look at how we create memorable and effective logos for our clients...',
        excerpt: 'Discover the systematic approach we use to create logos that resonate with target audiences.',
        category: 'tutorials',
        tags: ['process', 'guide', 'logo design'],
        featuredImage: 'https://images.unsplash.com/photo-1586717791821-3f44a563fa4c?w=800&h=600&fit=crop',
        author: {
          id: '1',
          name: 'Sarah Chen',
          avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b789?w=150&h=150&fit=crop'
        },
        status: 'published',
        createdAt: '2024-01-08T16:20:00Z',
        publishedAt: '2024-01-08T16:20:00Z',
        updatedAt: '2024-01-08T16:20:00Z',
        views: 1534,
        likes: 98
      },
      {
        id: '5',
        slug: 'future-of-brand-identity',
        title: 'The Future of Brand Identity in Digital Age',
        content: 'Exploring how digital transformation is reshaping brand identity design...',
        excerpt: 'Examine how emerging technologies are influencing the way brands express their identity online.',
        category: 'industry-news',
        tags: ['future', 'digital', 'brand identity'],
        featuredImage: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&h=600&fit=crop',
        author: {
          id: '2',
          name: 'Marcus Rodriguez',
          avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop'
        },
        status: 'published',
        createdAt: '2024-01-05T11:45:00Z',
        publishedAt: '2024-01-05T11:45:00Z',
        updatedAt: '2024-01-05T11:45:00Z',
        views: 945,
        likes: 72
      },
      {
        id: '6',
        slug: 'typography-in-logo-design',
        title: 'The Art of Typography in Logo Design',
        content: 'Understanding how typography choices can make or break a logo design...',
        excerpt: 'Master the principles of typography and learn how to choose the perfect font for your brand.',
        category: 'design-tips',
        tags: ['typography', 'fonts', 'logo design'],
        featuredImage: 'https://images.unsplash.com/photo-1503428593586-e225b39bddfe?w=800&h=600&fit=crop',
        author: {
          id: '3',
          name: 'Jennifer Kim',
          avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop'
        },
        status: 'published',
        createdAt: '2024-01-03T13:10:00Z',
        publishedAt: '2024-01-03T13:10:00Z',
        updatedAt: '2024-01-03T13:10:00Z',
        views: 1267,
        likes: 115
      }
    ];

    setPosts(samplePosts);
    setPagination({
      page: 1,
      limit: 9,
      total: samplePosts.length,
      totalPages: Math.ceil(samplePosts.length / 9)
    });
  };

  const filteredPosts = posts.filter(post => 
    post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    post.excerpt.toLowerCase().includes(searchQuery.toLowerCase()) ||
    post.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
  );



  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FAFAF8] to-[#F5F3ED]">
      {/* Hero Section */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-[#B6652E]/20 to-[#FFB84D]/20"></div>
        <div className="absolute top-10 left-10 w-32 h-32 rounded-full bg-[#FFB84D] opacity-20 blur-xl"></div>
        <div className="absolute bottom-10 right-10 w-48 h-48 rounded-full bg-[#B6652E] opacity-20 blur-xl"></div>

        <div className="relative max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6">
            <span className="bg-gradient-to-r from-[#B6652E] to-[#FFB84D] bg-clip-text text-transparent">
              Design Insights
            </span>
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto leading-relaxed">
            Expert insights, industry trends, and creative inspiration for modern logo design and brand identity.
          </p>

          {/* Search Bar */}
          <div className="relative max-w-md mx-auto">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search articles..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-4 rounded-2xl backdrop-blur-xl bg-white/80 border border-white/20 focus:border-[#B6652E] focus:ring-2 focus:ring-[#B6652E]/20 transition-all text-gray-900 placeholder-gray-500"
            />
          </div>
        </div>
      </section>

      {/* Content Section - Added top padding to prevent overlap */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20 pt-12">
        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-3 mb-16">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => {
                setSelectedCategory(category.id);
                setCurrentPage(1);
              }}
              className={`px-6 py-3 rounded-full font-medium transition-all ${
                selectedCategory === category.id
                  ? 'bg-gradient-to-r from-[#B6652E] to-[#FFB84D] text-white shadow-lg transform scale-105'
                  : 'backdrop-blur-xl bg-white/80 text-gray-700 hover:bg-white/90 border border-white/20'
              }`}
            >
              {category.name}
            </button>
          ))}
        </div>

        {/* Blog Posts Grid */}
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[...Array(6)].map((_, index) => (
              <div key={index} className="backdrop-blur-xl bg-white/80 rounded-2xl overflow-hidden animate-pulse">
                <div className="aspect-video bg-gray-200"></div>
                <div className="p-6 space-y-4">
                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                  <div className="space-y-2">
                    <div className="h-3 bg-gray-200 rounded"></div>
                    <div className="h-3 bg-gray-200 rounded w-5/6"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredPosts.map((post) => (
              <BlogPostCard key={post.id} post={post} />
            ))}
          </div>
        )}

        {/* Empty State */}
        {!loading && filteredPosts.length === 0 && (
          <div className="text-center py-16">
            <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-gradient-to-br from-[#B6652E] to-[#FFB84D] flex items-center justify-center">
              <Search className="w-12 h-12 text-white" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">No articles found</h3>
            <p className="text-gray-600 mb-6">
              {searchQuery 
                ? `No articles match "${searchQuery}". Try different keywords.`
                : "No articles available in this category yet."
              }
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('all');
              }}
              className="px-6 py-3 bg-gradient-to-r from-[#B6652E] to-[#FFB84D] text-white rounded-lg hover:shadow-lg transition-all"
            >
              View All Articles
            </button>
          </div>
        )}

        {/* Pagination */}
        {!loading && filteredPosts.length > 0 && pagination.totalPages > 1 && (
          <div className="flex justify-center items-center gap-4 mt-20">
            <button
              onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
              disabled={currentPage === 1}
              className="flex items-center gap-2 px-4 py-2 rounded-lg backdrop-blur-xl bg-white/80 border border-white/20 hover:bg-white/90 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <ChevronLeft className="w-4 h-4" />
              Previous
            </button>

            <div className="flex items-center gap-2">
              {[...Array(pagination.totalPages)].map((_, index) => {
                const page = index + 1;
                return (
                  <button
                    key={page}
                    onClick={() => setCurrentPage(page)}
                    className={`w-10 h-10 rounded-lg font-medium transition-all ${
                      currentPage === page
                        ? 'bg-gradient-to-r from-[#B6652E] to-[#FFB84D] text-white'
                        : 'backdrop-blur-xl bg-white/80 text-gray-700 hover:bg-white/90'
                    }`}
                  >
                    {page}
                  </button>
                );
              })}
            </div>

            <button
              onClick={() => setCurrentPage(Math.min(pagination.totalPages, currentPage + 1))}
              disabled={currentPage === pagination.totalPages}
              className="flex items-center gap-2 px-4 py-2 rounded-lg backdrop-blur-xl bg-white/80 border border-white/20 hover:bg-white/90 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Next
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

// Blog Post Card Component
function BlogPostCard({ post }: { post: BlogPost }) {
  return (
    <article className="group backdrop-blur-xl bg-white/80 rounded-2xl overflow-hidden border border-white/20 hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
      {/* Featured Image */}
      <div className="aspect-video overflow-hidden">
        <ImageWithFallback
          src={post.featuredImage}
          alt={post.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
      </div>

      {/* Content */}
      <div className="p-6">
        {/* Category & Date */}
        <div className="flex items-center justify-between mb-3">
          <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium bg-gradient-to-r from-[#B6652E] to-[#FFB84D] text-white">
            <Tag className="w-3 h-3" />
            {post.category.replace('-', ' ')}
          </span>
          <div className="flex items-center gap-4 text-xs text-gray-500">
            <span className="flex items-center gap-1">
              <Calendar className="w-3 h-3" />
              {formatDate(post.publishedAt)}
            </span>
            <span className="flex items-center gap-1">
              <Clock className="w-3 h-3" />
              {formatReadTime(post.content)} min read
            </span>
          </div>
        </div>

        {/* Title */}
        <h3 className="text-lg font-semibold text-gray-900 mb-3 group-hover:text-[#B6652E] transition-colors line-clamp-2">
          {post.title}
        </h3>

        {/* Excerpt */}
        <p className="text-gray-600 text-sm mb-4 line-clamp-3">
          {post.excerpt}
        </p>

        {/* Tags */}
        {post.tags && post.tags.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-4">
            {post.tags.slice(0, 3).map((tag) => (
              <span
                key={tag}
                className="px-2 py-1 text-xs text-gray-600 bg-gray-100 rounded-md"
              >
                #{tag}
              </span>
            ))}
          </div>
        )}

        {/* Author & Stats */}
        <div className="flex items-center justify-between pt-4 border-t border-gray-100">
          <div className="flex items-center gap-3">
            <ImageWithFallback
              src={post.author.avatar}
              alt={post.author.name}
              className="w-8 h-8 rounded-full object-cover"
            />
            <div>
              <p className="text-sm font-medium text-gray-900">{post.author.name}</p>
            </div>
          </div>
          <div className="flex items-center gap-4 text-xs text-gray-500">
            <span className="flex items-center gap-1">
              <Eye className="w-3 h-3" />
              {post.views.toLocaleString()}
            </span>
          </div>
        </div>
      </div>
    </article>
  );
}