import React, { useState, useEffect } from 'react';
import { 
  User, Settings, LogOut, Plus, FolderOpen, Clock, 
  CheckCircle, AlertCircle, Upload, Download, Eye,
  BarChart3, TrendingUp, Star, Calendar
} from 'lucide-react';
import { authAPI, projectsAPI, dashboardAPI, handleApiError } from '../../utils/supabase/client';

interface Project {
  id: string;
  title: string;
  description: string;
  package: string;
  status: string;
  createdAt: string;
  updatedAt: string;
  timeline: {
    estimated: number;
    started: string | null;
    completed: string | null;
  };
  files: Array<{
    id: string;
    name: string;
    type: string;
    size: number;
    url: string;
    uploadedAt: string;
  }>;
  revisions: number;
  maxRevisions: number;
}

interface DashboardStats {
  totalProjects: number;
  activeProjects: number;
  completedProjects: number;
  pendingProjects: number;
  recentActivity: Array<{
    id: string;
    title: string;
    status: string;
    updatedAt: string;
  }>;
}

export function Page_UserPortal() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [user, setUser] = useState<any>(null);
  const [projects, setProjects] = useState<Project[]>([]);
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [showNewProjectModal, setShowNewProjectModal] = useState(false);

  useEffect(() => {
    loadUserData();
  }, []);

  const loadUserData = async () => {
    try {
      // 检查登录状态
      const session = await authAPI.getCurrentSession();
      if (!session) {
        window.location.href = '/login';
        return;
      }

      // 加载用户资料
      const profileResult = await authAPI.getProfile();
      setUser(profileResult.profile);

      // 加载项目数据
      const projectsResult = await projectsAPI.getAll();
      setProjects(projectsResult.projects);

      // 加载仪表板统计
      const statsResult = await dashboardAPI.getStats();
      setStats(statsResult.stats);

    } catch (error) {
      console.error('Failed to load user data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSignOut = async () => {
    try {
      await authAPI.signOut();
      window.location.href = '/';
    } catch (error) {
      console.error('Sign out failed:', error);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'text-green-600 bg-green-100';
      case 'in_progress': return 'text-blue-600 bg-blue-100';
      case 'pending': return 'text-yellow-600 bg-yellow-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle className="w-4 h-4" />;
      case 'in_progress': return <Clock className="w-4 h-4" />;
      case 'pending': return <AlertCircle className="w-4 h-4" />;
      default: return <FolderOpen className="w-4 h-4" />;
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-[#B6652E] border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FAFAF8] to-[#F5F3ED]">
      {/* 顶部导航 */}
      <header className="backdrop-blur-xl bg-white/80 border-b border-white/20 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#B6652E] to-[#FFB84D] flex items-center justify-center">
                <User className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="font-semibold text-gray-900">Welcome back, {user?.fullName}</h1>
                <p className="text-sm text-gray-500">{user?.email}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <button className="p-2 rounded-lg hover:bg-white/50 transition-colors">
                <Settings className="w-5 h-5 text-gray-600" />
              </button>
              <button 
                onClick={handleSignOut}
                className="p-2 rounded-lg hover:bg-white/50 transition-colors"
              >
                <LogOut className="w-5 h-5 text-gray-600" />
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex gap-8">
          {/* 侧边栏 */}
          <aside className="w-64 flex-shrink-0">
            <nav className="space-y-2">
              {[
                { id: 'dashboard', label: 'Dashboard', icon: BarChart3 },
                { id: 'projects', label: 'My Projects', icon: FolderOpen },
                { id: 'profile', label: 'Profile', icon: User }
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-left transition-all ${
                    activeTab === item.id
                      ? 'bg-gradient-to-r from-[#B6652E] to-[#FFB84D] text-white shadow-lg'
                      : 'hover:bg-white/50 text-gray-700'
                  }`}
                >
                  <item.icon className="w-5 h-5" />
                  {item.label}
                </button>
              ))}
            </nav>
          </aside>

          {/* 主内容区 */}
          <main className="flex-1">
            {/* 仪表板 */}
            {activeTab === 'dashboard' && stats && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h2 className="text-2xl font-bold text-gray-900">Dashboard</h2>
                  <button
                    onClick={() => setShowNewProjectModal(true)}
                    className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-[#B6652E] to-[#FFB84D] text-white rounded-lg hover:shadow-lg transition-all"
                  >
                    <Plus className="w-4 h-4" />
                    New Project
                  </button>
                </div>

                {/* 统计卡片 */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {[
                    { label: 'Total Projects', value: stats.totalProjects, icon: FolderOpen, color: 'blue' },
                    { label: 'Active Projects', value: stats.activeProjects, icon: Clock, color: 'yellow' },
                    { label: 'Completed', value: stats.completedProjects, icon: CheckCircle, color: 'green' },
                    { label: 'Pending', value: stats.pendingProjects, icon: AlertCircle, color: 'orange' }
                  ].map((stat, index) => (
                    <div key={index} className="backdrop-blur-xl bg-white/80 rounded-2xl p-6 border border-white/20">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm text-gray-600">{stat.label}</p>
                          <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                        </div>
                        <div className={`p-3 rounded-xl bg-${stat.color}-100`}>
                          <stat.icon className={`w-6 h-6 text-${stat.color}-600`} />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* 最近活动 */}
                <div className="backdrop-blur-xl bg-white/80 rounded-2xl p-6 border border-white/20">
                  <h3 className="font-semibold text-gray-900 mb-4">Recent Activity</h3>
                  <div className="space-y-3">
                    {stats.recentActivity.map((activity) => (
                      <div key={activity.id} className="flex items-center gap-4 p-3 rounded-lg hover:bg-gray-50 transition-colors">
                        <div className={`p-2 rounded-lg ${getStatusColor(activity.status)}`}>
                          {getStatusIcon(activity.status)}
                        </div>
                        <div className="flex-1">
                          <p className="font-medium text-gray-900">{activity.title}</p>
                          <p className="text-sm text-gray-500">Updated {formatDate(activity.updatedAt)}</p>
                        </div>
                        <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(activity.status)}`}>
                          {activity.status.replace('_', ' ')}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* 项目列表 */}
            {activeTab === 'projects' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h2 className="text-2xl font-bold text-gray-900">My Projects</h2>
                  <button
                    onClick={() => setShowNewProjectModal(true)}
                    className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-[#B6652E] to-[#FFB84D] text-white rounded-lg hover:shadow-lg transition-all"
                  >
                    <Plus className="w-4 h-4" />
                    New Project
                  </button>
                </div>

                {projects.length === 0 ? (
                  <div className="text-center py-12">
                    <FolderOpen className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No projects yet</h3>
                    <p className="text-gray-500 mb-6">Start your first logo design project today!</p>
                    <button
                      onClick={() => setShowNewProjectModal(true)}
                      className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-[#B6652E] to-[#FFB84D] text-white rounded-lg hover:shadow-lg transition-all"
                    >
                      <Plus className="w-4 h-4" />
                      Create First Project
                    </button>
                  </div>
                ) : (
                  <div className="grid gap-6">
                    {projects.map((project) => (
                      <ProjectCard key={project.id} project={project} />
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* 用户资料 */}
            {activeTab === 'profile' && user && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-gray-900">Profile Settings</h2>
                
                <div className="backdrop-blur-xl bg-white/80 rounded-2xl p-6 border border-white/20">
                  <div className="flex items-center gap-6 mb-6">
                    <div className="w-20 h-20 rounded-full bg-gradient-to-br from-[#B6652E] to-[#FFB84D] flex items-center justify-center">
                      <User className="w-10 h-10 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900">{user.fullName}</h3>
                      <p className="text-gray-500">{user.email}</p>
                      <span className="inline-flex items-center gap-2 px-3 py-1 bg-gradient-to-r from-[#B6652E] to-[#FFB84D] text-white rounded-full text-sm mt-2">
                        <Star className="w-4 h-4" />
                        {user.subscription || 'Free'} Plan
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
                      <input
                        type="text"
                        value={user.fullName}
                        className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-[#B6652E] focus:ring-2 focus:ring-[#B6652E]/20 transition-all"
                        readOnly
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                      <input
                        type="email"
                        value={user.email}
                        className="w-full px-4 py-3 rounded-xl border border-gray-300 bg-gray-50"
                        readOnly
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Member Since</label>
                      <input
                        type="text"
                        value={formatDate(user.createdAt)}
                        className="w-full px-4 py-3 rounded-xl border border-gray-300 bg-gray-50"
                        readOnly
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Projects Completed</label>
                      <input
                        type="text"
                        value={user.projectsCount || 0}
                        className="w-full px-4 py-3 rounded-xl border border-gray-300 bg-gray-50"
                        readOnly
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}
          </main>
        </div>
      </div>

      {/* 新建项目模态框 */}
      {showNewProjectModal && (
        <NewProjectModal 
          onClose={() => setShowNewProjectModal(false)}
          onSuccess={loadUserData}
        />
      )}
    </div>
  );
}

// 项目卡片组件
function ProjectCard({ project }: { project: Project }) {
  return (
    <div className="backdrop-blur-xl bg-white/80 rounded-2xl p-6 border border-white/20 hover:shadow-lg transition-all">
      <div className="flex justify-between items-start mb-4">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">{project.title}</h3>
          <p className="text-gray-600 text-sm mt-1">{project.description}</p>
        </div>
        <span className={`flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(project.status)}`}>
          {getStatusIcon(project.status)}
          {project.status.replace('_', ' ')}
        </span>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
        <div>
          <p className="text-xs text-gray-500">Package</p>
          <p className="font-medium capitalize">{project.package}</p>
        </div>
        <div>
          <p className="text-xs text-gray-500">Created</p>
          <p className="font-medium">{formatDate(project.createdAt)}</p>
        </div>
        <div>
          <p className="text-xs text-gray-500">Files</p>
          <p className="font-medium">{project.files?.length || 0}</p>
        </div>
        <div>
          <p className="text-xs text-gray-500">Revisions</p>
          <p className="font-medium">{project.revisions}/{project.maxRevisions}</p>
        </div>
      </div>

      <div className="flex justify-end gap-2">
        <button className="flex items-center gap-2 px-3 py-2 text-gray-600 hover:text-gray-800 transition-colors">
          <Eye className="w-4 h-4" />
          View
        </button>
        <button className="flex items-center gap-2 px-3 py-2 text-gray-600 hover:text-gray-800 transition-colors">
          <Upload className="w-4 h-4" />
          Upload
        </button>
      </div>
    </div>
  );
}

// 新建项目模态框组件
function NewProjectModal({ onClose, onSuccess }: { onClose: () => void; onSuccess: () => void }) {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    package: 'basic',
    requirements: {
      industry: '',
      style: '',
      colors: '',
      inspiration: ''
    }
  });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      await projectsAPI.create(formData);
      onSuccess();
      onClose();
    } catch (error) {
      console.error('Failed to create project:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <h2 className="text-xl font-bold text-gray-900 mb-6">Start New Project</h2>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Project Title</label>
            <input
              type="text"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-[#B6652E] focus:ring-2 focus:ring-[#B6652E]/20 transition-all"
              placeholder="e.g., Tech Startup Logo"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-[#B6652E] focus:ring-2 focus:ring-[#B6652E]/20 transition-all"
              rows={3}
              placeholder="Brief description of your project..."
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Package</label>
            <select
              value={formData.package}
              onChange={(e) => setFormData({ ...formData, package: e.target.value })}
              className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-[#B6652E] focus:ring-2 focus:ring-[#B6652E]/20 transition-all"
            >
              <option value="basic">Basic Package - $299</option>
              <option value="professional">Professional Package - $599</option>
              <option value="premium">Premium Package - $999</option>
            </select>
          </div>

          <div className="flex justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-3 text-gray-600 hover:text-gray-800 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-6 py-3 bg-gradient-to-r from-[#B6652E] to-[#FFB84D] text-white rounded-lg hover:shadow-lg transition-all disabled:opacity-50"
            >
              {loading ? 'Creating...' : 'Create Project'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// 辅助函数
function getStatusColor(status: string) {
  switch (status) {
    case 'completed': return 'text-green-600 bg-green-100';
    case 'in_progress': return 'text-blue-600 bg-blue-100';
    case 'pending': return 'text-yellow-600 bg-yellow-100';
    default: return 'text-gray-600 bg-gray-100';
  }
}

function getStatusIcon(status: string) {
  switch (status) {
    case 'completed': return <CheckCircle className="w-4 h-4" />;
    case 'in_progress': return <Clock className="w-4 h-4" />;
    case 'pending': return <AlertCircle className="w-4 h-4" />;
    default: return <FolderOpen className="w-4 h-4" />;
  }
}