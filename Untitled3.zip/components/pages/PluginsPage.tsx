import { useState } from "react";
import { Plugin, mockPlugins, categories } from "../../types/plugin";
import { PluginCard } from "../PluginCard";
import { PluginFilters } from "../PluginFilters";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { Separator } from "../ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { toast } from "sonner@2.0.3";
import { Package, Sparkles, TrendingUp, Zap, Star, Users, ArrowRight } from "lucide-react";

export function Page_Plugins() {
  const [plugins, setPlugins] = useState<Plugin[]>(mockPlugins);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("全部");
  const [showInstalledOnly, setShowInstalledOnly] = useState(false);
  const [activeTab, setActiveTab] = useState("discover");

  const handleInstall = (plugin: Plugin) => {
    setPlugins(prev => prev.map(p => 
      p.id === plugin.id ? { ...p, isInstalled: true } : p
    ));
    toast.success(`${plugin.name} 安装成功！`);
  };

  const handleUninstall = (plugin: Plugin) => {
    setPlugins(prev => prev.map(p => 
      p.id === plugin.id ? { ...p, isInstalled: false } : p
    ));
    toast.success(`${plugin.name} 已卸载`);
  };

  const filteredPlugins = plugins.filter(plugin => {
    const matchesSearch = plugin.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         plugin.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         plugin.developer.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         plugin.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesCategory = selectedCategory === "全部" || plugin.category === selectedCategory;
    const matchesInstalled = !showInstalledOnly || plugin.isInstalled;
    
    return matchesSearch && matchesCategory && matchesInstalled;
  });

  const featuredPlugins = plugins.filter(plugin => plugin.isFeatured);
  const wixPlugins = plugins.filter(plugin => 
    plugin.developer.toLowerCase().includes('wix') || 
    plugin.tags.some(tag => tag.toLowerCase().includes('wix'))
  );
  const installedPlugins = plugins.filter(plugin => plugin.isInstalled);
  const totalDownloads = plugins.reduce((sum, plugin) => sum + plugin.downloads, 0);
  const averageRating = plugins.reduce((sum, plugin) => sum + plugin.rating, 0) / plugins.length;

  return (
    <div className="Page_Plugins min-h-screen">
      <div className="Container_Desktop max-w-screen-2xl mx-auto">
        <div className="Container_Tablet">
          <div className="Container_Mobile responsive-padding">
            
            {/* Section_Hero - 插件中心介绍 */}
            <div className="Section_Hero section-mobile text-center">
              <div className="Container_Content max-w-4xl mx-auto">
                <div className="glass-card rounded-3xl responsive-padding">
                  <div className="flex justify-center mb-6">
                    <div className="gradient-gold-rich rounded-2xl p-4">
                      <Zap className="w-8 h-8 text-white" />
                    </div>
                  </div>
                  
                  <h1 className="text-gradient-gold-rich mb-4">
                    WeDesign 插件中心
                  </h1>
                  
                  <p className="text-lead text-ink-soft-brown mb-8 max-w-2xl mx-auto">
                    发现强大的 Figma 插件生态系统，提升你的设计工作流程。特别推荐 Wix 插件，让设计到网站的转换更加无缝。
                  </p>
                  
                  {/* 统计数据 */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 max-w-2xl mx-auto">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-accent-terra mb-2">
                        {plugins.length}+
                      </div>
                      <div className="text-sm text-muted-foreground">优质插件</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-accent-terra mb-2">
                        {(totalDownloads / 1000000).toFixed(1)}M+
                      </div>
                      <div className="text-sm text-muted-foreground">总下载量</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-accent-terra mb-2">
                        {averageRating.toFixed(1)}★
                      </div>
                      <div className="text-sm text-muted-foreground">平均评分</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Section_PluginManager - 主要插件管理功能 */}
            <div className="Section_PluginManager section-mobile">
              <div className="Container_Content max-w-7xl mx-auto">
                
                <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-8">
                  
                  {/* Navigation Tabs */}
                  <div className="glass-card rounded-2xl p-2">
                    <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4 gap-2 bg-transparent">
                      <TabsTrigger 
                        value="discover" 
                        className="flex items-center gap-2 button-glass hover-glass data-[state=active]:gradient-gold data-[state=active]:text-white data-[state=active]:shadow-gold touch-target"
                      >
                        <Sparkles className="w-4 h-4" />
                        <span className="hidden sm:inline">发现</span>
                      </TabsTrigger>
                      <TabsTrigger 
                        value="wix"
                        className="flex items-center gap-2 button-glass hover-glass data-[state=active]:gradient-gold data-[state=active]:text-white data-[state=active]:shadow-gold touch-target"
                      >
                        <Package className="w-4 h-4" />
                        <span className="hidden sm:inline">Wix插件</span>
                      </TabsTrigger>
                      <TabsTrigger 
                        value="installed"
                        className="flex items-center gap-2 button-glass hover-glass data-[state=active]:gradient-gold data-[state=active]:text-white data-[state=active]:shadow-gold touch-target"
                      >
                        <Package className="w-4 h-4" />
                        <span className="hidden sm:inline">已安装</span>
                        <Badge variant="secondary" className="ml-1 text-xs">
                          {installedPlugins.length}
                        </Badge>
                      </TabsTrigger>
                      <TabsTrigger 
                        value="trending"
                        className="flex items-center gap-2 button-glass hover-glass data-[state=active]:gradient-gold data-[state=active]:text-white data-[state=active]:shadow-gold touch-target"
                      >
                        <TrendingUp className="w-4 h-4" />
                        <span className="hidden sm:inline">热门</span>
                      </TabsTrigger>
                    </TabsList>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
                    
                    {/* 侧边栏筛选 */}
                    <div className="lg:col-span-1">
                      <div className="sticky top-6">
                        <div className="glass-card rounded-2xl responsive-padding">
                          <PluginFilters
                            searchQuery={searchQuery}
                            onSearchChange={setSearchQuery}
                            selectedCategory={selectedCategory}
                            onCategoryChange={setSelectedCategory}
                            showInstalledOnly={showInstalledOnly}
                            onShowInstalledChange={setShowInstalledOnly}
                          />
                        </div>
                      </div>
                    </div>

                    {/* 主内容区域 */}
                    <div className="lg:col-span-3">
                      
                      <TabsContent value="discover" className="space-y-8 mt-0">
                        
                        {/* WeDesign 特别推荐 - Wix 插件 */}
                        {wixPlugins.length > 0 && (
                          <div className="glass-card rounded-2xl responsive-padding">
                            <div className="flex items-center justify-between mb-6">
                              <div className="flex items-center gap-3">
                                <div className="gradient-gold rounded-xl p-2">
                                  <Star className="w-5 h-5 text-white" />
                                </div>
                                <div>
                                  <h2 className="text-accent-terra">WeDesign × Wix 插件推荐</h2>
                                  <p className="text-sm text-muted-foreground">
                                    完美集成WeDesign设计到Wix网站的转换
                                  </p>
                                </div>
                              </div>
                              <Badge className="gradient-gold text-white border-none">
                                特别推荐
                              </Badge>
                            </div>
                            
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                              {wixPlugins.map((plugin) => (
                                <div key={plugin.id} className="glass-card rounded-xl hover-glass">
                                  <PluginCard
                                    plugin={plugin}
                                    onInstall={handleInstall}
                                    onUninstall={handleUninstall}
                                  />
                                </div>
                              ))}
                            </div>
                            
                            <div className="text-center">
                              <Button 
                                onClick={() => setActiveTab("wix")}
                                className="button-glass-secondary hover-gold"
                              >
                                查看所有 Wix 插件
                                <ArrowRight className="w-4 h-4 ml-2" />
                              </Button>
                            </div>
                          </div>
                        )}

                        {/* 精选插件 */}
                        {featuredPlugins.length > 0 && (
                          <div className="glass-card rounded-2xl responsive-padding">
                            <div className="flex items-center gap-3 mb-6">
                              <div className="gradient-gold-soft rounded-xl p-2">
                                <Sparkles className="w-5 h-5 text-white" />
                              </div>
                              <h2 className="text-accent-terra">精选插件</h2>
                            </div>
                            
                            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                              {featuredPlugins.slice(0, 6).map((plugin) => (
                                <div key={plugin.id} className="glass-card rounded-xl hover-glass">
                                  <PluginCard
                                    plugin={plugin}
                                    onInstall={handleInstall}
                                    onUninstall={handleUninstall}
                                  />
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* 所有插件 */}
                        <div className="glass-card rounded-2xl responsive-padding">
                          <div className="flex items-center justify-between mb-6">
                            <div className="flex items-center gap-3">
                              <div className="gradient-gold-rich rounded-xl p-2">
                                <Package className="w-5 h-5 text-white" />
                              </div>
                              <h2 className="text-accent-terra">所有插件</h2>
                            </div>
                            <span className="text-sm text-muted-foreground">
                              {filteredPlugins.length} 个插件
                            </span>
                          </div>
                          
                          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                            {filteredPlugins.map((plugin) => (
                              <div key={plugin.id} className="glass-card rounded-xl hover-glass">
                                <PluginCard
                                  plugin={plugin}
                                  onInstall={handleInstall}
                                  onUninstall={handleUninstall}
                                />
                              </div>
                            ))}
                          </div>
                        </div>
                      </TabsContent>

                      <TabsContent value="wix" className="space-y-6 mt-0">
                        <div className="glass-card rounded-2xl responsive-padding">
                          <div className="flex items-center gap-3 mb-4">
                            <div className="gradient-gold rounded-xl p-2">
                              <Package className="w-5 h-5 text-white" />
                            </div>
                            <div>
                              <h2 className="text-accent-terra">Wix 插件生态</h2>
                              <p className="text-sm text-muted-foreground">
                                官方和第三方插件，帮你将 Figma 设计无缝转换为 Wix 网站
                              </p>
                            </div>
                          </div>
                          
                          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                            {wixPlugins.map((plugin) => (
                              <div key={plugin.id} className="glass-card rounded-xl hover-glass">
                                <PluginCard
                                  plugin={plugin}
                                  onInstall={handleInstall}
                                  onUninstall={handleUninstall}
                                />
                              </div>
                            ))}
                          </div>
                        </div>
                      </TabsContent>

                      <TabsContent value="installed" className="space-y-6 mt-0">
                        <div className="glass-card rounded-2xl responsive-padding">
                          <div className="flex items-center gap-3 mb-6">
                            <div className="gradient-gold-rich rounded-xl p-2">
                              <Package className="w-5 h-5 text-white" />
                            </div>
                            <h2 className="text-accent-terra">已安装插件</h2>
                          </div>
                          
                          {installedPlugins.length === 0 ? (
                            <div className="text-center py-16">
                              <div className="gradient-gold-soft rounded-2xl p-6 w-20 h-20 mx-auto mb-6 flex items-center justify-center">
                                <Package className="w-8 h-8 text-white" />
                              </div>
                              
                              <h3 className="text-accent-terra mb-3">还没有安装任何插件</h3>
                              <p className="text-muted-foreground mb-6 max-w-md mx-auto">
                                浏览我们精选的插件库，找到适合你工作流程的完美工具
                              </p>
                              
                              <Button 
                                className="button-glass-primary"
                                onClick={() => setActiveTab("discover")}
                              >
                                浏览插件商店
                                <Sparkles className="w-4 h-4 ml-2" />
                              </Button>
                            </div>
                          ) : (
                            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                              {installedPlugins.map((plugin) => (
                                <div key={plugin.id} className="glass-card rounded-xl hover-glass">
                                  <PluginCard
                                    plugin={plugin}
                                    onInstall={handleInstall}
                                    onUninstall={handleUninstall}
                                  />
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      </TabsContent>

                      <TabsContent value="trending" className="space-y-6 mt-0">
                        <div className="glass-card rounded-2xl responsive-padding">
                          <div className="flex items-center gap-3 mb-4">
                            <div className="gradient-gold-rich rounded-xl p-2">
                              <TrendingUp className="w-5 h-5 text-white" />
                            </div>
                            <div>
                              <h2 className="text-accent-terra">热门插件排行</h2>
                              <p className="text-sm text-muted-foreground">
                                根据下载量和用户评分排序的热门插件
                              </p>
                            </div>
                          </div>
                          
                          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                            {[...plugins]
                              .sort((a, b) => b.downloads - a.downloads)
                              .map((plugin, index) => (
                                <div key={plugin.id} className="glass-card rounded-xl hover-glass relative">
                                  {index < 3 && (
                                    <div className="absolute -top-2 -right-2 z-10">
                                      <div className="gradient-gold rounded-full w-8 h-8 flex items-center justify-center text-white text-sm font-bold shadow-gold">
                                        {index + 1}
                                      </div>
                                    </div>
                                  )}
                                  <PluginCard
                                    plugin={plugin}
                                    onInstall={handleInstall}
                                    onUninstall={handleUninstall}
                                  />
                                </div>
                              ))}
                          </div>
                        </div>
                      </TabsContent>
                    </div>
                  </div>
                </Tabs>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}