import { CheckCircle, AlertTriangle, AlertCircle, Monitor, Tablet, Smartphone } from 'lucide-react';

interface AuditItem {
  page: string;
  viewport: 'Desktop' | 'Tablet' | 'Mobile';
  status: 'good' | 'warning' | 'critical';
  recommendations: string[];
}

const auditData: AuditItem[] = [
  // Home Page
  {
    page: 'Home',
    viewport: 'Desktop',
    status: 'warning',
    recommendations: [
      'Hero section could use better vertical spacing on larger screens',
      'Live Design Hall background image needs optimization for 1440px+',
      'Consider sticky navigation behavior during scroll'
    ]
  },
  {
    page: 'Home',
    viewport: 'Tablet',
    status: 'warning',
    recommendations: [
      'Journey cards need better spacing in 2-column layout',
      'How It Works video thumbnail should scale proportionally',
      'Header navigation requires hamburger menu implementation'
    ]
  },
  {
    page: 'Home',
    viewport: 'Mobile',
    status: 'critical',
    recommendations: [
      'Live Design Hall project cards overlap on screens < 400px',
      'Hero CTA buttons need vertical stacking with proper spacing',
      'Choose Journey section needs single column layout',
      'Touch targets in Live Hall are too small (< 44px)'
    ]
  },

  // Logos Design Page
  {
    page: 'Logos Design',
    viewport: 'Desktop',
    status: 'good',
    recommendations: [
      'Masonry grid layout works well',
      'Filter controls are properly aligned'
    ]
  },
  {
    page: 'Logos Design',
    viewport: 'Tablet',
    status: 'warning',
    recommendations: [
      'Filter bar needs better responsive stacking',
      'Logo grid should reduce to 2 columns instead of 3',
      'Modal content needs tablet-specific padding adjustments'
    ]
  },
  {
    page: 'Logos Design',
    viewport: 'Mobile',
    status: 'warning',
    recommendations: [
      'Search input and filters should stack vertically',
      'Logo cards need increased vertical spacing',
      'Modal dialog should be full-height on mobile'
    ]
  },

  // Live Design Hall
  {
    page: 'Live Design Hall',
    viewport: 'Desktop',
    status: 'good',
    recommendations: [
      '4-column grid layout works effectively',
      'Background image overlay provides good text contrast'
    ]
  },
  {
    page: 'Live Design Hall',
    viewport: 'Tablet',
    status: 'warning',
    recommendations: [
      'Project cards should reduce to 2 columns',
      'Tab buttons need better touch targets',
      'Stats section needs responsive number formatting'
    ]
  },
  {
    page: 'Live Design Hall',
    viewport: 'Mobile',
    status: 'critical',
    recommendations: [
      'Single column layout required for project cards',
      'Background image creates text readability issues',
      'Action buttons need full-width treatment',
      'Timer displays are too small and hard to read'
    ]
  },

  // About Us Page
  {
    page: 'About Us',
    viewport: 'Desktop',
    status: 'good',
    recommendations: [
      'Timeline layout is well-structured',
      'Team grid displays properly'
    ]
  },
  {
    page: 'About Us',
    viewport: 'Tablet',
    status: 'warning',
    recommendations: [
      'Team member grid should reduce to 2 columns',
      'Timeline alternating layout needs adjustment',
      'Stats section icons need size optimization'
    ]
  },
  {
    page: 'About Us',
    viewport: 'Mobile',
    status: 'warning',
    recommendations: [
      'Timeline should use single column layout',
      'Team member cards need better mobile spacing',
      'Hero section image positioning needs work'
    ]
  },

  // Blog Page
  {
    page: 'Blog',
    viewport: 'Desktop',
    status: 'good',
    recommendations: [
      'Article grid layout is effective',
      'Sidebar content is well-organized'
    ]
  },
  {
    page: 'Blog',
    viewport: 'Tablet',
    status: 'warning',
    recommendations: [
      'Sidebar should move below main content',
      'Article cards need better responsive images',
      'Category filters need scrollable horizontal layout'
    ]
  },
  {
    page: 'Blog',
    viewport: 'Mobile',
    status: 'critical',
    recommendations: [
      'Article detail modal should be full-screen',
      'Search bar is too narrow on small screens',
      'Category buttons overflow container',
      'Reading experience needs typography improvements'
    ]
  },

  // Login Page
  {
    page: 'Login',
    viewport: 'Desktop',
    status: 'good',
    recommendations: [
      'Centered layout works well',
      'Form validation is clear'
    ]
  },
  {
    page: 'Login',
    viewport: 'Tablet',
    status: 'good',
    recommendations: [
      'Form maintains good proportions',
      'Background elements scale appropriately'
    ]
  },
  {
    page: 'Login',
    viewport: 'Mobile',
    status: 'warning',
    recommendations: [
      'Form could use better vertical spacing',
      'Social login buttons need touch target optimization',
      'Error states need better mobile formatting'
    ]
  },

  // User Portal
  {
    page: 'User Portal',
    viewport: 'Desktop',
    status: 'good',
    recommendations: [
      'Sidebar navigation works effectively',
      'Dashboard cards are well-organized'
    ]
  },
  {
    page: 'User Portal',
    viewport: 'Tablet',
    status: 'critical',
    recommendations: [
      'Sidebar needs collapsible mobile drawer',
      'Order cards should stack in single column',
      'Chat interface needs touch optimization',
      'File grid needs responsive columns'
    ]
  },
  {
    page: 'User Portal',
    viewport: 'Mobile',
    status: 'critical',
    recommendations: [
      'Missing responsive version - sidebar blocks content',
      'Need bottom tab navigation for mobile',
      'Chat messages need better mobile layout',
      'File download actions are too small',
      'Progress bars need larger touch targets'
    ]
  },

  // Admin Dashboard (Future)
  {
    page: 'Admin Dashboard',
    viewport: 'Desktop',
    status: 'warning',
    recommendations: [
      'Page not implemented yet',
      'Should include data tables and admin controls',
      'Needs proper role-based access'
    ]
  },
  {
    page: 'Admin Dashboard',
    viewport: 'Tablet',
    status: 'critical',
    recommendations: [
      'Missing responsive version',
      'Admin controls need touch-friendly interface',
      'Data visualization needs mobile adaptation'
    ]
  },
  {
    page: 'Admin Dashboard',
    viewport: 'Mobile',
    status: 'critical',
    recommendations: [
      'Missing responsive version',
      'Complex admin functions need mobile UX design',
      'Consider simplified mobile admin interface'
    ]
  }
];

const getStatusIcon = (status: string) => {
  switch (status) {
    case 'good':
      return <CheckCircle className="w-5 h-5 text-green-600" />;
    case 'warning':
      return <AlertTriangle className="w-5 h-5 text-yellow-600" />;
    case 'critical':
      return <AlertCircle className="w-5 h-5 text-red-600" />;
    default:
      return <CheckCircle className="w-5 h-5 text-gray-400" />;
  }
};

const getStatusColor = (status: string) => {
  switch (status) {
    case 'good':
      return 'bg-green-50 border-green-200';
    case 'warning':
      return 'bg-yellow-50 border-yellow-200';
    case 'critical':
      return 'bg-red-50 border-red-200';
    default:
      return 'bg-gray-50 border-gray-200';
  }
};

const getViewportIcon = (viewport: string) => {
  switch (viewport) {
    case 'Desktop':
      return <Monitor className="w-4 h-4" />;
    case 'Tablet':
      return <Tablet className="w-4 h-4" />;
    case 'Mobile':
      return <Smartphone className="w-4 h-4" />;
    default:
      return <Monitor className="w-4 h-4" />;
  }
};

export function UXAuditBoard() {
  const pages = [...new Set(auditData.map(item => item.page))];
  const totalIssues = auditData.length;
  const criticalIssues = auditData.filter(item => item.status === 'critical').length;
  const warningIssues = auditData.filter(item => item.status === 'warning').length;
  const goodItems = auditData.filter(item => item.status === 'good').length;

  return (
    <div className="Audit_Responsive_Review bg-[#F9F8F4] min-h-screen">
      {/* Sticky Header */}
      <div className="sticky top-0 z-10 bg-white shadow-luxury border-b border-border">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-ink-deep-brown mb-2">
                Responsive UX Audit – WeDesign
              </h1>
              <p className="text-muted-foreground">
                Cross-platform UX improvements and responsive design recommendations
              </p>
            </div>
            
            {/* Summary Stats */}
            <div className="flex items-center gap-6">
              <div className="text-center">
                <div className="text-xl font-bold text-red-600">{criticalIssues}</div>
                <div className="text-xs text-muted-foreground">Critical</div>
              </div>
              <div className="text-center">
                <div className="text-xl font-bold text-yellow-600">{warningIssues}</div>
                <div className="text-xs text-muted-foreground">Warning</div>
              </div>
              <div className="text-center">
                <div className="text-xl font-bold text-green-600">{goodItems}</div>
                <div className="text-xs text-muted-foreground">Good</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Audit Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Filter Tabs */}
        <div className="mb-8">
          <div className="flex flex-wrap gap-2 mb-6">
            <button className="px-4 py-2 gradient-gold text-white rounded-lg font-medium">
              All Pages
            </button>
            {pages.map((page) => (
              <button
                key={page}
                className="px-4 py-2 bg-white hover:bg-muted border border-border rounded-lg font-medium transition-colors"
              >
                {page}
              </button>
            ))}
          </div>
        </div>

        {/* Audit Grid */}
        <div className="space-y-4">
          {/* Grid Header */}
          <div className="grid grid-cols-12 gap-4 p-4 bg-white rounded-lg shadow-sm border border-border font-medium text-sm text-muted-foreground">
            <div className="col-span-3">Page Name</div>
            <div className="col-span-2">Viewport</div>
            <div className="col-span-1">Status</div>
            <div className="col-span-6">Recommendations</div>
          </div>

          {/* Audit Rows */}
          {auditData.map((item, index) => (
            <div
              key={index}
              className={`grid grid-cols-12 gap-4 p-4 rounded-lg border-2 shadow-sm ${getStatusColor(item.status)}`}
            >
              {/* Page Name */}
              <div className="col-span-3">
                <div className="font-semibold text-ink-deep-brown">{item.page}</div>
              </div>

              {/* Viewport */}
              <div className="col-span-2">
                <div className="flex items-center gap-2 text-sm">
                  {getViewportIcon(item.viewport)}
                  <span>{item.viewport}</span>
                  <span className="text-muted-foreground">
                    {item.viewport === 'Desktop' && '(1440px)'}
                    {item.viewport === 'Tablet' && '(768px)'}
                    {item.viewport === 'Mobile' && '(375px)'}
                  </span>
                </div>
              </div>

              {/* Status */}
              <div className="col-span-1">
                {getStatusIcon(item.status)}
              </div>

              {/* Recommendations */}
              <div className="col-span-6">
                <ul className="space-y-2">
                  {item.recommendations.map((rec, recIndex) => (
                    <li key={recIndex} className="flex items-start gap-2 text-sm">
                      <span className="text-accent-terra font-bold">•</span>
                      <span>{rec}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>

        {/* Priority Summary */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-red-50 border-2 border-red-200 rounded-2xl p-6">
            <h3 className="text-red-800 font-semibold mb-3 flex items-center gap-2">
              <AlertCircle className="w-5 h-5" />
              Critical Issues ({criticalIssues})
            </h3>
            <p className="text-red-700 text-sm">
              These issues significantly impact user experience and should be addressed immediately. 
              Focus on mobile responsiveness and touch target optimization.
            </p>
          </div>

          <div className="bg-yellow-50 border-2 border-yellow-200 rounded-2xl p-6">
            <h3 className="text-yellow-800 font-semibold mb-3 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5" />
              Warnings ({warningIssues})
            </h3>
            <p className="text-yellow-700 text-sm">
              Areas for improvement that would enhance user experience. Consider addressing these 
              in the next development cycle.
            </p>
          </div>

          <div className="bg-green-50 border-2 border-green-200 rounded-2xl p-6">
            <h3 className="text-green-800 font-semibold mb-3 flex items-center gap-2">
              <CheckCircle className="w-5 h-5" />
              Working Well ({goodItems})
            </h3>
            <p className="text-green-700 text-sm">
              These implementations are working effectively and provide good user experience 
              across the specified viewport.
            </p>
          </div>
        </div>

        {/* Action Items */}
        <div className="mt-12 bg-white rounded-2xl p-8 shadow-luxury">
          <h3 className="text-xl font-semibold text-ink-deep-brown mb-6">Recommended Action Plan</h3>
          
          <div className="space-y-6">
            <div>
              <h4 className="font-semibold text-ink-deep-brown mb-3 flex items-center gap-2">
                <span className="w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center text-sm">1</span>
                Immediate Priority: Mobile Responsiveness
              </h4>
              <ul className="space-y-1 text-sm text-muted-foreground ml-8">
                <li>• Fix User Portal mobile layout - implement bottom navigation</li>
                <li>• Resolve Live Design Hall card overlapping on small screens</li>
                <li>• Optimize touch targets across all pages (minimum 44px)</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold text-ink-deep-brown mb-3 flex items-center gap-2">
                <span className="w-6 h-6 bg-yellow-500 text-white rounded-full flex items-center justify-center text-sm">2</span>
                Medium Priority: Tablet Experience
              </h4>
              <ul className="space-y-1 text-sm text-muted-foreground ml-8">
                <li>• Implement responsive grid layouts (4→2→1 columns)</li>
                <li>• Optimize filter controls for tablet touch interaction</li>
                <li>• Adjust modal sizing for tablet viewports</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold text-ink-deep-brown mb-3 flex items-center gap-2">
                <span className="w-6 h-6 bg-green-500 text-white rounded-full flex items-center justify-center text-sm">3</span>
                Enhancement: Desktop Polish
              </h4>
              <ul className="space-y-1 text-sm text-muted-foreground ml-8">
                <li>• Optimize large screen layouts (1440px+)</li>
                <li>• Enhance scroll behaviors and animations</li>
                <li>• Implement Admin Dashboard responsive design</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Technical Notes */}
        <div className="mt-8 bg-muted/30 rounded-xl p-6">
          <h4 className="font-semibold text-ink-deep-brown mb-3">Technical Implementation Notes</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <h5 className="font-medium mb-2">Frame Naming for Wix Studio</h5>
              <ul className="space-y-1 text-muted-foreground">
                <li>• Use Page_[Name] for top-level frames</li>
                <li>• Section_[Name] for major content areas</li>
                <li>• Component_[Name] for reusable elements</li>
              </ul>
            </div>
            <div>
              <h5 className="font-medium mb-2">Responsive Breakpoints</h5>
              <ul className="space-y-1 text-muted-foreground">
                <li>• Mobile: 320px - 767px</li>
                <li>• Tablet: 768px - 1023px</li>
                <li>• Desktop: 1024px+</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}