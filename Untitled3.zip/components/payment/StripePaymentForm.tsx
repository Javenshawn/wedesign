import React, { useState, useEffect } from 'react';
import { loadStripe } from '@stripe/stripe-js';
import { Elements, CardElement, useStripe, useElements } from '@stripe/react-stripe-js';
import { 
  CreditCard, Shield, Lock, CheckCircle, AlertCircle, 
  DollarSign, Calendar, User, Mail 
} from 'lucide-react';
import { getEnvVar } from '../../utils/env-utils';
import { stripePaymentAPI, formatAmount, getCurrencySymbol, STRIPE_TEST_CARDS } from '../../utils/stripe-client';
import { projectId, publicAnonKey } from '../../utils/supabase/info';

interface PaymentFormProps {
  amount: number;
  currency: string;
  packageName: string;
  projectDetails: any;
  onSuccess: (paymentResult: any) => void;
  onError: (error: string) => void;
  onCancel: () => void;
}

interface PaymentMethod {
  id: string;
  type: 'card' | 'paypal' | 'alipay' | 'wechat';
  name: string;
  icon: React.ReactNode;
  fees: string;
  processingTime: string;
}

interface CardFormData {
  cardholderName: string;
  email: string;
  billingAddress: {
    country: string;
    postalCode: string;
  };
}

// Get Stripe publishable key - using a more build-system compatible approach
const getStripeKey = () => {
  // For now, return empty string to avoid build issues
  // This will allow the app to use development mode simulation
  return '';
};

// Initialize Stripe - will be null without key, triggering dev mode
const stripePromise = loadStripe(getStripeKey());

// Stripe card element styles
const cardElementStyle = {
  style: {
    base: {
      fontSize: '16px',
      color: '#4a3f36',
      fontFamily: 'Inter, sans-serif',
      '::placeholder': {
        color: '#9b8b7a',
      },
    },
    invalid: {
      color: '#e85d5d',
      iconColor: '#e85d5d',
    },
  },
};

// Payment form component (wrapped inside Elements)
function PaymentForm({ 
  amount, 
  currency, 
  packageName, 
  projectDetails, 
  onSuccess, 
  onError, 
  onCancel 
}: PaymentFormProps) {
  const stripe = useStripe();
  const elements = useElements();
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentIntent, setPaymentIntent] = useState<any>(null);
  const [showTestCards, setShowTestCards] = useState(false);
  const [cardData, setCardData] = useState<CardFormData>({
    cardholderName: '',
    email: projectDetails?.email || '',
    billingAddress: {
      country: 'US',
      postalCode: ''
    }
  });
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});

  // Create payment intent
  useEffect(() => {
    const createPaymentIntent = async () => {
      try {
        console.log('🔄 Creating payment intent:', { amount, currency, packageName });
        
        const intent = await stripePaymentAPI.createPaymentIntent(
          amount, // Amount should already be in cents
          currency,
          {
            package: packageName,
            project_name: projectDetails?.logoName || projectDetails?.companyName || 'Untitled Project',
            source: 'wedesign_website'
          }
        );
        
        setPaymentIntent(intent);
        console.log('✅ Payment intent created successfully:', intent.id);
      } catch (error: any) {
        console.error('❌ Failed to create payment intent:', error);
        onError(error.message || 'Payment initialization failed');
      }
    };

    if (amount && currency) {
      createPaymentIntent();
    }
  }, [amount, currency, packageName, projectDetails]);

  const handleInputChange = (field: string, value: string) => {
    setCardData(prev => {
      if (field.includes('.')) {
        const [parent, child] = field.split('.');
        return {
          ...prev,
          [parent]: {
            ...prev[parent as keyof CardFormData],
            [child]: value
          }
        };
      }
      return {
        ...prev,
        [field]: value
      };
    });

    // Clear validation error
    if (validationErrors[field]) {
      setValidationErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[field];
        return newErrors;
      });
    }
  };

  const validateForm = (): boolean => {
    const errors: Record<string, string> = {};

    if (!cardData.cardholderName.trim()) {
      errors.cardholderName = 'Please enter cardholder name';
    }

    if (!cardData.email.trim()) {
      errors.email = 'Please enter email address';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cardData.email)) {
      errors.email = 'Please enter a valid email address';
    }

    if (!cardData.billingAddress.postalCode.trim()) {
      errors.postalCode = 'Please enter postal code';
    }

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();

    if (!stripe || !elements || !paymentIntent) {
      onError('Payment system not ready, please try again');
      return;
    }

    if (!validateForm()) {
      return;
    }

    setIsProcessing(true);

    try {
      const cardElement = elements.getElement(CardElement);
      if (!cardElement) {
        throw new Error('Card element not found');
      }

      console.log('🔄 Starting payment confirmation process');

      const { error, paymentIntent: confirmedPaymentIntent } = await stripe.confirmCardPayment(
        paymentIntent.client_secret,
        {
          payment_method: {
            card: cardElement,
            billing_details: {
              name: cardData.cardholderName,
              email: cardData.email,
              address: {
                country: cardData.billingAddress.country,
                postal_code: cardData.billingAddress.postalCode,
              },
            },
          },
        }
      );

      if (error) {
        console.error('❌ Payment confirmation failed:', error);
        const errorMessage = error.message || 'Payment failed, please try again';
        onError(errorMessage);
      } else if (confirmedPaymentIntent && confirmedPaymentIntent.status === 'succeeded') {
        console.log('✅ Payment completed successfully:', confirmedPaymentIntent.id);
        
        // Create order record
        try {
          const orderData = {
            projectId: projectDetails?.id || `proj_${Date.now()}`,
            amount: amount / 100, // Convert cents back to dollars for order record
            currency,
            paymentIntentId: confirmedPaymentIntent.id,
            packageType: packageName,
            projectDetails
          };
          
          // Call backend API to create order
          const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-d0d1e627/orders`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${publicAnonKey}`
            },
            body: JSON.stringify(orderData)
          });

          if (response.ok) {
            console.log('✅ Order record created successfully');
          } else {
            console.warn('⚠️ Order record creation failed, but payment succeeded');
          }
        } catch (orderError) {
          console.warn('⚠️ Order creation failed:', orderError);
        }

        onSuccess({
          id: confirmedPaymentIntent.id,
          amount: confirmedPaymentIntent.amount,
          currency: confirmedPaymentIntent.currency,
          status: confirmedPaymentIntent.status,
          receipt_email: cardData.email,
          payment_method: confirmedPaymentIntent.payment_method
        });
      } else {
        onError('Payment status anomaly, please contact customer service');
      }
    } catch (error: any) {
      console.error('❌ Payment processing exception:', error);
      onError(error.message || 'Payment processing failed, please try again');
    } finally {
      setIsProcessing(false);
    }
  };

  const insertTestCardNumber = (cardNumber: string) => {
    const cardElement = elements?.getElement(CardElement);
    if (cardElement) {
      // Due to Stripe Elements limitations, we can't directly insert card numbers
      // But we can show test card numbers for manual input
      setShowTestCards(true);
    }
  };

  return (
    <div className="StripePaymentForm max-w-2xl mx-auto">
      {/* Order Summary */}
      <div className="glass-card rounded-2xl p-6 mb-6">
        <h3 className="text-lg font-semibold text-ink-deep-brown mb-4">Order Summary</h3>
        <div className="space-y-3">
          <div className="flex justify-between">
            <span className="text-ink-soft-brown">Package</span>
            <span className="font-medium text-ink-deep-brown">{packageName}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-ink-soft-brown">Project Name</span>
            <span className="font-medium text-ink-deep-brown">{projectDetails?.logoName || projectDetails?.companyName || 'Untitled Project'}</span>
          </div>
          <div className="border-t border-glass-border pt-3 flex justify-between text-lg font-semibold">
            <span className="text-ink-deep-brown">Total</span>
            <span className="text-gradient-gold-rich">
              {formatAmount(amount / 100, currency)}
            </span>
          </div>
        </div>
      </div>

      {/* Test card number prompt - always show in development mode */}
      {true && (
        <div className="glass-card rounded-2xl p-4 mb-6 border-l-4 border-blue-500">
          <div className="flex items-start gap-3">
            <CheckCircle className="w-5 h-5 text-blue-500 flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="font-medium text-ink-deep-brown mb-2">Test Mode</h4>
              <p className="text-sm text-ink-soft-brown mb-3">
                Currently in test environment, please use the following test card numbers. No real charges will be made.
              </p>
              <div className="space-y-2">
                <div className="p-3 bg-gray-50 rounded-lg">
                  <div className="font-mono text-sm">
                    <strong>Successful Payment:</strong> 4242 4242 4242 4242
                  </div>
                  <div className="text-xs text-gray-500 mt-1">
                    Expiry: Any future date (e.g. 12/25) | CVV: Any 3 digits (e.g. 123)
                  </div>
                </div>
                <div className="p-3 bg-red-50 rounded-lg">
                  <div className="font-mono text-sm">
                    <strong>Failed Payment:</strong> 4000 0000 0000 0002
                  </div>
                  <div className="text-xs text-gray-500 mt-1">For testing payment failure scenarios</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Payment form */}
      <form onSubmit={handleSubmit} className="glass-card rounded-2xl p-6">
        <div className="flex items-center gap-2 mb-6">
          <Shield className="w-5 h-5 text-green-600" />
          <span className="text-sm text-ink-soft-brown">256-bit SSL encryption protection</span>
        </div>

        <div className="space-y-6">
          {/* Card information */}
          <div>
            <label className="block text-sm font-medium text-ink-deep-brown mb-3">
              Card Information *
            </label>
            <div className="p-4 border border-glass-border rounded-xl bg-white focus-within:border-accent-terra focus-within:ring-2 focus-within:ring-accent-terra/20">
              <CardElement options={cardElementStyle} />
            </div>
          </div>

          {/* Cardholder name */}
          <div>
            <label className="block text-sm font-medium text-ink-deep-brown mb-2">
              Cardholder Name *
            </label>
            <div className="relative">
              <input
                type="text"
                value={cardData.cardholderName}
                onChange={(e) => handleInputChange('cardholderName', e.target.value)}
                className={`w-full px-4 py-3 pl-12 input-glass rounded-xl transition-colors ${
                  validationErrors.cardholderName 
                    ? 'border-red-300 focus:border-red-500' 
                    : 'border-glass-border focus:border-accent-terra'
                } focus:ring-2 focus:ring-accent-terra/20`}
                placeholder="As shown on card"
              />
              <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            </div>
            {validationErrors.cardholderName && (
              <p className="text-sm text-red-600 mt-1">{validationErrors.cardholderName}</p>
            )}
          </div>

          {/* Email address */}
          <div>
            <label className="block text-sm font-medium text-ink-deep-brown mb-2">
              Email Address * <span className="text-xs text-ink-soft-brown">(for receipt)</span>
            </label>
            <div className="relative">
              <input
                type="email"
                value={cardData.email}
                onChange={(e) => handleInputChange('email', e.target.value)}
                className={`w-full px-4 py-3 pl-12 input-glass rounded-xl transition-colors ${
                  validationErrors.email 
                    ? 'border-red-300 focus:border-red-500' 
                    : 'border-glass-border focus:border-accent-terra'
                } focus:ring-2 focus:ring-accent-terra/20`}
                placeholder="your@email.com"
              />
              <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            </div>
            {validationErrors.email && (
              <p className="text-sm text-red-600 mt-1">{validationErrors.email}</p>
            )}
          </div>

          {/* Billing address */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-ink-deep-brown mb-2">
                Country/Region *
              </label>
              <select
                value={cardData.billingAddress.country}
                onChange={(e) => handleInputChange('billingAddress.country', e.target.value)}
                className="w-full px-4 py-3 input-glass rounded-xl border-glass-border focus:border-accent-terra focus:ring-2 focus:ring-accent-terra/20"
              >
                <option value="US">United States</option>
                <option value="CA">Canada</option>
                <option value="GB">United Kingdom</option>
                <option value="AU">Australia</option>
                <option value="DE">Germany</option>
                <option value="FR">France</option>
                <option value="CN">China</option>
                <option value="JP">Japan</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-ink-deep-brown mb-2">
                Postal Code *
              </label>
              <input
                type="text"
                value={cardData.billingAddress.postalCode}
                onChange={(e) => handleInputChange('billingAddress.postalCode', e.target.value)}
                className={`w-full px-4 py-3 input-glass rounded-xl transition-colors ${
                  validationErrors.postalCode 
                    ? 'border-red-300 focus:border-red-500' 
                    : 'border-glass-border focus:border-accent-terra'
                } focus:ring-2 focus:ring-accent-terra/20`}
                placeholder="12345"
              />
              {validationErrors.postalCode && (
                <p className="text-sm text-red-600 mt-1">{validationErrors.postalCode}</p>
              )}
            </div>
          </div>
        </div>

        {/* Security notice */}
        <div className="mt-6 p-4 glass-effect rounded-xl">
          <div className="flex items-start gap-3">
            <Lock className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="font-medium text-ink-deep-brown mb-1">Security Guarantee</h4>
              <p className="text-sm text-ink-soft-brown">
                Your payment information is transmitted via 256-bit SSL encryption and complies with PCI DSS security standards. We do not store your card information.
              </p>
            </div>
          </div>
        </div>

        {/* Submit buttons */}
        <div className="flex flex-col sm:flex-row gap-4 mt-8">
          <button
            type="button"
            onClick={onCancel}
            className="flex-1 px-6 py-3 border border-glass-border text-ink-soft-brown rounded-xl hover:bg-gray-50 transition-colors"
            disabled={isProcessing}
          >
            Cancel
          </button>
          
          <button
            type="submit"
            disabled={isProcessing || !stripe || !paymentIntent}
            className="flex-1 px-6 py-4 button-glass-primary rounded-xl font-medium disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isProcessing ? (
              <div className="flex items-center justify-center gap-2">
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                Processing...
              </div>
            ) : (
              `Pay ${formatAmount(amount / 100, currency)}`
            )}
          </button>
        </div>
      </form>
    </div>
  );
}

// Main component, wrapping Stripe Elements Provider
export function StripePaymentForm(props: PaymentFormProps) {
  return (
    <Elements stripe={stripePromise}>
      <PaymentForm {...props} />
    </Elements>
  );
}