import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Input } from "../ui/input";
import { Search, Filter } from "lucide-react";
import { WeDesignButton } from "../design-system/WeDesignButton";

const portfolioItems = [
  {
    image: "https://images.unsplash.com/photo-1572044162444-ad60f128bdea?w=300&h=300&fit=crop&crop=center",
    title: "Modern Tech Startup",
    industry: "Technology",
    colors: ["Blue", "White"],
  },
  {
    image: "https://images.unsplash.com/photo-1515378791036-0648a814c963?w=300&h=300&fit=crop&crop=center",
    title: "Organic Restaurant",
    industry: "Food & Beverage", 
    colors: ["Green", "Brown"],
  },
  {
    image: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1f?w=300&h=300&fit=crop&crop=center",
    title: "Healthcare Clinic",
    industry: "Healthcare",
    colors: ["Blue", "White"],
  },
  {
    image: "https://images.unsplash.com/photo-1533750349088-cd871a92f312?w=300&h=300&fit=crop&crop=center", 
    title: "Fashion Boutique",
    industry: "Fashion",
    colors: ["Pink", "Gold"],
  },
  {
    image: "https://images.unsplash.com/photo-1555421689-491a97ff2040?w=300&h=300&fit=crop&crop=center",
    title: "Fitness Studio", 
    industry: "Fitness",
    colors: ["Orange", "Black"],
  },
  {
    image: "https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=300&h=300&fit=crop&crop=center",
    title: "Law Firm",
    industry: "Legal",
    colors: ["Navy", "Gold"],
  }
];

export function Section_CompactPortfolio() {
  return (
    <section className="Section_CompactPortfolio bg-bg-light-ivory">
      <div className="max-w-7xl mx-auto responsive-padding">
        {/* Compact Header with Gradient Title - Total height ~60px */}
        <div className="text-center mb-4">
          <h2 className="text-gradient-gold font-heading text-xl md:text-2xl lg:text-3xl font-bold mb-1 tracking-tight">
            Our Logo Design Portfolio
          </h2>
          <p className="font-body text-sm md:text-base text-ink-soft-brown max-w-2xl mx-auto leading-relaxed">
            Explore our collection of professional logo designs created for clients across various industries. Each design tells a unique story and builds a memorable brand identity.
          </p>
        </div>

        {/* Compact Filter Bar - Height ~40px */}
        <div className="FilterBar_Compact flex flex-col sm:flex-row gap-2 mb-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search logos..."
                className="Input_Search pl-8 h-9 text-sm input-glass"
              />
            </div>
          </div>
          
          <div className="flex gap-2">
            <Select>
              <SelectTrigger className="Select_Industry w-32 h-9 bg-white border-border text-sm">
                <SelectValue placeholder="All Industries" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Industries</SelectItem>
                <SelectItem value="technology">Technology</SelectItem>
                <SelectItem value="food">Food & Beverage</SelectItem>
                <SelectItem value="healthcare">Healthcare</SelectItem>
                <SelectItem value="fashion">Fashion</SelectItem>
                <SelectItem value="fitness">Fitness</SelectItem>
                <SelectItem value="legal">Legal</SelectItem>
              </SelectContent>
            </Select>

            <Select>
              <SelectTrigger className="Select_Color w-28 h-9 bg-white border-border text-sm">
                <SelectValue placeholder="All Colors" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Colors</SelectItem>
                <SelectItem value="blue">Blue</SelectItem>
                <SelectItem value="green">Green</SelectItem>
                <SelectItem value="red">Red</SelectItem>
                <SelectItem value="purple">Purple</SelectItem>
                <SelectItem value="orange">Orange</SelectItem>
                <SelectItem value="black">Black</SelectItem>
              </SelectContent>
            </Select>

            <button className="button-glass px-2 h-9 rounded-md hover:shadow-glass transition-all touch-target">
              <Filter className="w-4 h-4 text-muted-foreground" />
            </button>
          </div>

          <div className="text-sm text-muted-foreground flex items-center">
            6 results
          </div>
        </div>

        {/* Compact Portfolio Grid - Height ~110px */}
        <div className="Portfolio_Grid_Compact" style={{ height: '110px' }}>
          <div className="grid grid-cols-3 md:grid-cols-6 gap-2 h-full">
            {portfolioItems.map((item, index) => (
              <div 
                key={index}
                className="Portfolio_Item glass-card rounded-lg overflow-hidden hover:shadow-glass-lg transition-all duration-300 hover:scale-105 cursor-pointer group"
              >
                <div className="relative h-full">
                  <img 
                    src={item.image}
                    alt={item.title}
                    className="w-full h-full object-cover"
                  />
                  {/* Gradient Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  
                  {/* Compact Info Overlay */}
                  <div className="absolute bottom-0 left-0 right-0 p-1.5 transform translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                    <div className="text-white text-xs font-medium mb-0.5 line-clamp-1">
                      {item.title}
                    </div>
                    <div className="text-white/80 text-xs line-clamp-1">
                      {item.industry}
                    </div>
                    <div className="flex gap-1 mt-0.5">
                      {item.colors.map((color, colorIndex) => (
                        <span 
                          key={colorIndex}
                          className="text-xs px-1 py-0.5 bg-white/20 backdrop-blur-sm rounded text-white/90"
                        >
                          {color}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Compact Action Section - Height ~16px */}
        <div className="text-center mt-4">
          <WeDesignButton
            variant="secondary-outline"
            size="sm"
            className="text-sm px-4 py-1.5 h-8"
          >
            View All Portfolio →
          </WeDesignButton>
        </div>
      </div>
    </section>
  );
}