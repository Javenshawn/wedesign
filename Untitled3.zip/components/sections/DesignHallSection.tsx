import { WeDesignTaskCard } from "../design-system/WeDesignTaskCard";
import { WeDesignButton } from "../design-system/WeDesignButton";
import { ArrowRight } from "lucide-react";

const mockTasks = [
  {
    orderNumber: "WD-2024-001",
    packageName: "Restaurant Logo Design",
    packageType: "Business" as const,
    progress: 85,
    timeRemaining: "2 hours",
    status: "In Progress" as const
  },
  {
    orderNumber: "WD-2024-002", 
    packageName: "Tech Startup Branding",
    packageType: "Private Jet" as const,
    progress: 100,
    timeRemaining: "",
    status: "Completed" as const
  },
  {
    orderNumber: "WD-2024-003",
    packageName: "E-commerce Logo",
    packageType: "Economy" as const,
    progress: 45,
    timeRemaining: "1 day",
    status: "In Progress" as const
  },
  {
    orderNumber: "WD-2024-004",
    packageName: "Healthcare Brand Identity",
    packageType: "Business" as const,
    progress: 75,
    timeRemaining: "6 hours",
    status: "Review" as const
  }
];

export function Section_LiveTasks() {
  return (
    <section className="Section_DesignHall py-20 bg-bg-light-ivory">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="font-heading text-2xl md:text-3xl font-bold text-ink-deep-brown mb-4 tracking-tight">
            Live Design Hall
          </h2>
          <p className="font-body text-lg md:text-xl text-ink-soft-brown max-w-2xl mx-auto leading-relaxed">
            Watch our designers work their magic in real-time. 
            Your project could be featured here next!
          </p>
        </div>

        <div className="Repeater_TaskCards grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {mockTasks.map((task, index) => (
            <WeDesignTaskCard
              key={task.orderNumber}
              {...task}
              className="Card_Task"
            />
          ))}
        </div>

        <div className="text-center">
          <WeDesignButton
            variant="primary-gold"
            size="lg"
            className="flex items-center gap-2 mx-auto"
          >
            View All Projects
            <ArrowRight className="w-5 h-5" />
          </WeDesignButton>
        </div>
      </div>
    </section>
  );
}