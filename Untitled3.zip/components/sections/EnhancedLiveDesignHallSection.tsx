import { useState, useEffect } from 'react';
import { Clock, User, Package, Download, MessageCircle, Eye } from 'lucide-react';
import { WeDesignButton } from '../design-system/WeDesignButton';

interface ProjectCard {
  id: string;
  orderNumber: string;
  clientName: string;
  clientInitials: string;
  logoName: string;
  packageType: 'Economy' | 'Business' | 'Private Jet';
  status: 'In Progress' | 'Review' | 'Completed' | 'Revision';
  progress: number;
  timeLeft: string;
  timeLeftMs: number;
  designer: string;
}

// 扩展的项目数据池，用于翻牌动画
const allProjects: ProjectCard[] = [
  // 第一组
  {
    id: '1',
    orderNumber: 'WD-2024-0847',
    clientName: 'TechFlow Solutions',
    clientInitials: 'TF',
    logoName: 'TechFlow Logo',
    packageType: 'Business',
    status: 'In Progress',
    progress: 75,
    timeLeft: '18h 42m',
    timeLeftMs: 67320000,
    designer: 'Sarah Chen'
  },
  {
    id: '2',
    orderNumber: 'WD-2024-0848',
    clientName: 'Green Garden Cafe',
    clientInitials: 'GG',
    logoName: 'Organic Cafe Brand',
    packageType: 'Economy',
    status: 'Review',
    progress: 95,
    timeLeft: '4h 15m',
    timeLeftMs: 15300000,
    designer: 'Marcus Rodriguez'
  },
  {
    id: '3',
    orderNumber: 'WD-2024-0849',
    clientName: 'Urban Fashion Co',
    clientInitials: 'UF',
    logoName: 'Fashion House Logo',
    packageType: 'Private Jet',
    status: 'Completed',
    progress: 100,
    timeLeft: 'Delivered',
    timeLeftMs: 0,
    designer: 'Emily Thompson'
  },
  {
    id: '4',
    orderNumber: 'WD-2024-0850',
    clientName: 'MedCare Plus',
    clientInitials: 'MC',
    logoName: 'Healthcare Identity',
    packageType: 'Business',
    status: 'Revision',
    progress: 60,
    timeLeft: '24h 30m',
    timeLeftMs: 88200000,
    designer: 'David Kim'
  },
  // 第二组
  {
    id: '5',
    orderNumber: 'WD-2024-0851',
    clientName: 'FitLife Gym',
    clientInitials: 'FL',
    logoName: 'Fitness Center Brand',
    packageType: 'Business',
    status: 'In Progress',
    progress: 40,
    timeLeft: '36h 12m',
    timeLeftMs: 130320000,
    designer: 'Lisa Wang'
  },
  {
    id: '6',
    orderNumber: 'WD-2024-0852',
    clientName: 'EduBright Academy',
    clientInitials: 'EA',
    logoName: 'Education Logo',
    packageType: 'Economy',
    status: 'In Progress',
    progress: 25,
    timeLeft: '48h 08m',
    timeLeftMs: 173280000,
    designer: 'James Foster'
  },
  {
    id: '7',
    orderNumber: 'WD-2024-0853',
    clientName: 'Solar Innovations',
    clientInitials: 'SI',
    logoName: 'Clean Energy Brand',
    packageType: 'Private Jet',
    status: 'In Progress',
    progress: 85,
    timeLeft: '12h 25m',
    timeLeftMs: 44700000,
    designer: 'Sarah Chen'
  },
  {
    id: '8',
    orderNumber: 'WD-2024-0854',
    clientName: 'Artisan Coffee',
    clientInitials: 'AC',
    logoName: 'Coffee House Logo',
    packageType: 'Business',
    status: 'Review',
    progress: 90,
    timeLeft: '6h 55m',
    timeLeftMs: 24900000,
    designer: 'Marcus Rodriguez'
  },
  // 第三组
  {
    id: '9',
    orderNumber: 'WD-2024-0855',
    clientName: 'Sky Airlines',
    clientInitials: 'SA',
    logoName: 'Airline Identity',
    packageType: 'Private Jet',
    status: 'In Progress',
    progress: 65,
    timeLeft: '28h 15m',
    timeLeftMs: 101700000,
    designer: 'Emma Johnson'
  },
  {
    id: '10',
    orderNumber: 'WD-2024-0856',
    clientName: 'Fresh Mart',
    clientInitials: 'FM',
    logoName: 'Grocery Store Logo',
    packageType: 'Economy',
    status: 'Completed',
    progress: 100,
    timeLeft: 'Delivered',
    timeLeftMs: 0,
    designer: 'Alex Cooper'
  },
  {
    id: '11',
    orderNumber: 'WD-2024-0857',
    clientName: 'Digital Dynamics',
    clientInitials: 'DD',
    logoName: 'Tech Startup Brand',
    packageType: 'Business',
    status: 'Review',
    progress: 88,
    timeLeft: '8h 33m',
    timeLeftMs: 30780000,
    designer: 'Sophie Martinez'
  },
  {
    id: '12',
    orderNumber: 'WD-2024-0858',
    clientName: 'Ocean View Resort',
    clientInitials: 'OV',
    logoName: 'Luxury Resort Logo',
    packageType: 'Private Jet',
    status: 'In Progress',
    progress: 52,
    timeLeft: '41h 22m',
    timeLeftMs: 148920000,
    designer: 'Ryan Taylor'
  },
  // 第四组
  {
    id: '13',
    orderNumber: 'WD-2024-0859',
    clientName: 'Pure Wellness',
    clientInitials: 'PW',
    logoName: 'Spa & Wellness Brand',
    packageType: 'Business',
    status: 'Revision',
    progress: 72,
    timeLeft: '19h 45m',
    timeLeftMs: 71100000,
    designer: 'Maya Patel'
  },
  {
    id: '14',
    orderNumber: 'WD-2024-0860',
    clientName: 'Smart Home Pro',
    clientInitials: 'SH',
    logoName: 'IoT Company Logo',
    packageType: 'Economy',
    status: 'In Progress',
    progress: 33,
    timeLeft: '44h 16m',
    timeLeftMs: 159360000,
    designer: 'Chris Lee'
  },
  {
    id: '15',
    orderNumber: 'WD-2024-0861',
    clientName: 'Apex Financial',
    clientInitials: 'AF',
    logoName: 'Investment Firm Brand',
    packageType: 'Private Jet',
    status: 'Review',
    progress: 94,
    timeLeft: '2h 47m',
    timeLeftMs: 9420000,
    designer: 'Isabella Garcia'
  },
  {
    id: '16',
    orderNumber: 'WD-2024-0862',
    clientName: 'Green Energy Co',
    clientInitials: 'GE',
    logoName: 'Renewable Energy Logo',
    packageType: 'Business',
    status: 'Completed',
    progress: 100,
    timeLeft: 'Delivered',
    timeLeftMs: 0,
    designer: 'Nathan Brooks'
  }
];

interface EnhancedLiveDesignHallSectionProps {
  onStartProject: () => void;
  onSubmitChanges?: () => void;
  onViewAllProjects?: () => void;
}

export function Section_DesignHall({ onStartProject, onSubmitChanges, onViewAllProjects }: EnhancedLiveDesignHallSectionProps) {
  const [activeTab, setActiveTab] = useState<'all' | 'client'>('all');
  const [currentProjects, setCurrentProjects] = useState(allProjects.slice(0, 8));
  const [currentTime, setCurrentTime] = useState(new Date());
  const [animationStates, setAnimationStates] = useState<('idle' | 'flipping' | 'updating')[]>(new Array(8).fill('idle'));
  const [projectSetIndex, setProjectSetIndex] = useState(0);

  // Update time every minute
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 60000);

    return () => clearInterval(timer);
  }, []);

  // 优化的连续翻牌动画效果
  useEffect(() => {
    const flipCycle = setInterval(() => {
      const rowsCount = 2; // 2行
      const cardsPerRow = 4; // 每行4个卡片
      const totalAnimationTime = 3600; // 每个卡片完整循环时间（毫秒）

      for (let row = 0; row < rowsCount; row++) {
        setTimeout(() => {
          // 开始翻转动画
          setAnimationStates(prev => {
            const newStates = [...prev];
            for (let col = 0; col < cardsPerRow; col++) {
              const index = row * cardsPerRow + col;
              if (index < newStates.length) {
                newStates[index] = 'flipping';
              }
            }
            return newStates;
          });

          // 在动画中间点更换数据
          setTimeout(() => {
            setAnimationStates(prev => {
              const newStates = [...prev];
              for (let col = 0; col < cardsPerRow; col++) {
                const index = row * cardsPerRow + col;
                if (index < newStates.length) {
                  newStates[index] = 'updating';
                }
              }
              return newStates;
            });

            // 更换项目数据
            if (row === rowsCount - 1) { // 最后一行开始更新时更换数据
              setProjectSetIndex(prevIndex => {
                const nextIndex = (prevIndex + 1) % 2; // 在两组数据之间切换
                const startIndex = nextIndex * 8;
                setCurrentProjects(allProjects.slice(startIndex, startIndex + 8));
                return nextIndex;
              });
            }
          }, totalAnimationTime / 2); // 在动画中间点更换数据

          // 完成翻转回到正面
          setTimeout(() => {
            setAnimationStates(prev => {
              const newStates = [...prev];
              for (let col = 0; col < cardsPerRow; col++) {
                const index = row * cardsPerRow + col;
                if (index < newStates.length) {
                  newStates[index] = 'idle';
                }
              }
              return newStates;
            });
          }, totalAnimationTime);

        }, row * 500); // 每行延迟500ms，让动画更有层次
      }
    }, 8000); // 每8秒进行一次完整的翻牌循环

    return () => clearInterval(flipCycle);
  }, []);

  // 随机更新项目进度 - 调整为更慢的节奏
  useEffect(() => {
    const progressTimer = setInterval(() => {
      setCurrentProjects(prev => {
        const newProjects = [...prev];
        const randomIndex = Math.floor(Math.random() * newProjects.length);
        if (newProjects[randomIndex].status === 'In Progress' && newProjects[randomIndex].progress < 95) {
          newProjects[randomIndex] = {
            ...newProjects[randomIndex],
            progress: Math.min(100, newProjects[randomIndex].progress + Math.floor(Math.random() * 3) + 1)
          };
        }
        return newProjects;
      });
    }, 10000); // 从8秒增加到10秒，让进度更新更慢

    return () => clearInterval(progressTimer);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Completed':
        return 'bg-green-100 text-green-800 border border-green-200';
      case 'In Progress':
        return 'bg-blue-100 text-blue-800 border border-blue-200';
      case 'Review':
        return 'bg-yellow-100 text-yellow-800 border border-yellow-200';
      case 'Revision':
        return 'bg-orange-100 text-orange-800 border border-orange-200';
      default:
        return 'bg-gray-100 text-gray-800 border border-gray-200';
    }
  };

  const getPackageColor = (packageType: string) => {
    switch (packageType) {
      case 'Private Jet':
        return 'gradient-gold text-white';
      case 'Business':
        return 'bg-accent-terra text-white';
      case 'Economy':
        return 'bg-green-600 text-white';
      default:
        return 'bg-gray-500 text-white';
    }
  };

  const filteredProjects = activeTab === 'client' 
    ? currentProjects.filter(p => ['Completed', 'Review'].includes(p.status))
    : currentProjects;

  return (
    <div className="enhanced-live-design-hall-section">
      <style dangerouslySetInnerHTML={{
        __html: `
          .enhanced-live-design-hall-section .card-flip-continuous {
            animation: cardFlipContinuous 3.6s ease-in-out;
          }

          .enhanced-live-design-hall-section .card-updating {
            animation: cardFlipContinuous 3.6s ease-in-out;
            animation-fill-mode: forwards;
          }

          .enhanced-live-design-hall-section .card-container-3d {
            transform-style: preserve-3d;
            perspective: 1200px;
          }

          .enhanced-live-design-hall-section .card-inner-3d {
            transition: transform 0.1s ease-out;
            transform-style: preserve-3d;
          }

          .enhanced-live-design-hall-section .card-back-optimized {
            backface-visibility: hidden;
            transform: rotateY(180deg);
          }

          .enhanced-live-design-hall-section .card-front-optimized {
            backface-visibility: hidden;
          }

          @keyframes cardFlipContinuous {
            0% {
              transform: rotateY(0deg);
            }
            50% {
              transform: rotateY(180deg);
            }
            100% {
              transform: rotateY(360deg);
            }
          }
        `
      }} />

      <section className="Section_LiveDesignHall glass-card py-8 md:py-12 relative overflow-hidden">
        {/* Background Elements */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-1/4 left-10 w-64 h-64 gradient-gold-soft opacity-5 rounded-full blur-3xl"></div>
          <div className="absolute bottom-1/4 right-10 w-80 h-80 gradient-gold opacity-3 rounded-full blur-3xl"></div>
        </div>

        <div className="Container_Content max-w-7xl mx-auto px-4 md:px-6 relative z-10">
          {/* 紧凑的Section Header */}
          <div className="Container_SectionHeader text-center mb-4">
            {/* 渐变色标题 */}
            <h2 className="text-gradient-gold text-2xl md:text-3xl lg:text-4xl font-bold mb-2">
              Live Design Hall
            </h2>
            <p className="text-sm md:text-base text-ink-soft-brown max-w-2xl mx-auto">
              Watch our busy design studio in action! Projects are constantly being updated, reviewed, and delivered to satisfied clients worldwide.
            </p>
          </div>

          {/* 紧凑的Tabs */}
          <div className="Container_Tabs flex items-center justify-center gap-2 mb-4">
            <button
              onClick={() => setActiveTab('all')}
              className={`button-glass px-4 py-2 rounded-lg font-medium text-sm transition-all touch-target ${ 
                activeTab === 'all' 
                  ? 'button-glass-primary shadow-glass' 
                  : 'hover:shadow-glass text-ink-deep-brown'
              }`}
            >
              All Projects ({allProjects.length})
            </button>
            <button
              onClick={() => setActiveTab('client')}
              className={`button-glass px-4 py-2 rounded-lg font-medium text-sm transition-all touch-target ${
                activeTab === 'client' 
                  ? 'button-glass-primary shadow-glass' 
                  : 'hover:shadow-glass text-ink-deep-brown'
              }`}
            >
              Client View ({currentProjects.filter(p => ['Completed', 'Review'].includes(p.status)).length})
            </button>
          </div>

          {/* 紧凑的Live Status Indicator */}
          <div className="Container_LiveIndicator flex items-center justify-center gap-2 mb-6">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            <span className="text-xs text-muted-foreground">Live updates • Projects refreshing automatically</span>
          </div>

          {/* Project Grid with Enhanced Continuous Flip Animation */}
          <div className="Grid_Projects grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
            {filteredProjects.map((project, index) => (
              <div 
                key={`${project.id}-${projectSetIndex}`}
                className={`Card_ProjectContainer relative h-72 card-container-3d ${
                  animationStates[index] === 'flipping' ? 'card-flip-continuous' : ''
                } ${
                  animationStates[index] === 'updating' ? 'card-updating' : ''
                }`}
                style={{ 
                  perspective: '1200px',
                  animationDelay: `${Math.floor(index / 4) * 500 + (index % 4) * 125}ms`,
                }}
              >
                <div className={`Card_ProjectInner card-inner-3d relative w-full h-full`}>
                  {/* Front of card */}
                  <div className="Card_ProjectFront card-front-optimized glass-card rounded-xl p-3 hover:shadow-glass-lg transition-all duration-500 absolute inset-0">
                    {/* Header */}
                    <div className="Container_ProjectHeader flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 gradient-gold-soft rounded-lg flex items-center justify-center text-white font-semibold text-xs">
                          {project.clientInitials}
                        </div>
                        <div>
                          <div className="text-ink-deep-brown font-medium text-xs">{project.orderNumber}</div>
                          <div className="text-muted-foreground text-xs">{project.clientName}</div>
                        </div>
                      </div>
                      
                      <div className={`px-1.5 py-0.5 rounded-md text-xs font-medium glass-effect ${getStatusColor(project.status)}`}>
                        {project.status}
                      </div>
                    </div>

                    {/* Logo Name & Package */}
                    <div className="Container_ProjectInfo mb-2">
                      <h4 className="text-ink-deep-brown font-semibold text-sm mb-1 line-clamp-1">{project.logoName}</h4>
                      <div className={`inline-block px-2 py-0.5 rounded-md text-xs font-medium ${getPackageColor(project.packageType)}`}>
                        {project.packageType}
                      </div>
                    </div>

                    {/* Progress Bar */}
                    <div className="Container_Progress mb-2">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-muted-foreground text-xs">Progress</span>
                        <span className="text-ink-deep-brown font-semibold text-xs">{project.progress}%</span>
                      </div>
                      <div className="w-full bg-muted/40 rounded-full h-1.5">
                        <div 
                          className="gradient-gold-soft h-1.5 rounded-full transition-all duration-[3000ms] ease-out"
                          style={{ width: `${project.progress}%` }}
                        ></div>
                      </div>
                    </div>

                    {/* Countdown Timer */}
                    <div className="Container_Timer mb-2">
                      <div className="flex items-center gap-1.5 text-muted-foreground">
                        <Clock className="w-3 h-3" />
                        <span className="text-xs font-mono glass-effect px-2 py-0.5 rounded text-ink-deep-brown">
                          {project.timeLeft}
                        </span>
                      </div>
                    </div>

                    {/* Designer */}
                    <div className="Container_Designer mb-2">
                      <div className="flex items-center gap-1.5 text-muted-foreground text-xs">
                        <User className="w-3 h-3" />
                        <span>Designer: {project.designer}</span>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="Container_Actions space-y-1">
                      {project.status === 'Completed' && (
                        <button className="w-full button-glass flex items-center justify-center gap-1.5 gradient-gold-soft text-white py-1.5 rounded-md text-xs font-medium transition-all duration-300 hover:scale-105">
                          <Download className="w-3 h-3" />
                          Download
                        </button>
                      )}
                      
                      {project.status === 'Review' && (
                        <button className="w-full button-glass flex items-center justify-center gap-1.5 bg-yellow-600/90 text-white py-1.5 rounded-md text-xs font-medium transition-all duration-300 hover:scale-105">
                          <Eye className="w-3 h-3" />
                          Review
                        </button>
                      )}

                      <button className="w-full button-glass flex items-center justify-center gap-1.5 text-ink-deep-brown py-1.5 rounded-md text-xs font-medium transition-all duration-300 hover:shadow-glass">
                        <MessageCircle className="w-3 h-3" />
                        Message
                      </button>
                    </div>
                  </div>

                  {/* Back of card - Enhanced Loading state */}
                  <div className="Card_ProjectBack card-back-optimized glass-modal rounded-xl p-3 absolute inset-0 gradient-gold-soft flex flex-col items-center justify-center text-white">
                    <div className="w-12 h-12 border-4 border-white/30 border-t-white rounded-full animate-spin mb-3"></div>
                    <div className="text-base font-semibold mb-1">Refreshing...</div>
                    <div className="text-sm opacity-90 text-center">
                      Fetching latest project data
                    </div>
                    <div className="mt-3 flex gap-1">
                      <div className="w-1.5 h-1.5 bg-white/60 rounded-full animate-pulse"></div>
                      <div className="w-1.5 h-1.5 bg-white/60 rounded-full animate-pulse" style={{animationDelay: '0.2s'}}></div>
                      <div className="w-1.5 h-1.5 bg-white/60 rounded-full animate-pulse" style={{animationDelay: '0.4s'}}></div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* 紧凑的Action Buttons */}
          <div className="Container_ActionButtons flex flex-col sm:flex-row items-center justify-center gap-3 mb-6">
            <WeDesignButton
              variant="primary-gold"
              size="md"
              onClick={onStartProject}
              className="px-5 py-2.5"
            >
              Start Project
            </WeDesignButton>

            <WeDesignButton
              variant="secondary-outline"
              size="md"
              onClick={onSubmitChanges}
              className="px-5 py-2.5"
            >
              Submit Changes
            </WeDesignButton>

            <button
              onClick={onViewAllProjects}
              className="text-accent-terra hover:text-accent-terra/80 font-medium transition-colors text-sm"
            >
              View All Projects →
            </button>
          </div>

          {/* 紧凑的Live Stats - Single Row */}
          <div className="Container_Stats grid grid-cols-4 gap-3 max-w-3xl mx-auto">
            <div className="glass-card text-center rounded-lg p-3 hover:shadow-glass transition-all duration-300">
              <div className="text-lg font-bold text-ink-deep-brown mb-0.5">
                {allProjects.filter(p => p.status === 'In Progress').length}
              </div>
              <div className="text-muted-foreground text-xs">Active Projects</div>
            </div>
            <div className="glass-card text-center rounded-lg p-3 hover:shadow-glass transition-all duration-300">
              <div className="text-lg font-bold text-ink-deep-brown mb-0.5">15</div>
              <div className="text-muted-foreground text-xs">Designers Online</div>
            </div>
            <div className="glass-card text-center rounded-lg p-3 hover:shadow-glass transition-all duration-300">
              <div className="text-lg font-bold text-ink-deep-brown mb-0.5">
                {allProjects.filter(p => p.status === 'Completed').length}
              </div>
              <div className="text-muted-foreground text-xs">Completed Today</div>
            </div>
            <div className="glass-card text-center rounded-lg p-3 hover:shadow-glass transition-all duration-300">
              <div className="text-lg font-bold text-ink-deep-brown mb-0.5">24h</div>
              <div className="text-muted-foreground text-xs">Avg Delivery</div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}