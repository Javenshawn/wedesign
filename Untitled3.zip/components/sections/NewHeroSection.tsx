interface NewHeroSectionProps {
  onStartProject?: () => void;
  onViewWork?: () => void;
}

export function NewHeroSection({ onStartProject, onViewWork }: NewHeroSectionProps) {
  return (
    <section className="Section_Hero relative bg-gradient-to-b from-bg-light-ivory to-white py-20 lg:py-32 overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-20 left-10 w-64 h-64 gradient-gold rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-10 w-80 h-80 gradient-gold rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-7xl mx-auto px-6 relative">
        <div className="flex justify-center items-center">
          {/* Hero Content - Image Removed */}
          <div className="text-center max-w-4xl">
            <h1 className="mb-6">
              Professional <span className="text-gradient-gold">Logo Design</span> Services
            </h1>
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Get stunning, memorable logos crafted by expert designers. From concept to completion with unlimited revisions.
            </p>
            
            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={onStartProject}
                className="px-8 py-4 gradient-gold text-white rounded-xl font-medium hover:scale-105 transition-transform shadow-luxury"
              >
                Start Your Project
              </button>
              <button
                onClick={onViewWork}
                className="px-8 py-4 bg-white border border-accent-terra text-accent-terra rounded-xl font-medium hover:bg-accent-terra/5 transition-colors shadow-luxury"
              >
                View Our Work
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}