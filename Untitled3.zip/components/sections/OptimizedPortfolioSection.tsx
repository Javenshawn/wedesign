import { useState } from "react";
import { Search, Filter } from "lucide-react";
import { Input } from "../ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";

const portfolioItems = [
  {
    image: "https://images.unsplash.com/photo-1572044162444-ad60f128bdea?w=400&h=300&fit=crop&crop=center",
    title: "Modern Tech Startup",
    industry: "Technology",
    colors: ["Minimalist", "Blue", "Professional"],
    category: "tech"
  },
  {
    image: "https://images.unsplash.com/photo-1515378791036-0648a814c963?w=400&h=300&fit=crop&crop=center",
    title: "Organic Restaurant",
    industry: "Food & Beverage", 
    colors: ["Organic", "Green", "Natural"],
    category: "food"
  },
  {
    image: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1f?w=400&h=300&fit=crop&crop=center",
    title: "Healthcare Clinic",
    industry: "Healthcare",
    colors: ["Medical", "Trust", "Clean"],
    category: "health"
  },
  {
    image: "https://images.unsplash.com/photo-1533750349088-cd871a92f312?w=400&h=300&fit=crop&crop=center", 
    title: "Fashion Boutique",
    industry: "Fashion",
    colors: ["Elegant", "Luxury", "Pink"],
    category: "fashion"
  },
  {
    image: "https://images.unsplash.com/photo-1555421689-491a97ff2040?w=400&h=300&fit=crop&crop=center",
    title: "Fitness Studio", 
    industry: "Fitness",
    colors: ["Dynamic", "Energy", "Orange"],
    category: "fitness"
  },
  {
    image: "https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=400&h=300&fit=crop&crop=center",
    title: "Law Firm",
    industry: "Legal",
    colors: ["Professional", "Trust", "Navy"],
    category: "legal"
  },
  {
    image: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=400&h=300&fit=crop&crop=center",
    title: "Creative Agency",
    industry: "Marketing",
    colors: ["Creative", "Bold", "Purple"],
    category: "marketing"
  },
  {
    image: "https://images.unsplash.com/photo-1486312338219-ce68e2c6b7bd?w=400&h=300&fit=crop&crop=center",
    title: "Financial Services",
    industry: "Finance",
    colors: ["Trust", "Stability", "Blue"],
    category: "finance"
  }
];

export function Section_OptimizedPortfolio() {
  const [selectedIndustry, setSelectedIndustry] = useState("all");
  const [selectedColor, setSelectedColor] = useState("all");
  
  // Show all items
  const visibleItems = portfolioItems;

  return (
    <section className="Section_OptimizedPortfolio bg-bg-light-ivory py-4 md:py-6">
      <div className="max-w-7xl mx-auto px-4 md:px-6">
        
        {/* Header Section */}
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-4 gap-3">
          <div className="flex-1 text-center">
            <h2 className="text-gradient-gold-rich font-heading text-xl md:text-2xl lg:text-3xl font-bold tracking-tight leading-tight mb-2">
              Our Logo Design Portfolio
            </h2>
            <p className="font-body text-sm md:text-base text-ink-soft-brown leading-relaxed max-w-2xl mx-auto">
              Explore our collection of professional logo designs created for clients across various industries. Each design tells a unique story and builds a memorable brand identity.
            </p>
          </div>
        </div>

        {/* Filters Section */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 mb-6">
          <div className="flex-1 max-w-sm">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search logos..."
                className="Input_Search pl-10 h-12 sm:h-10 text-sm input-glass border-0 rounded-xl focus:ring-2 focus:ring-accent-terra/20"
              />
            </div>
          </div>
          
          <div className="flex gap-3 flex-wrap sm:flex-nowrap">
            <Select value={selectedIndustry} onValueChange={setSelectedIndustry}>
              <SelectTrigger className="flex-1 sm:w-40 h-12 sm:h-10 glass-effect border-0 text-sm rounded-xl focus:ring-2 focus:ring-accent-terra/20">
                <SelectValue placeholder="All Industries" />
              </SelectTrigger>
              <SelectContent className="glass-modal rounded-xl">
                <SelectItem value="all">All Industries</SelectItem>
                <SelectItem value="technology">Technology</SelectItem>
                <SelectItem value="food">Food & Beverage</SelectItem>
                <SelectItem value="healthcare">Healthcare</SelectItem>
                <SelectItem value="fashion">Fashion</SelectItem>
                <SelectItem value="fitness">Fitness</SelectItem>
                <SelectItem value="legal">Legal</SelectItem>
              </SelectContent>
            </Select>

            <Select value={selectedColor} onValueChange={setSelectedColor}>
              <SelectTrigger className="flex-1 sm:w-32 h-12 sm:h-10 glass-effect border-0 text-sm rounded-xl focus:ring-2 focus:ring-accent-terra/20">
                <SelectValue placeholder="All Colors" />
              </SelectTrigger>
              <SelectContent className="glass-modal rounded-xl">
                <SelectItem value="all">All Colors</SelectItem>
                <SelectItem value="blue">Blue</SelectItem>
                <SelectItem value="green">Green</SelectItem>
                <SelectItem value="orange">Orange</SelectItem>
                <SelectItem value="purple">Purple</SelectItem>
                <SelectItem value="pink">Pink</SelectItem>
                <SelectItem value="navy">Navy</SelectItem>
              </SelectContent>
            </Select>

            <div className="hidden sm:flex items-center text-sm text-muted-foreground px-4 whitespace-nowrap">
              {portfolioItems.length} results
            </div>
          </div>
        </div>



        {/* Portfolio Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
          {visibleItems.map((item, index) => (
            <div 
              key={item.image}
              className="Portfolio_Item glass-card rounded-xl overflow-hidden hover:shadow-luxury-lg transition-all duration-300 hover:scale-[1.02] cursor-pointer group relative aspect-square"
            >
              <div className="relative w-full h-full">
                <img 
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                
                {/* Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                
                {/* Info Overlay */}
                <div className="absolute bottom-0 left-0 right-0 p-3 transform translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                  <div className="text-white font-medium text-sm mb-1 line-clamp-1">
                    {item.title}
                  </div>
                  <div className="text-white/80 text-xs mb-2 line-clamp-1">
                    {item.industry}
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {item.colors.slice(0, 2).map((color, colorIndex) => (
                      <span 
                        key={colorIndex}
                        className="text-xs px-2 py-1 glass-effect-strong rounded-md text-white/90 font-medium"
                      >
                        {color}
                      </span>
                    ))}
                    {item.colors.length > 2 && (
                      <span className="text-xs px-2 py-1 glass-effect-strong rounded-md text-white/70">
                        +{item.colors.length - 2}
                      </span>
                    )}
                  </div>
                </div>

                {/* Corner Badge */}
                <div className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="w-6 h-6 gradient-gold rounded-full flex items-center justify-center">
                    <div className="w-2 h-2 bg-white rounded-full"></div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>


      </div>
    </section>
  );
}