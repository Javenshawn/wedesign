import { WeDesignPricingCard } from "../design-system/WeDesignPricingCard";
import { Badge } from "../ui/badge";
import { Sparkles, Zap, Crown } from "lucide-react";

interface Section_PricingProps {
  onSelectPackage: (packageName: string) => void;
}

const packages = [
  {
    name: "Economy",
    icon: <Sparkles className="w-5 h-5" />,
    price: 199,
    originalPrice: 299,
    features: [
      "3 Original Logo Concepts",
      "2 Revision Rounds",
      "High-Resolution Files (PNG, JPG)",
      "Basic Brand Guidelines",
      "7-Day Delivery",
      "Email Support"
    ],
    isPopular: false
  },
  {
    name: "Business", 
    icon: <Zap className="w-5 h-5" />,
    price: 399,
    originalPrice: 599,
    features: [
      "5 Original Logo Concepts",
      "Unlimited Revisions",
      "High-Resolution Files (PNG, JPG, SVG, PDF)",
      "Complete Brand Guidelines",
      "Business Card Design",
      "Social Media Kit",
      "3-Day Rush Delivery",
      "Priority Support"
    ],
    isPopular: true
  },
  {
    name: "Private Jet",
    icon: <Crown className="w-5 h-5" />,
    price: 799,
    originalPrice: 1199,
    features: [
      "10 Original Logo Concepts",
      "Unlimited Revisions",
      "All File Formats + Source Files",
      "Premium Brand Guidelines",
      "Complete Stationery Suite",
      "Social Media & Web Kit",
      "Trademark Research",
      "24-Hour Rush Delivery",
      "Dedicated Account Manager",
      "1-on-1 Design Consultation"
    ],
    isPopular: false
  }
];

export function Section_Pricing({ onSelectPackage }: Section_PricingProps) {
  return (
    <section className="Section_Pricing pt-8 pb-16 md:pt-12 md:pb-20 lg:pt-16 lg:pb-24 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-10 w-64 h-64 gradient-gold-soft opacity-5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 right-10 w-80 h-80 gradient-gold opacity-3 rounded-full blur-3xl"></div>
      </div>

      <div className="Container_Content max-w-7xl mx-auto responsive-padding relative z-10">
        
        {/* Simplified Section Header */}
        <div className="Container_SectionHeader text-center mb-8 md:mb-10 lg:mb-12">
          <h2 className="text-gradient-gold-rich font-heading text-2xl md:text-3xl lg:text-4xl font-bold mb-3 md:mb-4 tracking-tight">
            Choose Your Package
          </h2>
          <p className="font-body text-base md:text-lg text-ink-soft-brown max-w-xl mx-auto leading-relaxed">
            Professional logo design with unlimited revisions
          </p>
        </div>

        {/* Pricing Cards Grid */}
        <div className="Grid_PricingCards grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {packages.map((pkg, index) => (
            <WeDesignPricingCard
              key={pkg.name}
              packageName={pkg.name}
              price={pkg.price}
              originalPrice={pkg.originalPrice}
              features={pkg.features}
              isPopular={pkg.isPopular}
              onSelect={() => onSelectPackage(pkg.name)}
              className={index === 1 ? 'lg:scale-105' : ''}
            />
          ))}
        </div>

        {/* Compact Trust Indicators */}
        <div className="Container_TrustIndicators text-center">
          <div className="flex items-center justify-center gap-6 flex-wrap">
            <div className="glass-effect px-3 py-1.5 rounded-lg">
              <span className="text-sm text-muted-foreground">5,000+ businesses</span>
            </div>
            <div className="glass-effect px-3 py-1.5 rounded-lg">
              <span className="text-sm text-muted-foreground">4.9/5 ⭐</span>
            </div>
            <div className="glass-effect px-3 py-1.5 rounded-lg">
              <span className="text-sm text-muted-foreground">2 hour response</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}