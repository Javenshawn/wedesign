import { WeDesignStatCard } from "../design-system/WeDesignStatCard";
import { TrendingUp, Clock, CheckCircle } from "lucide-react";

export function Section_Stats() {
  return (
    <section className="Section_Stats py-16 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <WeDesignStatCard
            number="47"
            label="Orders Today"
            icon={<TrendingUp className="w-8 h-8" />}
            className="Card_Stat_OrdersToday"
          />
          
          <WeDesignStatCard
            number="134"
            label="Projects In Progress"
            icon={<Clock className="w-8 h-8" />}
            className="Card_Stat_InProgress"
          />
          
          <WeDesignStatCard
            number="2,847"
            label="Completed Designs"
            icon={<CheckCircle className="w-8 h-8" />}
            className="Card_Stat_CompletedTotal"
          />
        </div>
      </div>
    </section>
  );
}