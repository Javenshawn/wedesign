// WeDesign 最终部署检查脚本
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

console.log('🔎 WeDesign 最终部署检查');
console.log('================================');

let allChecksPass = true;
const issues = [];
const warnings = [];

// 1. 文件结构检查
console.log('\n📁 文件结构检查:');
const requiredFiles = {
  'index.html': '主 HTML 入口',
  'src/main.tsx': 'React 入口点',
  'src/App.tsx': '主应用组件',
  'src/styles/globals.css': '全局样式',
  'package.json': '项目配置',
  'vite.config.ts': 'Vite 配置',
  'vercel.json': 'Vercel 配置'
};

Object.entries(requiredFiles).forEach(([file, description]) => {
  const exists = fs.existsSync(path.join(__dirname, file));
  if (exists) {
    console.log(`✅ ${file} - ${description}`);
  } else {
    console.log(`❌ ${file} - ${description} (缺失)`);
    issues.push(`缺失文件: ${file}`);
    allChecksPass = false;
  }
});

// 2. 检查 index.html 内容
console.log('\n🌐 index.html 内容检查:');
const indexPath = path.join(__dirname, 'index.html');
if (fs.existsSync(indexPath)) {
  const indexContent = fs.readFileSync(indexPath, 'utf8');
  
  const indexChecks = [
    { 
      check: indexContent.includes('<div id="root">'), 
      message: 'React root 元素存在',
      critical: true
    },
    { 
      check: indexContent.includes('/src/main.tsx'), 
      message: 'main.tsx 脚本引用正确',
      critical: true
    },
    { 
      check: indexContent.includes('WeDesign'), 
      message: '页面标题包含 WeDesign',
      critical: false
    },
    { 
      check: indexContent.includes('viewport'), 
      message: '响应式 viewport 设置',
      critical: false
    }
  ];
  
  indexChecks.forEach(({ check, message, critical }) => {
    if (check) {
      console.log(`✅ ${message}`);
    } else {
      console.log(`${critical ? '❌' : '⚠️'} ${message}`);
      if (critical) {
        issues.push(`index.html: ${message}`);
        allChecksPass = false;
      } else {
        warnings.push(`index.html: ${message}`);
      }
    }
  });
}

// 3. 检查 src/main.tsx
console.log('\n⚡ main.tsx 检查:');
const mainPath = path.join(__dirname, 'src/main.tsx');
if (fs.existsSync(mainPath)) {
  const mainContent = fs.readFileSync(mainPath, 'utf8');
  
  const mainChecks = [
    { 
      check: mainContent.includes('import React'), 
      message: 'React 导入正确',
      critical: true
    },
    { 
      check: mainContent.includes('import ReactDOM'), 
      message: 'ReactDOM 导入正确',
      critical: true
    },
    { 
      check: mainContent.includes('import App from \'./App.tsx\''), 
      message: 'App 组件导入路径正确',
      critical: true
    },
    { 
      check: mainContent.includes('createRoot'), 
      message: '使用 React 18 createRoot API',
      critical: true
    }
  ];
  
  mainChecks.forEach(({ check, message, critical }) => {
    if (check) {
      console.log(`✅ ${message}`);
    } else {
      console.log(`❌ ${message}`);
      issues.push(`main.tsx: ${message}`);
      allChecksPass = false;
    }
  });
}

// 4. 检查依赖安装
console.log('\n📦 依赖检查:');
try {
  const nodeModulesExists = fs.existsSync(path.join(__dirname, 'node_modules'));
  if (nodeModulesExists) {
    console.log('✅ node_modules 目录存在');
  } else {
    console.log('⚠️ node_modules 目录不存在，需要运行 npm install');
    warnings.push('需要安装依赖: npm install');
  }
  
  // 检查关键依赖
  const packagePath = path.join(__dirname, 'package.json');
  const packageJson = JSON.parse(fs.readFileSync(packagePath, 'utf8'));
  
  const criticalDeps = ['react', 'react-dom', 'vite', '@vitejs/plugin-react'];
  criticalDeps.forEach(dep => {
    if (packageJson.dependencies[dep] || packageJson.devDependencies[dep]) {
      console.log(`✅ ${dep} 依赖配置正确`);
    } else {
      console.log(`❌ ${dep} 依赖缺失`);
      issues.push(`缺失关键依赖: ${dep}`);
      allChecksPass = false;
    }
  });
  
} catch (error) {
  console.log(`❌ 依赖检查失败: ${error.message}`);
  issues.push('依赖检查失败');
  allChecksPass = false;
}

// 5. 构建测试
console.log('\n🔨 构建测试:');
try {
  if (fs.existsSync(path.join(__dirname, 'node_modules'))) {
    console.log('🔄 正在测试构建...');
    execSync('npm run build', { stdio: 'pipe' });
    
    // 检查构建结果
    const distExists = fs.existsSync(path.join(__dirname, 'dist'));
    const distIndexExists = fs.existsSync(path.join(__dirname, 'dist/index.html'));
    
    if (distExists && distIndexExists) {
      console.log('✅ 构建测试成功');
    } else {
      console.log('❌ 构建测试失败 - 输出文件不完整');
      issues.push('构建输出不完整');
      allChecksPass = false;
    }
  } else {
    console.log('⚠️ 跳过构建测试 - 需要先安装依赖');
    warnings.push('需要先安装依赖才能测试构建');
  }
} catch (error) {
  console.log('❌ 构建测试失败');
  console.log(`   错误: ${error.message}`);
  issues.push('构建失败');
  allChecksPass = false;
}

// 6. Vercel 配置检查
console.log('\n🚀 Vercel 配置检查:');
const vercelConfigPath = path.join(__dirname, 'vercel.json');
if (fs.existsSync(vercelConfigPath)) {
  try {
    const vercelConfig = JSON.parse(fs.readFileSync(vercelConfigPath, 'utf8'));
    
    if (vercelConfig.framework) {
      console.log(`✅ 框架设置: ${vercelConfig.framework}`);
    }
    
    if (vercelConfig.buildCommand) {
      console.log(`✅ 构建命令: ${vercelConfig.buildCommand}`);
    }
    
    if (vercelConfig.outputDirectory) {
      console.log(`✅ 输出目录: ${vercelConfig.outputDirectory}`);
    }
    
  } catch (error) {
    console.log('❌ vercel.json 格式错误');
    issues.push('vercel.json 格式错误');
    allChecksPass = false;
  }
} else {
  console.log('⚠️ vercel.json 不存在，将使用 Vercel 自动检测');
  warnings.push('建议创建 vercel.json 配置文件');
}

// 7. 最终报告
console.log('\n📊 部署就绪报告');
console.log('===================');

if (allChecksPass && issues.length === 0) {
  console.log('🎉 所有检查都通过！项目已准备好部署');
  console.log('');
  console.log('🚀 推荐部署命令:');
  console.log('');
  console.log('# 快速部署');
  console.log('npm run deploy:quick');
  console.log('');
  console.log('# 或分步部署');
  console.log('npm run deploy:prepare  # 重组项目');
  console.log('npm install             # 安装依赖');
  console.log('npm run build           # 构建项目');
  console.log('vercel --prod           # 部署到 Vercel');
  
} else {
  console.log('❌ 发现问题，需要修复后才能部署');
  console.log('');
  
  if (issues.length > 0) {
    console.log('🔧 必须修复的问题:');
    issues.forEach((issue, index) => {
      console.log(`   ${index + 1}. ${issue}`);
    });
    console.log('');
  }
  
  if (warnings.length > 0) {
    console.log('⚠️ 建议处理的警告:');
    warnings.forEach((warning, index) => {
      console.log(`   ${index + 1}. ${warning}`);
    });
    console.log('');
  }
  
  console.log('📋 修复建议:');
  console.log('1. 运行 npm run deploy:prepare 重组项目结构');
  console.log('2. 运行 npm install 安装依赖');
  console.log('3. 运行 npm run build 测试构建');
  console.log('4. 重新运行此检查脚本');
}

console.log('\nWeDesign 部署检查完成！');

// 返回适当的退出码
process.exit(allChecksPass ? 0 : 1);