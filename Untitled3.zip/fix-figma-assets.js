// WeDesign Figma Asset 修复脚本
const fs = require('fs');
const path = require('path');

console.log('🔧 WeDesign Figma Asset 修复脚本');
console.log('====================================');

// 扫描目录中的所有文件
function scanDirectory(dirPath, extensions = ['.tsx', '.ts', '.jsx', '.js']) {
  const files = [];
  
  function scan(currentPath) {
    const items = fs.readdirSync(currentPath);
    
    for (const item of items) {
      const fullPath = path.join(currentPath, item);
      const stat = fs.statSync(fullPath);
      
      if (stat.isDirectory()) {
        // 跳过 node_modules 和 .git 目录
        if (!['node_modules', '.git', 'dist'].includes(item)) {
          scan(fullPath);
        }
      } else if (stat.isFile()) {
        const ext = path.extname(item);
        if (extensions.includes(ext)) {
          files.push(fullPath);
        }
      }
    }
  }
  
  scan(dirPath);
  return files;
}

// 高质量占位图映射
const placeholderImages = {
  // Logo 相关图片
  'logo': 'https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?w=200&h=200&fit=crop&crop=center',
  'wedesign-logo': 'https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?w=200&h=200&fit=crop&crop=center',
  
  // 英雄区域图片
  'hero': 'https://images.unsplash.com/photo-1561070791-2526d30994b5?w=1200&h=800&fit=crop&crop=center',
  'hero-bg': 'https://images.unsplash.com/photo-1558655146-d09347e92766?w=1920&h=1080&fit=crop&crop=center',
  
  // 案例展示图片
  'case-1': 'https://images.unsplash.com/photo-1609921141835-710b7fa6e438?w=400&h=300&fit=crop&crop=center',
  'case-2': 'https://images.unsplash.com/photo-1600132806608-231446b2e7af?w=400&h=300&fit=crop&crop=center',
  'case-3': 'https://images.unsplash.com/photo-1609921141835-710b7fa6e438?w=400&h=300&fit=crop&crop=center',
  'case-4': 'https://images.unsplash.com/photo-1600132806608-231446b2e7af?w=400&h=300&fit=crop&crop=center',
  'case-5': 'https://images.unsplash.com/photo-1609921141835-710b7fa6e438?w=400&h=300&fit=crop&crop=center',
  'case-6': 'https://images.unsplash.com/photo-1600132806608-231446b2e7af?w=400&h=300&fit=crop&crop=center',
  
  // 设计大厅图片
  'design-hall-1': 'https://images.unsplash.com/photo-1609921141835-710b7fa6e438?w=300&h=400&fit=crop&crop=center',
  'design-hall-2': 'https://images.unsplash.com/photo-1600132806608-231446b2e7af?w=300&h=400&fit=crop&crop=center',
  'design-hall-3': 'https://images.unsplash.com/photo-1609921141835-710b7fa6e438?w=300&h=400&fit=crop&crop=center',
  
  // 关于我们页面图片
  'about-team': 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=600&h=400&fit=crop&crop=center',
  'about-office': 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=600&h=400&fit=crop&crop=center',
  
  // 博客图片
  'blog-1': 'https://images.unsplash.com/photo-1499750310107-5fef28a66643?w=400&h=250&fit=crop&crop=center',
  'blog-2': 'https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?w=400&h=250&fit=crop&crop=center',
  'blog-3': 'https://images.unsplash.com/photo-1499750310107-5fef28a66643?w=400&h=250&fit=crop&crop=center',
  
  // 通用背景图片
  'background-1': 'https://images.unsplash.com/photo-1558655146-d09347e92766?w=1920&h=1080&fit=crop&crop=center',
  'background-2': 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=1920&h=1080&fit=crop&crop=center',
  
  // 图标和装饰图片
  'icon-design': 'https://images.unsplash.com/photo-1609921141835-710b7fa6e438?w=100&h=100&fit=crop&crop=center',
  'icon-branding': 'https://images.unsplash.com/photo-1600132806608-231446b2e7af?w=100&h=100&fit=crop&crop=center',
  'icon-creative': 'https://images.unsplash.com/photo-1609921141835-710b7fa6e438?w=100&h=100&fit=crop&crop=center',
  
  // 默认占位图
  'default': 'https://images.unsplash.com/photo-1609921141835-710b7fa6e438?w=400&h=300&fit=crop&crop=center'
};

// 从 figma:asset 路径中提取文件名并映射到占位图
function getPlaceholderUrl(figmaAssetPath) {
  // 提取文件名（去掉扩展名）
  const filename = path.basename(figmaAssetPath, path.extname(figmaAssetPath));
  
  // 尝试根据文件名匹配合适的占位图
  for (const [key, url] of Object.entries(placeholderImages)) {
    if (filename.toLowerCase().includes(key) || figmaAssetPath.toLowerCase().includes(key)) {
      return url;
    }
  }
  
  // 默认占位图
  return placeholderImages.default;
}

// 主处理函数
function fixFigmaAssets() {
  console.log('\n🔍 扫描项目文件...');
  
  const projectRoot = __dirname;
  const files = scanDirectory(projectRoot);
  
  console.log(`找到 ${files.length} 个文件需要检查`);
  
  let totalReplacements = 0;
  const affectedFiles = [];
  
  for (const filePath of files) {
    const relativePath = path.relative(projectRoot, filePath);
    
    try {
      const content = fs.readFileSync(filePath, 'utf8');
      let modifiedContent = content;
      let fileReplacements = 0;
      
      // 查找 figma:asset 引用的正则表达式
      const figmaAssetRegex = /(?:import\s+.*?from\s+["']|src\s*=\s*["']|url\s*\(\s*["']?)figma:asset\/([^"')\s]+)["')\s]?/g;
      
      let match;
      while ((match = figmaAssetRegex.exec(content)) !== null) {
        const fullMatch = match[0];
        const assetPath = match[1];
        const placeholderUrl = getPlaceholderUrl(assetPath);
        
        // 替换 figma:asset 为占位图 URL
        const replacement = fullMatch.replace(`figma:asset/${assetPath}`, placeholderUrl);
        modifiedContent = modifiedContent.replace(fullMatch, replacement);
        
        fileReplacements++;
        totalReplacements++;
        
        console.log(`  ✅ ${relativePath}: figma:asset/${assetPath} → ${placeholderUrl}`);
      }
      
      // 如果有修改，写回文件
      if (fileReplacements > 0) {
        fs.writeFileSync(filePath, modifiedContent, 'utf8');
        affectedFiles.push({
          file: relativePath,
          replacements: fileReplacements
        });
      }
      
    } catch (error) {
      console.log(`❌ 处理文件失败 ${relativePath}: ${error.message}`);
    }
  }
  
  console.log('\n📊 修复结果:');
  console.log('==================');
  
  if (totalReplacements > 0) {
    console.log(`✅ 成功修复 ${totalReplacements} 个 figma:asset 引用`);
    console.log(`📁 影响文件数: ${affectedFiles.length}`);
    console.log('');
    console.log('📋 详细修改:');
    affectedFiles.forEach(({ file, replacements }) => {
      console.log(`   • ${file}: ${replacements} 个替换`);
    });
    
    console.log('\n🎨 使用的占位图类型:');
    console.log('• Logo 图片: 品牌设计相关');
    console.log('• 案例图片: 设计作品展示');
    console.log('• 背景图片: 高质量渐变背景');
    console.log('• 图标图片: 设计和品牌图标');
    console.log('• 博客图片: 内容营销相关');
    
  } else {
    console.log('✅ 没有找到需要修复的 figma:asset 引用');
  }
  
  return totalReplacements > 0;
}

// 执行修复
const hasReplacements = fixFigmaAssets();

if (hasReplacements) {
  console.log('\n🔧 后续操作建议:');
  console.log('1. 运行 npm run build 测试构建');
  console.log('2. 检查图片显示是否正常');
  console.log('3. 如需要，手动替换为更合适的图片');
  console.log('4. 提交更改到版本控制');
} else {
  console.log('\n✅ 项目已经没有 figma:asset 引用，可以直接构建！');
}

console.log('\nWeDesign Figma Asset 修复完成！');