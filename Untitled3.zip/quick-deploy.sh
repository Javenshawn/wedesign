#!/bin/bash

echo "🚀 WeDesign Quick Deployment Script"
echo "=================================="
echo ""

# Step 1: Clean up project
echo "Step 1: Cleaning up project..."
node cleanup-project.js

echo ""
echo "Step 2: Checking git status..."
if git rev-parse --git-dir > /dev/null 2>&1; then
    echo "✅ Git repository already initialized"
else
    echo "🔧 Initializing git repository..."
    git init
fi

echo ""
echo "Step 3: Adding all files..."
git add .

echo ""
echo "Step 4: Creating commit..."
git status --porcelain | wc -l | xargs echo "📊 Files to commit:"
read -p "Enter commit message (or press Enter for default): " commit_message
if [ -z "$commit_message" ]; then
    commit_message="Production ready: WeDesign Premium Logo Design Platform"
fi
git commit -m "$commit_message"

echo ""
echo "Step 5: GitHub setup"
echo "⚠️  Manual step required:"
echo "1. Create a new repository on GitHub.com"
echo "2. Copy the repository URL"
echo "3. Run these commands:"
echo ""
echo "   git remote add origin https://github.com/YOUR_USERNAME/wedesign.git"
echo "   git branch -M main" 
echo "   git push -u origin main"
echo ""
echo "Step 6: Vercel deployment"
echo "⚠️  Manual steps required:"
echo "1. Go to vercel.com"
echo "2. Import your GitHub repository"
echo "3. Add environment variables (see COMPLETE_DEPLOYMENT_STEPS.md)"
echo "4. Deploy"
echo ""
echo "📖 See COMPLETE_DEPLOYMENT_STEPS.md for detailed instructions"
echo ""
echo "🎉 Project is ready for deployment!"