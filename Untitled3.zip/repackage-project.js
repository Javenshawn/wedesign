// WeDesign 项目重打包脚本
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

console.log('📦 WeDesign 项目重打包');
console.log('=========================');

const steps = [
  {
    name: '修复 Figma Asset 引用',
    action: async () => {
      console.log('🔧 运行 Figma Asset 修复...');
      execSync('node fix-figma-assets.js', { stdio: 'inherit' });
    }
  },
  {
    name: '重组项目结构',
    action: async () => {
      console.log('📁 重组到标准 Vite 结构...');
      
      // 确保 src 目录存在
      const srcDir = path.join(__dirname, 'src');
      if (!fs.existsSync(srcDir)) {
        fs.mkdirSync(srcDir, { recursive: true });
      }
      
      // 创建必要的子目录
      const subDirs = ['components', 'utils', 'types', 'supabase', 'styles'];
      subDirs.forEach(dir => {
        const dirPath = path.join(srcDir, dir);
        if (!fs.existsSync(dirPath)) {
          fs.mkdirSync(dirPath, { recursive: true });
        }
      });
      
      // 移动文件到 src 目录
      const moveOperations = [
        { from: 'components', to: 'src/components' },
        { from: 'utils', to: 'src/utils' },
        { from: 'types', to: 'src/types' },
        { from: 'supabase', to: 'src/supabase' }
      ];
      
      moveOperations.forEach(({ from, to }) => {
        const sourcePath = path.join(__dirname, from);
        const targetPath = path.join(__dirname, to);
        
        if (fs.existsSync(sourcePath) && !fs.existsSync(targetPath)) {
          try {
            fs.renameSync(sourcePath, targetPath);
            console.log(`  ✅ 移动 ${from} → ${to}`);
          } catch (error) {
            console.log(`  ⚠️ 移动失败 ${from}: ${error.message}`);
          }
        }
      });
      
      // 复制样式文件
      const globalsCssSource = path.join(__dirname, 'styles/globals.css');
      const globalsCssTarget = path.join(__dirname, 'src/styles/globals.css');
      
      if (fs.existsSync(globalsCssSource)) {
        if (!fs.existsSync(path.dirname(globalsCssTarget))) {
          fs.mkdirSync(path.dirname(globalsCssTarget), { recursive: true });
        }
        fs.copyFileSync(globalsCssSource, globalsCssTarget);
        console.log('  ✅ 复制样式文件到 src/styles/');
      }
    }
  },
  {
    name: '清理重复文件',
    action: async () => {
      console.log('🧹 清理重复和过时文件...');
      
      const filesToRemove = [
        'next.config.js',           // Next.js 配置，不需要
        'App.tsx',                  // 根目录的旧版本
        '删除Wix内容脚本.js',       // 中文脚本文件
        '完整清理脚本.js',
        '环境配置助手.js',
        '项目清理脚本.js'
      ];
      
      filesToRemove.forEach(file => {
        const filePath = path.join(__dirname, file);
        if (fs.existsSync(filePath)) {
          fs.unlinkSync(filePath);
          console.log(`  ✅ 删除 ${file}`);
        }
      });
      
      // 清理多余的文档文件
      const docsToRemove = fs.readdirSync(__dirname).filter(file => 
        file.endsWith('.md') && 
        !['README.md', 'Guidelines.md'].includes(file) &&
        file.includes('STRIPE') || file.includes('SUPABASE') || file.includes('VERCEL')
      );
      
      docsToRemove.forEach(file => {
        const filePath = path.join(__dirname, file);
        fs.unlinkSync(filePath);
        console.log(`  ✅ 清理文档 ${file}`);
      });
    }
  },
  {
    name: '验证项目结构',
    action: async () => {
      console.log('🔍 验证项目结构...');
      
      const requiredFiles = [
        'index.html',
        'src/main.tsx',
        'src/App.tsx',
        'src/styles/globals.css',
        'package.json',
        'vite.config.ts'
      ];
      
      let structureValid = true;
      
      requiredFiles.forEach(file => {
        const filePath = path.join(__dirname, file);
        const exists = fs.existsSync(filePath);
        
        if (exists) {
          console.log(`  ✅ ${file}`);
        } else {
          console.log(`  ❌ ${file} (缺失)`);
          structureValid = false;
        }
      });
      
      if (!structureValid) {
        throw new Error('项目结构不完整，请检查缺失文件');
      }
    }
  },
  {
    name: '更新导入路径',
    action: async () => {
      console.log('🔄 更新 src/App.tsx 导入路径...');
      
      const appTsxPath = path.join(__dirname, 'src/App.tsx');
      if (fs.existsSync(appTsxPath)) {
        let content = fs.readFileSync(appTsxPath, 'utf8');
        
        // 更新导入路径为相对路径
        const imports = [
          { from: 'from "./components/', to: 'from "./components/' },
          { from: 'from "./utils/', to: 'from "./utils/' },
          { from: 'from "./types/', to: 'from "./types/' }
        ];
        
        // 确保所有导入都是相对路径
        content = content.replace(/from ["'](?!\.)/g, 'from "./');
        
        fs.writeFileSync(appTsxPath, content, 'utf8');
        console.log('  ✅ App.tsx 导入路径已更新');
      }
    }
  },
  {
    name: '安装依赖',
    action: async () => {
      console.log('📦 安装项目依赖...');
      execSync('npm install', { stdio: 'inherit' });
    }
  },
  {
    name: '测试构建',
    action: async () => {
      console.log('🔨 测试项目构建...');
      execSync('npm run build', { stdio: 'inherit' });
      
      // 验证构建结果
      const distDir = path.join(__dirname, 'dist');
      const indexHtml = path.join(distDir, 'index.html');
      
      if (fs.existsSync(distDir) && fs.existsSync(indexHtml)) {
        console.log('  ✅ 构建成功，输出文件完整');
      } else {
        throw new Error('构建失败或输出文件不完整');
      }
    }
  }
];

// 执行重打包步骤
async function repackage() {
  let currentStep = 0;
  
  try {
    for (const step of steps) {
      currentStep++;
      console.log(`\n[${currentStep}/${steps.length}] ${step.name}`);
      console.log('─'.repeat(50));
      
      await step.action();
    }
    
    console.log('\n🎉 WeDesign 项目重打包成功！');
    console.log('=====================================');
    console.log('');
    console.log('📊 重打包摘要:');
    console.log('• ✅ Figma Asset 引用已修复');
    console.log('• ✅ 项目结构已标准化');
    console.log('• ✅ 重复文件已清理');
    console.log('• ✅ 导入路径已更新');
    console.log('• ✅ 依赖安装完成');
    console.log('• ✅ 构建测试通过');
    console.log('');
    console.log('🚀 现在可以部署到 Vercel:');
    console.log('vercel --prod');
    console.log('');
    console.log('🌐 或者本地预览:');
    console.log('npm run preview');
    
  } catch (error) {
    console.log(`\n❌ 重打包失败 (步骤 ${currentStep}): ${error.message}`);
    
    if (currentStep === 6) {
      console.log('\n🔧 构建失败排查:');
      console.log('1. 检查 TypeScript 错误');
      console.log('2. 验证所有导入路径正确');
      console.log('3. 确保图片路径有效');
      console.log('4. 运行 npm run dev 查看详细错误');
    }
    
    process.exit(1);
  }
}

// 开始重打包
repackage().catch(console.error);