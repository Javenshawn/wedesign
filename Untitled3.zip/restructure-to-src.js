// WeDesign 项目结构重组脚本 - 移动到标准 Vite src 结构
const fs = require('fs');
const path = require('path');

console.log('🔄 WeDesign 项目结构重组 - 移动到标准 Vite src 结构');
console.log('================================================================');

// 需要移动到 src 目录的文件和文件夹
const moveToSrc = [
  'components',
  'utils', 
  'types',
  'supabase'
];

// 需要保留在根目录的文件
const keepInRoot = [
  'index.html',
  'package.json',
  'vite.config.ts',
  'vercel.json',
  '.env.example',
  '.env.local',
  '.gitignore',
  'README.md',
  'Guidelines.md',
  'public'
];

// 创建 src 目录
const srcDir = path.join(__dirname, 'src');
if (!fs.existsSync(srcDir)) {
  fs.mkdirSync(srcDir, { recursive: true });
  console.log('✅ 创建 src 目录');
}

// 移动文件和文件夹到 src
moveToSrc.forEach(item => {
  const sourcePath = path.join(__dirname, item);
  const targetPath = path.join(srcDir, item);
  
  if (fs.existsSync(sourcePath)) {
    try {
      // 如果目标已存在，先删除
      if (fs.existsSync(targetPath)) {
        fs.rmSync(targetPath, { recursive: true, force: true });
      }
      
      // 移动文件夹
      fs.renameSync(sourcePath, targetPath);
      console.log(`✅ 移动 ${item} 到 src/${item}`);
    } catch (error) {
      console.log(`❌ 移动失败 ${item}: ${error.message}`);
    }
  } else {
    console.log(`⚠️  ${item} 不存在，跳过`);
  }
});

// 删除旧的 App.tsx（已经在 src/App.tsx 中创建了新版本）
const oldAppPath = path.join(__dirname, 'App.tsx');
if (fs.existsSync(oldAppPath)) {
  fs.unlinkSync(oldAppPath);
  console.log('✅ 删除根目录的旧 App.tsx');
}

// 删除旧的 styles 目录（已经在 src/styles 中创建了新版本）
const oldStylesPath = path.join(__dirname, 'styles');
if (fs.existsSync(oldStylesPath)) {
  fs.rmSync(oldStylesPath, { recursive: true, force: true });
  console.log('✅ 删除根目录的旧 styles 目录');
}

console.log('\n📝 更新导入路径处理说明:');
console.log('所有组件的导入路径已经在新的 src/App.tsx 中更新为相对路径。');
console.log('如果遇到任何导入错误，请检查以下路径:');
console.log('- 组件: ./components/');
console.log('- 工具: ./utils/');
console.log('- 类型: ./types/');
console.log('- Supabase: ./supabase/');

console.log('\n🎯 项目结构重组完成！');
console.log('现在项目采用标准的 Vite + React + TypeScript 结构:');
console.log('');
console.log('根目录:');
console.log('├── index.html          # HTML 入口');
console.log('├── package.json        # 项目配置');
console.log('├── vite.config.ts      # Vite 配置');
console.log('├── vercel.json         # 部署配置');
console.log('├── .env.example        # 环境变量模板');
console.log('└── src/                # 源代码目录');
console.log('    ├── main.tsx        # JS 入口点');
console.log('    ├── App.tsx         # React 主组件');
console.log('    ├── styles/         # 样式文件');
console.log('    ├── components/     # React 组件');
console.log('    ├── utils/          # 工具函数');
console.log('    ├── types/          # TypeScript 类型');
console.log('    └── supabase/       # 数据库函数');

console.log('\n🚀 现在可以正常运行:');
console.log('npm install');
console.log('npm run dev');
console.log('npm run build');