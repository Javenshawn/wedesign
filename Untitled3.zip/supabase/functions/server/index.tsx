import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { logger } from 'npm:hono/logger';
import { createClient } from 'jsr:@supabase/supabase-js@2';
import * as kv from './kv_store.tsx';
import { 
  createPaymentIntent, 
  confirmPayment, 
  getPaymentStatus, 
  handleStripeWebhook,
  getStripeConfig 
} from './stripe-api.tsx';

const app = new Hono();

// CORS设置
app.use('*', cors({
  origin: ['http://localhost:3000', 'https://*.supabase.co', 'https://*.vercel.app'],
  allowHeaders: ['Content-Type', 'Authorization', 'stripe-signature'],
  allowMethods: ['POST', 'GET', 'PUT', 'DELETE', 'OPTIONS'],
}));

// 日志记录
app.use('*', logger(console.log));

// Supabase客户端
const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
);

// 存储桶初始化
async function initializeBuckets() {
  const buckets = [
    'make-d0d1e627-user-avatars',
    'make-d0d1e627-design-files',
    'make-d0d1e627-blog-images',
    'make-d0d1e627-case-studies'
  ];

  for (const bucketName of buckets) {
    const { data: existingBuckets } = await supabase.storage.listBuckets();
    const bucketExists = existingBuckets?.some(bucket => bucket.name === bucketName);
    
    if (!bucketExists) {
      const { error } = await supabase.storage.createBucket(bucketName, {
        public: false,
        allowedMimeTypes: ['image/*', 'application/pdf', 'application/zip'],
        fileSizeLimit: 10485760 // 10MB
      });
      
      if (error) {
        console.log(`Error creating bucket ${bucketName}:`, error);
      } else {
        console.log(`Bucket ${bucketName} created successfully`);
      }
    }
  }
}

// 权限验证中间件
async function requireAuth(c: any, next: any) {
  const accessToken = c.req.header('Authorization')?.split(' ')[1];
  if (!accessToken) {
    return c.json({ error: 'No authorization token provided' }, 401);
  }

  const { data: { user }, error } = await supabase.auth.getUser(accessToken);
  if (error || !user) {
    return c.json({ error: 'Invalid or expired token' }, 401);
  }

  c.set('user', user);
  await next();
}

// ============ 用户认证 API ============

// 用户注册
app.post('/make-server-d0d1e627/auth/signup', async (c) => {
  try {
    const { email, password, fullName } = await c.req.json();

    if (!email || !password || !fullName) {
      return c.json({ error: 'Email, password, and full name are required' }, 400);
    }

    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { 
        full_name: fullName,
        avatar_url: '',
        created_at: new Date().toISOString()
      },
      // 自动确认邮箱，因为没有配置邮件服务器
      email_confirm: true
    });

    if (error) {
      console.log('Signup error:', error);
      return c.json({ error: error.message }, 400);
    }

    // 创建用户档案
    await kv.set(`user_profile:${data.user.id}`, {
      id: data.user.id,
      email: data.user.email,
      fullName,
      createdAt: new Date().toISOString(),
      subscription: 'free',
      projectsCount: 0,
      preferences: {
        notifications: true,
        newsletter: true
      }
    });

    return c.json({ 
      message: 'User created successfully',
      user: {
        id: data.user.id,
        email: data.user.email,
        fullName
      }
    });

  } catch (error) {
    console.log('Signup processing error:', error);
    return c.json({ error: 'Internal server error during signup' }, 500);
  }
});

// 获取用户档案
app.get('/make-server-d0d1e627/auth/profile', requireAuth, async (c) => {
  try {
    const user = c.get('user');
    const profile = await kv.get(`user_profile:${user.id}`);
    
    if (!profile) {
      return c.json({ error: 'User profile not found' }, 404);
    }

    return c.json({ profile });
  } catch (error) {
    console.log('Get profile error:', error);
    return c.json({ error: 'Failed to retrieve user profile' }, 500);
  }
});

// 更新用户档案
app.put('/make-server-d0d1e627/auth/profile', requireAuth, async (c) => {
  try {
    const user = c.get('user');
    const updates = await c.req.json();
    
    const existingProfile = await kv.get(`user_profile:${user.id}`);
    if (!existingProfile) {
      return c.json({ error: 'User profile not found' }, 404);
    }

    const updatedProfile = {
      ...existingProfile,
      ...updates,
      updatedAt: new Date().toISOString()
    };

    await kv.set(`user_profile:${user.id}`, updatedProfile);
    return c.json({ message: 'Profile updated successfully', profile: updatedProfile });

  } catch (error) {
    console.log('Update profile error:', error);
    return c.json({ error: 'Failed to update user profile' }, 500);
  }
});

// ============ 项目管理 API ============

// 创建新项目
app.post('/make-server-d0d1e627/projects', requireAuth, async (c) => {
  try {
    const user = c.get('user');
    const { title, description, package: selectedPackage, requirements } = await c.req.json();

    if (!title || !selectedPackage) {
      return c.json({ error: 'Title and package are required' }, 400);
    }

    const projectId = `proj_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const project = {
      id: projectId,
      userId: user.id,
      title,
      description: description || '',
      package: selectedPackage,
      requirements: requirements || {},
      status: 'pending',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      timeline: {
        estimated: selectedPackage === 'basic' ? 3 : selectedPackage === 'professional' ? 5 : 7,
        started: null,
        completed: null
      },
      files: [],
      revisions: 0,
      maxRevisions: selectedPackage === 'basic' ? 2 : selectedPackage === 'professional' ? 4 : 6
    };

    await kv.set(`project:${projectId}`, project);
    await kv.set(`user_project:${user.id}:${projectId}`, projectId);

    // 更新用户项目计数
    const userProfile = await kv.get(`user_profile:${user.id}`);
    if (userProfile) {
      userProfile.projectsCount = (userProfile.projectsCount || 0) + 1;
      await kv.set(`user_profile:${user.id}`, userProfile);
    }

    return c.json({ message: 'Project created successfully', project });

  } catch (error) {
    console.log('Create project error:', error);
    return c.json({ error: 'Failed to create project' }, 500);
  }
});

// 获取用户项目列表
app.get('/make-server-d0d1e627/projects', requireAuth, async (c) => {
  try {
    const user = c.get('user');
    const userProjectKeys = await kv.getByPrefix(`user_project:${user.id}:`);
    
    const projects = [];
    for (const projectId of userProjectKeys) {
      const project = await kv.get(`project:${projectId}`);
      if (project) {
        projects.push(project);
      }
    }

    // 按创建时间倒序排列
    projects.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    return c.json({ projects });

  } catch (error) {
    console.log('Get projects error:', error);
    return c.json({ error: 'Failed to retrieve projects' }, 500);
  }
});

// 获取单个项目详情
app.get('/make-server-d0d1e627/projects/:projectId', requireAuth, async (c) => {
  try {
    const user = c.get('user');
    const projectId = c.req.param('projectId');
    
    const project = await kv.get(`project:${projectId}`);
    if (!project) {
      return c.json({ error: 'Project not found' }, 404);
    }

    if (project.userId !== user.id) {
      return c.json({ error: 'Access denied' }, 403);
    }

    return c.json({ project });

  } catch (error) {
    console.log('Get project error:', error);
    return c.json({ error: 'Failed to retrieve project' }, 500);
  }
});

// 更新项目状态
app.put('/make-server-d0d1e627/projects/:projectId/status', requireAuth, async (c) => {
  try {
    const user = c.get('user');
    const projectId = c.req.param('projectId');
    const { status, notes } = await c.req.json();

    const project = await kv.get(`project:${projectId}`);
    if (!project) {
      return c.json({ error: 'Project not found' }, 404);
    }

    if (project.userId !== user.id) {
      return c.json({ error: 'Access denied' }, 403);
    }

    project.status = status;
    project.updatedAt = new Date().toISOString();
    
    if (status === 'in_progress' && !project.timeline.started) {
      project.timeline.started = new Date().toISOString();
    }
    
    if (status === 'completed' && !project.timeline.completed) {
      project.timeline.completed = new Date().toISOString();
    }

    if (notes) {
      project.notes = project.notes || [];
      project.notes.push({
        content: notes,
        timestamp: new Date().toISOString(),
        type: 'status_update'
      });
    }

    await kv.set(`project:${projectId}`, project);
    return c.json({ message: 'Project status updated successfully', project });

  } catch (error) {
    console.log('Update project status error:', error);
    return c.json({ error: 'Failed to update project status' }, 500);
  }
});

// ============ 文件上传 API ============

// 上传项目文件
app.post('/make-server-d0d1e627/projects/:projectId/upload', requireAuth, async (c) => {
  try {
    const user = c.get('user');
    const projectId = c.req.param('projectId');
    
    const project = await kv.get(`project:${projectId}`);
    if (!project || project.userId !== user.id) {
      return c.json({ error: 'Project not found or access denied' }, 404);
    }

    const formData = await c.req.formData();
    const file = formData.get('file') as File;
    
    if (!file) {
      return c.json({ error: 'No file provided' }, 400);
    }

    const fileName = `${projectId}/${Date.now()}_${file.name}`;
    const fileBuffer = await file.arrayBuffer();

    const { data, error } = await supabase.storage
      .from('make-d0d1e627-design-files')
      .upload(fileName, fileBuffer, {
        contentType: file.type,
        upsert: false
      });

    if (error) {
      console.log('File upload error:', error);
      return c.json({ error: 'Failed to upload file' }, 500);
    }

    // 生成签名URL
    const { data: urlData } = await supabase.storage
      .from('make-d0d1e627-design-files')
      .createSignedUrl(fileName, 3600 * 24 * 7); // 7天有效期

    const fileRecord = {
      id: `file_${Date.now()}`,
      name: file.name,
      type: file.type,
      size: file.size,
      path: fileName,
      url: urlData?.signedUrl,
      uploadedAt: new Date().toISOString()
    };

    project.files = project.files || [];
    project.files.push(fileRecord);
    project.updatedAt = new Date().toISOString();

    await kv.set(`project:${projectId}`, project);

    return c.json({ 
      message: 'File uploaded successfully',
      file: fileRecord
    });

  } catch (error) {
    console.log('Upload file error:', error);
    return c.json({ error: 'Failed to upload file' }, 500);
  }
});

// ============ 博客管理 API ============

// 获取博客文章列表
app.get('/make-server-d0d1e627/blog/posts', async (c) => {
  try {
    const { page = 1, limit = 10, category } = c.req.query();
    
    let posts = await kv.getByPrefix('blog_post:');
    
    // 筛选已发布的文章
    posts = posts.filter(post => post.status === 'published');
    
    // 按分类筛选
    if (category && category !== 'all') {
      posts = posts.filter(post => post.category === category);
    }

    // 按发布时间倒序排列
    posts.sort((a, b) => new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime());

    // 分页
    const startIndex = (parseInt(page) - 1) * parseInt(limit);
    const endIndex = startIndex + parseInt(limit);
    const paginatedPosts = posts.slice(startIndex, endIndex);

    return c.json({
      posts: paginatedPosts,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total: posts.length,
        totalPages: Math.ceil(posts.length / parseInt(limit))
      }
    });

  } catch (error) {
    console.log('Get blog posts error:', error);
    return c.json({ error: 'Failed to retrieve blog posts' }, 500);
  }
});

// 获取单篇博客文章
app.get('/make-server-d0d1e627/blog/posts/:slug', async (c) => {
  try {
    const slug = c.req.param('slug');
    const post = await kv.get(`blog_post:${slug}`);
    
    if (!post || post.status !== 'published') {
      return c.json({ error: 'Post not found' }, 404);
    }

    // 增加浏览量
    post.views = (post.views || 0) + 1;
    await kv.set(`blog_post:${slug}`, post);

    return c.json({ post });

  } catch (error) {
    console.log('Get blog post error:', error);
    return c.json({ error: 'Failed to retrieve blog post' }, 500);
  }
});

// 创建博客文章 (需要管理员权限)
app.post('/make-server-d0d1e627/blog/posts', requireAuth, async (c) => {
  try {
    const user = c.get('user');
    
    // 简单的管理员检查 (在实际应用中应该有更严格的权限控制)
    const userProfile = await kv.get(`user_profile:${user.id}`);
    if (!userProfile || userProfile.role !== 'admin') {
      return c.json({ error: 'Admin access required' }, 403);
    }

    const { title, content, excerpt, category, tags, featuredImage } = await c.req.json();

    if (!title || !content) {
      return c.json({ error: 'Title and content are required' }, 400);
    }

    const slug = title.toLowerCase()
      .replace(/[^a-z0-9 -]/g, '')
      .replace(/\s+/g, '-')
      .replace(/-+/g, '-');

    const post = {
      id: `post_${Date.now()}`,
      slug,
      title,
      content,
      excerpt: excerpt || content.substring(0, 200) + '...',
      category: category || 'uncategorized',
      tags: tags || [],
      featuredImage: featuredImage || '',
      author: {
        id: user.id,
        name: userProfile.fullName,
        avatar: userProfile.avatar_url
      },
      status: 'published',
      createdAt: new Date().toISOString(),
      publishedAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      views: 0,
      likes: 0
    };

    await kv.set(`blog_post:${slug}`, post);

    return c.json({ message: 'Blog post created successfully', post });

  } catch (error) {
    console.log('Create blog post error:', error);
    return c.json({ error: 'Failed to create blog post' }, 500);
  }
});

// ============ 统计数据 API ============

// 获取仪表板统计数据
app.get('/make-server-d0d1e627/dashboard/stats', requireAuth, async (c) => {
  try {
    const user = c.get('user');
    
    // 获取用户项目
    const userProjectKeys = await kv.getByPrefix(`user_project:${user.id}:`);
    const projects = [];
    for (const projectId of userProjectKeys) {
      const project = await kv.get(`project:${projectId}`);
      if (project) projects.push(project);
    }

    // 计算统计数据
    const stats = {
      totalProjects: projects.length,
      activeProjects: projects.filter(p => p.status === 'in_progress').length,
      completedProjects: projects.filter(p => p.status === 'completed').length,
      pendingProjects: projects.filter(p => p.status === 'pending').length,
      recentActivity: projects
        .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
        .slice(0, 5)
        .map(p => ({
          id: p.id,
          title: p.title,
          status: p.status,
          updatedAt: p.updatedAt
        }))
    };

    return c.json({ stats });

  } catch (error) {
    console.log('Get dashboard stats error:', error);
    return c.json({ error: 'Failed to retrieve dashboard statistics' }, 500);
  }
});

// ============ Stripe 支付 API ============

// Stripe配置信息
app.get('/make-server-d0d1e627/stripe/config', getStripeConfig);

// 创建支付意图
app.post('/make-server-d0d1e627/stripe/create-payment-intent', createPaymentIntent);

// 确认支付
app.post('/make-server-d0d1e627/stripe/confirm-payment', confirmPayment);

// 获取支付状态
app.get('/make-server-d0d1e627/stripe/payment-status/:id', getPaymentStatus);

// Stripe Webhook处理
app.post('/make-server-d0d1e627/stripe/webhook', handleStripeWebhook);

// ============ 订单管理 API ============

// 创建订单（支付成功后）
app.post('/make-server-d0d1e627/orders', requireAuth, async (c) => {
  try {
    const user = c.get('user');
    const { 
      projectId, 
      amount, 
      currency, 
      paymentIntentId,
      packageType,
      projectDetails 
    } = await c.req.json();

    if (!projectId || !amount || !paymentIntentId) {
      return c.json({ error: 'Missing required order information' }, 400);
    }

    const orderId = `order_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const order = {
      id: orderId,
      userId: user.id,
      projectId,
      amount: parseFloat(amount),
      currency: currency || 'USD',
      paymentIntentId,
      packageType,
      projectDetails,
      status: 'completed',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    await kv.set(`order:${orderId}`, order);
    await kv.set(`user_order:${user.id}:${orderId}`, orderId);
    await kv.set(`project_order:${projectId}`, orderId);

    return c.json({ 
      message: 'Order created successfully', 
      order 
    });

  } catch (error) {
    console.log('Create order error:', error);
    return c.json({ error: 'Failed to create order' }, 500);
  }
});

// 获取用户订单列表
app.get('/make-server-d0d1e627/orders', requireAuth, async (c) => {
  try {
    const user = c.get('user');
    const userOrderKeys = await kv.getByPrefix(`user_order:${user.id}:`);
    
    const orders = [];
    for (const orderId of userOrderKeys) {
      const order = await kv.get(`order:${orderId}`);
      if (order) {
        orders.push(order);
      }
    }

    // 按创建时间倒序排列
    orders.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    return c.json({ orders });

  } catch (error) {
    console.log('Get orders error:', error);
    return c.json({ error: 'Failed to retrieve orders' }, 500);
  }
});

// 初始化存储桶
initializeBuckets();

// 启动服务器
export default {
  fetch: app.fetch,
};

Deno.serve(app.fetch);