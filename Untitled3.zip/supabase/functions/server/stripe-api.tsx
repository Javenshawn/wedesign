import { Context } from 'npm:hono';
import Stripe from 'npm:stripe';

// 初始化Stripe客户端
const getStripeClient = () => {
  const secretKey = Deno.env.get('STRIPE_SECRET_KEY');
  
  if (!secretKey) {
    console.error('❌ STRIPE_SECRET_KEY环境变量未配置');
    throw new Error('Stripe配置错误');
  }
  
  console.log('✅ 初始化Stripe客户端，密钥类型:', secretKey.startsWith('sk_test_') ? '测试模式' : '生产模式');
  
  return new Stripe(secretKey, {
    apiVersion: '2023-10-16',
  });
};

/**
 * 创建支付意图
 */
export const createPaymentIntent = async (c: Context) => {
  try {
    const { amount, currency, metadata = {} } = await c.req.json();
    
    console.log('🔄 创建支付意图请求:', { amount, currency, metadata });
    
    // 验证必要参数
    if (!amount || amount <= 0) {
      return c.json({ error: '无效的支付金额' }, 400);
    }
    
    if (!currency) {
      return c.json({ error: '未指定支付货币' }, 400);
    }
    
    const stripe = getStripeClient();
    
    // 创建支付意图
    const paymentIntent = await stripe.paymentIntents.create({
      amount: Math.round(amount), // 确保是整数（美分）
      currency: currency.toLowerCase(),
      metadata: {
        ...metadata,
        source: 'wedesign_website',
        created_at: new Date().toISOString()
      },
      automatic_payment_methods: {
        enabled: true,
      },
    });
    
    console.log('✅ 支付意图创建成功:', paymentIntent.id);
    
    return c.json({
      id: paymentIntent.id,
      client_secret: paymentIntent.client_secret,
      amount: paymentIntent.amount,
      currency: paymentIntent.currency,
      status: paymentIntent.status
    });
    
  } catch (error: any) {
    console.error('❌ 创建支付意图失败:', error);
    return c.json({ 
      error: error.message || '创建支付意图失败',
      type: error.type || 'api_error'
    }, 500);
  }
};

/**
 * 确认支付
 */
export const confirmPayment = async (c: Context) => {
  try {
    const { paymentIntentId, paymentMethodId } = await c.req.json();
    
    console.log('🔄 确认支付请求:', { paymentIntentId, paymentMethodId });
    
    if (!paymentIntentId) {
      return c.json({ error: '缺少支付意图ID' }, 400);
    }
    
    const stripe = getStripeClient();
    
    // 确认支付意图
    const paymentIntent = await stripe.paymentIntents.confirm(paymentIntentId, {
      payment_method: paymentMethodId,
      return_url: `${Deno.env.get('NEXT_PUBLIC_SITE_URL') || 'http://localhost:3000'}/payment-success`,
    });
    
    console.log('✅ 支付确认成功:', paymentIntent.id, '状态:', paymentIntent.status);
    
    return c.json({
      id: paymentIntent.id,
      status: paymentIntent.status,
      amount: paymentIntent.amount,
      currency: paymentIntent.currency,
      payment_method: paymentIntent.payment_method
    });
    
  } catch (error: any) {
    console.error('❌ 确认支付失败:', error);
    return c.json({ 
      error: error.message || '确认支付失败',
      type: error.type || 'api_error'
    }, 500);
  }
};

/**
 * 获取支付状态
 */
export const getPaymentStatus = async (c: Context) => {
  try {
    const paymentIntentId = c.req.param('id');
    
    console.log('🔄 获取支付状态:', paymentIntentId);
    
    if (!paymentIntentId) {
      return c.json({ error: '缺少支付意图ID' }, 400);
    }
    
    const stripe = getStripeClient();
    
    const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);
    
    console.log('✅ 获取支付状态成功:', paymentIntent.status);
    
    return c.json({
      id: paymentIntent.id,
      status: paymentIntent.status,
      amount: paymentIntent.amount,
      currency: paymentIntent.currency,
      created: paymentIntent.created,
      payment_method: paymentIntent.payment_method
    });
    
  } catch (error: any) {
    console.error('❌ 获取支付状态失败:', error);
    return c.json({ 
      error: error.message || '获取支付状态失败',
      type: error.type || 'api_error'
    }, 500);
  }
};

/**
 * 处理Stripe Webhook
 */
export const handleStripeWebhook = async (c: Context) => {
  try {
    const signature = c.req.header('stripe-signature');
    const webhookSecret = Deno.env.get('STRIPE_WEBHOOK_SECRET');
    
    if (!signature) {
      console.error('❌ 缺少Stripe签名');
      return c.json({ error: '缺少签名' }, 400);
    }
    
    if (!webhookSecret) {
      console.error('❌ 未配置Webhook密钥');
      return c.json({ error: 'Webhook配置错误' }, 500);
    }
    
    const body = await c.req.text();
    const stripe = getStripeClient();
    
    // 验证Webhook签名
    const event = stripe.webhooks.constructEvent(body, signature, webhookSecret);
    
    console.log('🔄 处理Stripe Webhook事件:', event.type);
    
    switch (event.type) {
      case 'payment_intent.succeeded':
        const paymentIntent = event.data.object as Stripe.PaymentIntent;
        console.log('✅ 支付成功:', paymentIntent.id);
        
        // TODO: 更新订单状态，发送确认邮件等
        break;
        
      case 'payment_intent.payment_failed':
        const failedPayment = event.data.object as Stripe.PaymentIntent;
        console.log('❌ 支付失败:', failedPayment.id);
        
        // TODO: 处理支付失败逻辑
        break;
        
      default:
        console.log('ℹ️ 未处理的Webhook事件:', event.type);
    }
    
    return c.json({ received: true });
    
  } catch (error: any) {
    console.error('❌ 处理Webhook失败:', error);
    return c.json({ 
      error: error.message || 'Webhook处理失败',
      type: 'webhook_error'
    }, 400);
  }
};

/**
 * 获取Stripe公开配置
 */
export const getStripeConfig = async (c: Context) => {
  try {
    const publishableKey = Deno.env.get('NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY');
    
    if (!publishableKey) {
      return c.json({ 
        error: 'Stripe未配置',
        configured: false 
      }, 500);
    }
    
    return c.json({
      publishable_key: publishableKey,
      configured: true,
      test_mode: publishableKey.startsWith('pk_test_')
    });
    
  } catch (error: any) {
    console.error('❌ 获取Stripe配置失败:', error);
    return c.json({ 
      error: '获取配置失败',
      configured: false
    }, 500);
  }
};