export interface Plugin {
  id: string;
  name: string;
  description: string;
  developer: string;
  version: string;
  downloads: number;
  rating: number;
  category: string;
  tags: string[];
  icon: string;
  screenshots: string[];
  isInstalled: boolean;
  isFeatured: boolean;
  price: number; // 0 for free
}

export const mockPlugins: Plugin[] = [
  {
    id: "wix-website-builder",
    name: "Wix Website Builder",
    description: "将你的Figma设计直接转换为Wix网站。支持响应式设计、动画和交互元素。",
    developer: "Wix.com",
    version: "2.4.1",
    downloads: 150000,
    rating: 4.8,
    category: "网站建设",
    tags: ["wix", "网站", "导出", "响应式"],
    icon: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=100&h=100&fit=crop",
    screenshots: [
      "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&h=300&fit=crop",
      "https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=400&h=300&fit=crop"
    ],
    isInstalled: false,
    isFeatured: true,
    price: 0
  },
  {
    id: "wix-design-system",
    name: "Wix Design System",
    description: "Wix官方设计系统组件库，包含完整的UI组件、图标和模板。",
    developer: "Wix.com",
    version: "1.8.0",
    downloads: 95000,
    rating: 4.6,
    category: "设计系统",
    tags: ["wix", "组件", "设计系统", "模板"],
    icon: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=100&h=100&fit=crop",
    screenshots: [
      "https://images.unsplash.com/photo-1561070791-2526d30994b5?w=400&h=300&fit=crop"
    ],
    isInstalled: false,
    isFeatured: true,
    price: 0
  },
  {
    id: "figma-tokens",
    name: "Figma Tokens",
    description: "强大的设计令牌管理工具，支持导出到多种平台。",
    developer: "Jan Six",
    version: "3.2.1",
    downloads: 200000,
    rating: 4.9,
    category: "开发工具",
    tags: ["tokens", "开发", "导出"],
    icon: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=100&h=100&fit=crop",
    screenshots: [],
    isInstalled: true,
    isFeatured: false,
    price: 0
  },
  {
    id: "autoflow",
    name: "Autoflow",
    description: "自动生成用户流程图和连接线。",
    developer: "Autoflow Team",
    version: "1.5.3",
    downloads: 75000,
    rating: 4.4,
    category: "用户体验",
    tags: ["流程图", "用户体验", "连接"],
    icon: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=100&h=100&fit=crop",
    screenshots: [],
    isInstalled: false,
    isFeatured: false,
    price: 15
  },
  {
    id: "content-reel",
    name: "Content Reel",
    description: "快速插入真实内容，包括头像、文本和图片。",
    developer: "Content Team",
    version: "2.1.0",
    downloads: 120000,
    rating: 4.7,
    category: "内容",
    tags: ["内容", "文本", "图片", "头像"],
    icon: "https://images.unsplash.com/photo-1590479773265-7464e5d48118?w=100&h=100&fit=crop",
    screenshots: [],
    isInstalled: false,
    isFeatured: true,
    price: 0
  }
];

export const categories = [
  "全部",
  "网站建设",
  "设计系统", 
  "开发工具",
  "用户体验",
  "内容",
  "图标",
  "动画",
  "原型"
];