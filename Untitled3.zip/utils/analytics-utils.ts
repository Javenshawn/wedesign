import { getEnvVar } from './env-utils';

/**
 * Initializes Google Analytics if conditions are met
 */
export const initializeGoogleAnalytics = () => {
  try {
    const gaId = getEnvVar('NEXT_PUBLIC_GA_MEASUREMENT_ID') || getEnvVar('VITE_GA_MEASUREMENT_ID');
    
    // Only load GA in production environment with valid GA ID
    if (gaId && typeof window !== 'undefined') {
      const hostname = window.location.hostname;
      
      // Only load GA on production domains
      if (hostname === 'www.wedesign.design' || hostname === 'wedesign.design') {
        const existingScript = document.querySelector(`script[src*="googletagmanager.com/gtag/js?id=${gaId}"]`);
        
        if (!existingScript) {
          const script1 = document.createElement('script');
          script1.async = true;
          script1.src = `https://www.googletagmanager.com/gtag/js?id=${gaId}`;
          script1.onload = () => {
            console.log('Google Analytics loaded successfully');
          };
          script1.onerror = () => {
            console.warn('Failed to load Google Analytics');
          };
          document.head.appendChild(script1);

          const script2 = document.createElement('script');
          script2.textContent = `
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', '${gaId}', {
              page_title: document.title,
              page_location: window.location.href
            });
          `;
          document.head.appendChild(script2);
        }
      }
    }
  } catch (error) {
    console.warn('Google Analytics初始化失败:', error);
  }
};

/**
 * Tracks page view in Google Analytics
 * @param page - The page identifier
 */
export const trackPageView = (page: string) => {
  try {
    if (typeof window !== 'undefined' && (window as any).gtag) {
      const gaId = getEnvVar('NEXT_PUBLIC_GA_MEASUREMENT_ID') || getEnvVar('VITE_GA_MEASUREMENT_ID');
      if (gaId) {
        const url = page === 'home' ? '/' : `/${page}`;
        (window as any).gtag('config', gaId, {
          page_path: url,
          page_title: document.title,
          page_location: window.location.href
        });
      }
    }
  } catch (error) {
    console.warn('GA页面追踪失败:', error);
  }
};

/**
 * Tracks navigation events in Google Analytics
 * @param page - The page identifier being navigated to
 */
export const trackNavigation = (page: string) => {
  try {
    if (typeof window !== 'undefined' && (window as any).gtag) {
      const gaId = getEnvVar('NEXT_PUBLIC_GA_MEASUREMENT_ID') || getEnvVar('VITE_GA_MEASUREMENT_ID');
      if (gaId) {
        const url = page === 'home' ? '/' : `/${page}`;
        (window as any).gtag('config', gaId, {
          page_path: url,
          page_title: document.title,
          page_location: window.location.href
        });
        
        // Send page view event
        (window as any).gtag('event', 'page_view', {
          page_title: document.title,
          page_location: window.location.href,
          page_path: url
        });
      }
    }
  } catch (error) {
    console.warn('GA导航追踪失败:', error);
  }
};

/**
 * Tracks user logout event in Google Analytics
 */
export const trackUserLogout = () => {
  try {
    if (typeof window !== 'undefined' && (window as any).gtag) {
      (window as any).gtag('event', 'user_logout', {
        event_category: 'engagement',
        event_label: 'user_management'
      });
    }
  } catch (error) {
    console.warn('GA登出事件记录失败:', error);
  }
};