/**
 * Safely gets environment variables across different environments
 * @param key - The environment variable key
 * @returns The environment variable value or undefined
 */
export const getEnvVar = (key: string): string | undefined => {
  try {
    // Browser environment with injected env
    if (typeof window !== 'undefined' && (window as any).__ENV__) {
      return (window as any).__ENV__[key];
    }
    
    // Node environment (fallback for SSR)  
    if (typeof process !== 'undefined' && process?.env) {
      return process.env[key];
    }
    
    // Return undefined to allow development mode simulation
    return undefined;
  } catch (error) {
    return undefined;
  }
};

/**
 * Check if we're in development mode
 */
export const isDevelopment = (): boolean => {
  try {
    // Check various development indicators
    const nodeEnv = getEnvVar('NODE_ENV');
    const viteNodeEnv = getEnvVar('VITE_NODE_ENV');
    
    // Check if explicitly set to development
    if (nodeEnv === 'development' || viteNodeEnv === 'development') {
      return true;
    }
    
    // Check if explicitly set to production
    if (nodeEnv === 'production' || viteNodeEnv === 'production') {
      return false;
    }
    
    // Default to development for safety (this allows payment simulation to work)
    return true;
  } catch {
    return true; // Default to development if unsure
  }
};

/**
 * Check if Stripe is properly configured
 */
export const isStripeConfigured = (): boolean => {
  const publishableKey = getEnvVar('VITE_STRIPE_PUBLISHABLE_KEY') || getEnvVar('NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY');
  return !!(publishableKey && publishableKey.startsWith('pk_'));
};

/**
 * Check if Supabase is properly configured
 */
export const isSupabaseConfigured = (): boolean => {
  const url = getEnvVar('VITE_SUPABASE_URL') || getEnvVar('NEXT_PUBLIC_SUPABASE_URL');
  const key = getEnvVar('VITE_SUPABASE_ANON_KEY') || getEnvVar('NEXT_PUBLIC_SUPABASE_ANON_KEY');
  return !!(url && key);
};