// 示例博客数据 - 在实际应用中，这些将来自Supabase后端
export const sampleBlogPosts = [
  {
    id: 'post_1',
    slug: 'logo-design-trends-2024',
    title: 'Logo Design Trends That Will Define 2024',
    content: `
      The world of logo design is constantly evolving, and 2024 promises to bring exciting new trends that will reshape how brands express their identity. As we move deeper into the digital age, designers are finding innovative ways to create logos that work seamlessly across all platforms while maintaining their unique character.

      **Minimalism with Purpose**
      
      The trend toward minimalism continues to dominate, but with a twist. Designers are now focusing on "purposeful minimalism" - stripping away unnecessary elements while ensuring every remaining component serves a specific function. This approach creates logos that are not only visually clean but also meaningful and memorable.

      **Geometric Harmony**
      
      Geometric shapes are making a strong comeback, but not in the rigid, mathematical way we've seen before. Instead, designers are exploring organic geometry - shapes that feel natural and fluid while maintaining geometric principles. This creates a perfect balance between structure and creativity.

      **Sustainable Design Thinking**
      
      With increasing awareness of environmental issues, brands are incorporating sustainable design principles into their logos. This includes using colors that represent nature, choosing forms that suggest growth and renewal, and creating designs that can be easily reproduced across various media without excessive resource consumption.

      **Dynamic Brand Systems**
      
      Static logos are giving way to dynamic brand systems that can adapt to different contexts while maintaining core brand recognition. These flexible systems allow brands to express different facets of their personality while remaining consistent.

      **Cultural Authenticity**
      
      As global markets become more interconnected, brands are focusing on cultural authenticity in their logo design. This means creating designs that respect and reflect the cultural values of their target audiences, moving away from one-size-fits-all approaches.

      The key to successful logo design in 2024 will be finding the right balance between these trends while staying true to the brand's core values and mission. Remember, trends should inform your design decisions, not dictate them.
    `,
    excerpt: 'Explore the latest logo design trends including minimalism, geometric shapes, and sustainable branding approaches that are shaping 2024.',
    category: 'design-tips',
    tags: ['trends', 'logo design', '2024', 'minimalism', 'geometric'],
    featuredImage: 'https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=800&h=600&fit=crop',
    author: {
      id: 'author_1',
      name: 'Sarah Chen',
      avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b789?w=150&h=150&fit=crop'
    },
    status: 'published',
    createdAt: '2024-01-15T10:00:00Z',
    publishedAt: '2024-01-15T10:00:00Z',
    updatedAt: '2024-01-15T10:00:00Z',
    views: 1247,
    likes: 89
  },
  {
    id: 'post_2',
    slug: 'psychology-of-color-in-branding',
    title: 'The Psychology of Color in Brand Identity',
    content: `
      Color is one of the most powerful tools in a designer's arsenal, capable of evoking emotions, triggering memories, and influencing behavior. Understanding color psychology is crucial for creating effective brand identities that resonate with target audiences.

      **The Science Behind Color Perception**
      
      Our brains are wired to respond to color in specific ways. Research shows that people make subconscious judgments about a product within 90 seconds of initial viewing, and between 62% and 90% of that assessment is based on color alone. This makes color choice critical in logo design and brand identity.

      **Primary Colors and Their Impact**
      
      Red: Associated with energy, passion, and urgency. Brands like Coca-Cola and Netflix use red to create excitement and grab attention. However, red can also signify danger or aggression, so it must be used thoughtfully.

      Blue: Represents trust, stability, and professionalism. It's no coincidence that many financial institutions and tech companies (IBM, Facebook, LinkedIn) use blue in their branding. Blue is the most universally liked color and is considered safe for most industries.

      Yellow: Symbolizes optimism, creativity, and warmth. McDonald's and IKEA use yellow to create feelings of happiness and accessibility. However, yellow can be overwhelming if overused and may appear cheap if not balanced properly.

      **Secondary Colors and Emotional Responses**
      
      Green: Connected to nature, growth, and prosperity. It's increasingly popular among eco-friendly brands and financial services (Starbucks, Whole Foods). Green also represents balance and harmony.

      Orange: Combines the energy of red with the happiness of yellow. It's associated with enthusiasm, creativity, and affordability. Brands like Home Depot and Fanta use orange to appear friendly and approachable.

      Purple: Traditionally associated with luxury, royalty, and sophistication. Brands like Cadbury and Yahoo use purple to convey premium quality and creativity.

      **Cultural Considerations**
      
      Color meanings can vary significantly across cultures. White represents purity in Western cultures but mourning in some Eastern cultures. Red is lucky in China but can signify danger in Western contexts. Global brands must consider these differences when expanding internationally.

      **Practical Application in Logo Design**
      
      When choosing colors for a logo, consider:
      - Your target audience and their cultural background
      - Your industry and competitor colors
      - The emotions you want to evoke
      - How the colors will reproduce across different media
      - Accessibility considerations for colorblind users

      The most effective brand colors are those that align with the brand's personality while considering the psychological impact on the target audience. Remember, there are no universally "good" or "bad" colors - only colors that are appropriate or inappropriate for specific contexts and audiences.
    `,
    excerpt: 'Learn how different colors evoke emotions and influence purchasing decisions in brand design. Discover the science behind color psychology.',
    category: 'branding',
    tags: ['color psychology', 'branding', 'marketing', 'emotions'],
    featuredImage: 'https://images.unsplash.com/photo-1561070791-2526d30994b5?w=800&h=600&fit=crop',
    author: {
      id: 'author_2',
      name: 'Marcus Rodriguez',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop'
    },
    status: 'published',
    createdAt: '2024-01-12T14:30:00Z',
    publishedAt: '2024-01-12T14:30:00Z',
    updatedAt: '2024-01-12T14:30:00Z',
    views: 2156,
    likes: 134
  },
  {
    id: 'post_3',
    slug: 'startup-logo-case-study',
    title: 'Case Study: Rebranding a Tech Startup',
    content: `
      When FinanceFlow, a promising fintech startup, approached us for a complete rebrand, they were facing a common challenge: their current visual identity wasn't reflecting their innovative approach to financial technology. This case study walks through our complete rebranding process.

      **The Challenge**
      
      FinanceFlow's original logo was a generic combination of a dollar sign and an arrow, created quickly during their initial launch. As they grew and secured Series A funding, they realized their brand needed to convey trust, innovation, and accessibility - three core values that weren't reflected in their current identity.

      Key challenges included:
      - Differentiating from traditional financial institutions
      - Appealing to tech-savvy millennials and Gen Z
      - Maintaining trustworthiness while appearing innovative
      - Creating a flexible system for rapid growth

      **Research and Discovery**
      
      We began with comprehensive research, including:
      - Stakeholder interviews with founders, employees, and key customers
      - Competitive analysis of both fintech and traditional finance brands
      - User surveys to understand brand perception
      - Market trend analysis in financial technology

      Our research revealed that users wanted a financial app that felt more like a lifestyle brand than a bank. They valued transparency, simplicity, and personal empowerment in their financial decisions.

      **Concept Development**
      
      Based on our research, we developed three distinct concepts:

      1. **The Flow Concept**: Emphasized the smooth, seamless nature of financial transactions
      2. **The Growth Concept**: Focused on personal financial growth and prosperity
      3. **The Connection Concept**: Highlighted the relationship between user and their financial goals

      After testing with focus groups, the Flow concept resonated most strongly, combining feelings of progress, ease, and forward momentum.

      **Design Execution**
      
      The final logo features a dynamic, flowing mark that suggests both water and data visualization. The form is created from a single, continuous line that flows through space, representing the seamless movement of money and information.

      Color palette:
      - Primary: Deep teal (#1A5F5F) - trustworthy yet approachable
      - Secondary: Bright coral (#FF6B6B) - energetic and optimistic
      - Accent: Warm gold (#FFD93D) - prosperity and achievement

      Typography: We selected a custom typeface based on Sofia Pro, modified to include unique characters that echo the flowing theme of the mark.

      **Implementation and Results**
      
      The rebrand was rolled out across all touchpoints over six months:
      - Mobile app redesign with new brand elements
      - Website rebuild with updated visual system
      - Marketing materials and social media templates
      - Office space and branded merchandise

      Results after 12 months:
      - 340% increase in brand recognition
      - 25% improvement in user acquisition
      - 45% increase in user engagement
      - 90% positive feedback on brand perception surveys

      **Key Learnings**
      
      1. **Research is crucial**: Deep understanding of users and market context informed every design decision
      2. **Flexibility matters**: The new brand system adapted well to rapid product development
      3. **Implementation is everything**: Even the best design fails without proper rollout planning
      4. **Measure success**: Clear metrics helped prove the rebrand's business impact

      This project reinforced our belief that successful rebranding requires equal parts creative vision and strategic thinking. The most beautiful logo in the world won't succeed if it doesn't serve the business and its users.
    `,
    excerpt: 'Follow our complete process of rebranding a fintech startup, from research to final implementation. See how strategic design drives business results.',
    category: 'case-studies',
    tags: ['case study', 'startup', 'rebranding', 'fintech'],
    featuredImage: 'https://images.unsplash.com/photo-1552664730-d307ca884978?w=800&h=600&fit=crop',
    author: {
      id: 'author_3',
      name: 'Jennifer Kim',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop'
    },
    status: 'published',
    createdAt: '2024-01-10T09:15:00Z',
    publishedAt: '2024-01-10T09:15:00Z',
    updatedAt: '2024-01-10T09:15:00Z',
    views: 892,
    likes: 67
  }
];

// 博客分类数据
export const blogCategories = [
  { id: 'all', name: 'All Articles', count: 0 },
  { id: 'design-tips', name: 'Design Tips', count: 0 },
  { id: 'branding', name: 'Branding', count: 0 },
  { id: 'case-studies', name: 'Case Studies', count: 0 },
  { id: 'industry-news', name: 'Industry News', count: 0 },
  { id: 'tutorials', name: 'Tutorials', count: 0 }
];

// 博客作者数据
export const blogAuthors = [
  {
    id: 'author_1',
    name: 'Sarah Chen',
    title: 'Lead Brand Designer',
    bio: 'Sarah has over 8 years of experience in brand design and has helped shape the visual identity of over 200 startups and established companies.',
    avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b789?w=150&h=150&fit=crop',
    social: {
      twitter: '@sarahchen_design',
      linkedin: 'sarah-chen-design',
      dribbble: 'sarahchen'
    }
  },
  {
    id: 'author_2',
    name: 'Marcus Rodriguez',
    title: 'Creative Director',
    bio: 'Marcus brings 12 years of creative leadership experience, having worked with Fortune 500 companies and innovative startups across various industries.',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop',
    social: {
      twitter: '@marcusdesigns',
      linkedin: 'marcus-rodriguez-creative',
      behance: 'marcusrodriguez'
    }
  },
  {
    id: 'author_3',
    name: 'Jennifer Kim',
    title: 'Strategy & Research Lead',
    bio: 'Jennifer specializes in brand strategy and user research, ensuring every design decision is backed by solid data and user insights.',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop',
    social: {
      twitter: '@jennkim_strategy',
      linkedin: 'jennifer-kim-strategy'
    }
  }
];