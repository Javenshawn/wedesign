// WeDesign SEO Keywords Database
// All keywords organized by industry and style categories

export interface Keyword {
  id: string;
  keyword: string;
  category: string;
  searchVolume: number;
  difficulty: number;
  ctr: number;
  currentRanking: number | null;
  targetUrl: string;
  lastUpdated: string;
  trend: 'up' | 'down' | 'stable';
}

export interface KeywordCategory {
  id: string;
  name: string;
  description: string;
  keywords: string[];
  color: string;
}

// Keyword categories with embedded data
export const keywordCategories: KeywordCategory[] = [
  {
    id: '3d',
    name: '3D Design',
    description: '3D logo design and modeling services',
    color: 'bg-blue-500',
    keywords: [
      '3D app logo design', '3D auto logo design', '3D bakery logo design', '3D bank logo design', 
      '3D barber logo design', '3D beauty logo design', '3D bookstore logo design', '3D boutique logo design',
      '3D cafe logo design', '3D charity logo design', '3D church logo design', '3D clinic logo design',
      '3D clothing logo design', '3D coffee shop logo design', '3D construction logo design', '3D cosmetics logo design',
      '3D craft logo design', '3D cryptocurrency logo design', '3D e-commerce logo design', '3D education logo design',
      '3D environment logo design', '3D event logo design', '3D farm logo design', '3D fashion logo design',
      '3D finance logo design', '3D fitness logo design', '3D food logo design', '3D gaming logo design',
      '3D gym logo design', '3D handmade logo design', '3D hotel logo design', '3D insurance logo design',
      '3D law firm logo design', '3D logo design', '3D music logo design', '3D nonprofit logo design',
      '3D organic logo design', '3D pet shop logo design', '3D photography logo design', '3D publishing logo design',
      '3D real estate logo design', '3D restaurant logo design', '3D retail logo design', '3D salon logo design',
      '3D school logo design', '3D software logo design', '3D spa logo design', '3D sports team logo design',
      '3D technology logo design', '3D toy logo design', '3D travel logo design', '3D wedding logo design', '3D yoga logo design'
    ]
  },
  {
    id: 'abstract',
    name: 'Abstract Design',
    description: 'Modern abstract and geometric logo designs',
    color: 'bg-purple-500',
    keywords: [
      'abstract app logo design', 'abstract auto logo design', 'abstract bakery logo design', 'abstract bank logo design',
      'abstract barber logo design', 'abstract beauty logo design', 'abstract bookstore logo design', 'abstract boutique logo design',
      'abstract cafe logo design', 'abstract charity logo design', 'abstract church logo design', 'abstract clinic logo design',
      'abstract clothing logo design', 'abstract coffee shop logo design', 'abstract construction logo design', 'abstract cosmetics logo design',
      'abstract craft logo design', 'abstract cryptocurrency logo design', 'abstract e-commerce logo design', 'abstract education logo design',
      'abstract environment logo design', 'abstract event logo design', 'abstract farm logo design', 'abstract fashion logo design',
      'abstract finance logo design', 'abstract fitness logo design', 'abstract food logo design', 'abstract gaming logo design',
      'abstract gym logo design', 'abstract handmade logo design', 'abstract hotel logo design', 'abstract insurance logo design',
      'abstract law firm logo design', 'abstract music logo design', 'abstract nonprofit logo design', 'abstract organic logo design',
      'abstract pet shop logo design', 'abstract photography logo design', 'abstract publishing logo design', 'abstract real estate logo design',
      'abstract restaurant logo design', 'abstract retail logo design', 'abstract salon logo design', 'abstract school logo design',
      'abstract software logo design', 'abstract spa logo design', 'abstract sports team logo design', 'abstract technology logo design',
      'abstract toy logo design', 'abstract travel logo design', 'abstract wedding logo design', 'abstract yoga logo design'
    ]
  },
  {
    id: 'app',
    name: 'App & Software',
    description: 'Mobile app and software logo designs',
    color: 'bg-green-500',
    keywords: [
      'app 3D logo design', 'app abstract logo design', 'app bold logo design', 'app classic logo design',
      'app clean logo design', 'app colorful logo design', 'app creative logo design', 'app custom logo design',
      'app cute logo design', 'app dynamic logo design', 'app elegant logo design', 'app feminine logo design',
      'app flat logo design', 'app fresh logo design', 'app geometric logo design', 'app hand-drawn logo design',
      'app luxury logo design', 'app masculine logo design', 'app minimalist logo design', 'app modern logo design',
      'app organic logo design', 'app professional logo design', 'app retro logo design', 'app simple logo design',
      'app unique logo design', 'app versatile logo design', 'app vintage logo design'
    ]
  },
  {
    id: 'automotive',
    name: 'Automotive',
    description: 'Car, auto, and transportation logo designs',
    color: 'bg-red-500',
    keywords: [
      'auto 3D logo design', 'auto abstract logo design', 'auto bold logo design', 'auto classic logo design',
      'auto clean logo design', 'auto colorful logo design', 'auto creative logo design', 'auto custom logo design',
      'auto cute logo design', 'auto dynamic logo design', 'auto elegant logo design', 'auto feminine logo design',
      'auto flat logo design', 'auto fresh logo design', 'auto geometric logo design', 'auto hand-drawn logo design',
      'auto luxury logo design', 'auto masculine logo design', 'auto minimalist logo design', 'auto modern logo design',
      'auto organic logo design', 'auto professional logo design', 'auto retro logo design', 'auto simple logo design',
      'auto unique logo design', 'auto versatile logo design', 'auto vintage logo design'
    ]
  },
  {
    id: 'food-beverage',
    name: 'Food & Beverage',
    description: 'Restaurant, cafe, and food service logos',
    color: 'bg-orange-500',
    keywords: [
      'bakery logo design', 'cafe logo design', 'coffee shop logo design', 'restaurant logo design',
      'food logo design', 'organic logo design', 'fresh food logo design', 'gourmet logo design',
      'bistro logo design', 'pizzeria logo design', 'sandwich shop logo design', 'ice cream logo design',
      'brewery logo design', 'winery logo design', 'juice bar logo design', 'smoothie logo design',
      'catering logo design', 'food truck logo design', 'farm to table logo design', 'healthy food logo design'
    ]
  },
  {
    id: 'beauty-fashion',
    name: 'Beauty & Fashion',
    description: 'Beauty, fashion, and lifestyle brand logos',
    color: 'bg-pink-500',
    keywords: [
      'beauty logo design', 'fashion logo design', 'boutique logo design', 'salon logo design',
      'spa logo design', 'cosmetics logo design', 'barber logo design', 'clothing logo design',
      'jewelry logo design', 'makeup logo design', 'skincare logo design', 'haircare logo design',
      'nail salon logo design', 'wedding logo design', 'bridal logo design', 'luxury fashion logo design'
    ]
  },
  {
    id: 'business-finance',
    name: 'Business & Finance',
    description: 'Corporate, finance, and professional services',
    color: 'bg-blue-600',
    keywords: [
      'bank logo design', 'finance logo design', 'insurance logo design', 'law firm logo design',
      'consulting logo design', 'accounting logo design', 'real estate logo design', 'investment logo design',
      'corporate logo design', 'business logo design', 'professional logo design', 'financial advisor logo design',
      'cryptocurrency logo design', 'fintech logo design', 'startup logo design', 'enterprise logo design'
    ]
  },
  {
    id: 'health-medical',
    name: 'Health & Medical',
    description: 'Healthcare, medical, and wellness logos',
    color: 'bg-teal-500',
    keywords: [
      'clinic logo design', 'medical logo design', 'healthcare logo design', 'hospital logo design',
      'dental logo design', 'pharmacy logo design', 'veterinary logo design', 'wellness logo design',
      'fitness logo design', 'gym logo design', 'yoga logo design', 'therapy logo design',
      'chiropractic logo design', 'nutrition logo design', 'mental health logo design', 'elder care logo design'
    ]
  },
  {
    id: 'education',
    name: 'Education',
    description: 'Schools, universities, and educational services',
    color: 'bg-indigo-500',
    keywords: [
      'school logo design', 'education logo design', 'university logo design', 'college logo design',
      'academy logo design', 'training logo design', 'tutoring logo design', 'online learning logo design',
      'e-learning logo design', 'library logo design', 'bookstore logo design', 'publishing logo design',
      'research logo design', 'scientific logo design', 'academic logo design', 'student logo design'
    ]
  },
  {
    id: 'technology',
    name: 'Technology',
    description: 'Tech, software, and digital services',
    color: 'bg-cyan-500',
    keywords: [
      'technology logo design', 'software logo design', 'tech startup logo design', 'IT logo design',
      'digital logo design', 'web design logo design', 'app development logo design', 'cloud logo design',
      'cybersecurity logo design', 'AI logo design', 'robotics logo design', 'blockchain logo design',
      'data analytics logo design', 'gaming logo design', 'esports logo design', 'streaming logo design'
    ]
  },
  {
    id: 'nonprofit',
    name: 'Non-Profit',
    description: 'Charity, NGO, and community organizations',
    color: 'bg-green-600',
    keywords: [
      'nonprofit logo design', 'charity logo design', 'church logo design', 'community logo design',
      'foundation logo design', 'volunteer logo design', 'social cause logo design', 'humanitarian logo design',
      'environmental logo design', 'conservation logo design', 'animal rescue logo design', 'food bank logo design',
      'homeless shelter logo design', 'youth program logo design', 'senior center logo design', 'disability support logo design'
    ]
  },
  {
    id: 'entertainment',
    name: 'Entertainment',
    description: 'Music, events, and entertainment industry',
    color: 'bg-yellow-500',
    keywords: [
      'music logo design', 'event logo design', 'entertainment logo design', 'concert logo design',
      'festival logo design', 'band logo design', 'artist logo design', 'record label logo design',
      'nightclub logo design', 'theater logo design', 'comedy logo design', 'dance logo design',
      'photography logo design', 'videography logo design', 'film production logo design', 'podcast logo design'
    ]
  }
];

// Generate sample keyword data with realistic metrics
export const generateKeywordData = (): Keyword[] => {
  const keywords: Keyword[] = [];
  let keywordId = 1;

  keywordCategories.forEach(category => {
    category.keywords.forEach(keyword => {
      keywords.push({
        id: keywordId.toString(),
        keyword: keyword,
        category: category.id,
        searchVolume: Math.floor(Math.random() * 10000) + 100,
        difficulty: Math.floor(Math.random() * 100) + 1,
        ctr: Math.random() * 5 + 0.5,
        currentRanking: Math.random() > 0.6 ? Math.floor(Math.random() * 100) + 1 : null,
        targetUrl: `https://wedesign.com/${category.id}/${keyword.toLowerCase().replace(/\s+/g, '-')}`,
        lastUpdated: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString(),
        trend: ['up', 'down', 'stable'][Math.floor(Math.random() * 3)] as 'up' | 'down' | 'stable'
      });
      keywordId++;
    });
  });

  return keywords;
};

// Sample page optimization data
export interface PageOptimization {
  id: string;
  url: string;
  title: string;
  metaDescription: string;
  h1: string;
  h2Count: number;
  h3Count: number;
  keywordCount: number;
  status: 'optimized' | 'needs-attention' | 'poor';
  schemaType: 'Article' | 'Product' | 'Organization' | 'Service';
  lastOptimized: string;
  targetKeywords: string[];
}

export const samplePageOptimizations: PageOptimization[] = [
  {
    id: '1',
    url: 'https://wedesign.com/',
    title: 'WeDesign - Professional Logo Design Services | Custom Brand Identity',
    metaDescription: 'Create stunning custom logos with WeDesign. Professional logo design services for businesses worldwide. Get your unique brand identity today.',
    h1: 'Professional Logo Design Services',
    h2Count: 4,
    h3Count: 8,
    keywordCount: 12,
    status: 'optimized',
    schemaType: 'Organization',
    lastOptimized: '2024-01-20T10:30:00Z',
    targetKeywords: ['logo design', 'custom logo design', 'professional logo design']
  },
  {
    id: '2',
    url: 'https://wedesign.com/logos-design',
    title: 'Custom Logo Design Services | WeDesign Portfolio',
    metaDescription: 'Explore our custom logo design portfolio. Professional designers creating unique brand identities for businesses across all industries.',
    h1: 'Custom Logo Design Portfolio',
    h2Count: 3,
    h3Count: 6,
    keywordCount: 8,
    status: 'needs-attention',
    schemaType: 'Service',
    lastOptimized: '2024-01-18T14:20:00Z',
    targetKeywords: ['custom logo design', 'logo portfolio', 'brand identity design']
  },
  {
    id: '3',
    url: 'https://wedesign.com/blog',
    title: 'Logo Design Blog | Design Tips & Inspiration | WeDesign',
    metaDescription: 'Get the latest logo design tips, trends, and inspiration from our expert designers. Learn about brand identity and visual design.',
    h1: 'Design Insights & Tips',
    h2Count: 2,
    h3Count: 4,
    keywordCount: 5,
    status: 'poor',
    schemaType: 'Article',
    lastOptimized: '2024-01-15T09:15:00Z',
    targetKeywords: ['logo design tips', 'design blog', 'brand inspiration']
  }
];

// SEO settings data
export interface SEOSettings {
  sitemapUrl: string;
  robotsTxt: string;
  canonicalUrls: { [key: string]: string };
  redirects: { from: string; to: string; type: '301' | '302' }[];
  analytics: {
    googleAnalyticsId: string;
    googleSearchConsole: string;
    bingWebmaster: string;
  };
}

export const defaultSEOSettings: SEOSettings = {
  sitemapUrl: 'https://wedesign.com/sitemap.xml',
  robotsTxt: `User-agent: *
Allow: /
Disallow: /admin/
Disallow: /api/

Sitemap: https://wedesign.com/sitemap.xml`,
  canonicalUrls: {
    '/': 'https://wedesign.com/',
    '/logos-design': 'https://wedesign.com/logos-design',
    '/design-hall': 'https://wedesign.com/design-hall',
    '/about-us': 'https://wedesign.com/about-us',
    '/blog': 'https://wedesign.com/blog'
  },
  redirects: [
    { from: '/old-logo-design', to: '/logos-design', type: '301' },
    { from: '/portfolio', to: '/design-hall', type: '301' },
    { from: '/contact', to: '/about-us', type: '302' }
  ],
  analytics: {
    googleAnalyticsId: 'GA-XXXXX-X',
    googleSearchConsole: 'verified',
    bingWebmaster: 'verified'
  }
};