// WeDesign Vite 项目结构验证脚本
const fs = require('fs');
const path = require('path');

console.log('🔍 WeDesign Vite 项目结构验证');
console.log('===================================');

// 验证必需的文件结构
const requiredStructure = {
  'index.html': 'HTML 入口文件',
  'src/main.tsx': 'JavaScript 入口点',
  'src/App.tsx': 'React 主组件',
  'src/styles/globals.css': '全局样式文件',
  'package.json': '项目配置文件',
  'vite.config.ts': 'Vite 配置文件',
  'vercel.json': 'Vercel 部署配置',
  '.env.example': '环境变量模板'
};

console.log('\n📁 文件结构验证:');
let structureValid = true;

Object.entries(requiredStructure).forEach(([filePath, description]) => {
  const fullPath = path.join(__dirname, filePath);
  const exists = fs.existsSync(fullPath);
  
  console.log(`${exists ? '✅' : '❌'} ${filePath} - ${description}`);
  
  if (!exists) {
    structureValid = false;
  }
});

// 验证 src 目录结构
console.log('\n📂 src 目录结构验证:');
const srcDirectories = [
  'src/components',
  'src/utils', 
  'src/types',
  'src/supabase',
  'src/styles'
];

srcDirectories.forEach(dir => {
  const dirPath = path.join(__dirname, dir);
  const exists = fs.existsSync(dirPath);
  console.log(`${exists ? '✅' : '❌'} ${dir}/`);
  
  if (!exists) {
    structureValid = false;
  }
});

// 验证 index.html 内容
console.log('\n🌐 index.html 验证:');
const indexPath = path.join(__dirname, 'index.html');
if (fs.existsSync(indexPath)) {
  const indexContent = fs.readFileSync(indexPath, 'utf8');
  
  const checks = [
    { check: indexContent.includes('<div id="root">'), message: 'React root 元素' },
    { check: indexContent.includes('/src/main.tsx'), message: 'main.tsx 入口脚本' },
    { check: indexContent.includes('WeDesign'), message: '页面标题' },
    { check: indexContent.includes('viewport'), message: '响应式 viewport' },
    { check: indexContent.includes('og:'), message: 'Open Graph 标签' }
  ];
  
  checks.forEach(({ check, message }) => {
    console.log(`${check ? '✅' : '❌'} ${message}`);
    if (!check) structureValid = false;
  });
}

// 验证 main.tsx 内容
console.log('\n⚡ main.tsx 验证:');
const mainPath = path.join(__dirname, 'src/main.tsx');
if (fs.existsSync(mainPath)) {
  const mainContent = fs.readFileSync(mainPath, 'utf8');
  
  const checks = [
    { check: mainContent.includes('import React'), message: 'React 导入' },
    { check: mainContent.includes('import ReactDOM'), message: 'ReactDOM 导入' },
    { check: mainContent.includes('import App'), message: 'App 组件导入' },
    { check: mainContent.includes('globals.css'), message: '全局样式导入' },
    { check: mainContent.includes('createRoot'), message: 'React 18 createRoot' }
  ];
  
  checks.forEach(({ check, message }) => {
    console.log(`${check ? '✅' : '❌'} ${message}`);
    if (!check) structureValid = false;
  });
}

// 验证 App.tsx 内容
console.log('\n🎯 App.tsx 验证:');
const appPath = path.join(__dirname, 'src/App.tsx');
if (fs.existsSync(appPath)) {
  const appContent = fs.readFileSync(appPath, 'utf8');
  
  const checks = [
    { check: appContent.includes('export default function App'), message: '默认导出函数' },
    { check: appContent.includes('./components/'), message: '相对路径导入' },
    { check: appContent.includes('useState'), message: 'React Hooks' },
    { check: appContent.includes('useEffect'), message: 'Effect Hook' }
  ];
  
  checks.forEach(({ check, message }) => {
    console.log(`${check ? '✅' : '❌'} ${message}`);
    if (!check) structureValid = false;
  });
}

// 验证 vite.config.ts
console.log('\n⚙️  vite.config.ts 验证:');
const viteConfigPath = path.join(__dirname, 'vite.config.ts');
if (fs.existsSync(viteConfigPath)) {
  const viteContent = fs.readFileSync(viteConfigPath, 'utf8');
  
  const checks = [
    { check: viteContent.includes("'./src'"), message: 'src 目录别名配置' },
    { check: viteContent.includes('@vitejs/plugin-react'), message: 'React 插件' },
    { check: viteContent.includes('outDir: \'dist\''), message: '构建输出目录' },
    { check: viteContent.includes('manualChunks'), message: '代码分割配置' }
  ];
  
  checks.forEach(({ check, message }) => {
    console.log(`${check ? '✅' : '❌'} ${message}`);
    if (!check) structureValid = false;
  });
}

// 验证 package.json 脚本
console.log('\n📦 package.json 脚本验证:');
const packagePath = path.join(__dirname, 'package.json');
if (fs.existsSync(packagePath)) {
  const packageContent = JSON.parse(fs.readFileSync(packagePath, 'utf8'));
  const scripts = packageContent.scripts || {};
  
  const requiredScripts = {
    'dev': 'vite',
    'build': 'vite build',
    'preview': 'vite preview'
  };
  
  Object.entries(requiredScripts).forEach(([script, command]) => {
    const hasScript = scripts[script] && scripts[script].includes(command);
    console.log(`${hasScript ? '✅' : '❌'} ${script}: ${scripts[script] || '缺失'}`);
    if (!hasScript) structureValid = false;
  });
}

// 最终结果
console.log('\n📊 验证结果:');
console.log('=================');

if (structureValid) {
  console.log('🎉 Vite 项目结构验证通过！');
  console.log('');
  console.log('✅ 所有必需文件都存在');
  console.log('✅ 文件内容配置正确');
  console.log('✅ 导入路径结构正确');
  console.log('✅ 构建配置完整');
  
  console.log('\n🚀 现在可以运行以下命令:');
  console.log('');
  console.log('# 安装依赖');
  console.log('npm install');
  console.log('');
  console.log('# 开发模式');
  console.log('npm run dev');
  console.log('');
  console.log('# 构建生产版本');
  console.log('npm run build');
  console.log('');
  console.log('# 预览构建结果');
  console.log('npm run preview');
  
  console.log('\n🌐 部署到 ChatGPT:');
  console.log('项目现在采用标准 Vite 结构，可以直接在 ChatGPT 中自动部署');
  
} else {
  console.log('❌ Vite 项目结构验证失败');
  console.log('');
  console.log('请先修复上述标记为 ❌ 的问题，然后重新运行验证。');
  console.log('');
  console.log('🔧 修复建议:');
  console.log('1. 确保所有必需文件都存在');
  console.log('2. 运行项目结构重组脚本: node restructure-to-src.js');
  console.log('3. 检查文件内容是否正确');
  console.log('4. 验证导入路径是否匹配新的 src 结构');
}

console.log('\nWeDesign Vite 结构验证完成！');