#!/usr/bin/env node

const fs = require('fs');
const path = require('path');

console.log('🗑️  删除 Wix Studio 相关内容');
console.log('================================\n');

// 要删除的 Wix 相关文件
const wixFilesToRemove = [
  'WIX_STUDIO_EXPORT_GUIDE.md',
  'VISUAL_EXPORT_LOCATION_GUIDE.md',
  'FIGMA_MAKE_EXPORT_GUIDE.md'
];

let removedCount = 0;

// 删除 Wix 相关文件
console.log('📁 删除 Wix 相关文件：');
wixFilesToRemove.forEach(file => {
  const filePath = path.join(process.cwd(), file);
  if (fs.existsSync(filePath)) {
    try {
      fs.unlinkSync(filePath);
      console.log(`✅ 已删除: ${file}`);
      removedCount++;
    } catch (error) {
      console.log(`❌ 删除失败 ${file}: ${error.message}`);
    }
  } else {
    console.log(`⚠️  文件不存在: ${file}`);
  }
});

// 清理 Guidelines.md 中的 Wix Studio 内容
console.log('\n📝 清理 Guidelines.md 文件：');
const guidelinesPath = path.join(process.cwd(), 'Guidelines.md');
if (fs.existsSync(guidelinesPath)) {
  try {
    let content = fs.readFileSync(guidelinesPath, 'utf8');
    
    // 删除 Wix Studio Compatibility 整个部分
    const wixSectionRegex = /## Wix Studio Compatibility[\s\S]*?(?=(?:##|$))/g;
    const updatedContent = content.replace(wixSectionRegex, '');
    
    // 删除任何剩余的 wix 或 Wix 相关引用
    const cleanedContent = updatedContent
      .replace(/\* \*\*Export Readiness\*\*:.*wix.*\n/gi, '')
      .replace(/\* \*\*Wix Studio.*\n/gi, '')
      .replace(/- Clean hierarchy for Wix export.*\n/gi, '')
      .replace(/- Wix Studio ready structure.*\n/gi, '')
      .replace(/.*wix.*export.*\n/gi, '')
      .replace(/.*Wix.*export.*\n/gi, '');
    
    fs.writeFileSync(guidelinesPath, cleanedContent, 'utf8');
    console.log('✅ 已清理 Guidelines.md 中的 Wix Studio 内容');
    removedCount++;
  } catch (error) {
    console.log(`❌ 清理 Guidelines.md 失败: ${error.message}`);
  }
} else {
  console.log('⚠️  Guidelines.md 文件不存在');
}

// 检查并清理其他文件中的 Wix 引用
console.log('\n🔍 检查其他文件中的 Wix 引用：');

const filesToCheck = [
  'README.md',
  'EXPORT_CHECKLIST.md',
  'EXPORT_EXECUTION_GUIDE.md',
  'EXPORT_READY_REPORT.md',
  'PREPARATION_CHECKLIST.md'
];

filesToCheck.forEach(file => {
  const filePath = path.join(process.cwd(), file);
  if (fs.existsSync(filePath)) {
    try {
      let content = fs.readFileSync(filePath, 'utf8');
      const originalContent = content;
      
      // 删除包含 Wix 的行
      content = content
        .split('\n')
        .filter(line => !line.toLowerCase().includes('wix'))
        .join('\n');
      
      if (content !== originalContent) {
        fs.writeFileSync(filePath, content, 'utf8');
        console.log(`✅ 已清理 ${file} 中的 Wix 引用`);
        removedCount++;
      } else {
        console.log(`✓ ${file} 中没有找到 Wix 引用`);
      }
    } catch (error) {
      console.log(`❌ 检查 ${file} 失败: ${error.message}`);
    }
  }
});

// 检查组件文件中是否有 Wix 相关内容
console.log('\n🧩 检查组件文件：');
const componentsDir = path.join(process.cwd(), 'components');
if (fs.existsSync(componentsDir)) {
  const checkDirectory = (dir) => {
    const files = fs.readdirSync(dir);
    files.forEach(file => {
      const filePath = path.join(dir, file);
      const stat = fs.lstatSync(filePath);
      
      if (stat.isDirectory()) {
        checkDirectory(filePath);
      } else if (file.endsWith('.tsx') || file.endsWith('.ts')) {
        try {
          const content = fs.readFileSync(filePath, 'utf8');
          if (content.toLowerCase().includes('wix')) {
            console.log(`⚠️  发现 Wix 引用: ${path.relative(process.cwd(), filePath)}`);
            // 可以在这里添加自动清理逻辑，或者只是报告
          }
        } catch (error) {
          // 忽略读取错误
        }
      }
    });
  };
  
  checkDirectory(componentsDir);
  console.log('✅ 组件文件检查完成');
}

console.log('\n' + '='.repeat(50));
console.log('📊 Wix 清理完成');
console.log('='.repeat(50));

console.log(`🎉 成功处理了 ${removedCount} 个文件/内容！`);
console.log('\n✅ 已删除的内容：');
console.log('   • WIX_STUDIO_EXPORT_GUIDE.md');
console.log('   • Guidelines.md 中的 Wix Studio Compatibility 部分');
console.log('   • 其他文件中的 Wix 相关引用');

console.log('\n📁 您的项目现在完全独立于 Wix Studio');
console.log('🚀 专注于独立的 React 应用程序部署');

console.log('\n📝 下一步：');
console.log('1. 运行 node 项目清理脚本.js 删除其他冗余文件');
console.log('2. 按照 项目部署指南.md 进行 GitHub + Vercel 部署');
console.log('3. 配置 Supabase 和 Stripe 环境变量');