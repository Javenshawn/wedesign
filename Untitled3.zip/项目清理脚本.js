#!/usr/bin/env node

const fs = require('fs');
const path = require('path');

console.log('🧹 WeDesign 项目清理 - GitHub 部署准备\n');

// 要删除的文件和目录
const filesToRemove = [
  // 所有冗余指南文件
  'API_KEYS_CHECKLIST.md',
  'COMPLETE_SUPABASE_SETUP_GUIDE.md',
  'CONFIGURE_YOUR_SUPABASE_PROJECT.md',
  'CONTINUE_STRIPE_AND_DEPLOYMENT.md',
  'CREATE_SUPABASE_PROJECT_FOR_WEDESIGN.md',
  'DEPLOYMENT_EXECUTION_GUIDE.md',
  'DOMAIN_BINDING_GUIDE.md',
  'EXPORT_CHECKLIST.md',
  'EXPORT_EXECUTION_GUIDE.md',
  'EXPORT_READY_REPORT.md',
  'FIGMA_MAKE_EXPORT_GUIDE.md',
  'GODADDY_DOMAIN_BINDING_GUIDE.md',
  'PREPARATION_CHECKLIST.md',
  'QUICK_CONFIG_TEST.md',
  'START_DOMAIN_BINDING_NOW.md',
  'STEP_1_GET_API_KEYS_DETAILED.md',
  'STEP_2_GET_STRIPE_KEYS_DETAILED.md',
  'STRIPE_ACTUAL_CONSOLE_API_KEY_GUIDE.md',
  'STRIPE_COMPLETE_SETUP_GUIDE.md',
  'STRIPE_CONFIG_VERIFICATION.md',
  'STRIPE_CORRECT_KEYS_GUIDE.md',
  'STRIPE_FINAL_VERIFICATION.md',
  'STRIPE_KEYS_CONFIGURATION_GUIDE.md',
  'STRIPE_KEYS_SETUP_GUIDE.md',
  'STRIPE_KEY_FORMAT_VALIDATOR.md',
  'STRIPE_LIVE_KEY_CONFIGURATION_GUIDE.md',
  'STRIPE_LIVE_VERIFICATION_CHECKLIST.md',
  'STRIPE_MODE_SWITCHER_DETAILED_LOCATION_GUIDE.md',
  'STRIPE_MODE_SWITCHER_VISUAL_CHECKLIST.md',
  'STRIPE_PUBLISHABLE_KEY_STEP_BY_STEP_GUIDE.md',
  'STRIPE_QUICK_TEST_GUIDE.md',
  'STRIPE_SANDBOX_MODE_LOCATION_GUIDE.md',
  'STRIPE_SANDBOX_QUICK_CHECKLIST.md',
  'STRIPE_SCREENSHOT_SPECIFIC_GUIDE.md',
  'STRIPE_VISUAL_NAVIGATION_GUIDE.md',
  'STRUCTURE_AUDIT_REPORT.md',
  'SUPABASE_ACCOUNT_VERIFICATION_AND_SETUP.md',
  'SUPABASE_PROJECT_CREATION_CHECKLIST.md',
  'UPDATE_SUPABASE_CONFIG.md',
  'VERCEL_CONSOLE_SPECIFIC_GUIDE.md',
  'VERCEL_DEPLOYMENT_EXECUTION.md',
  'VERCEL_DEPLOYMENT_GUIDE.md',
  'VERCEL_VISUAL_NEXT_JS_SELECTION.md',
  'VISUAL_EXPORT_LOCATION_GUIDE.md',
  'WEBSITE_MODIFICATION_GUIDE.md',
  'WIX_STUDIO_EXPORT_GUIDE.md',
  
  // 中文文件
  '管理员后台访问指南.md',
  '网站修改指南.md',
  
  // Wix Studio 相关文件
  'WIX_STUDIO_EXPORT_GUIDE.md',
  'VISUAL_EXPORT_LOCATION_GUIDE.md',
  'FIGMA_MAKE_EXPORT_GUIDE.md',
  
  // 未使用的组件文件
  'components/PluginCard.tsx',
  'components/PluginFilters.tsx',
  'components/PluginManager.tsx',
  'components/TestModalPage.tsx',
  'components/pages/PluginsPage.tsx',
  'components/pages/UXAuditBoard.tsx',
  'types/plugin.ts',
  
  // Next.js 配置（Vite 项目不需要）
  'next.config.js',
];

let removedCount = 0;

// 删除文件
filesToRemove.forEach(file => {
  const filePath = path.join(process.cwd(), file);
  if (fs.existsSync(filePath)) {
    try {
      if (fs.lstatSync(filePath).isDirectory()) {
        fs.rmSync(filePath, { recursive: true, force: true });
      } else {
        fs.unlinkSync(filePath);
      }
      console.log(`✅ 已删除: ${file}`);
      removedCount++;
    } catch (error) {
      console.log(`❌ 删除失败 ${file}: ${error.message}`);
    }
  }
});

console.log(`\n🎉 清理完成！删除了 ${removedCount} 个文件。`);
console.log('\n📁 干净的项目结构已准备好部署！');
console.log('\n📝 下一步：');
console.log('1. 查看剩余文件');
console.log('2. 按照 GitHub 部署指南操作');
console.log('3. 提交并推送到 GitHub');
console.log('4. 部署到 Vercel');