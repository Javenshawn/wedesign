#!/usr/bin/env node

const fs = require('fs');
const path = require('path');

console.log('🔍 WeDesign 部署就绪检查\n');

let allGood = true;
let warnings = 0;

function checkFile(filePath, description, critical = true) {
  const exists = fs.existsSync(path.join(process.cwd(), filePath));
  if (exists) {
    console.log(`✅ ${description}`);
    return true;
  } else {
    if (critical) {
      console.log(`❌ ${description} - 缺失（关键）`);
      allGood = false;
    } else {
      console.log(`⚠️  ${description} - 缺失（可选）`);
      warnings++;
    }
    return false;
  }
}

function checkPackageJson() {
  console.log('\n📦 Package.json 验证：');
  try {
    const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));
    
    // 检查脚本
    if (pkg.scripts?.build) {
      console.log('✅ 构建脚本已找到');
    } else {
      console.log('❌ 构建脚本缺失');
      allGood = false;
    }
    
    if (pkg.scripts?.dev) {
      console.log('✅ 开发脚本已找到');
    } else {
      console.log('❌ 开发脚本缺失'); 
      allGood = false;
    }
    
    // 检查关键依赖
    const requiredDeps = [
      'react',
      'react-dom', 
      'typescript',
      '@supabase/supabase-js',
      '@stripe/stripe-js'
    ];
    
    console.log('\n📋 关键依赖：');
    requiredDeps.forEach(dep => {
      if (pkg.dependencies?.[dep] || pkg.devDependencies?.[dep]) {
        console.log(`✅ ${dep}`);
      } else {
        console.log(`❌ ${dep} - 缺失`);
        allGood = false;
      }
    });
    
  } catch (error) {
    console.log('❌ 无法读取 package.json');
    allGood = false;
  }
}

function checkEnvironment() {
  console.log('\n🔐 环境配置：');
  checkFile('.env.example', '环境模板存在');
  
  // 检查 .env 文件是否正确被忽略
  if (fs.existsSync('.gitignore')) {
    const gitignore = fs.readFileSync('.gitignore', 'utf8');
    if (gitignore.includes('.env')) {
      console.log('✅ .env 文件在 .gitignore 中');
    } else {
      console.log('⚠️  .env 文件应添加到 .gitignore');
      warnings++;
    }
  }
}

function checkUnwantedFiles() {
  console.log('\n🧹 检查应删除的文件：');
  
  const shouldBeRemoved = [
    'STRIPE_COMPLETE_SETUP_GUIDE.md',
    'SUPABASE_PROJECT_CREATION_CHECKLIST.md',
    'API_KEYS_CHECKLIST.md',
    '管理员后台访问指南.md',
    'next.config.js'
  ];
  
  let foundUnwanted = 0;
  shouldBeRemoved.forEach(file => {
    if (fs.existsSync(file)) {
      console.log(`⚠️  发现应删除的文件：${file}`);
      foundUnwanted++;
    }
  });
  
  if (foundUnwanted === 0) {
    console.log('✅ 未发现不需要的文件 - 项目干净');
  } else {
    console.log(`⚠️  发现 ${foundUnwanted} 个应删除的文件`);
    console.log('💡 运行：node 项目清理脚本.js');
    warnings++;
  }
}

// 运行所有检查
console.log('🔍 开始 WeDesign 部署就绪检查...\n');

// 必要文件检查
console.log('📁 必要文件验证：');
checkFile('App.tsx', '主应用组件');
checkFile('vite.config.ts', 'Vite 配置');
checkFile('vercel.json', 'Vercel 部署配置');
checkFile('styles/globals.css', '全局样式');
checkFile('.gitignore', '.gitignore 文件');
checkFile('README.md', 'README 文档');

// 组件结构
console.log('\n🧩 组件结构：');
checkFile('components/layout/Header.tsx', 'Header 组件');
checkFile('components/layout/Footer.tsx', 'Footer 组件');
checkFile('components/pages/HomePage.tsx', 'HomePage 组件');
checkFile('utils/supabase/client.ts', 'Supabase 客户端');
checkFile('utils/stripe-client.ts', 'Stripe 客户端');

// Package.json 检查
checkPackageJson();

// 环境检查
checkEnvironment();

// 不需要的文件检查
checkUnwantedFiles();

// 最终评估
console.log('\n' + '='.repeat(50));
console.log('📊 部署就绪评估');
console.log('='.repeat(50));

if (allGood && warnings === 0) {
  console.log('🎉 太棒了！您的项目已准备好部署。');
  console.log('\n📝 下一步：');
  console.log('1. 按照 项目部署指南.md 操作');
  console.log('2. 设置 GitHub 仓库');
  console.log('3. 使用环境变量部署到 Vercel');
  console.log('4. 配置 Supabase 和 Stripe 设置');
} else if (allGood && warnings > 0) {
  console.log('✅ 不错！您的项目已准备好部署。');
  console.log(`⚠️  有 ${warnings} 个警告应该处理以获得最佳设置。`);
  console.log('\n📝 您可以继续部署。');
} else {
  console.log('🚨 尚未准备好！部署前必须修复关键问题。');
  console.log('\n🔧 请先修复上述关键问题。');
}

if (warnings > 0) {
  console.log('\n💡 要修复警告，考虑运行：node 项目清理脚本.js');
}

console.log('\n📖 详细部署说明请参阅：项目部署指南.md');