import { useState } from 'react';
import { Modal_StartProject } from './modals/StartProjectModal';
import { WeDesignButton } from './design-system/WeDesignButton';
import { Play, Package, FileText, CreditCard } from 'lucide-react';

export function TestModalPage() {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleSubmitProject = (data: any) => {
    console.log('✅ Project Data Submitted:', data);
    
    // Display submitted data in a nice format
    alert(`Project Submitted Successfully!
    
Package: ${data.package.name} (${data.package.price})
Logo Name: ${data.form.logoName}
Industry: ${data.form.industry}
Styles: ${data.form.preferredStyles.join(', ')}
Colors: ${data.form.colorPreferences}
Description: ${data.form.description.substring(0, 100)}...
Files: ${data.form.referenceFiles.length} file(s) uploaded
    `);
  };

  const modalFeatures = [
    {
      icon: <Package className="w-5 h-5" />,
      title: 'Package Selection',
      description: 'Choose from Economy, Business, or Private Jet packages',
      color: 'bg-blue-500'
    },
    {
      icon: <FileText className="w-5 h-5" />,
      title: 'Design Brief Form',
      description: 'Complete project details and requirements',
      color: 'bg-green-500'
    },
    {
      icon: <CreditCard className="w-5 h-5" />,
      title: 'Payment Integration',
      description: 'Seamless transition to payment processing',
      color: 'bg-purple-500'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-bg-light-ivory to-muted/20 p-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="mb-4">Start Project Modal Test</h1>
          <p className="text-lg text-muted-foreground mb-8">
            Test the complete "Start Your Project" modal flow with package selection and design brief form.
          </p>
          
          <WeDesignButton
            variant="primary-gold"
            size="lg"
            onClick={() => setIsModalOpen(true)}
            className="px-8 py-4"
          >
            <Play className="w-5 h-5 mr-2" />
            Open Start Project Modal
          </WeDesignButton>
        </div>

        {/* Feature Overview */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {modalFeatures.map((feature, index) => (
            <div key={index} className="bg-white rounded-2xl p-6 shadow-luxury">
              <div className={`w-12 h-12 ${feature.color} rounded-xl flex items-center justify-center text-white mb-4`}>
                {feature.icon}
              </div>
              <h3 className="mb-2">{feature.title}</h3>
              <p className="text-muted-foreground">{feature.description}</p>
            </div>
          ))}
        </div>

        {/* Test Instructions */}
        <div className="bg-white rounded-2xl p-8 shadow-luxury">
          <h3 className="mb-4">Test Instructions</h3>
          <div className="space-y-4 text-muted-foreground">
            <div className="flex items-start gap-3">
              <div className="w-6 h-6 bg-accent-terra text-white rounded-full flex items-center justify-center text-sm font-bold mt-0.5">1</div>
              <div>
                <strong>Step 1:</strong> Click "Open Start Project Modal" to launch the modal
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-6 h-6 bg-accent-terra text-white rounded-full flex items-center justify-center text-sm font-bold mt-0.5">2</div>
              <div>
                <strong>Package Selection:</strong> Choose from Economy ($199), Business ($399), or Private Jet ($999) packages
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-6 h-6 bg-accent-terra text-white rounded-full flex items-center justify-center text-sm font-bold mt-0.5">3</div>
              <div>
                <strong>Design Brief:</strong> Fill out the project details form with logo name, industry, styles, and description
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-6 h-6 bg-accent-terra text-white rounded-full flex items-center justify-center text-sm font-bold mt-0.5">4</div>
              <div>
                <strong>Submit:</strong> Complete the form and submit to see the collected data in console/alert
              </div>
            </div>
          </div>
        </div>

        {/* Design System Notes */}
        <div className="mt-8 bg-gradient-to-r from-accent-terra/10 to-accent-gold-end/10 border border-accent-terra/20 rounded-2xl p-6">
          <h4 className="font-semibold text-accent-terra mb-2">WeDesign Styling Applied</h4>
          <ul className="text-sm text-muted-foreground space-y-1">
            <li>• Ivory background (#F7F5EE) with gold gradient accents</li>
            <li>• Merriweather font for headings, Inter for body text</li>
            <li>• Luxury shadows with gold glow effects</li>
            <li>• Responsive design: desktop/tablet/mobile optimized</li>
            <li>• Smooth animations and transitions</li>
          </ul>
        </div>
      </div>

      {/* Start Project Modal */}
      <Modal_StartProject
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSubmit={handleSubmitProject}
      />
    </div>
  );
}