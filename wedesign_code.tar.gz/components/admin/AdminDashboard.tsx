import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Users, ShoppingCart, CreditCard, MessageSquare, FileText, TrendingUp,
  AlertCircle, CheckCircle, Clock, DollarSign, Eye, Settings, LogOut,
  Bell, Search, Filter, Calendar, Download, Plus, BarChart3, PieChart
} from 'lucide-react';
import { WeDesignButton } from '../design-system/WeDesignButton';
import { Card } from '../ui/card';
import { Badge } from '../ui/badge';
import { Input } from '../ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { AdminSidebar } from './AdminSidebar';
import { AdminHeader } from './AdminHeader';

interface DashboardStats {
  customers: { total: number; change: number; trend: 'up' | 'down' };
  orders: { total: number; change: number; trend: 'up' | 'down' };
  revenue: { total: number; change: number; trend: 'up' | 'down' };
  tickets: { total: number; change: number; trend: 'up' | 'down' };
}

interface AdminDashboardProps {
  onNavigate: (page: string) => void;
}

export function AdminDashboard({ onNavigate }: AdminDashboardProps) {
  const [currentUser] = useState({ name: 'Sarah Chen', role: 'Super Admin', avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop' });
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [timeFilter, setTimeFilter] = useState('7d');
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState<DashboardStats>({
    customers: { total: 2847, change: 12.3, trend: 'up' },
    orders: { total: 1234, change: 8.7, trend: 'up' },
    revenue: { total: 89750, change: -2.1, trend: 'down' },
    tickets: { total: 43, change: -15.6, trend: 'down' }
  });

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => setLoading(false), 1500);
    return () => clearTimeout(timer);
  }, []);

  const recentActivities = [
    { id: 1, type: 'order', title: 'New logo order', customer: 'TechStart Inc.', time: '2 min ago', status: 'new' },
    { id: 2, type: 'ticket', title: 'Support ticket opened', customer: 'Green Garden Cafe', time: '15 min ago', status: 'pending' },
    { id: 3, type: 'payment', title: 'Payment received', customer: 'Urban Fashion', time: '1 hour ago', status: 'completed' },
    { id: 4, type: 'customer', title: 'New customer registered', customer: 'MedCare Clinic', time: '2 hours ago', status: 'active' }
  ];

  const pendingTasks = [
    { id: 1, title: 'Review logo designs for TechStart Inc.', priority: 'high', due: 'Today 3:00 PM' },
    { id: 2, title: 'Process refund for cancelled order', priority: 'medium', due: 'Tomorrow 10:00 AM' },
    { id: 3, title: 'Update payment gateway settings', priority: 'low', due: 'This week' },
    { id: 4, title: 'Monthly report generation', priority: 'medium', due: 'Dec 31' }
  ];

  const StatCard = ({ title, value, change, trend, icon: Icon, loading: cardLoading }: any) => (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ scale: 1.02 }}
      className="glass-card rounded-2xl p-6 hover:shadow-luxury-lg transition-all duration-300"
    >
      {cardLoading ? (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="w-12 h-12 bg-muted/30 rounded-xl animate-pulse"></div>
            <div className="w-8 h-4 bg-muted/30 rounded animate-pulse"></div>
          </div>
          <div className="w-20 h-8 bg-muted/30 rounded animate-pulse"></div>
          <div className="w-24 h-4 bg-muted/30 rounded animate-pulse"></div>
        </div>
      ) : (
        <>
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 gradient-gold rounded-xl flex items-center justify-center shadow-gold">
              <Icon className="w-6 h-6 text-white" />
            </div>
            <Badge className={`${trend === 'up' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'} border-0`}>
              {trend === 'up' ? '+' : ''}{change}%
            </Badge>
          </div>
          <h3 className="text-2xl font-bold text-ink-deep-brown mb-1">
            {title === 'Revenue' ? `$${value.toLocaleString()}` : value.toLocaleString()}
          </h3>
          <p className="text-ink-soft-brown text-sm">{title}</p>
        </>
      )}
    </motion.div>
  );

  if (loading) {
    return (
      <div className="Page_AdminDashboard min-h-screen bg-gradient-to-br from-bg-light-ivory to-bg-light-ivory/50">
        <div className="flex items-center justify-center min-h-screen">
          <div className="text-center">
            <div className="w-16 h-16 gradient-gold rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-gold animate-pulse">
              <BarChart3 className="w-8 h-8 text-white" />
            </div>
            <p className="text-ink-soft-brown">Loading admin dashboard...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="Page_AdminDashboard min-h-screen bg-gradient-to-br from-bg-light-ivory to-bg-light-ivory/50">
      {/* Layout Container */}
      <div className="flex h-screen">
        {/* Sidebar */}
        <AdminSidebar 
          collapsed={sidebarCollapsed}
          onToggle={() => setSidebarCollapsed(!sidebarCollapsed)}
          currentPage="dashboard"
          onNavigate={onNavigate}
        />

        {/* Main Content */}
        <div className={`flex-1 flex flex-col overflow-hidden transition-all duration-300 ${sidebarCollapsed ? 'ml-20' : 'ml-80'}`}>
          {/* Header */}
          <AdminHeader 
            user={currentUser}
            onNavigate={onNavigate}
          />

          {/* Content Area */}
          <main className="flex-1 overflow-y-auto p-6 space-y-6">
            {/* Page Title & Actions */}
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
              <div>
                <h1 className="text-3xl font-heading font-bold text-gradient-gold-rich mb-2">
                  Dashboard Overview
                </h1>
                <p className="text-ink-soft-brown">
                  Monitor your business performance and manage operations
                </p>
              </div>
              
              <div className="flex items-center gap-3">
                <Select value={timeFilter} onValueChange={setTimeFilter}>
                  <SelectTrigger className="w-32 glass-effect border-0">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="glass-modal">
                    <SelectItem value="24h">Last 24h</SelectItem>
                    <SelectItem value="7d">Last 7 days</SelectItem>
                    <SelectItem value="30d">Last 30 days</SelectItem>
                    <SelectItem value="90d">Last 90 days</SelectItem>
                  </SelectContent>
                </Select>
                
                <WeDesignButton variant="secondary-outline" size="sm">
                  <Download className="w-4 h-4 mr-2" />
                  Export Report
                </WeDesignButton>
              </div>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <StatCard
                title="Total Customers"
                value={stats.customers.total}
                change={stats.customers.change}
                trend={stats.customers.trend}
                icon={Users}
                loading={false}
              />
              <StatCard
                title="Active Orders"
                value={stats.orders.total}
                change={stats.orders.change}
                trend={stats.orders.trend}
                icon={ShoppingCart}
                loading={false}
              />
              <StatCard
                title="Revenue"
                value={stats.revenue.total}
                change={stats.revenue.change}
                trend={stats.revenue.trend}
                icon={DollarSign}
                loading={false}
              />
              <StatCard
                title="Open Tickets"
                value={stats.tickets.total}
                change={stats.tickets.change}
                trend={stats.tickets.trend}
                icon={MessageSquare}
                loading={false}
              />
            </div>

            {/* Main Content Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Recent Activity */}
              <div className="lg:col-span-2">
                <div className="glass-card rounded-2xl p-6">
                  <h3 className="text-xl font-heading font-semibold text-ink-deep-brown mb-6">
                    Recent Activity
                  </h3>
                  <div className="space-y-4">
                    {recentActivities.map((activity, index) => (
                      <motion.div
                        key={activity.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.1 }}
                        className="flex items-center gap-4 p-4 glass-effect rounded-xl hover:shadow-glass transition-all"
                      >
                        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                          activity.type === 'order' ? 'bg-blue-100 text-blue-600' :
                          activity.type === 'ticket' ? 'bg-orange-100 text-orange-600' :
                          activity.type === 'payment' ? 'bg-green-100 text-green-600' :
                          'bg-purple-100 text-purple-600'
                        }`}>
                          {activity.type === 'order' && <ShoppingCart className="w-5 h-5" />}
                          {activity.type === 'ticket' && <MessageSquare className="w-5 h-5" />}
                          {activity.type === 'payment' && <CreditCard className="w-5 h-5" />}
                          {activity.type === 'customer' && <Users className="w-5 h-5" />}
                        </div>
                        <div className="flex-1">
                          <p className="font-medium text-ink-deep-brown">{activity.title}</p>
                          <p className="text-sm text-ink-soft-brown">{activity.customer}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm text-ink-soft-brown">{activity.time}</p>
                          <Badge className={`${
                            activity.status === 'completed' ? 'bg-green-100 text-green-800' :
                            activity.status === 'pending' ? 'bg-orange-100 text-orange-800' :
                            activity.status === 'new' ? 'bg-blue-100 text-blue-800' :
                            'bg-gray-100 text-gray-800'
                          } border-0 text-xs`}>
                            {activity.status}
                          </Badge>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Pending Tasks */}
              <div>
                <div className="glass-card rounded-2xl p-6">
                  <h3 className="text-xl font-heading font-semibold text-ink-deep-brown mb-6">
                    Pending Tasks
                  </h3>
                  <div className="space-y-3">
                    {pendingTasks.map((task, index) => (
                      <motion.div
                        key={task.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.1 }}
                        className="p-4 glass-effect rounded-xl hover:shadow-glass transition-all cursor-pointer"
                      >
                        <div className="flex items-start gap-3">
                          <div className={`w-2 h-2 rounded-full mt-2 ${
                            task.priority === 'high' ? 'bg-red-500' :
                            task.priority === 'medium' ? 'bg-orange-500' :
                            'bg-green-500'
                          }`}></div>
                          <div className="flex-1">
                            <p className="font-medium text-ink-deep-brown text-sm mb-1">
                              {task.title}
                            </p>
                            <p className="text-xs text-ink-soft-brown flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              {task.due}
                            </p>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                  
                  <WeDesignButton 
                    variant="secondary-outline" 
                    size="sm" 
                    className="w-full mt-4"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Task
                  </WeDesignButton>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="glass-card rounded-2xl p-6">
              <h3 className="text-xl font-heading font-semibold text-ink-deep-brown mb-6">
                Quick Actions
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                {[
                  { label: 'Add Customer', icon: Users, page: 'admin-customers' },
                  { label: 'New Order', icon: Plus, page: 'admin-orders' },
                  { label: 'Create Ticket', icon: MessageSquare, page: 'admin-tickets' },
                  { label: 'Blog Post', icon: FileText, page: 'admin-blog' },
                  { label: 'View Reports', icon: BarChart3, page: 'admin-reports' },
                  { label: 'Settings', icon: Settings, page: 'admin-settings' }
                ].map((action, index) => (
                  <motion.button
                    key={action.label}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: index * 0.05 }}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => onNavigate(action.page)}
                    className="p-4 glass-effect rounded-xl hover:shadow-glass transition-all text-center group"
                  >
                    <action.icon className="w-6 h-6 text-accent-terra mx-auto mb-2 group-hover:text-accent-gold-rich transition-colors" />
                    <p className="text-sm font-medium text-ink-deep-brown">{action.label}</p>
                  </motion.button>
                ))}
              </div>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
}