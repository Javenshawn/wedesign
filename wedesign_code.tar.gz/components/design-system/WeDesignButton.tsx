import { Button } from "../ui/button";
import { cn } from "../ui/utils";
import { ReactNode } from "react";

interface WeDesignButtonProps {
  variant: "primary-gold" | "secondary-outline" | "tertiary";
  size?: "sm" | "md" | "lg";
  children: ReactNode;
  onClick?: () => void;
  className?: string;
  disabled?: boolean;
  type?: "button" | "submit" | "reset";
}

export function WeDesignButton({ 
  variant, 
  size = "md", 
  children, 
  onClick, 
  className,
  disabled = false,
  type = "button"
}: WeDesignButtonProps) {
  const variants = {
    "primary-gold": "gradient-gold text-white hover:scale-105 shadow-gold hover:shadow-gold-lg border-0 font-medium",
    "secondary-outline": "glass-card border-2 border-accent-terra/30 text-accent-terra bg-glass-white hover:bg-glass-white-strong hover:border-accent-terra hover:scale-105 hover:shadow-glass font-medium",
    "tertiary": "text-accent-terra bg-transparent hover:bg-glass-white/50 border-0 shadow-none hover:shadow-glass font-medium"
  };

  const sizes = {
    sm: "px-4 py-2 text-sm min-h-[36px] rounded-lg touch-target",
    md: "px-6 py-3 text-base min-h-[44px] rounded-xl touch-target",
    lg: "px-8 py-4 text-lg min-h-[48px] rounded-xl touch-target"
  };

  return (
    <Button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={cn(
        "transition-all duration-300 backdrop-blur-16 font-body",
        variants[variant],
        sizes[size],
        disabled && "opacity-50 cursor-not-allowed hover:scale-100 hover:shadow-none",
        className
      )}
    >
      {children}
    </Button>
  );
}