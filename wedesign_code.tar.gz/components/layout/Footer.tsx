import weDesignLogo from '@/assets/placeholder.png';
// Replaced Figma asset import with a local placeholder image to avoid build errors.
import { Facebook, Instagram, Linkedin, Twitter, Mail, Phone, MapPin } from 'lucide-react';

interface FooterProps {
  onNavigate: (page: string) => void;
}

export function Footer({ onNavigate }: FooterProps) {
  const footerSections = [
    {
      title: "Services",
      links: [
        { label: "Logo Design", page: "logos-design" },
        { label: "Brand Identity", page: "logos-design" },
        { label: "Design Consultation", page: "about-us" },
        { label: "Rush Orders", page: "logos-design" }
      ]
    },
    {
      title: "Company", 
      links: [
        { label: "About Us", page: "about-us" },
        { label: "Design Hall", page: "design-hall" },
        { label: "Blog", page: "blog" },
        { label: "Careers", page: "about-us" }
      ]
    },
    {
      title: "Support",
      links: [
        { label: "Help Center", page: "about-us" },
        { label: "Contact Us", page: "about-us" },
        { label: "Privacy Policy", page: "about-us" },
        { label: "Terms of Service", page: "about-us" }
      ]
    }
  ];

  const socialLinks = [
    { platform: 'Facebook', url: '#', icon: Facebook, color: 'hover:text-blue-600' },
    { platform: 'Instagram', url: '#', icon: Instagram, color: 'hover:text-pink-600' },
    { platform: 'LinkedIn', url: '#', icon: Linkedin, color: 'hover:text-blue-700' },
    { platform: 'Twitter', url: '#', icon: Twitter, color: 'hover:text-blue-500' }
  ];

  return (
    <footer className="Footer_Global border-t border-glass-border glass-navigation">
      <div className="Container_Footer max-w-7xl mx-auto responsive-padding">
        
        {/* Main Footer Content */}
        <div className="Container_FooterMain py-8 md:py-16">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 md:gap-12">
            
            {/* Brand Section */}
            <div className="Container_Brand md:col-span-2 lg:col-span-2">
              <div className="mb-6">
                <img 
                  src={weDesignLogo} 
                  alt="WeDesign - Worldwide Design, Well Delivered" 
                  className="Image_FooterLogo h-10 sm:h-12 w-auto mb-4"
                />
                <p className="Text_BrandDescription text-ink-soft-brown leading-relaxed max-w-md text-sm sm:text-base">
                  Professional logo design services that help businesses build memorable brand identities. 
                  Get stunning designs from expert designers in 24-72 hours.
                </p>
              </div>
              
              {/* Contact Info */}
              <div className="Container_ContactInfo space-y-3">
                <div className="flex items-center gap-3 text-sm text-muted-foreground">
                  <div className="glass-card p-2 rounded-lg">
                    <Mail className="w-4 h-4 text-accent-terra" />
                  </div>
                  <span>hello@wedesign.com</span>
                </div>
                <div className="flex items-center gap-3 text-sm text-muted-foreground">
                  <div className="glass-card p-2 rounded-lg">
                    <Phone className="w-4 h-4 text-accent-terra" />
                  </div>
                  <span>+1 (555) 123-4567</span>
                </div>
                <div className="flex items-center gap-3 text-sm text-muted-foreground">
                  <div className="glass-card p-2 rounded-lg">
                    <MapPin className="w-4 h-4 text-accent-terra" />
                  </div>
                  <span>New York, United States</span>
                </div>
              </div>
            </div>

            {/* Navigation Links */}
            {footerSections.map((section, index) => (
              <div key={index} className="Container_FooterSection">
                <h3 className="Text_SectionTitle font-semibold text-ink-deep-brown mb-6">
                  {section.title}
                </h3>
                <ul className="List_FooterLinks space-y-4">
                  {section.links.map((link, linkIndex) => (
                    <li key={linkIndex}>
                      <button
                        onClick={() => onNavigate(link.page)}
                        className="touch-target Link_Footer text-muted-foreground hover:text-accent-terra transition-colors duration-300 text-sm p-2 -m-2 min-h-[44px] flex items-center"
                      >
                        {link.label}
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        {/* Newsletter Section */}
        <div className="Container_Newsletter py-8 md:py-12 border-t border-glass-border">
          <div className="glass-card rounded-2xl p-6 md:p-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8 items-center">
              <div className="text-center md:text-left">
                <h3 className="Text_NewsletterTitle text-lg md:text-xl font-semibold text-ink-deep-brown mb-2">
                  Stay Updated
                </h3>
                <p className="Text_NewsletterDescription text-muted-foreground text-sm md:text-base">
                  Get design tips, industry insights, and exclusive offers delivered to your inbox.
                </p>
              </div>
              <div className="Container_NewsletterForm">
                <div className="flex flex-col sm:flex-row gap-3">
                  <input
                    type="email"
                    placeholder="Enter your email"
                    className="Input_Newsletter input-glass flex-1 px-4 py-4 sm:py-3 rounded-xl text-sm min-h-[48px] sm:min-h-[44px]"
                  />
                  <button className="touch-target Button_Subscribe button-glass-primary px-6 py-4 sm:py-3 rounded-xl text-sm font-medium text-white hover:scale-105 transition-transform duration-300 min-h-[48px] sm:min-h-[44px] whitespace-nowrap">
                    Subscribe
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Footer */}
        <div className="Container_FooterBottom py-8 border-t border-glass-border">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            
            {/* Copyright */}
            <div className="Text_Copyright text-sm text-muted-foreground text-center md:text-left">
              © 2024 WeDesign. All rights reserved. Designed with ❤️ for amazing brands.
            </div>

            {/* Social Links */}
            <div className="Container_SocialLinks flex items-center gap-3">
              {socialLinks.map((social) => {
                const IconComponent = social.icon;
                return (
                  <a
                    key={social.platform}
                    href={social.url}
                    className={`Social_Link glass-card w-10 h-10 rounded-xl flex items-center justify-center text-muted-foreground hover:scale-110 transition-all duration-300 ${social.color}`}
                    aria-label={social.platform}
                  >
                    <IconComponent className="w-4 h-4" />
                  </a>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}