import { useState, useEffect } from 'react';
import { X, ArrowLeft, Upload, Check, Star, CreditCard } from 'lucide-react';
import { WeDesignButton } from '../design-system/WeDesignButton';
import { StripePaymentForm } from '../payment/StripePaymentForm';

interface StartProjectModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit?: (data: any) => void;
  selectedPackage?: {
    id?: string;
    name: string;
    price: string;
    priceValue?: number;
    tagline?: string;
    features?: string[];
    isPopular?: boolean;
  } | null;
}

interface PackageData {
  id: string;
  name: string;
  price: string;
  priceValue: number;
  tagline: string;
  features: string[];
  isPopular?: boolean;
}

interface FormData {
  logoName: string;
  industry: string;
  preferredStyles: string[];
  colorPreferences: string;
  description: string;
  referenceFiles: File[];
}

const packages: PackageData[] = [
  {
    id: 'economy',
    name: 'Economy Class',
    price: '$199',
    priceValue: 199,
    tagline: "Entrepreneur's weapon, always full of surprises",
    features: [
      '3 Logo design concepts',
      '2 revision rounds',
      'High-resolution files (PNG, JPG)',
      'Basic brand guidelines',
      '72-hour delivery',
      'Email support'
    ]
  },
  {
    id: 'business',
    name: 'Business Class',
    price: '$399',
    priceValue: 399,
    tagline: 'Expert assistance, essential for market entry',
    isPopular: true,
    features: [
      '5 Logo design concepts',
      'Unlimited revisions',
      'Complete file package',
      'Comprehensive brand guidelines',
      'Social media suite',
      'Business card design',
      '48-hour delivery',
      'Priority support'
    ]
  },
  {
    id: 'private',
    name: 'Private Jet',
    price: '$999',
    priceValue: 999,
    tagline: 'Heritage branding, absolute guarantee',
    features: [
      'Unlimited logo design concepts',
      'Unlimited revisions',
      'Premium file package',
      'Complete brand identity system',
      'Stationery design suite',
      'Marketing materials package',
      'Website design mockups',
      '24-hour delivery',
      'Dedicated account manager',
      '1-year brand support'
    ]
  }
];

const industries = [
  'Technology', 'Healthcare', 'Finance', 'Retail', 'Education',
  'Real Estate', 'Food & Beverage', 'Fashion', 'Automotive',
  'Entertainment', 'Non-profit', 'Other'
];

const designStyles = [
  'Modern Minimalist', 'Classic Traditional', 'Creative Artistic',
  'Corporate Professional', 'Playful Fun', 'Luxury Premium',
  'Tech Digital', 'Handcrafted Organic'
];

const colorPreferences = [
  'Warm & Energetic (Red, Orange, Yellow)',
  'Cool & Professional (Blue, Green, Purple)', 
  'Calm & Trustworthy (Blues and Whites)',
  'Natural & Organic (Earth Tones, Greens)',
  'Bold & Vibrant (High Contrast Colors)',
  'Elegant & Sophisticated (Black, Gold, Silver)',
  'Fresh & Modern (Bright, Clean Colors)',
  'Creative & Artistic (Rainbow, Multi-color)',
  'Minimal & Monochrome (Single Color, B&W)',
  'Luxurious & Rich (Deep Jewel Tones)'
];

export function Modal_StartProject({ isOpen, onClose, onSubmit, selectedPackage }: StartProjectModalProps) {
  const [currentStep, setCurrentStep] = useState(1);
  const [internalSelectedPackage, setInternalSelectedPackage] = useState<PackageData | null>(null);
  const [formData, setFormData] = useState<FormData>({
    logoName: '',
    industry: '',
    preferredStyles: [],
    colorPreferences: '',
    description: '',
    referenceFiles: []
  });

  // Helper function to normalize package data
  const normalizePackage = (pkg: any): PackageData => {
    if (!pkg) return packages[0]; // fallback to first package

    // If it's already normalized, return as is
    if (pkg.id && pkg.priceValue && pkg.tagline && pkg.features) {
      return pkg as PackageData;
    }

    // Try to map package name to internal packages
    const foundPackage = packages.find(p => 
      p.name.toLowerCase().includes(pkg.name?.toLowerCase() || '') ||
      pkg.name?.toLowerCase().includes(p.name.toLowerCase()) ||
      pkg.type?.toLowerCase() === p.id
    );

    if (foundPackage) {
      return foundPackage;
    }

    // Create normalized package from provided data
    return {
      id: pkg.type || pkg.name?.toLowerCase().replace(/\s+/g, '-') || 'custom',
      name: pkg.name || 'Custom Package',
      price: pkg.price || '$399',
      priceValue: pkg.priceValue || parseInt(pkg.price?.replace(/\D/g, '') || '399'),
      tagline: pkg.tagline || 'Professional logo design package',
      features: pkg.features || [
        'Professional logo design',
        'High-resolution files',
        'Brand guidelines',
        'Professional support'
      ],
      isPopular: pkg.isPopular || false
    };
  };

  // Reset modal state when opened/closed
  useEffect(() => {
    if (isOpen) {
      // If a package is provided, skip to information collection (step 2)
      if (selectedPackage) {
        const normalizedPackage = normalizePackage(selectedPackage);
        setInternalSelectedPackage(normalizedPackage);
        setCurrentStep(2); // Skip package selection, go directly to form
      } else {
        setCurrentStep(1); // Start with package selection
        setInternalSelectedPackage(null);
      }
      
      // Reset form data
      setFormData({
        logoName: '',
        industry: '',
        preferredStyles: [],
        colorPreferences: '',
        description: '',
        referenceFiles: []
      });
    }
  }, [isOpen, selectedPackage]);

  const handlePackageSelect = (pkg: PackageData) => {
    setInternalSelectedPackage(pkg);
  };

  const handleContinueToForm = () => {
    if (internalSelectedPackage) {
      setCurrentStep(2);
    }
  };

  const handleBackToPackages = () => {
    // If we came from external package selection, close modal instead
    if (selectedPackage) {
      onClose();
    } else {
      setCurrentStep(1);
    }
  };

  const handleContinueToPayment = () => {
    const isFormValid = formData.logoName.trim() && formData.industry && formData.description.trim();
    if (isFormValid) {
      setCurrentStep(3);
    }
  };

  const handleBackToForm = () => {
    setCurrentStep(2);
  };

  const handleStyleToggle = (style: string) => {
    setFormData(prev => ({
      ...prev,
      preferredStyles: prev.preferredStyles.includes(style)
        ? prev.preferredStyles.filter(s => s !== style)
        : [...prev.preferredStyles, style]
    }));
  };

  const handleFileUpload = (files: FileList | null) => {
    if (files) {
      setFormData(prev => ({
        ...prev,
        referenceFiles: [...prev.referenceFiles, ...Array.from(files)]
      }));
    }
  };

  const handlePaymentSuccess = (paymentResult: any) => {
    const submitData = {
      package: internalSelectedPackage,
      form: formData,
      payment: paymentResult
    };
    
    onSubmit?.(submitData);
    onClose();
    
    // Redirect to payment success page
    setTimeout(() => {
      window.history.pushState({}, '', '/payment-success');
      window.dispatchEvent(new PopStateEvent('popstate'));
    }, 100);
  };

  const handlePaymentError = (error: string) => {
    console.error('Payment error:', error);
    // Can display error notification
  };

  const isFormValid = formData.logoName.trim() && formData.industry && formData.description.trim();

  if (!isOpen) return null;

  return (
    <div className="Modal_StartProject fixed inset-0 z-50 flex items-center justify-center">
      {/* Background Overlay */}
      <div 
        className="absolute inset-0 bg-black/40 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Modal Container */}
      <div className="relative w-full max-w-4xl mx-4 md:mx-6 bg-[#FAFAF8] rounded-2xl md:rounded-3xl shadow-2xl overflow-hidden max-h-[90vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 md:top-6 md:right-6 z-10 w-10 h-10 md:w-12 md:h-12 bg-white/80 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white transition-colors shadow-lg"
        >
          <X className="w-5 h-5 md:w-6 md:h-6 text-gray-700" />
        </button>

        {/* Step 1: Package Selection - Only show if no package was pre-selected */}
        {currentStep === 1 && !selectedPackage && (
          <div className="Step_SelectPackage p-6 md:p-8 lg:p-12">
            {/* Header */}
            <div className="text-center mb-6 md:mb-8">
              <h2 className="mb-4 text-2xl md:text-3xl font-bold text-gray-900">Choose Your Perfect Logo Package</h2>
              <p className="text-base md:text-lg text-gray-600">
                All packages include unlimited revisions and professional designer support.
              </p>
            </div>

            {/* Package Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6 mb-6 md:mb-8">
              {packages.map((pkg) => (
                <div
                  key={pkg.id}
                  className={`Card_Package_${pkg.name.replace(/\s/g, '')} relative backdrop-blur-xl bg-white/90 rounded-2xl p-6 border-2 transition-all cursor-pointer hover:shadow-xl ${
                    internalSelectedPackage?.id === pkg.id 
                      ? 'border-[#B6652E] shadow-xl ring-4 ring-[#B6652E]/20' 
                      : 'border-white/20 hover:border-[#B6652E]/50'
                  }`}
                  onClick={() => handlePackageSelect(pkg)}
                >
                  {/* Popular Badge */}
                  {pkg.isPopular && (
                    <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                      <div className="bg-gradient-to-r from-[#B6652E] to-[#FFB84D] text-white px-4 py-1 rounded-full text-sm font-medium flex items-center gap-1">
                        <Star className="w-3 h-3 fill-current" />
                        Most Popular
                      </div>
                    </div>
                  )}

                  {/* Selection Indicator */}
                  {internalSelectedPackage?.id === pkg.id && (
                    <div className="absolute top-4 right-4 w-6 h-6 bg-[#B6652E] rounded-full flex items-center justify-center">
                      <Check className="w-4 h-4 text-white" />
                    </div>
                  )}

                  {/* Package Content */}
                  <div className="text-center mb-6">
                    <h3 className="text-xl font-bold text-gray-900 mb-2">{pkg.name}</h3>
                    <p className="text-sm text-gray-600 mb-4">{pkg.tagline}</p>
                    <div className="text-4xl font-bold bg-gradient-to-r from-[#B6652E] to-[#FFB84D] bg-clip-text text-transparent mb-1">
                      {pkg.price}
                    </div>
                  </div>

                  {/* Features List */}
                  <div className="space-y-3 mb-6">
                    {pkg.features.map((feature, index) => (
                      <div key={index} className="flex items-start gap-3">
                        <div className="w-5 h-5 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                          <Check className="w-3 h-3 text-green-600" />
                        </div>
                        <span className="text-sm text-gray-600">{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            {/* Continue Button */}
            <div className="text-center">
              <WeDesignButton
                variant="primary-gold"
                size="lg"
                onClick={handleContinueToForm}
                disabled={!internalSelectedPackage}
                className="px-12 py-4"
              >
                Continue to Project Details
              </WeDesignButton>
            </div>
          </div>
        )}

        {/* Step 2: Design Brief Form */}
        {currentStep === 2 && internalSelectedPackage && (
          <div className="Step_DesignBriefForm p-6 md:p-8 lg:p-12">
            {/* Header with Package Summary */}
            <div className="mb-6 md:mb-8">
              <div className="flex items-center gap-3 md:gap-4 mb-4">
                <button
                  onClick={handleBackToPackages}
                  className="w-10 h-10 md:w-12 md:h-12 bg-white/80 rounded-full flex items-center justify-center hover:bg-white/90 transition-colors"
                >
                  <ArrowLeft className="w-5 h-5" />
                </button>
                <div className="min-w-0 flex-1">
                  <h2 className="text-xl md:text-2xl font-bold text-gray-900">Project Information</h2>
                  <p className="text-sm md:text-base text-gray-600 truncate">
                    Selected: {internalSelectedPackage.name} - {internalSelectedPackage.price}
                  </p>
                </div>
              </div>

              {/* Package Summary Card */}
              <div className="bg-white/50 p-4 rounded-lg border border-gray-200 mb-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-semibold text-gray-900">{internalSelectedPackage.name}</h4>
                    <p className="text-sm text-gray-600">{internalSelectedPackage.tagline}</p>
                  </div>
                  <div className="text-2xl font-bold bg-gradient-to-r from-[#B6652E] to-[#FFB84D] bg-clip-text text-transparent">
                    {internalSelectedPackage.price}
                  </div>
                </div>
              </div>
            </div>

            {/* Form Fields */}
            <div className="space-y-5 md:space-y-6">
              {/* Logo Name */}
              <div>
                <label className="block mb-2 text-sm md:text-base font-medium text-gray-700">Logo Name *</label>
                <input
                  type="text"
                  className="w-full px-4 py-3 md:py-4 bg-white/90 border border-gray-300 rounded-xl focus:ring-2 focus:ring-[#B6652E] focus:border-[#B6652E] transition-colors text-base"
                  placeholder="Enter your company or brand name"
                  value={formData.logoName}
                  onChange={(e) => setFormData(prev => ({ ...prev, logoName: e.target.value }))}
                />
              </div>

              {/* Industry */}
              <div>
                <label className="block mb-2 text-sm md:text-base font-medium text-gray-700">Industry *</label>
                <select
                  className="w-full px-4 py-3 md:py-4 bg-white/90 border border-gray-300 rounded-xl focus:ring-2 focus:ring-[#B6652E] focus:border-[#B6652E] transition-colors text-base"
                  value={formData.industry}
                  onChange={(e) => setFormData(prev => ({ ...prev, industry: e.target.value }))}
                >
                  <option value="">Select your industry</option>
                  {industries.map((industry) => (
                    <option key={industry} value={industry}>{industry}</option>
                  ))}
                </select>
              </div>

              {/* Preferred Styles */}
              <div>
                <label className="block mb-3 text-sm md:text-base font-medium text-gray-700">Preferred Design Styles</label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {designStyles.map((style) => (
                    <button
                      key={style}
                      type="button"
                      onClick={() => handleStyleToggle(style)}
                      className={`p-3 md:p-4 text-sm md:text-base rounded-xl border transition-all text-left ${
                        formData.preferredStyles.includes(style)
                          ? 'border-[#B6652E] bg-[#B6652E]/10 text-[#B6652E]'
                          : 'border-gray-300 hover:border-[#B6652E]/50'
                      }`}
                    >
                      {style}
                    </button>
                  ))}
                </div>
              </div>

              {/* Color Preferences */}
              <div>
                <label className="block mb-2 text-sm md:text-base font-medium text-gray-700">Color Preferences</label>
                <select
                  className="w-full px-4 py-3 md:py-4 bg-white/90 border border-gray-300 rounded-xl focus:ring-2 focus:ring-[#B6652E] focus:border-[#B6652E] transition-colors text-base"
                  value={formData.colorPreferences}
                  onChange={(e) => setFormData(prev => ({ ...prev, colorPreferences: e.target.value }))}
                >
                  <option value="">Select your color preference</option>
                  {colorPreferences.map((preference) => (
                    <option key={preference} value={preference}>{preference}</option>
                  ))}
                </select>
              </div>

              {/* Description */}
              <div>
                <label className="block mb-2 text-sm md:text-base font-medium text-gray-700">Design Description *</label>
                <textarea
                  className="w-full px-4 py-3 md:py-4 bg-white/90 border border-gray-300 rounded-xl focus:ring-2 focus:ring-[#B6652E] focus:border-[#B6652E] transition-colors min-h-[120px] md:min-h-[140px] resize-y text-base"
                  placeholder="Describe your brand, values, target audience, and any special requirements..."
                  value={formData.description}
                  onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                />
              </div>

              {/* File Upload */}
              <div>
                <label className="block mb-2 text-sm md:text-base font-medium text-gray-700">Reference Files (Optional)</label>
                <div className="border-2 border-dashed border-gray-300 rounded-xl p-4 md:p-6 text-center hover:border-[#B6652E]/50 transition-colors">
                  <input
                    type="file"
                    multiple
                    accept="image/*,.pdf"
                    onChange={(e) => handleFileUpload(e.target.files)}
                    className="hidden"
                    id="file-upload"
                  />
                  <label htmlFor="file-upload" className="cursor-pointer block py-4">
                    <Upload className="w-8 h-8 md:w-10 md:h-10 text-gray-400 mx-auto mb-3" />
                    <p className="text-gray-600 mb-1 text-sm md:text-base">Upload reference images or documents</p>
                    <p className="text-xs md:text-sm text-gray-500">PNG, JPG, PDF max 10MB each</p>
                  </label>
                  
                  {/* File List */}
                  {formData.referenceFiles.length > 0 && (
                    <div className="mt-4 space-y-2">
                      {formData.referenceFiles.map((file, index) => (
                        <div key={index} className="flex items-center justify-between bg-gray-50 rounded-lg p-3">
                          <span className="text-sm md:text-base truncate flex-1 mr-2">{file.name}</span>
                          <button
                            onClick={() => setFormData(prev => ({
                              ...prev,
                              referenceFiles: prev.referenceFiles.filter((_, i) => i !== index)
                            }))}
                            className="text-red-500 hover:text-red-700 p-1 flex-shrink-0"
                          >
                            <X className="w-4 h-4 md:w-5 md:h-5" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-3 md:gap-4 mt-6 md:mt-8 pt-4 border-t border-gray-200">
              <WeDesignButton
                variant="primary-gold"
                size="lg"
                onClick={handleContinueToPayment}
                disabled={!isFormValid}
                className="w-full text-base md:text-lg py-4 order-1"
              >
                <CreditCard className="w-5 h-5 mr-2" />
                Continue to Payment
              </WeDesignButton>

              <WeDesignButton
                variant="secondary-outline"
                size="md"
                onClick={handleBackToPackages}
                className="w-full order-2"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                {selectedPackage ? 'Back' : 'Back to Package Selection'}
              </WeDesignButton>
            </div>
          </div>
        )}

        {/* Step 3: Payment */}
        {currentStep === 3 && internalSelectedPackage && (
          <div className="Step_Payment p-6 md:p-8 lg:p-12">
            {/* Header */}
            <div className="mb-6 md:mb-8">
              <div className="flex items-center gap-3 md:gap-4 mb-4">
                <button
                  onClick={handleBackToForm}
                  className="w-10 h-10 md:w-12 md:h-12 bg-white/80 rounded-full flex items-center justify-center hover:bg-white/90 transition-colors"
                >
                  <ArrowLeft className="w-5 h-5" />
                </button>
                <div className="min-w-0 flex-1">
                  <h2 className="text-xl md:text-2xl font-bold text-gray-900">Secure Payment</h2>
                  <p className="text-sm md:text-base text-gray-600">
                    Complete payment to start your logo design project
                  </p>
                </div>
              </div>
            </div>

            {/* Payment Form */}
            <StripePaymentForm
              amount={internalSelectedPackage.priceValue}
              currency="USD"
              packageName={internalSelectedPackage.name}
              projectDetails={formData}
              onSuccess={handlePaymentSuccess}
              onError={handlePaymentError}
              onCancel={handleBackToForm}
            />
          </div>
        )}
      </div>
    </div>
  );
}