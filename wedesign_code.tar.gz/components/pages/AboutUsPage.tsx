import { ImageWithFallback } from '../figma/ImageWithFallback';
import { Award, Users, Globe, Sparkles } from 'lucide-react';

const teamMembers = [
  {
    id: '1',
    name: 'Sarah Chen',
    role: 'Creative Director',
    image: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=400&h=400&fit=crop&face',
    bio: '12+ years in brand design, former Apple design team member.'
  },
  {
    id: '2',
    name: 'Marcus Rodriguez',
    role: 'Senior Logo Designer',
    image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&face',
    bio: 'Award-winning designer specializing in minimalist and modern aesthetics.'
  },
  {
    id: '3',
    name: 'Emily Thompson',
    role: 'Brand Strategist',
    image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop&face',
    bio: 'Brand psychology expert helping businesses connect with their audience.'
  },
  {
    id: '4',
    name: 'David Kim',
    role: 'Digital Designer',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&face',
    bio: 'Specializes in digital-first brand identities and scalable design systems.'
  },
  {
    id: '5',
    name: 'Lisa Wang',
    role: 'Client Success Manager',
    image: 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=400&h=400&fit=crop&face',
    bio: 'Ensures every client receives exceptional service and perfect results.'
  },
  {
    id: '6',
    name: 'James Foster',
    role: 'Lead Illustrator',
    image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=400&fit=crop&face',
    bio: 'Creates custom illustrations and icons that bring brands to life.'
  }
];

const milestones = [
  {
    year: '2019',
    title: 'Founded',
    description: 'WeDesign was born from a passion to democratize professional design for businesses worldwide.'
  },
  {
    year: '2020',
    title: 'Global Expansion',
    description: 'Opened design studios in 3 countries, serving clients across 25+ nations.'
  },
  {
    year: '2021',
    title: '1000+ Logos',
    description: 'Celebrated delivering our 1000th logo design, marking a major milestone.'
  },
  {
    year: '2022',
    title: 'Award Recognition',
    description: 'Won "Best Design Agency" award and featured in major design publications.'
  },
  {
    year: '2023',
    title: 'AI Integration',
    description: 'Integrated AI tools to enhance our design process while maintaining human creativity.'
  },
  {
    year: '2024',
    title: '5000+ Happy Clients',
    description: 'Reached 5000+ satisfied clients with 98% customer satisfaction rate.'
  }
];

const stats = [
  {
    icon: <Award className="w-8 h-8" />,
    number: '5000+',
    label: 'Logos Created',
    color: 'text-blue-600'
  },
  {
    icon: <Users className="w-8 h-8" />,
    number: '50+',
    label: 'Team Members',
    color: 'text-green-600'
  },
  {
    icon: <Globe className="w-8 h-8" />,
    number: '40+',
    label: 'Countries Served',
    color: 'text-purple-600'
  },
  {
    icon: <Sparkles className="w-8 h-8" />,
    number: '98%',
    label: 'Satisfaction Rate',
    color: 'text-orange-600'
  }
];

export function Page_AboutUs() {
  return (
    <div className="Page_AboutUs">
      {/* Hero Section */}
      <section className="Section_Hero relative bg-gradient-to-b from-bg-light-ivory to-white py-20 overflow-hidden">
        <div className="absolute inset-0 opacity-5">
          <div className="absolute top-10 left-10 w-32 h-32 gradient-gold rounded-full blur-3xl"></div>
          <div className="absolute bottom-10 right-10 w-48 h-48 gradient-gold rounded-full blur-3xl"></div>
        </div>
        
        <div className="max-w-7xl mx-auto px-6 relative">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="text-center lg:text-left">
              <h1 className="font-heading text-3xl md:text-4xl lg:text-5xl font-extrabold text-gradient-gold-rich mb-6 tracking-tight text-center">
                About WeDesign
              </h1>
              <p className="font-body text-xl md:text-2xl text-ink-soft-brown mb-8 leading-relaxed text-center lg:text-left">
                We are a passionate team of designers, strategists, and creatives dedicated to 
                helping businesses worldwide build memorable brand identities through exceptional logo design.
              </p>
              <div className="flex items-center justify-center lg:justify-start gap-4 text-sm md:text-base text-gradient-gold font-semibold">
                <span>Worldwide Design</span>
                <span>•</span>
                <span>Best Delivered</span>
              </div>
            </div>
            
            <div className="relative">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=600&h=400&fit=crop"
                alt="WeDesign team collaboration"
                className="w-full h-80 object-cover rounded-2xl shadow-luxury-lg"
              />
              <div className="absolute -bottom-6 -left-6 bg-white p-4 rounded-xl shadow-luxury">
                <div className="text-2xl font-bold text-gradient-gold">2019</div>
                <div className="text-sm text-muted-foreground">Founded</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="Section_Stats py-16 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className={`${stat.color} mb-4 flex justify-center`}>
                  {stat.icon}
                </div>
                <div className="font-heading text-3xl font-bold text-gradient-gold-rich mb-2">{stat.number}</div>
                <div className="font-body text-sm text-ink-soft-brown">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="Section_Mission py-20 bg-muted/20">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            <div className="text-center">
              <div className="inline-block p-3 gradient-gold rounded-2xl mb-6">
                <Award className="w-8 h-8 text-white" />
              </div>
              <h2 className="font-heading text-2xl md:text-3xl font-bold text-gradient-gold mb-6 tracking-tight">Our Mission</h2>
              <p className="font-body text-lg md:text-xl text-ink-soft-brown leading-relaxed">
                To democratize professional logo design by making world-class creative services 
                accessible to businesses of all sizes, anywhere in the world. We believe every 
                business deserves a memorable visual identity that tells their unique story.
              </p>
            </div>

            <div className="text-center">
              <div className="inline-block p-3 gradient-gold rounded-2xl mb-6">
                <Globe className="w-8 h-8 text-white" />
              </div>
              <h2 className="font-heading text-2xl md:text-3xl font-bold text-gradient-gold mb-6 tracking-tight">Our Vision</h2>
              <p className="font-body text-lg md:text-xl text-ink-soft-brown leading-relaxed">
                To become the world's most trusted logo design partner, known for exceptional 
                creativity, lightning-fast delivery, and unmatched customer satisfaction. 
                We envision a world where great design drives business success.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="Section_Team py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="font-heading text-2xl md:text-3xl font-bold text-gradient-gold mb-6 tracking-tight">Meet Our Team</h2>
            <p className="font-body text-xl md:text-2xl text-ink-soft-brown max-w-3xl mx-auto leading-relaxed">
              Our diverse team of creative professionals brings together decades of experience 
              from top design agencies and brands around the world.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {teamMembers.map((member) => (
              <div key={member.id} className="TeamMember text-center group">
                <div className="relative mb-4 inline-block">
                  <ImageWithFallback
                    src={member.image}
                    alt={member.name}
                    className="w-32 h-32 object-cover rounded-full mx-auto group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-accent-terra/20 to-transparent rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </div>
                <h3 className="font-heading text-xl font-semibold text-ink-deep-brown mb-2">{member.name}</h3>
                <p className="font-body text-gradient-gold font-semibold mb-3">{member.role}</p>
                <p className="font-body text-sm text-ink-soft-brown px-4 leading-relaxed">{member.bio}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline Section */}
      <section className="Section_Timeline py-20 bg-gradient-to-b from-muted/20 to-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="font-heading text-2xl md:text-3xl font-bold text-gradient-gold mb-6 tracking-tight">Our Journey</h2>
            <p className="font-body text-xl md:text-2xl text-ink-soft-brown max-w-3xl mx-auto leading-relaxed">
              From a small design studio to a global creative agency, here's how we've grown 
              and evolved to better serve our clients worldwide.
            </p>
          </div>

          <div className="relative">
            {/* Timeline Line */}
            <div className="absolute left-1/2 transform -translate-x-1/2 w-1 gradient-gold h-full rounded-full hidden lg:block"></div>

            <div className="space-y-12">
              {milestones.map((milestone, index) => (
                <div key={milestone.year} className={`flex items-center ${index % 2 === 0 ? 'lg:flex-row' : 'lg:flex-row-reverse'}`}>
                  <div className={`flex-1 ${index % 2 === 0 ? 'lg:text-right lg:pr-12' : 'lg:text-left lg:pl-12'} text-center lg:text-${index % 2 === 0 ? 'right' : 'left'}`}>
                    <div className="bg-white p-6 rounded-2xl shadow-luxury">
                      <div className="text-2xl font-bold text-gradient-gold mb-2">{milestone.year}</div>
                      <h3 className="font-heading text-xl font-semibold text-ink-deep-brown mb-3">{milestone.title}</h3>
                      <p className="font-body text-ink-soft-brown leading-relaxed">{milestone.description}</p>
                    </div>
                  </div>

                  {/* Timeline Dot */}
                  <div className="relative z-10 hidden lg:block">
                    <div className="w-4 h-4 gradient-gold rounded-full border-4 border-white shadow-lg"></div>
                  </div>

                  <div className="flex-1"></div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}