import React, { useState, useEffect } from 'react';
import { ArrowLeft, CheckCircle, Shield, CreditCard, User, Package, FileText, AlertTriangle, ExternalLink } from 'lucide-react';
import { StripePaymentForm } from '../payment/StripePaymentForm';
import { WeDesignButton } from '../design-system/WeDesignButton';
import { getConfigurationStatus } from '../../utils/stripe-client';

interface CheckoutPageProps {
  onNavigate?: (page: string) => void;
  orderData?: {
    selectedPackage: {
      name: string;
      price: number;
    };
    projectInfo: {
      companyName: string;
      contactName: string;
      email: string;
      phone: string;
      projectType: string;
      industry: string;
      projectDescription: string;
      timeline: string;
      designStyle: string[];
      colorPreferences: string;
      inspiration: string;
      targetAudience: string;
      specialRequirements: string;
    };
    userCredentials?: {
      username: string;
      password: string;
    };
  };
}

export function Page_Checkout({ onNavigate, orderData }: CheckoutPageProps) {
  const [paymentStep, setPaymentStep] = useState<'review' | 'payment' | 'success'>('review');
  const [isCreatingAccount, setIsCreatingAccount] = useState(false);
  const [accountCreated, setAccountCreated] = useState(false);
  const [paymentResult, setPaymentResult] = useState<any>(null);
  const [configStatus, setConfigStatus] = useState<any>(null);

  // Check configuration status
  useEffect(() => {
    const status = getConfigurationStatus();
    setConfigStatus(status);
    console.log('Configuration status:', status);
  }, []);

  // 如果没有订单数据，重定向到首页
  useEffect(() => {
    if (!orderData?.selectedPackage || !orderData?.projectInfo) {
      onNavigate?.('home');
    }
  }, [orderData, onNavigate]);

  if (!orderData?.selectedPackage || !orderData?.projectInfo) {
    return null;
  }

  const { selectedPackage, projectInfo, userCredentials } = orderData;

  const handleCreateAccount = async () => {
    setIsCreatingAccount(true);
    
    try {
      // 模拟账户创建过程
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      console.log('账户创建成功:', {
        username: projectInfo.companyName,
        email: projectInfo.email,
        password: '888888'
      });
      
      setAccountCreated(true);
      setPaymentStep('payment');
    } catch (error) {
      console.error('账户创建失败:', error);
    } finally {
      setIsCreatingAccount(false);
    }
  };

  const handlePaymentSuccess = (result: any) => {
    setPaymentResult(result);
    setPaymentStep('success');
  };

  const handlePaymentError = (error: string) => {
    console.error('支付失败:', error);
    // 可以添加错误提示
  };

  const handlePaymentCancel = () => {
    setPaymentStep('review');
  };

  const renderReviewStep = () => (
    <div className="max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex items-center gap-4 mb-8">
        <button
          onClick={() => onNavigate?.('home')}
          className="flex items-center gap-2 px-4 py-2 glass-effect rounded-xl hover:glass-effect-strong transition-all duration-300"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back to Home</span>
        </button>
        
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 gradient-gold rounded-2xl flex items-center justify-center">
            <Package className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="font-heading text-2xl font-bold text-gradient-gold-rich">
              Order Review
            </h1>
            <p className="text-ink-soft-brown">
              Review your project details before payment
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Order Details - Left Column */}
        <div className="lg:col-span-2 space-y-6">
          {/* Package Summary */}
          <div className="glass-card rounded-2xl p-6">
            <h3 className="font-heading text-xl font-semibold text-ink-deep-brown mb-4 flex items-center gap-2">
              <Package className="w-5 h-5" />
              Selected Package
            </h3>
            <div className="flex justify-between items-center p-4 glass-effect rounded-xl">
              <div>
                <h4 className="font-semibold text-ink-deep-brown">{selectedPackage.name}</h4>
                <p className="text-ink-soft-brown text-sm">Professional logo design package</p>
              </div>
              <span className="font-heading text-2xl font-bold text-gradient-gold-rich">
                ${selectedPackage.price}
              </span>
            </div>
          </div>

          {/* Project Information */}
          <div className="glass-card rounded-2xl p-6">
            <h3 className="font-heading text-xl font-semibold text-ink-deep-brown mb-4 flex items-center gap-2">
              <FileText className="w-5 h-5" />
              Project Details
            </h3>
            
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="glass-effect rounded-xl p-4">
                  <h4 className="font-semibold text-ink-deep-brown mb-2">Company Information</h4>
                  <div className="space-y-1 text-sm">
                    <p><strong>Company:</strong> {projectInfo.companyName}</p>
                    <p><strong>Contact:</strong> {projectInfo.contactName}</p>
                    <p><strong>Email:</strong> {projectInfo.email}</p>
                    {projectInfo.phone && <p><strong>Phone:</strong> {projectInfo.phone}</p>}
                  </div>
                </div>

                <div className="glass-effect rounded-xl p-4">
                  <h4 className="font-semibold text-ink-deep-brown mb-2">Project Type</h4>
                  <div className="space-y-1 text-sm">
                    <p><strong>Type:</strong> {projectInfo.projectType}</p>
                    <p><strong>Industry:</strong> {projectInfo.industry}</p>
                    {projectInfo.timeline && <p><strong>Timeline:</strong> {projectInfo.timeline}</p>}
                  </div>
                </div>
              </div>

              <div className="glass-effect rounded-xl p-4">
                <h4 className="font-semibold text-ink-deep-brown mb-2">Design Preferences</h4>
                <div className="space-y-2 text-sm">
                  <p><strong>Styles:</strong> {projectInfo.designStyle.join(', ')}</p>
                  {projectInfo.colorPreferences && (
                    <p><strong>Colors:</strong> {projectInfo.colorPreferences}</p>
                  )}
                  {projectInfo.targetAudience && (
                    <p><strong>Target Audience:</strong> {projectInfo.targetAudience}</p>
                  )}
                </div>
              </div>

              {projectInfo.projectDescription && (
                <div className="glass-effect rounded-xl p-4">
                  <h4 className="font-semibold text-ink-deep-brown mb-2">Project Description</h4>
                  <p className="text-sm text-ink-soft-brown">{projectInfo.projectDescription}</p>
                </div>
              )}
            </div>
          </div>

          {/* Account Creation Section */}
          <div className="glass-card rounded-2xl p-6">
            <h3 className="font-heading text-xl font-semibold text-ink-deep-brown mb-4 flex items-center gap-2">
              <User className="w-5 h-5" />
              Account Setup
            </h3>
            
            {!accountCreated ? (
              <div className="space-y-4">
                <div className="glass-effect rounded-xl p-4">
                  <p className="text-ink-soft-brown mb-4">
                    We'll create a project management account for you with these credentials:
                  </p>
                  <div className="space-y-2 text-sm bg-glass-ivory rounded-lg p-3">
                    <p><strong>Username:</strong> {projectInfo.companyName}</p>
                    <p><strong>Email:</strong> {projectInfo.email}</p>
                    <p><strong>Initial Password:</strong> 888888</p>
                  </div>
                  <p className="text-xs text-ink-soft-brown mt-2">
                    You can change your password after first login.
                  </p>
                </div>
                
                <WeDesignButton
                  variant="secondary-outline"
                  onClick={handleCreateAccount}
                  disabled={isCreatingAccount}
                  className="w-full"
                >
                  {isCreatingAccount ? (
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-accent-terra border-t-transparent rounded-full animate-spin"></div>
                      Creating Account...
                    </div>
                  ) : (
                    'Create Account & Proceed to Payment'
                  )}
                </WeDesignButton>
              </div>
            ) : (
              <div className="flex items-center gap-3 p-4 bg-green-50 border border-green-200 rounded-xl">
                <CheckCircle className="w-6 h-6 text-green-600" />
                <div>
                  <p className="font-medium text-green-800">Account Created Successfully!</p>
                  <p className="text-sm text-green-600">You can now proceed to payment.</p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Order Summary - Right Sidebar */}
        <div className="space-y-6">
          <div className="glass-card rounded-2xl p-6 sticky top-6">
            <h3 className="font-heading text-xl font-semibold text-ink-deep-brown mb-4">Order Summary</h3>
            
            <div className="space-y-4">
              <div className="flex justify-between">
                <span className="text-ink-soft-brown">{selectedPackage.name} Package</span>
                <span className="font-semibold">${selectedPackage.price}</span>
              </div>
              
              <div className="flex justify-between">
                <span className="text-ink-soft-brown">Processing Fee</span>
                <span className="font-semibold">$0</span>
              </div>
              
              <div className="border-t border-glass-border pt-4">
                <div className="flex justify-between items-center">
                  <span className="font-heading text-lg font-bold text-ink-deep-brown">Total</span>
                  <span className="font-heading text-2xl font-bold text-gradient-gold-rich">
                    ${selectedPackage.price}
                  </span>
                </div>
              </div>
            </div>

            <div className="mt-6 p-4 glass-effect rounded-xl">
              <div className="flex items-start gap-2">
                <Shield className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-medium text-ink-deep-brown">100% Satisfaction Guarantee</p>
                  <p className="text-sm text-ink-soft-brown">
                    Unlimited revisions until you're completely satisfied.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderPaymentStep = () => (
    <div className="max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex items-center gap-4 mb-8">
        <button
          onClick={() => setPaymentStep('review')}
          className="flex items-center gap-2 px-4 py-2 glass-effect rounded-xl hover:glass-effect-strong transition-all duration-300"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back to Review</span>
        </button>
        
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 gradient-gold rounded-2xl flex items-center justify-center">
            <CreditCard className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="font-heading text-2xl font-bold text-gradient-gold-rich">
              Secure Payment
            </h1>
            <p className="text-ink-soft-brown">
              Complete your order with secure payment processing
            </p>
          </div>
        </div>
      </div>

      {/* Configuration Warning */}
      {configStatus && (!configStatus.stripe || (!configStatus.supabase && !configStatus.development)) && (
        <div className="max-w-3xl mx-auto mb-8">
          <div className="glass-card rounded-2xl p-6 border-l-4 border-yellow-500">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-6 h-6 text-yellow-600 flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <h3 className="font-heading text-lg font-semibold text-ink-deep-brown mb-2">
                  Payment System Configuration Needed
                </h3>
                <p className="text-ink-soft-brown mb-4">
                  The payment system requires additional configuration to process real payments. 
                  {configStatus?.development ? ' Currently running in development mode with payment simulation.' : ''}
                </p>
                
                <div className="space-y-2 mb-4">
                  {!configStatus?.stripe && (
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                      <span className="text-sm text-ink-soft-brown">Stripe not configured (VITE_STRIPE_PUBLISHABLE_KEY missing)</span>
                    </div>
                  )}
                  {!configStatus?.supabase && !configStatus?.development && (
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                      <span className="text-sm text-ink-soft-brown">Supabase backend not configured</span>
                    </div>
                  )}
                  {configStatus?.development && (
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                      <span className="text-sm text-ink-soft-brown">Development mode active - payments will be simulated</span>
                    </div>
                  )}
                </div>

                <div className="flex flex-col sm:flex-row gap-3">
                  <a
                    href="https://docs.stripe.com/keys"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 px-4 py-2 text-sm bg-blue-50 text-blue-700 rounded-lg hover:bg-blue-100 transition-colors"
                  >
                    <ExternalLink className="w-4 h-4" />
                    Stripe Setup Guide
                  </a>
                  <a
                    href="https://supabase.com/docs/guides/functions"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 px-4 py-2 text-sm bg-green-50 text-green-700 rounded-lg hover:bg-green-100 transition-colors"
                  >
                    <ExternalLink className="w-4 h-4" />
                    Supabase Functions Guide
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Payment Form */}
      <StripePaymentForm
        amount={selectedPackage.price * 100} // Stripe uses cents
        currency="usd"
        packageName={selectedPackage.name}
        projectDetails={{
          logoName: projectInfo.companyName,
          id: `proj_${Date.now()}`,
          ...projectInfo
        }}
        onSuccess={handlePaymentSuccess}
        onError={handlePaymentError}
        onCancel={handlePaymentCancel}
      />
    </div>
  );

  const renderSuccessStep = () => (
    <div className="max-w-3xl mx-auto text-center">
      <div className="glass-card rounded-3xl p-8">
        <div className="w-20 h-20 gradient-gold rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle className="w-10 h-10 text-white" />
        </div>
        
        <h1 className="font-heading text-3xl font-bold text-gradient-gold-rich mb-4">
          Payment Successful!
        </h1>
        
        <p className="text-ink-soft-brown text-lg mb-8">
          Your project has been created and our design team will start working on it shortly.
        </p>

        <div className="glass-effect rounded-2xl p-6 mb-8">
          <h3 className="font-heading text-xl font-semibold text-ink-deep-brown mb-4">
            What happens next?
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-left">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 gradient-gold rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-white font-bold text-sm">1</span>
              </div>
              <div>
                <h4 className="font-semibold text-ink-deep-brown mb-1">Project Setup</h4>
                <p className="text-sm text-ink-soft-brown">
                  We'll review your requirements and set up your project dashboard.
                </p>
              </div>
            </div>
            
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 gradient-gold rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-white font-bold text-sm">2</span>
              </div>
              <div>
                <h4 className="font-semibold text-ink-deep-brown mb-1">Design Process</h4>
                <p className="text-sm text-ink-soft-brown">
                  Our designers will start creating your logo concepts.
                </p>
              </div>
            </div>
            
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 gradient-gold rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-white font-bold text-sm">3</span>
              </div>
              <div>
                <h4 className="font-semibold text-ink-deep-brown mb-1">Delivery</h4>
                <p className="text-sm text-ink-soft-brown">
                  You'll receive your first concepts within 2-3 business days.
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="glass-effect rounded-2xl p-4 mb-8">
          <h4 className="font-semibold text-ink-deep-brown mb-2">Your Account Details</h4>
          <div className="text-sm space-y-1">
            <p><strong>Username:</strong> {projectInfo.companyName}</p>
            <p><strong>Email:</strong> {projectInfo.email}</p>
            <p><strong>Temporary Password:</strong> 888888</p>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-4">
          <WeDesignButton
            variant="secondary-outline"
            onClick={() => onNavigate?.('login')}
            className="flex-1"
          >
            Login to Dashboard
          </WeDesignButton>
          
          <WeDesignButton
            variant="primary-gold"
            onClick={() => onNavigate?.('home')}
            className="flex-1"
          >
            Return to Home
          </WeDesignButton>
        </div>
      </div>
    </div>
  );

  return (
    <div className="Page_Checkout min-h-screen bg-gradient-to-br from-bg-light-ivory to-[#F5F3ED] py-8 px-4">
      {paymentStep === 'review' && renderReviewStep()}
      {paymentStep === 'payment' && renderPaymentStep()}
      {paymentStep === 'success' && renderSuccessStep()}
    </div>
  );
}