import { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Play, ArrowRight, Users, Clock, CheckCircle, Package, FileText, CreditCard, Palette } from 'lucide-react';
import { WeDesignButton } from '../design-system/WeDesignButton';
import designStudioImage from '@/assets/placeholder.png';
import officeTeamImage from '@/assets/placeholder.png';
// Replaced Figma asset imports with local placeholder images to avoid build errors.

interface CompactCarouselSectionProps {
  onStartProject?: () => void;
  onViewWork?: () => void;
}

const processSteps = [
  {
    number: 1,
    title: 'Choose Package',
    description: 'Select your perfect design package',
    icon: <Package className="w-4 h-4" />,
    color: 'bg-orange-500'
  },
  {
    number: 2,
    title: 'Submit Brief',
    description: 'Share your brand vision with us',
    icon: <FileText className="w-4 h-4" />,
    color: 'bg-green-500'
  },
  {
    number: 3,
    title: 'Secure Payment',
    description: 'Complete payment safely',
    icon: <CreditCard className="w-4 h-4" />,
    color: 'bg-blue-500'
  },
  {
    number: 4,
    title: 'Design Delivery',
    description: 'Get your logo within 24-72h',
    icon: <Palette className="w-4 h-4" />,
    color: 'bg-purple-500'
  }
];

export function Section_Hero({ onStartProject, onViewWork }: CompactCarouselSectionProps) {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);
  const totalSlides = 2;

  // Auto-advance functionality
  useEffect(() => {
    if (!isAutoPlaying) return;

    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % totalSlides);
    }, 6000); // 6 seconds for faster transitions

    return () => clearInterval(interval);
  }, [isAutoPlaying, totalSlides]);

  const nextSlide = () => {
    setIsAutoPlaying(false);
    setCurrentSlide((prev) => (prev + 1) % totalSlides);
    setTimeout(() => setIsAutoPlaying(true), 8000);
  };

  const prevSlide = () => {
    setIsAutoPlaying(false);
    setCurrentSlide((prev) => (prev - 1 + totalSlides) % totalSlides);
    setTimeout(() => setIsAutoPlaying(true), 8000);
  };

  const goToSlide = (index: number) => {
    setIsAutoPlaying(false);
    setCurrentSlide(index);
    setTimeout(() => setIsAutoPlaying(true), 8000);
  };

  const renderIntroSlide = () => (
    <div className="Slide_IntroBranding relative flex items-center justify-center">
      {/* Main Content - Centered */}
      <div className="space-y-4 md:space-y-5 relative z-10 max-w-2xl mx-auto text-center">
        {/* Premium Badge */}
        <div className="inline-flex items-center gap-2 px-3 py-1.5 gradient-gold rounded-full text-white text-sm font-medium shadow-lg">
          <div className="w-1.5 h-1.5 bg-white rounded-full animate-pulse"></div>
          <span>Premium Logo Design</span>
        </div>

        {/* Heading */}
        <div className="space-y-2 md:space-y-3 text-center">
          <h2 className="text-xl sm:text-2xl md:text-3xl lg:text-4xl leading-tight text-white font-bold">
            Professional{' '}
            <span className="text-gradient-gold">Logo Design</span>{' '}
            <span className="block sm:inline">That Builds Brands</span>
          </h2>
          
          <p className="text-sm sm:text-base md:text-lg text-gray-200 leading-relaxed">
            Expert-crafted logos delivered in 24-72 hours with unlimited revisions.
          </p>
        </div>

        {/* Special Offer */}
        <div className="bg-gradient-to-r from-white/20 to-white/10 backdrop-blur-sm border border-white/30 rounded-xl p-3 max-w-md mx-auto">
          <div className="flex items-center justify-between gap-2">
            <div className="font-semibold text-accent-gold-end text-sm">
              50% off all packages this week
            </div>
            <div className="text-xs text-white font-medium bg-accent-terra/80 px-2 py-1 rounded-full">
              Ends Soon
            </div>
          </div>
        </div>

        {/* CTA Buttons - Mobile optimized */}
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <WeDesignButton
            variant="primary-gold"
            size="md"
            onClick={onStartProject}
            className="group touch-target min-h-[48px] px-6 py-3 text-sm sm:text-base font-medium shadow-lg w-full sm:w-auto"
          >
            Start Your Project
            <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
          </WeDesignButton>

          <WeDesignButton
            variant="secondary-outline"
            size="md"
            onClick={onViewWork}
            className="touch-target min-h-[48px] px-6 py-3 text-sm sm:text-base font-medium bg-white/10 backdrop-blur-sm border-white/30 text-white hover:bg-white/20 w-full sm:w-auto"
          >
            <Play className="w-4 h-4 mr-2" />
            View Our Work
          </WeDesignButton>
        </div>

        {/* Trust Indicators - Mobile responsive */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-2 sm:gap-6 pt-2 text-xs text-gray-200">
          <div className="flex items-center gap-1.5">
            <div className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse"></div>
            <Users className="w-3.5 h-3.5" />
            <span className="font-medium">15+ designers online</span>
          </div>
          <div className="flex items-center gap-4 sm:gap-6">
            <div className="flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5" />
              <span className="font-medium">24/7 support</span>
            </div>
            <div className="flex items-center gap-1.5">
              <CheckCircle className="w-3.5 h-3.5" />
              <span className="font-medium">100% satisfaction</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderProcessSlide = () => (
    <div className="Slide_LogoProcess relative grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-8 items-center">
      {/* Background Pattern */}
      <div className="absolute inset-0 z-0">
        <div 
          className="w-full h-full opacity-5"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23FFB84D' fill-opacity='0.3'%3E%3Ccircle cx='30' cy='30' r='4'/%3E%3C/g%3E%3C/svg%3E")`,
            backgroundSize: '60px 60px'
          }}
        ></div>
      </div>

      {/* Left Column - Process Visual */}
      <div className="relative order-2 lg:order-1 z-10">
        <div className="relative rounded-2xl overflow-hidden shadow-luxury-lg">
          <img 
            src="https://images.unsplash.com/photo-1586717791821-3f44a563fa4c?w=600&h=400&fit=crop&auto=format"
            alt="Design workflow process"
            className="w-full h-32 sm:h-40 md:h-48 lg:h-56 object-cover"
          />
          
          <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent"></div>
          
          {/* Play Button - Touch-friendly */}
          <div className="absolute inset-0 flex items-center justify-center">
            <button className="touch-target w-14 h-14 md:w-16 md:h-16 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center shadow-luxury hover:scale-110 transition-transform min-w-[56px] min-h-[56px]">
              <div className="w-0 h-0 border-l-[12px] md:border-l-[14px] border-l-accent-terra border-y-[8px] md:border-y-[9px] border-y-transparent ml-1"></div>
            </button>
          </div>
        </div>
      </div>

      {/* Right Column - Process Steps */}
      <div className="space-y-3 md:space-y-5 order-1 lg:order-2 relative z-10">
        {/* Title */}
        <div className="space-y-2 text-center">
          <h2 className="text-xl sm:text-2xl md:text-3xl lg:text-4xl leading-tight text-white font-bold">How WeDesign Works</h2>
          <p className="text-sm sm:text-base md:text-lg text-gray-200 leading-relaxed">
            Professional logo in 4 simple steps
          </p>
        </div>

        {/* Compact Steps */}
        <div className="space-y-3">
          {processSteps.map((step, index) => (
            <div key={step.number} className="flex gap-3 items-center">
              {/* Step Icon */}
              <div className={`w-8 h-8 ${step.color} rounded-lg flex items-center justify-center text-white flex-shrink-0`}>
                {step.icon}
              </div>

              {/* Step Number */}
              <div className="w-6 h-6 gradient-gold rounded-full flex items-center justify-center text-white text-sm font-bold flex-shrink-0">
                {step.number}
              </div>

              {/* Step Content */}
              <div className="flex-1 min-w-0">
                <h4 className="font-semibold text-white text-sm md:text-base">
                  {step.title}
                </h4>
                <p className="text-xs md:text-sm text-gray-200">
                  {step.description}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* CTA Section */}
        <div className="pt-3">
          <div className="bg-gradient-to-r from-white/20 to-white/10 backdrop-blur-sm border border-white/30 rounded-xl p-3">
            <p className="text-sm text-gray-200 mb-2">
              Join 5000+ satisfied customers who trust WeDesign.
            </p>
            <button 
              onClick={onStartProject}
              className="touch-target text-accent-gold-end font-medium hover:text-white transition-colors flex items-center gap-1 text-sm p-2 rounded-lg -ml-2 min-h-[44px]"
            >
              Start Now →
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <section className="Section_Home_CarouselIntroProcess py-6 md:py-8 lg:py-12">
      <div className="max-w-7xl mx-auto px-4 md:px-6">
        {/* Carousel Container - Responsive height */}
        <div className="Component_Carousel_IntroProcess relative bg-bg-light-ivory rounded-2xl shadow-luxury-lg overflow-hidden h-[400px] sm:h-[460px] md:h-[520px]">
          {/* Background Images for each slide */}
          {/* First slide background */}
          <div className={`absolute inset-0 z-0 transition-opacity duration-500 ${currentSlide === 0 ? 'opacity-100' : 'opacity-0'}`}>
            <img 
              src={designStudioImage}
              alt="Design studio workspace"
              className="w-full h-full object-cover"
              style={{
                filter: 'blur(1px)',
                transform: 'scale(1.02)'
              }}
            />
            {/* Dark overlay for text readability */}
            <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-black/40 to-black/30"></div>
            {/* Additional brand-colored overlay */}
            <div className="absolute inset-0 bg-gradient-to-br from-accent-terra/20 via-transparent to-accent-gold-end/10"></div>
          </div>

          {/* Second slide background */}
          <div className={`absolute inset-0 z-0 transition-opacity duration-500 ${currentSlide === 1 ? 'opacity-100' : 'opacity-0'}`}>
            <img 
              src={officeTeamImage}
              alt="Professional office team workspace"
              className="w-full h-full object-cover"
              style={{
                filter: 'blur(1px)',
                transform: 'scale(1.02)'
              }}
            />
            {/* Dark overlay for text readability on second slide - matching first slide */}
            <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-black/40 to-black/30"></div>
            {/* Additional brand-colored overlay */}
            <div className="absolute inset-0 bg-gradient-to-br from-accent-terra/20 via-transparent to-accent-gold-end/10"></div>
          </div>
          <div 
            className="carousel-content flex h-full transition-transform duration-500 ease-in-out relative z-10"
            style={{ transform: `translateX(-${currentSlide * 100}%)` }}
          >
            {/* Slide 1: Intro Branding */}
            <div className="w-full flex-shrink-0 p-6 md:p-8 lg:p-10 h-full flex items-center">
              {renderIntroSlide()}
            </div>

            {/* Slide 2: Logo Process */}
            <div className="w-full flex-shrink-0 p-6 md:p-8 lg:p-10 h-full flex items-center relative">
              <div className="relative z-10 w-full">
                {renderProcessSlide()}
              </div>
            </div>
          </div>

          {/* Navigation Arrows - Touch-friendly */}
          <button
            onClick={prevSlide}
            className="touch-target absolute left-2 top-1/2 transform -translate-y-1/2 w-10 h-10 sm:w-8 sm:h-8 md:w-7 md:h-7 bg-white/50 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white/70 transition-all duration-200 opacity-60 hover:opacity-100 z-20 min-w-[44px] min-h-[44px] sm:min-w-[32px] sm:min-h-[32px] md:min-w-[28px] md:min-h-[28px]"
            aria-label="Previous slide"
          >
            <ChevronLeft className="w-4 h-4 sm:w-3.5 sm:h-3.5 text-ink-deep-brown" />
          </button>

          <button
            onClick={nextSlide}
            className="touch-target absolute right-2 top-1/2 transform -translate-y-1/2 w-10 h-10 sm:w-8 sm:h-8 md:w-7 md:h-7 bg-white/50 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white/70 transition-all duration-200 opacity-60 hover:opacity-100 z-20 min-w-[44px] min-h-[44px] sm:min-w-[32px] sm:min-h-[32px] md:min-w-[28px] md:min-h-[28px]"
            aria-label="Next slide"
          >
            <ChevronRight className="w-4 h-4 sm:w-3.5 sm:h-3.5 text-ink-deep-brown" />
          </button>





          {/* Auto-play Toggle Button - Touch-friendly */}
          <button 
            onClick={() => setIsAutoPlaying(!isAutoPlaying)}
            className="touch-target absolute top-4 left-4 bg-white/80 backdrop-blur-sm rounded-full px-3 py-2 z-20 hover:bg-white/90 transition-all duration-200 group min-h-[44px] flex items-center"
            aria-label={isAutoPlaying ? 'Disable auto-play' : 'Enable auto-play'}
          >
            <div className="flex items-center gap-2">
              <div className={`w-1.5 h-1.5 rounded-full transition-all duration-300 ${
                isAutoPlaying 
                  ? 'bg-green-500 animate-pulse' 
                  : 'bg-gray-400 group-hover:bg-gray-500'
              }`}></div>
              <span className="text-xs font-medium text-ink-deep-brown">
                {isAutoPlaying ? 'Auto' : 'Manual'}
              </span>
            </div>
          </button>
        </div>
      </div>
    </section>
  );
}