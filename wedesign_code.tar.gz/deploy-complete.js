// WeDesign 完整部署脚本
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

console.log('🚀 WeDesign 完整部署流程');
console.log('==============================');

// 部署步骤配置
const deploymentSteps = [
  {
    id: 'fix-assets',
    name: '修复 Figma Asset 引用', 
    critical: true,
    action: async () => {
      console.log('🔧 修复 figma:asset 引用...');
      execSync('node fix-figma-assets.js', { stdio: 'inherit' });
    }
  },
  {
    id: 'repackage',
    name: '重打包项目结构',
    critical: true, 
    action: async () => {
      console.log('📦 重新打包项目...');
      execSync('node repackage-project.js', { stdio: 'inherit' });
    }
  },
  {
    id: 'verify-structure', 
    name: '验证项目结构',
    critical: true,
    action: async () => {
      console.log('🔍 验证项目结构...');
      
      const requiredFiles = {
        'index.html': 'HTML 入口文件',
        'src/main.tsx': 'React 入口点',
        'src/App.tsx': '主应用组件',
        'src/styles/globals.css': '全局样式',
        'package.json': '项目配置',
        'vite.config.ts': 'Vite 配置',
        'vercel.json': 'Vercel 配置'
      };
      
      let missingFiles = [];
      
      Object.entries(requiredFiles).forEach(([file, description]) => {
        const filePath = path.join(__dirname, file);
        const exists = fs.existsSync(filePath);
        
        if (exists) {
          console.log(`  ✅ ${file} - ${description}`);
        } else {
          console.log(`  ❌ ${file} - ${description} (缺失)`);
          missingFiles.push(file);
        }
      });
      
      if (missingFiles.length > 0) {
        throw new Error(`关键文件缺失: ${missingFiles.join(', ')}`);
      }
    }
  },
  {
    id: 'install-deps',
    name: '安装项目依赖',
    critical: true,
    action: async () => {
      console.log('📦 安装 npm 依赖...');
      execSync('npm install', { stdio: 'inherit' });
    }
  },
  {
    id: 'build-test',
    name: '构建测试',
    critical: true,
    action: async () => {
      console.log('🔨 测试项目构建...');
      execSync('npm run build', { stdio: 'inherit' });
      
      // 验证构建结果
      const distPath = path.join(__dirname, 'dist');
      const indexPath = path.join(distPath, 'index.html');
      
      if (!fs.existsSync(distPath) || !fs.existsSync(indexPath)) {
        throw new Error('构建失败，输出文件不存在');
      }
      
      console.log('  ✅ 构建成功，输出文件完整');
    }
  },
  {
    id: 'env-check',
    name: '环境变量检查',
    critical: false,
    action: async () => {
      console.log('🔐 检查环境变量配置...');
      
      const envExamplePath = path.join(__dirname, '.env.example'); 
      const envLocalPath = path.join(__dirname, '.env.local');
      
      if (fs.existsSync(envExamplePath)) {
        console.log('  ✅ .env.example 存在');
      } else {
        console.log('  ⚠️ .env.example 不存在');
      }
      
      if (fs.existsSync(envLocalPath)) {
        console.log('  ✅ .env.local 存在');
        console.log('  💡 记得在 Vercel 中配置相同的环境变量');
      } else {
        console.log('  ⚠️ .env.local 不存在');
        console.log('  💡 部署后需要在 Vercel 中配置环境变量');
      }
    }
  },
  {
    id: 'deploy-vercel',
    name: '部署到 Vercel',
    critical: true,
    action: async () => {
      console.log('🚀 部署到 Vercel...');
      
      // 检查 Vercel CLI
      try {
        execSync('vercel --version', { stdio: 'ignore' });
        console.log('  ✅ Vercel CLI 已安装');
      } catch {
        console.log('  📦 安装 Vercel CLI...');
        execSync('npm install -g vercel', { stdio: 'inherit' });
      }
      
      // 执行部署
      console.log('  🚀 正在部署...');
      execSync('vercel --prod --yes', { stdio: 'inherit' });
    }
  }
];

// 执行部署流程
async function deployComplete() {
  const startTime = Date.now();
  let completedSteps = 0;
  const results = [];
  
  console.log(`📋 开始执行 ${deploymentSteps.length} 个部署步骤\n`);
  
  for (const step of deploymentSteps) {
    const stepStartTime = Date.now();
    
    try {
      console.log(`\n[${completedSteps + 1}/${deploymentSteps.length}] ${step.name}`);
      console.log('─'.repeat(60));
      
      await step.action();
      
      const stepDuration = ((Date.now() - stepStartTime) / 1000).toFixed(1);
      results.push({
        ...step,
        status: 'success',
        duration: stepDuration
      });
      
      console.log(`✅ 完成 (耗时: ${stepDuration}s)`);
      completedSteps++;
      
    } catch (error) {
      const stepDuration = ((Date.now() - stepStartTime) / 1000).toFixed(1);
      results.push({
        ...step,
        status: 'failed',
        duration: stepDuration,
        error: error.message
      });
      
      console.log(`❌ 失败: ${error.message} (耗时: ${stepDuration}s)`);
      
      if (step.critical) {
        console.log('\n💥 关键步骤失败，部署终止');
        break;
      } else {
        console.log('\n⚠️ 非关键步骤失败，继续执行');
        completedSteps++;
      }
    }
  }
  
  // 部署结果报告
  const totalDuration = ((Date.now() - startTime) / 1000).toFixed(1);
  const successCount = results.filter(r => r.status === 'success').length;
  const failedCount = results.filter(r => r.status === 'failed').length;
  
  console.log('\n📊 WeDesign 部署报告');
  console.log('==============================');
  console.log(`总耗时: ${totalDuration}s`);
  console.log(`成功步骤: ${successCount}/${deploymentSteps.length}`);
  console.log(`失败步骤: ${failedCount}/${deploymentSteps.length}`);
  
  if (failedCount === 0) {
    console.log('\n🎉 WeDesign 部署完全成功！');
    console.log('================================');
    console.log('');
    console.log('🌐 你的网站已经部署完成！');
    console.log('');
    console.log('📝 下一步操作:');
    console.log('• 在 Vercel 控制台查看部署状态');
    console.log('• 配置环境变量 (Supabase, Stripe, etc.)');
    console.log('• 绑定自定义域名 (可选)');
    console.log('• 测试网站所有功能');
    console.log('');
    console.log('🔗 重要链接:');
    console.log('• 主页面: https://your-domain.vercel.app/');
    console.log('• 管理员后台: https://your-domain.vercel.app/admin-login');
    console.log('• 用户登录: https://your-domain.vercel.app/login');
    
  } else {
    console.log('\n⚠️ 部署部分成功');
    console.log('====================');
    
    const failedSteps = results.filter(r => r.status === 'failed');
    console.log('\n❌ 失败的步骤:');
    failedSteps.forEach(step => {
      console.log(`   • ${step.name}: ${step.error}`);
    });
    
    console.log('\n🔧 修复建议:');
    if (failedSteps.some(s => s.id === 'build-test')) {
      console.log('• 检查 TypeScript 类型错误');
      console.log('• 验证所有导入路径正确');
      console.log('• 确保图片 URL 有效');
    }
    if (failedSteps.some(s => s.id === 'deploy-vercel')) {
      console.log('• 确保已登录 Vercel: vercel login');
      console.log('• 检查网络连接');
      console.log('• 手动运行: vercel --prod');
    }
  }
  
  console.log('\n✨ WeDesign 部署流程完成！');
  
  // 返回适当的退出码
  process.exit(failedCount > 0 ? 1 : 0);
}

// 启动部署
console.log('WeDesign - Professional Logo Design Platform');
console.log('Starting deployment process...\n');

deployComplete().catch(error => {
  console.error('\n💥 部署流程异常终止:', error.message);
  process.exit(1);
});