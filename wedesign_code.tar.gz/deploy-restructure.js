// WeDesign 自动部署重组脚本
const fs = require('fs');
const path = require('path');

console.log('🚀 WeDesign 项目自动部署重组');
console.log('========================================');

// 1. 创建 src 目录结构
const directories = [
  'src',
  'src/components',
  'src/utils',
  'src/types',
  'src/supabase',
  'src/styles'
];

directories.forEach(dir => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
    console.log(`✅ 创建目录: ${dir}`);
  }
});

// 2. 移动文件到 src 目录
const moveOperations = [
  {
    from: 'components',
    to: 'src/components',
    description: 'React 组件'
  },
  {
    from: 'utils',
    to: 'src/utils',
    description: '工具函数'
  },
  {
    from: 'types',
    to: 'src/types',
    description: 'TypeScript 类型'
  },
  {
    from: 'supabase',
    to: 'src/supabase',
    description: 'Supabase 配置'
  }
];

moveOperations.forEach(({ from, to, description }) => {
  const sourcePath = path.join(__dirname, from);
  const targetPath = path.join(__dirname, to);
  
  if (fs.existsSync(sourcePath)) {
    try {
      // 如果目标存在，先删除
      if (fs.existsSync(targetPath)) {
        fs.rmSync(targetPath, { recursive: true, force: true });
      }
      
      // 移动文件夹
      fs.renameSync(sourcePath, targetPath);
      console.log(`✅ 移动 ${description}: ${from} → ${to}`);
    } catch (error) {
      console.log(`⚠️  移动失败 ${from}: ${error.message}`);
    }
  }
});

// 3. 移动 styles 到 src，但保留根目录的作为备份
const rootStylesPath = path.join(__dirname, 'styles');
const srcStylesPath = path.join(__dirname, 'src/styles');

if (fs.existsSync(rootStylesPath)) {
  try {
    if (!fs.existsSync(srcStylesPath)) {
      fs.mkdirSync(srcStylesPath, { recursive: true });
    }
    
    // 复制而不是移动，保留根目录的 styles
    const globalsPath = path.join(rootStylesPath, 'globals.css');
    const targetGlobalsPath = path.join(srcStylesPath, 'globals.css');
    
    if (fs.existsSync(globalsPath)) {
      fs.copyFileSync(globalsPath, targetGlobalsPath);
      console.log('✅ 复制样式文件到 src/styles/globals.css');
    }
  } catch (error) {
    console.log(`⚠️  样式文件处理失败: ${error.message}`);
  }
}

// 4. 删除旧的根目录 App.tsx
const oldAppPath = path.join(__dirname, 'App.tsx');
if (fs.existsSync(oldAppPath)) {
  fs.unlinkSync(oldAppPath);
  console.log('✅ 删除根目录的旧 App.tsx');
}

// 5. 清理多余的配置文件
const filesToRemove = [
  'next.config.js',  // 这是 Next.js 配置，我们用 Vite
];

filesToRemove.forEach(file => {
  const filePath = path.join(__dirname, file);
  if (fs.existsSync(filePath)) {
    fs.unlinkSync(filePath);
    console.log(`✅ 删除多余文件: ${file}`);
  }
});

// 6. 验证关键文件存在
console.log('\n🔍 验证关键文件:');
const requiredFiles = [
  'index.html',
  'src/main.tsx',
  'src/App.tsx',
  'src/styles/globals.css',
  'package.json',
  'vite.config.ts',
  'vercel.json'
];

let allFilesExist = true;
requiredFiles.forEach(file => {
  const exists = fs.existsSync(path.join(__dirname, file));
  console.log(`${exists ? '✅' : '❌'} ${file}`);
  if (!exists) allFilesExist = false;
});

if (allFilesExist) {
  console.log('\n🎉 项目重组完成！');
  console.log('所有必需文件都已就位，可以开始部署。');
  
  console.log('\n📦 下一步操作:');
  console.log('1. npm install           # 安装依赖');
  console.log('2. npm run build         # 构建项目');
  console.log('3. npm run preview       # 本地预览');
  console.log('4. vercel --prod         # 部署到 Vercel');
  
} else {
  console.log('\n❌ 项目重组不完整');
  console.log('请检查缺失的文件并手动创建。');
}

console.log('\nWeDesign 项目重组完成！');