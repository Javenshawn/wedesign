#!/bin/bash

# WeDesign 一键部署脚本
echo "🚀 WeDesign 一键部署开始"
echo "================================"

# 设置错误时退出
set -e

# 1. 项目重组
echo ""
echo "📁 [1/6] 重组项目结构..."
node deploy-restructure.js

# 2. 验证配置
echo ""
echo "🔍 [2/6] 验证部署配置..."
node verify-deployment-config.js

# 检查配置验证结果
if [ $? -ne 0 ]; then
    echo "❌ 配置验证失败，请先修复配置问题"
    exit 1
fi

# 3. 安装依赖
echo ""
echo "📦 [3/6] 安装项目依赖..."
npm install

# 4. 构建项目
echo ""
echo "🔨 [4/6] 构建生产版本..."
npm run build

# 5. 本地预览 (可选)
echo ""
echo "👀 [5/6] 本地预览构建结果..."
echo "如果需要预览，请运行: npm run preview"

# 6. 部署到 Vercel
echo ""
echo "🚀 [6/6] 部署到 Vercel..."

# 检查 Vercel CLI
if ! command -v vercel &> /dev/null; then
    echo "📦 安装 Vercel CLI..."
    npm install -g vercel
fi

# 执行部署
echo "正在部署到 Vercel..."
vercel --prod --yes

echo ""
echo "🎉 WeDesign 部署完成！"
echo "================================"
echo ""
echo "📊 部署摘要:"
echo "• 项目结构: ✅ 已标准化"
echo "• 依赖安装: ✅ 完成"
echo "• 项目构建: ✅ 成功"
echo "• Vercel 部署: ✅ 完成"
echo ""
echo "🌐 下一步操作:"
echo "1. 在 Vercel 控制台配置环境变量"
echo "2. 绑定自定义域名 (可选)"
echo "3. 测试网站功能"
echo "4. 配置 DNS 解析 (如果使用自定义域名)"
echo ""
echo "📝 重要提醒:"
echo "• 管理员后台: https://your-domain.com/admin-login"
echo "• 用户登录: https://your-domain.com/login"
echo "• API 密钥需要在 Vercel 环境变量中配置"
echo ""
echo "WeDesign 部署成功！🎊"