import React, { useState, useEffect } from "react";
import { Header } from "./components/layout/Header";
import { Footer } from "./components/layout/Footer";

// Import page components
import { Page_Home } from "./components/pages/HomePage";
import { Page_LogosDesign } from "./components/pages/LogosDesignPage";
import { Page_DesignHall } from "./components/pages/DesignHallPage";
import { Page_AboutUs } from "./components/pages/AboutUsPage";
import { Page_Blog } from "./components/pages/Page_Blog";
import { Page_Login } from "./components/pages/Page_Login";
import { Page_UserPortal } from "./components/pages/Page_UserPortal";
import { Page_PaymentSettings } from "./components/pages/Page_PaymentSettings";
import { Page_PaymentSuccess } from "./components/pages/Page_PaymentSuccess";
import { Page_Checkout } from "./components/pages/Page_Checkout";

// Import modal components
import { PackageSelectionModal } from "./components/modals/PackageSelectionModal";
import { Modal_StartProject } from "./components/modals/StartProjectModal";

// Import admin components
import { AdminLogin } from "./components/admin/AdminLogin";
import { AdminDashboard } from "./components/admin/AdminDashboard";
import { AdminCustomers } from "./components/admin/AdminCustomers";
import { AdminSEO } from "./components/admin/AdminSEO";

// Import utilities
import { updatePageSEO } from "./utils/seo-utils";
import {
  initializeGoogleAnalytics,
  trackPageView,
  trackNavigation,
  trackUserLogout,
} from "./utils/analytics-utils";
import {
  mapRouteToPage,
  protectedPages,
  hiddenHeaderPages,
  hiddenFooterPages,
} from "./utils/routing-config";

interface SelectedPackage {
  name: string;
  price: string;
  priceValue: number;
  type: string;
}

export default function App() {
  const [currentPage, setCurrentPage] = useState("home");
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [showPackageModal, setShowPackageModal] = useState(false);
  const [showProjectInfoModal, setShowProjectInfoModal] = useState(false);
  const [selectedPackage, setSelectedPackage] = useState<SelectedPackage | null>(null);
  const [orderData, setOrderData] = useState<any>(null);

  // Admin pages that should not show main website header/footer
  const adminPages = [
    "admin-login",
    "admin-dashboard", 
    "admin-customers",
    "admin-interactions",
    "admin-tickets",
    "admin-orders",
    "admin-finance",
    "admin-blog",
    "admin-cases",
    "admin-seo",
    "admin-settings",
    "admin-roles",
    "admin-audit",
  ];

  // Update SEO information when page changes
  useEffect(() => {
    updatePageSEO(currentPage);
  }, [currentPage]);

  // Initialize Google Analytics on app load
  useEffect(() => {
    initializeGoogleAnalytics();
  }, []);

  // Handle routing and navigation
  useEffect(() => {
    const handleRouteChange = () => {
      const path = window.location.pathname;
      const mappedPage = mapRouteToPage(path);
      setCurrentPage(mappedPage);

      // Track page view in Google Analytics
      trackPageView(mappedPage);
    };

    // Initialize routing
    handleRouteChange();

    // Listen for browser navigation (back/forward)
    window.addEventListener("popstate", handleRouteChange);
    return () =>
      window.removeEventListener("popstate", handleRouteChange);
  }, []);

  const navigateTo = (page: string) => {
    setCurrentPage(page);
    const url = page === "home" ? "/" : `/${page}`;
    window.history.pushState({}, "", url);

    // Track navigation in Google Analytics
    trackNavigation(page);
  };

  const handleSignOut = async () => {
    try {
      setUser(null);
      navigateTo("home");

      // Track logout event in Google Analytics
      trackUserLogout();
    } catch (error) {
      console.error("Sign out failed:", error);
    }
  };

  const handleGetStarted = () => {
    setShowPackageModal(true);
  };

  const handleSelectPackage = (packageName: string, price: number) => {
    console.log(`Selected package: ${packageName} for ${price}`);
    
    // Convert to the format expected by Modal_StartProject
    const packageData: SelectedPackage = {
      name: packageName,
      price: `${price}`,
      priceValue: price,
      type: packageName.toLowerCase().replace(/\s+/g, "-"),
    };
    
    setSelectedPackage(packageData);
    setShowPackageModal(false);
    setShowProjectInfoModal(true);
  };

  const handleSubmitProject = (data: any) => {
    console.log("Project submitted:", data);

    // 准备订单数据
    const checkoutData = {
      selectedPackage: data.package,
      projectInfo: data.form,
      payment: data.payment,
      userCredentials: {
        username: data.form.logoName || 'User',
        password: "888888",
      },
    };

    setOrderData(checkoutData);
    setShowProjectInfoModal(false);
    // Modal_StartProject will handle navigation to payment success internally
  };

  // Redirect to login for protected pages when user is not authenticated
  if (protectedPages.includes(currentPage) && !user && !loading) {
    return <Page_Login onNavigate={navigateTo} />;
  }

  // Loading state
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-bg-light-ivory to-bg-light-ivory/50">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-accent-terra border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-ink-soft-brown">
            Loading WeDesign - Worldwide Design Best Delivered...
          </p>
        </div>
      </div>
    );
  }

  const renderPage = () => {
    switch (currentPage) {
      // Main website pages
      case "home":
        return <Page_Home onNavigate={navigateTo} />;
      case "logos-design":
        return <Page_LogosDesign />;
      case "design-hall":
        return <Page_DesignHall />;
      case "about-us":
        return <Page_AboutUs />;
      case "blog":
        return <Page_Blog />;
      case "login":
        return <Page_Login onNavigate={navigateTo} />;
      case "user-portal":
        return <Page_UserPortal />;
      case "payment-settings":
        return <Page_PaymentSettings onNavigate={navigateTo} />;
      case "checkout":
        return (
          <Page_Checkout
            onNavigate={navigateTo}
            orderData={orderData}
          />
        );
      case "payment-success":
        return <Page_PaymentSuccess onNavigate={navigateTo} />;

      // Admin pages - using direct components
      case "admin-login":
        return <AdminLogin onNavigate={navigateTo} />;
      case "admin-dashboard":
        return <AdminDashboard onNavigate={navigateTo} />;
      case "admin-customers":
        return <AdminCustomers onNavigate={navigateTo} />;
      case "admin-seo":
        return <AdminSEO onNavigate={navigateTo} />;

      default:
        return <Page_Home onNavigate={navigateTo} />;
    }
  };

  const isAdminPage = adminPages.includes(currentPage);

  return (
    <div className="min-h-screen bg-gradient-to-br from-bg-light-ivory to-bg-light-ivory/50">
      {/* Header - hidden on admin pages and specific pages */}
      {!isAdminPage && !hiddenHeaderPages.includes(currentPage) && (
        <Header
          currentPage={currentPage}
          onNavigate={navigateTo}
          user={user}
          onSignOut={handleSignOut}
          onGetStarted={handleGetStarted}
        />
      )}

      {/* Main content area */}
      <main
        className={
          !isAdminPage && !hiddenHeaderPages.includes(currentPage)
            ? "pt-20"
            : ""
        }
      >
        {renderPage()}
      </main>

      {/* Footer - hidden on admin pages and specific pages */}
      {!isAdminPage && !hiddenFooterPages.includes(currentPage) && (
        <Footer onNavigate={navigateTo} />
      )}

      {/* Modals - only show on main website pages */}
      {!isAdminPage && (
        <>
          {/* Package Selection Modal */}
          <PackageSelectionModal
            isOpen={showPackageModal}
            onClose={() => setShowPackageModal(false)}
            onSelectPackage={handleSelectPackage}
          />

          {/* Project Info Modal */}
          <Modal_StartProject
            isOpen={showProjectInfoModal}
            onClose={() => {
              setShowProjectInfoModal(false);
              setSelectedPackage(null);
            }}
            selectedPackage={selectedPackage}
            onSubmit={handleSubmitProject}
          />
        </>
      )}
    </div>
  );
}