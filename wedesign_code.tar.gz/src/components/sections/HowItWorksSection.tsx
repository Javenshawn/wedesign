// Replace Figma asset import with local placeholder image. The original Figma asset
// is unavailable at build time, causing Vite rollup resolution errors. Use the
// placeholder image instead. See src/assets/placeholder.png.
import howItWorksImage from '@/assets/placeholder.png';
import { Package, FileText, CreditCard, Palette } from 'lucide-react';

const steps = [
  {
    number: 1,
    title: 'Choose Package',
    description: 'Select the perfect package for your needs - Economy, Business, or Private Jet.',
    icon: <Package className="w-6 h-6" />,
    color: 'bg-blue-500'
  },
  {
    number: 2,
    title: 'Submit Brief',
    description: 'Tell us about your brand, style preferences, and vision through our simple form.',
    icon: <FileText className="w-6 h-6" />,
    color: 'bg-green-500'
  },
  {
    number: 3,
    title: 'Secure Payment',
    description: 'Complete your payment safely and get instant confirmation of your order.',
    icon: <CreditCard className="w-6 h-6" />,
    color: 'bg-orange-500'
  },
  {
    number: 4,
    title: 'Design Begins',
    description: 'Our expert designers start creating your unique logo within 3 hours.',
    icon: <Palette className="w-6 h-6" />,
    color: 'bg-purple-500'
  }
];

export function Section_Process() {
  return (
    <section className="Section_Process py-20 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="font-heading text-2xl md:text-3xl font-bold text-ink-deep-brown mb-6 tracking-tight">How WeDesign Works</h2>
          <p className="font-body text-lg md:text-xl text-ink-soft-brown max-w-2xl mx-auto leading-relaxed">
            Get your professional logo in 4 simple steps
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left: Video/Image */}
          <div className="relative">
            <div className="relative rounded-3xl overflow-hidden shadow-luxury-lg">
              <img 
                src={howItWorksImage} 
                alt="WeDesign process workflow demonstration"
                className="w-full h-auto"
              />
              
              {/* Play Button Overlay */}
              <div className="absolute inset-0 flex items-center justify-center">
                <button className="w-16 h-16 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center shadow-luxury hover:scale-110 transition-transform group">
                  <div className="w-0 h-0 border-l-[14px] border-l-accent-terra border-y-[10px] border-y-transparent ml-1"></div>
                </button>
              </div>

              {/* Video Duration Badge */}
              <div className="absolute bottom-4 right-4 bg-black/80 text-white px-3 py-1 rounded-lg text-sm">
                2:15 min
              </div>
            </div>
          </div>

          {/* Right: Steps */}
          <div className="space-y-8">
            {steps.map((step, index) => (
              <div key={step.number} className="flex gap-6">
                {/* Step Icon */}
                <div className="flex-shrink-0">
                  <div className={`w-12 h-12 ${step.color} rounded-xl flex items-center justify-center text-white`}>
                    {step.icon}
                  </div>
                </div>

                {/* Step Content */}
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-6 h-6 gradient-gold rounded-full flex items-center justify-center text-white text-sm font-bold">
                      {step.number}
                    </div>
                    <h3 className="font-heading text-xl font-semibold text-ink-deep-brown">
                      {step.title}
                    </h3>
                  </div>
                  <p className="font-body text-ink-soft-brown leading-relaxed">
                    {step.description}
                  </p>
                </div>

                {/* Connection Line */}
                {index < steps.length - 1 && (
                  <div className="absolute left-[30px] mt-16 w-0.5 h-8 bg-gradient-to-b from-muted to-transparent"></div>
                )}
              </div>
            ))}

            {/* CTA */}
            <div className="pt-6">
              <div className="bg-muted/30 rounded-2xl p-6">
                <h4 className="font-heading font-semibold text-ink-deep-brown mb-2">Ready to get started?</h4>
                <p className="font-body text-sm text-ink-soft-brown mb-4 leading-relaxed">
                  Join 5000+ satisfied customers who trust WeDesign for their logo needs.
                </p>
                <button className="text-accent-terra font-medium hover:text-accent-terra/80 transition-colors flex items-center gap-2">
                  See More →
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}