export const routeMap: { [key: string]: string } = {
  '': 'home',
  'home': 'home',
  'logos-design': 'logos-design',
  'design-hall': 'design-hall',
  'about-us': 'about-us',
  'blog': 'blog',
  'login': 'login',
  'admin': 'admin-login',
  'admin-login': 'admin-login',
  'admin-dashboard': 'admin-dashboard',
  'admin-customers': 'admin-customers',
  'admin-seo': 'admin-seo',
  'user-portal': 'user-portal',
  'payment-settings': 'payment-settings',
  'checkout': 'checkout',
  'payment-success': 'payment-success'
};

export const protectedPages = ['user-portal', 'payment-settings'];

export const hiddenHeaderPages = [
  'login', 'admin-login', 'admin-dashboard', 'admin-customers', 'admin-seo', 
  'checkout', 'payment-success'
];

export const hiddenFooterPages = [
  'login', 'admin-login', 'admin-dashboard', 'admin-customers', 'admin-seo',
  'user-portal', 'payment-settings', 'checkout', 'payment-success'
];

/**
 * Maps a URL path to a page identifier
 * @param path - The URL path
 * @returns The mapped page identifier
 */
export const mapRouteToPage = (path: string): string => {
  const page = path.slice(1) || 'home';
  return routeMap[page] || 'home';
};