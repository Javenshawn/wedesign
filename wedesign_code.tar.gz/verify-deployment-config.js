// WeDesign 部署配置验证脚本
const fs = require('fs');
const path = require('path');

console.log('🔐 WeDesign 部署配置验证');
console.log('==============================');

// 1. 检查环境变量文件
const envFiles = ['.env.example', '.env.local'];
let envConfig = {};

envFiles.forEach(file => {
  const filePath = path.join(__dirname, file);
  if (fs.existsSync(filePath)) {
    console.log(`✅ 找到 ${file}`);
    
    // 读取环境变量
    const content = fs.readFileSync(filePath, 'utf8');
    const lines = content.split('\n').filter(line => line.trim() && !line.startsWith('#'));
    
    lines.forEach(line => {
      const [key, value] = line.split('=');
      if (key && value) {
        envConfig[key.trim()] = value.trim();
      }
    });
  } else {
    console.log(`⚠️  ${file} 不存在`);
  }
});

// 2. 验证必需的环境变量
console.log('\n🔍 验证必需环境变量:');

const requiredEnvVars = {
  // Supabase 配置
  'VITE_SUPABASE_URL': 'Supabase 项目 URL',
  'VITE_SUPABASE_ANON_KEY': 'Supabase 匿名密钥',
  'SUPABASE_SERVICE_ROLE_KEY': 'Supabase 服务密钥 (服务端)',
  
  // Stripe 配置  
  'VITE_STRIPE_PUBLISHABLE_KEY': 'Stripe 可发布密钥',
  'STRIPE_SECRET_KEY': 'Stripe 密钥 (服务端)',
  
  // 应用配置
  'VITE_APP_URL': '应用 URL',
  'VITE_GA_MEASUREMENT_ID': 'Google Analytics ID (可选)'
};

let configValid = true;
const missingVars = [];
const invalidVars = [];

Object.entries(requiredEnvVars).forEach(([key, description]) => {
  const value = envConfig[key];
  const hasValue = value && value !== 'your-actual-key-here' && value !== 'https://your-project.supabase.co';
  
  if (!value) {
    console.log(`❌ ${key} - ${description} (缺失)`);
    missingVars.push(key);
    configValid = false;
  } else if (!hasValue) {
    console.log(`⚠️  ${key} - ${description} (需要替换为实际值)`);
    invalidVars.push(key);
    configValid = false;
  } else {
    // 验证格式
    let formatValid = true;
    let formatHint = '';
    
    if (key.includes('SUPABASE_URL') && !value.includes('supabase.co')) {
      formatValid = false;
      formatHint = ' (应该包含 supabase.co)';
    } else if (key.includes('STRIPE') && key.includes('PUBLISHABLE') && !value.startsWith('pk_')) {
      formatValid = false;
      formatHint = ' (应该以 pk_ 开头)';
    } else if (key.includes('STRIPE') && key.includes('SECRET') && !value.startsWith('sk_')) {
      formatValid = false;
      formatHint = ' (应该以 sk_ 开头)';
    }
    
    if (formatValid) {
      console.log(`✅ ${key} - ${description}`);
    } else {
      console.log(`⚠️  ${key} - ${description}${formatHint}`);
      invalidVars.push(key);
      configValid = false;
    }
  }
});

// 3. 检查 Vercel 配置
console.log('\n📋 Vercel 配置检查:');
const vercelConfigPath = path.join(__dirname, 'vercel.json');

if (fs.existsSync(vercelConfigPath)) {
  try {
    const vercelConfig = JSON.parse(fs.readFileSync(vercelConfigPath, 'utf8'));
    console.log('✅ vercel.json 存在且格式正确');
    
    // 检查关键配置
    if (vercelConfig.framework === 'vite') {
      console.log('✅ 框架设置为 Vite');
    } else {
      console.log('⚠️  建议设置 framework: "vite"');
    }
    
    if (vercelConfig.functions) {
      console.log('✅ Supabase 函数配置存在');
    }
    
  } catch (error) {
    console.log('❌ vercel.json 格式错误:', error.message);
    configValid = false;
  }
} else {
  console.log('⚠️  vercel.json 不存在，将使用默认配置');
}

// 4. 检查包配置
console.log('\n📦 Package.json 检查:');
const packagePath = path.join(__dirname, 'package.json');

if (fs.existsSync(packagePath)) {
  try {
    const packageConfig = JSON.parse(fs.readFileSync(packagePath, 'utf8'));
    
    const requiredScripts = ['dev', 'build', 'preview'];
    requiredScripts.forEach(script => {
      if (packageConfig.scripts && packageConfig.scripts[script]) {
        console.log(`✅ ${script} 脚本存在`);
      } else {
        console.log(`❌ ${script} 脚本缺失`);
        configValid = false;
      }
    });
    
    // 检查关键依赖
    const deps = { ...packageConfig.dependencies, ...packageConfig.devDependencies };
    const requiredDeps = ['react', 'react-dom', 'vite', '@vitejs/plugin-react'];
    
    requiredDeps.forEach(dep => {
      if (deps[dep]) {
        console.log(`✅ ${dep} 依赖存在`);
      } else {
        console.log(`❌ ${dep} 依赖缺失`);
        configValid = false;
      }
    });
    
  } catch (error) {
    console.log('❌ package.json 格式错误:', error.message);
    configValid = false;
  }
} else {
  console.log('❌ package.json 不存在');
  configValid = false;
}

// 5. 生成配置修复指南
console.log('\n📝 配置总结:');
console.log('===============');

if (configValid) {
  console.log('🎉 所有配置都正确，可以开始部署！');
  console.log('');
  console.log('🚀 部署命令:');
  console.log('npm install');
  console.log('npm run build');
  console.log('vercel --prod');
  
} else {
  console.log('❌ 配置需要修复');
  console.log('');
  
  if (missingVars.length > 0) {
    console.log('🔧 缺失的环境变量:');
    missingVars.forEach(key => {
      console.log(`   • ${key}: ${requiredEnvVars[key]}`);
    });
    console.log('');
  }
  
  if (invalidVars.length > 0) {
    console.log('🔧 需要更新的环境变量:');
    invalidVars.forEach(key => {
      console.log(`   • ${key}: ${requiredEnvVars[key]}`);
    });
    console.log('');
  }
  
  console.log('📋 修复步骤:');
  console.log('1. 编辑 .env.local 文件');
  console.log('2. 填入正确的 API 密钥');
  console.log('3. 重新运行此验证脚本');
  console.log('4. 验证通过后开始部署');
}

console.log('\nWeDesign 配置验证完成！');