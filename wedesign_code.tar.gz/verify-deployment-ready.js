#!/usr/bin/env node

const fs = require('fs');
const path = require('path');

console.log('🔍 WeDesign Deployment Readiness Check\n');

let allGood = true;
let warnings = 0;

function checkFile(filePath, description, critical = true) {
  const exists = fs.existsSync(path.join(process.cwd(), filePath));
  if (exists) {
    console.log(`✅ ${description}`);
    return true;
  } else {
    if (critical) {
      console.log(`❌ ${description} - MISSING (Critical)`);
      allGood = false;
    } else {
      console.log(`⚠️  ${description} - Missing (Optional)`);
      warnings++;
    }
    return false;
  }
}

function checkPackageJson() {
  console.log('\n📦 Package.json verification:');
  try {
    const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));
    
    // Check scripts
    if (pkg.scripts?.build) {
      console.log('✅ Build script found');
    } else {
      console.log('❌ Build script missing');
      allGood = false;
    }
    
    if (pkg.scripts?.dev) {
      console.log('✅ Dev script found');
    } else {
      console.log('❌ Dev script missing'); 
      allGood = false;
    }
    
    // Check key dependencies
    const requiredDeps = [
      'react',
      'react-dom', 
      'typescript',
      '@supabase/supabase-js',
      '@stripe/stripe-js'
    ];
    
    console.log('\n📋 Key dependencies:');
    requiredDeps.forEach(dep => {
      if (pkg.dependencies?.[dep] || pkg.devDependencies?.[dep]) {
        console.log(`✅ ${dep}`);
      } else {
        console.log(`❌ ${dep} - Missing`);
        allGood = false;
      }
    });
    
  } catch (error) {
    console.log('❌ Failed to read package.json');
    allGood = false;
  }
}

function checkEnvironment() {
  console.log('\n🔐 Environment configuration:');
  checkFile('.env.example', 'Environment template exists');
  
  // Check if .env files are properly ignored
  if (fs.existsSync('.gitignore')) {
    const gitignore = fs.readFileSync('.gitignore', 'utf8');
    if (gitignore.includes('.env')) {
      console.log('✅ .env files are in .gitignore');
    } else {
      console.log('⚠️  .env files should be added to .gitignore');
      warnings++;
    }
  }
}

function checkUnwantedFiles() {
  console.log('\n🧹 Checking for files that should be removed:');
  
  const shouldBeRemoved = [
    'STRIPE_COMPLETE_SETUP_GUIDE.md',
    'SUPABASE_PROJECT_CREATION_CHECKLIST.md',
    'API_KEYS_CHECKLIST.md',
    '管理员后台访问指南.md',
    'next.config.js'
  ];
  
  let foundUnwanted = 0;
  shouldBeRemoved.forEach(file => {
    if (fs.existsSync(file)) {
      console.log(`⚠️  Found file that should be removed: ${file}`);
      foundUnwanted++;
    }
  });
  
  if (foundUnwanted === 0) {
    console.log('✅ No unwanted files found - project is clean');
  } else {
    console.log(`⚠️  Found ${foundUnwanted} files that should be removed`);
    console.log('💡 Run: node cleanup-project.js');
    warnings++;
  }
}

// Run all checks
console.log('🔍 Starting WeDesign deployment readiness check...\n');

// Essential files check
console.log('📁 Essential files verification:');
checkFile('App.tsx', 'Main App component');
checkFile('vite.config.ts', 'Vite configuration');
checkFile('vercel.json', 'Vercel deployment config');
checkFile('styles/globals.css', 'Global styles');
checkFile('.gitignore', '.gitignore file');
checkFile('README.md', 'README documentation');

// Component structure
console.log('\n🧩 Component structure:');
checkFile('components/layout/Header.tsx', 'Header component');
checkFile('components/layout/Footer.tsx', 'Footer component');
checkFile('components/pages/HomePage.tsx', 'HomePage component');
checkFile('utils/supabase/client.ts', 'Supabase client');
checkFile('utils/stripe-client.ts', 'Stripe client');

// Package.json check
checkPackageJson();

// Environment check
checkEnvironment();

// Unwanted files check
checkUnwantedFiles();

// Final assessment
console.log('\n' + '='.repeat(50));
console.log('📊 DEPLOYMENT READINESS ASSESSMENT');
console.log('='.repeat(50));

if (allGood && warnings === 0) {
  console.log('🎉 EXCELLENT! Your project is ready for deployment.');
  console.log('\n📝 Next steps:');
  console.log('1. Follow COMPLETE_DEPLOYMENT_STEPS.md');
  console.log('2. Set up your GitHub repository');
  console.log('3. Deploy to Vercel with environment variables');
  console.log('4. Configure Supabase and Stripe settings');
} else if (allGood && warnings > 0) {
  console.log('✅ GOOD! Your project is ready for deployment.');
  console.log(`⚠️  ${warnings} warnings should be addressed for optimal setup.`);
  console.log('\n📝 You can proceed with deployment.');
} else {
  console.log('🚨 NOT READY! Critical issues must be fixed before deployment.');
  console.log('\n🔧 Please fix the critical issues above first.');
}

if (warnings > 0) {
  console.log('\n💡 To fix warnings, consider running: node cleanup-project.js');
}

console.log('\n📖 For detailed deployment instructions, see: COMPLETE_DEPLOYMENT_STEPS.md');