#!/usr/bin/env node

console.log('🔧 WeDesign 环境配置助手');
console.log('========================\n');

console.log('本指南将帮助您收集部署所需的 API 密钥。\n');

console.log('📋 必需的环境变量：\n');

console.log('🗄️  SUPABASE 配置：');
console.log('   从这里获取：https://supabase.com → 您的项目 → 设置 → API');
console.log('   ┌─────────────────────────────────────────────────────────────┐');
console.log('   │ VITE_SUPABASE_URL=https://您的项目ID.supabase.co           │');
console.log('   │ VITE_SUPABASE_ANON_KEY=eyJ...您的匿名密钥                  │');
console.log('   │ SUPABASE_SERVICE_ROLE_KEY=eyJ...您的服务角色密钥           │');
console.log('   └─────────────────────────────────────────────────────────────┘\n');

console.log('💳 STRIPE 配置：');
console.log('   从这里获取：https://dashboard.stripe.com → 开发者 → API 密钥');
console.log('   ┌─────────────────────────────────────────────────────────────┐');
console.log('   │ VITE_STRIPE_PUBLISHABLE_KEY=pk_live_...您的可发布密钥      │');
console.log('   │ STRIPE_SECRET_KEY=sk_live_...您的秘密密钥                  │');
console.log('   └─────────────────────────────────────────────────────────────┘\n');

console.log('⚠️  重要注意事项：');
console.log('   • 生产环境：使用实时密钥 (pk_live_, sk_live_)');
console.log('   • 测试环境：使用测试密钥 (pk_test_, sk_test_)');
console.log('   • 永远不要将这些密钥提交到 GitHub');
console.log('   • 在 Vercel 控制台中添加为环境变量\n');

console.log('📝 VERCEL 部署步骤：');
console.log('   1. 创建 GitHub 仓库');
console.log('   2. 导入到 Vercel');
console.log('   3. 在 Vercel 控制台中添加环境变量');
console.log('   4. 部署');
console.log('   5. 配置 Supabase CORS 设置');
console.log('   6. 配置 Stripe webhooks\n');

console.log('🔍 验证检查清单：');
console.log('   ✓ Supabase URL 以 "https://" 开头，以 ".supabase.co" 结尾');
console.log('   ✓ Supabase 密钥以 "eyJ" 开头');
console.log('   ✓ Stripe 可发布密钥以 "pk_live_" 或 "pk_test_" 开头');
console.log('   ✓ Stripe 秘密密钥以 "sk_live_" 或 "sk_test_" 开头');
console.log('   ✓ 所有密钥都在 Vercel 环境变量中正确设置\n');

console.log('📖 详细的分步说明请参阅：');
console.log('   → 项目部署指南.md\n');

console.log('🚀 准备部署？运行这些命令：');
console.log('   1. node 项目清理脚本.js          # 清理项目');
console.log('   2. node 验证部署准备.js          # 验证就绪状态');
console.log('   3. 按照 项目部署指南.md 操作');