# 🚀 WeDesign - Complete Deployment Guide

## Step 1: Clean Up Project (REQUIRED)

Run the cleanup script to remove 40+ redundant documentation files:

```bash
node cleanup-project.js
```

This will remove all the guide files and unused components, leaving you with a clean production-ready project.

## Step 2: Verify Project Structure

After cleanup, you should have these essential files:
- ✅ `App.tsx` (main application)
- ✅ `package.json` (dependencies)
- ✅ `vite.config.ts` (Vite configuration)
- ✅ `vercel.json` (deployment config)
- ✅ `.env.example` (environment template)
- ✅ `styles/globals.css` (styling)
- ✅ `components/` directory with all your components
- ✅ `utils/` directory with services
- ✅ `supabase/functions/` directory with server functions

## Step 3: Environment Variables Setup

You need these API keys for production deployment:

### 🗄️ Supabase Keys (Required):
1. Go to [supabase.com](https://supabase.com)
2. Select your project → Settings → API
3. Copy these values:
   ```
   VITE_SUPABASE_URL=https://your-project-id.supabase.co
   VITE_SUPABASE_ANON_KEY=eyJ...your_anon_key
   SUPABASE_SERVICE_ROLE_KEY=eyJ...your_service_role_key
   ```

### 💳 Stripe Keys (Required):
1. Go to [dashboard.stripe.com](https://dashboard.stripe.com)
2. Developers → API Keys
3. **For Production**: Use **Live** keys (pk_live_, sk_live_)
4. **For Testing**: Use **Test** keys (pk_test_, sk_test_)
   ```
   VITE_STRIPE_PUBLISHABLE_KEY=pk_live_...or_pk_test_...
   STRIPE_SECRET_KEY=sk_live_...or_sk_test_...
   ```

## Step 4: GitHub Repository Setup

### 4.1 Initialize Git (if not already done)
```bash
git init
git add .
git commit -m "Initial commit: WeDesign Premium Logo Design Platform - Production Ready"
```

### 4.2 Create GitHub Repository
1. Go to [GitHub.com](https://github.com)
2. Click **"New Repository"**
3. Repository name: `wedesign` (or your preferred name)
4. Description: `Premium Logo Design Service Platform`
5. Choose **Public** or **Private**
6. **Don't** initialize with README (we already have one)
7. Click **"Create repository"**

### 4.3 Connect and Push
```bash
# Replace YOUR_USERNAME with your actual GitHub username
git remote add origin https://github.com/YOUR_USERNAME/wedesign.git
git branch -M main
git push -u origin main
```

## Step 5: Vercel Deployment

### 5.1 Connect to Vercel
1. Go to [vercel.com](https://vercel.com)
2. **Sign in** with your GitHub account
3. Click **"New Project"**
4. **Import** your WeDesign repository from GitHub
5. Vercel will auto-detect it as a **Vite** project

### 5.2 Configure Build Settings
Vercel should automatically detect:
- **Framework Preset**: Vite
- **Build Command**: `npm run build`
- **Output Directory**: `dist`
- **Install Command**: `npm install`
- **Node.js Version**: 18.x (recommended)

### 5.3 Add Environment Variables in Vercel
In Vercel project settings → **Environment Variables**, add each of these:

```
Name: VITE_SUPABASE_URL
Value: https://your-project-id.supabase.co

Name: VITE_SUPABASE_ANON_KEY
Value: eyJ...your_anon_key_here

Name: VITE_STRIPE_PUBLISHABLE_KEY
Value: pk_live_...your_publishable_key

Name: SUPABASE_SERVICE_ROLE_KEY
Value: eyJ...your_service_role_key

Name: STRIPE_SECRET_KEY
Value: sk_live_...your_secret_key
```

### 5.4 Deploy
1. Click **"Deploy"** 
2. Wait for build to complete (2-4 minutes)
3. Your site will be live at: `https://your-project-name.vercel.app`

## Step 6: Post-Deployment Configuration

### 6.1 Update Supabase Settings
1. Go to Supabase Dashboard → Authentication → Settings
2. **Site URL**: Add your Vercel URL
   ```
   https://your-project-name.vercel.app
   ```
3. **Additional Redirect URLs**: Add wildcard
   ```
   https://your-project-name.vercel.app/**
   ```

### 6.2 Configure Stripe Webhooks (Important!)
1. Go to Stripe Dashboard → Developers → Webhooks
2. **Add endpoint**: `https://your-project-name.vercel.app/api/webhook`
3. Select events:
   - `payment_intent.succeeded`
   - `payment_intent.payment_failed`
   - `payment_intent.created`

### 6.3 Deploy Supabase Edge Functions
```bash
# Install Supabase CLI (if not installed)
npm install -g supabase

# Login to Supabase
supabase login

# Link to your project (replace with your project ID)
supabase link --project-ref your-project-id

# Deploy server functions
supabase functions deploy make-server-d0d1e627
```

## Step 7: Testing Your Live Site

### 7.1 Basic Functionality Checklist
Visit your live site and verify:
- ✅ Homepage loads correctly with proper styling
- ✅ Navigation works (all menu items functional)
- ✅ User registration/login functions
- ✅ Payment processing works (test with Stripe test cards)
- ✅ Admin dashboard accessible
- ✅ No console errors in browser DevTools
- ✅ Mobile responsive design works
- ✅ All images and assets load properly

### 7.2 Test Payment Flow
Use Stripe test card numbers:
- **Success**: `4242 4242 4242 4242`
- **Decline**: `4000 0000 0000 0002`
- **Requires Authentication**: `4000 0025 0000 3155`

## Step 8: Optional - Custom Domain

### 8.1 Add Custom Domain
1. In Vercel: Project Settings → Domains
2. Add your domain: `yourdomain.com`
3. Configure DNS as instructed by Vercel

### 8.2 Update URLs
After custom domain:
- Update Supabase redirect URLs
- Update Stripe webhook URLs
- Test all functionality

## 🚨 Important Security Reminders

1. **Environment Variables**: Never commit `.env` files to GitHub
2. **API Keys**: Use Live Stripe keys only in production
3. **Service Role Key**: Keep Supabase service role key secure
4. **HTTPS**: Vercel automatically provides HTTPS
5. **Monitoring**: Set up error monitoring and analytics

## 🎯 Quick Command Summary

```bash
# 1. Clean up project
node cleanup-project.js

# 2. Commit to GitHub
git add .
git commit -m "Production ready: WeDesign platform"
git remote add origin https://github.com/YOUR_USERNAME/wedesign.git
git push -u origin main

# 3. Deploy Supabase functions (after Vercel deployment)
supabase functions deploy make-server-d0d1e627
```

## 🆘 Troubleshooting

### Build Failures:
- Verify Node.js 18+ is being used
- Check all dependencies in package.json
- Review Vercel build logs for specific errors

### Runtime Errors:
- Verify all environment variables are set in Vercel
- Check browser console for JavaScript errors
- Review Vercel function logs

### Payment Issues:
- Confirm Stripe keys are correct format and mode
- Verify webhook endpoints are configured
- Check CORS settings in Supabase

### Database Connection Issues:
- Verify Supabase project is active
- Check database permissions
- Review Edge Function logs in Supabase dashboard

## 🎉 Success!

Once all steps are complete, your WeDesign platform will be:
- ✅ **Live** on the internet with HTTPS
- ✅ **Fully functional** with payment processing
- ✅ **Secure** with proper environment variable handling
- ✅ **Professional** with custom domain (optional)
- ✅ **Ready for customers** to use immediately

**Your premium logo design service is now live and ready to serve customers worldwide!** 🌍

---

**Need help?** Check the Vercel deployment logs and Supabase dashboard if you encounter any issues. The most common problems are related to environment variables not being set correctly.