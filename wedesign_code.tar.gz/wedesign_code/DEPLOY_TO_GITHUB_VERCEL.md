# 🚀 WeDesign - Complete GitHub & Vercel Deployment Guide

## 📋 Pre-Deployment Checklist

### Step 1: Clean Up Project
```bash
# Run the cleanup script to remove redundant files
node cleanup-project.js
```

### Step 2: Verify Project Structure
Make sure these essential files exist:
- ✅ `App.tsx` (main application)
- ✅ `package.json` (dependencies)
- ✅ `vercel.json` (deployment config)
- ✅ `.env.example` (environment template)
- ✅ `styles/globals.css` (styling)
- ✅ `components/` directory
- ✅ `utils/` directory

## 🔧 Environment Configuration

### Required Environment Variables
You'll need these for production:

```bash
# Supabase Configuration
VITE_SUPABASE_URL=https://your-project-id.supabase.co
VITE_SUPABASE_ANON_KEY=eyJ...your_anon_key

# Stripe Configuration (Use LIVE keys for production)
VITE_STRIPE_PUBLISHABLE_KEY=pk_live_...your_publishable_key

# Server-side keys (for Supabase Edge Functions)
SUPABASE_SERVICE_ROLE_KEY=eyJ...your_service_role_key
STRIPE_SECRET_KEY=sk_live_...your_secret_key
```

### How to Get Your API Keys

#### 🗄️ Supabase Keys:
1. Go to [supabase.com](https://supabase.com)
2. Select your project
3. Settings → API
4. Copy:
   - **URL**: `https://your-project.supabase.co`
   - **anon public**: `eyJ...` (starts with eyJ)
   - **service_role**: `eyJ...` (keep this secure!)

#### 💳 Stripe Keys:
1. Go to [dashboard.stripe.com](https://dashboard.stripe.com)
2. Developers → API Keys
3. **For Production**: Use **Live** keys (pk_live_, sk_live_)
4. **For Testing**: Use **Test** keys (pk_test_, sk_test_)

## 📁 GitHub Repository Setup

### 1. Initialize Git Repository
```bash
# Initialize git (if not already done)
git init

# Add all cleaned files
git add .

# Create initial commit
git commit -m "Initial commit: WeDesign Premium Logo Design Platform"
```

### 2. Create GitHub Repository
1. Go to [GitHub.com](https://github.com)
2. Click **"New Repository"**
3. Repository name: `wedesign` (or your preferred name)
4. Description: `Premium Logo Design Service Platform`
5. Choose **Public** or **Private**
6. **Don't** initialize with README (we already have one)
7. Click **"Create repository"**

### 3. Connect and Push to GitHub
```bash
# Add GitHub remote (replace YOUR_USERNAME with your GitHub username)
git remote add origin https://github.com/YOUR_USERNAME/wedesign.git

# Push to GitHub
git push -u origin main
```

## 🌐 Vercel Deployment

### 1. Connect to Vercel
1. Go to [vercel.com](https://vercel.com)
2. **Sign in** with your GitHub account
3. Click **"New Project"**
4. **Import** your WeDesign repository from GitHub
5. Vercel will auto-detect it as a **Vite** project

### 2. Configure Build Settings
Vercel should auto-detect these settings:
- **Framework Preset**: Vite
- **Build Command**: `npm run build`
- **Output Directory**: `dist`
- **Install Command**: `npm install`

### 3. Add Environment Variables
In Vercel project settings → **Environment Variables**, add:

```
VITE_SUPABASE_URL
https://your-project-id.supabase.co

VITE_SUPABASE_ANON_KEY
eyJ...your_anon_key_here

VITE_STRIPE_PUBLISHABLE_KEY
pk_live_...your_publishable_key

SUPABASE_SERVICE_ROLE_KEY
eyJ...your_service_role_key

STRIPE_SECRET_KEY
sk_live_...your_secret_key
```

### 4. Deploy
1. Click **"Deploy"**
2. Wait for build to complete (2-3 minutes)
3. Your site will be live at: `https://your-project-name.vercel.app`

## 🔗 Post-Deployment Configuration

### 1. Update Supabase CORS Settings
1. Go to Supabase Dashboard
2. Authentication → Settings
3. **Site URL**: Add your Vercel URL
   ```
   https://your-project-name.vercel.app
   ```
4. **Additional Redirect URLs**: Add wildcard
   ```
   https://your-project-name.vercel.app/**
   ```

### 2. Configure Stripe Webhooks
1. Go to Stripe Dashboard → Developers → Webhooks
2. **Add endpoint**:
   ```
   https://your-project-name.vercel.app/api/stripe/webhook
   ```
3. Select events:
   - `payment_intent.succeeded`
   - `payment_intent.payment_failed`

### 3. Deploy Supabase Edge Functions
```bash
# Install Supabase CLI (if not installed)
npm install -g supabase

# Login to Supabase
supabase login

# Link to your project
supabase link --project-ref your-project-id

# Deploy server function
supabase functions deploy make-server-d0d1e627
```

## ✅ Testing & Verification

### 1. Basic Functionality Test
Visit your live site and verify:
- ✅ Homepage loads correctly
- ✅ Navigation works
- ✅ User registration/login functions
- ✅ Payment processing works
- ✅ Admin dashboard accessible
- ✅ No console errors

### 2. Performance Check
- ✅ Fast loading times
- ✅ Mobile responsive design
- ✅ Images load properly
- ✅ All links work

## 🎯 Custom Domain (Optional)

### 1. Add Custom Domain
1. In Vercel: Project Settings → Domains
2. Add your domain: `yourdomain.com`
3. Configure DNS as instructed by Vercel

### 2. Update Environment URLs
- Update CORS settings in Supabase
- Update Stripe webhook URLs
- Test all functionality with new domain

## 🚨 Important Security Notes

1. **Environment Variables**: Never commit `.env` files to GitHub
2. **API Keys**: Use Live Stripe keys only in production
3. **Service Role**: Keep Supabase service role key secure
4. **HTTPS**: Vercel automatically enables HTTPS
5. **Monitoring**: Monitor usage in Supabase and Stripe dashboards

## 🔧 Troubleshooting

### Build Failures
- Check Node.js version (18+)
- Verify all dependencies in package.json
- Review build logs in Vercel dashboard

### Runtime Errors
- Verify environment variables are set correctly
- Check browser console for JavaScript errors
- Review Vercel function logs

### Payment Issues
- Confirm Stripe keys are correct format
- Verify webhook endpoints are configured
- Check CORS settings in Supabase

### Database Issues
- Verify Supabase connection
- Check database permissions
- Review Edge Function logs

## 📞 Support & Next Steps

### After Successful Deployment:
1. **Test thoroughly** with real payment scenarios
2. **Monitor performance** using Vercel Analytics
3. **Set up error tracking** for production monitoring
4. **Create backup strategy** for your data
5. **Document any custom configurations** for team members

### If You Need Help:
- Check Vercel deployment logs
- Review Supabase dashboard for errors
- Test environment variables locally first
- Ensure all API keys are valid and properly formatted

---

## 🎉 Success!

Once all steps are complete, your WeDesign platform will be:
- ✅ Live on the internet
- ✅ Fully functional with payments
- ✅ Secure with HTTPS
- ✅ Ready for customers
- ✅ Professionally deployed

**Your premium logo design service is now ready to serve customers worldwide!** 🌍

---

### Quick Commands Summary:
```bash
# 1. Clean up
node cleanup-project.js

# 2. Git setup
git add .
git commit -m "Ready for deployment"
git remote add origin https://github.com/YOUR_USERNAME/wedesign.git
git push -u origin main

# 3. Deploy to Vercel (via web interface)
# 4. Add environment variables
# 5. Test everything
```