# WeDesign Typography System Guidelines

## Typography Hierarchy

### Font Families
* **Headlines (H1-H3)**: Playfair Display - A modern serif font that balances elegance and professionalism, perfect for luxury branding
* **Body Text & UI**: Inter - Clean, highly legible sans-serif for optimal readability across all devices

### Font Size Guidelines
* **H1 (Page Titles)**: 
  - Mobile: 2.25rem (36px)
  - Tablet: 2.75rem (44px) 
  - Desktop: 3rem (48px)
* **H2 (Section Headers)**: 
  - Mobile: 1.875rem (30px)
  - Tablet+: 2.25rem (36px)
* **H3 (Subsection Titles)**: 
  - Mobile: 1.5rem (24px)
  - Tablet+: 1.75rem (28px)
* **H4 (Component Titles)**: 1.375rem (22px)
* **H5 (Small Headers)**: 1.125rem (18px)
* **H6 (Tiny Headers)**: 1rem (16px)
* **Body Text**: 1rem (16px)
* **Lead Text**: 1.125rem-1.25rem (18px-20px) responsive
* **Small Text**: 0.875rem (14px)

### Font Weight Guidelines
* **Headings**: 
  - H1: font-extrabold (800) for maximum impact
  - H2: font-bold (700) for section headers
  - H3: font-semibold (600) for subsection titles
  - H4-H6: font-semibold (600) for component titles
* **Body**: font-normal (400) for regular text, font-medium (500) for emphasis

### Letter Spacing (Tracking)
* **Large Headlines (H1)**: -0.02em (tighter spacing for impact)
* **Section Headers (H2)**: -0.01em (slightly tighter)
* **Smaller Headings (H3)**: -0.005em (subtle adjustment)

### Usage Rules
1. **Never override default typography** unless specifically required by design
2. **Use CSS variables** for consistency: `var(--font-heading)` and `var(--font-body)`
3. **Add tracking classes** for large headlines: `tracking-tight` or `tracking-tighter`
4. **Maintain hierarchy**: H1 > H2 > H3 > H4 in visual weight
5. **Use utility classes**: `.font-heading`, `.font-body`, `.heading-luxury` when needed

### Color System
* **Primary Text**: `text-ink-deep-brown` (#301F0F)
* **Secondary Text**: `text-muted-foreground` for less important content
* **Accent Text**: `text-gradient-gold` for highlights and important elements

## Component Guidelines

### WeDesign Components
* All custom components should respect the typography system
* Use explicit font-family CSS variables when needed: `style={{ fontFamily: 'var(--font-heading)' }}`
* Maintain consistent spacing and sizing across all components

### Button Typography
* Use `font-medium` for button text
* Size variations: sm (text-sm), md (text-base), lg (text-lg)
* Always use Inter font family for UI elements

## Implementation Notes
* The typography system is defined in `/styles/globals.css`
* Default HTML elements automatically use the correct fonts when no Tailwind classes override them
* Use Tailwind classes sparingly for typography - rely on semantic HTML when possible

## Mobile-First Design Guidelines

### Touch-Friendly Design
* **Minimum Touch Target**: 44px × 44px for all interactive elements
* **Button Heights**: sm (36px), md (44px), lg (48px)
* **Spacing**: Minimum 8px between touch targets
* **Form Elements**: Minimum 48px height for inputs and selects
* **Touch Target Class**: Use `touch-target` utility class for minimum sizing
* **Touch Area Class**: Use `touch-area` for proper padding around interactive elements

### Responsive Spacing
* **Mobile**: Compact padding (1rem), reduced gaps (0.75rem)
* **Tablet**: Medium padding (1.5rem), standard gaps (1rem)
* **Desktop**: Full padding (2rem), expanded gaps (1.5rem)
* **Responsive Padding**: Use `responsive-padding` utility class
* **Section Spacing**: Use `section-mobile` for consistent section padding

### Content Adaptation
* **Text Stacking**: Use flex-col on mobile, flex-row on larger screens
* **Grid Adaptation**: 1 column mobile → 2 columns tablet → 3 columns desktop
* **Navigation**: Collapsible mobile menu with touch-friendly 48px buttons

### Layout Patterns
* **Sections**: Use `.section-mobile` for responsive section padding
* **Cards**: Minimum 44px height, responsive padding
* **Modals**: Full-width on mobile with responsive breakpoints
* **Forms**: Stack form fields vertically on mobile

### Performance Considerations
* **Images**: Use responsive images with proper sizes
* **Interactions**: Optimize for touch vs hover states
* **Loading**: Consider mobile network speeds
* **Accessibility**: Ensure keyboard navigation works on all devices

## Component Naming Standards

### Page Components
* **Pattern**: `Page_[Name]` (e.g., `Page_Home`, `Page_AboutUs`)
* **Structure**: Always wrap content in responsive containers
* **Layout**: Use Container_Desktop → Container_Tablet → Container_Mobile hierarchy

### Section Components  
* **Pattern**: `Section_[Name]` (e.g., `Section_Hero`, `Section_Pricing`)
* **Spacing**: Use `section-mobile` for consistent responsive padding
* **Content**: Wrap in `Container_Content` with `max-w-7xl mx-auto responsive-padding`

### Layout Containers
* **Desktop**: `Container_Desktop` with `max-w-screen-2xl mx-auto`
* **Tablet**: `Container_Tablet` for tablet-specific adaptations
* **Mobile**: `Container_Mobile` for mobile-first content
* **Content**: `Container_Content` for section content with responsive padding

### Interactive Elements
* **Buttons**: `Button_[Purpose]` (e.g., `Button_StartNow`, `Button_Login`)
* **Inputs**: `Input_[Field]` (e.g., `Input_LogoSearch`, `Input_Email`) 
* **Selects**: `Select_[Type]` (e.g., `Select_Industry`, `Select_Color`)
* **Cards**: `Card_[Type]` (e.g., `Card_Logo`, `Card_Pricing`)

### Content Elements
* **Icons**: `Icon_[Name]` (e.g., `Icon_Search`, `Icon_Filter`)
* **Images**: `Image_[Purpose]` (e.g., `Image_Logo`, `Image_Hero`)
* **Text**: `Text_[Role]` (e.g., `Text_Title`, `Text_Description`)
* **Labels**: `Label_[Field]` for form field labels

### Modal Components
* **Pattern**: `Modal_[Type]` (e.g., `Modal_StartProject`, `Modal_Login`)
* **Content**: Use `Container_ModalContent` for main modal body
* **Structure**: Maintain consistent header, content, footer structure

## Responsive Structure Standards

### Auto Layout Equivalent Pattern
```jsx
<div className="Page_[Name]">
  <div className="Container_Desktop max-w-screen-2xl mx-auto">
    <div className="Container_Tablet">
      <div className="Container_Mobile">
        <Section_[Name] />
        // Additional sections...
      </div>
    </div>
  </div>
</div>
```

### Grid System
* **Mobile**: `grid-cols-1` (single column stacking)
* **Tablet**: `md:grid-cols-2` (two column layout)
* **Desktop**: `lg:grid-cols-3` or `xl:grid-cols-4` (multi-column)
* **Gaps**: Use consistent spacing - `gap-4`, `gap-6`, `gap-8`

### Flexbox Patterns
* **Mobile**: `flex flex-col` (vertical stacking)
* **Tablet+**: `sm:flex-row` (horizontal layout)
* **Alignment**: Use `items-center`, `justify-between`, `justify-center`
* **Wrap**: Use `flex-wrap` when content might overflow

## Production Deployment Guidelines

### Code Quality Standards
* **Clean Architecture**: Maintain proper component separation and file organization
* **Performance**: Optimize images, lazy load components, minimize bundle size
* **SEO Ready**: Proper meta tags, semantic HTML structure, accessibility compliance
* **Type Safety**: Full TypeScript implementation with proper type definitions

### Deployment Readiness
* **Environment Variables**: Proper configuration for production vs development
* **Build Optimization**: Vite production build with asset optimization
* **Error Handling**: Comprehensive error boundaries and fallback states
* **Monitoring**: Analytics integration and error tracking

### Browser Compatibility
* **Modern Browsers**: Chrome 90+, Firefox 88+, Safari 14+, Edge 90+
* **Mobile Support**: iOS 14+, Android 10+
* **Progressive Enhancement**: Graceful degradation for older browsers
* **Accessibility**: WCAG 2.1 AA compliance

### Security Considerations
* **API Security**: Proper environment variable handling
* **Content Security**: XSS protection and secure data handling
* **Authentication**: Secure user session management
* **HTTPS**: SSL/TLS encryption for all communications