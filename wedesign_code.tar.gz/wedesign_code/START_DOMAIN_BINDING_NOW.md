# 🚀 WeDesign域名绑定 - 立即开始执行指南
## 将www.wedesign.design绑定到您的WeDesign网站

---

## ⚡ **现在立即开始 - 按顺序执行以下步骤**

### **第1步: 获取API密钥 (10分钟)**

#### **🔑 Supabase密钥获取**

1. **访问Supabase Dashboard**
   - 打开: https://supabase.com/dashboard
   - 登录您的账户

2. **选择WeDesign项目**
   - 在项目列表中找到您的WeDesign项目
   - 点击进入项目

3. **获取API密钥**
   - 点击左侧菜单 "Settings" → "API"
   - 复制以下信息:
   ```
   Project URL: https://xxxxxxxxxxxxx.supabase.co
   Project API keys → anon public: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
   Project API keys → service_role: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
   ```

4. **保存密钥** (复制到记事本)
   ```
   SUPABASE_URL=https://xxxxxxxxxxxxx.supabase.co
   SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
   SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
   ```

#### **💳 Stripe密钥获取**

1. **访问Stripe Dashboard**
   - 打开: https://dashboard.stripe.com/apikeys
   - 登录您的账户

2. **复制API密钥**
   - Publishable key (以pk_开头): `pk_test_xxxxx` 或 `pk_live_xxxxx`
   - Secret key (以sk_开头): `sk_test_xxxxx` 或 `sk_live_xxxxx`

3. **保存密钥** (添加到记事本)
   ```
   STRIPE_PUBLISHABLE_KEY=pk_test_xxxxx
   STRIPE_SECRET_KEY=sk_test_xxxxx
   ```

---

### **第2步: 配置环境变量 (5分钟)**

#### **创建.env.local文件**

1. **在项目根目录创建文件**
   - 文件名: `.env.local`
   - 如果文件已存在，请编辑它

2. **填入所有密钥**
   ```bash
   # Supabase 配置
   NEXT_PUBLIC_SUPABASE_URL=https://你的项目ID.supabase.co
   NEXT_PUBLIC_SUPABASE_ANON_KEY=你的anon密钥
   SUPABASE_SERVICE_ROLE_KEY=你的service_role密钥

   # Stripe 配置
   NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=你的pk_密钥
   STRIPE_SECRET_KEY=你的sk_密钥

   # 网站配置
   NEXT_PUBLIC_SITE_URL=https://www.wedesign.design
   NEXT_PUBLIC_SITE_NAME="WeDesign - Worldwide Design Best Delivered"

   # 环境设置
   NODE_ENV=production
   ```

3. **保存文件**
   - 确保所有密钥都正确填入
   - 检查没有多余的空格

---

### **第3步: Vercel部署 (15分钟)**

#### **3A. 创建Vercel账户**

1. **注册Vercel**
   - 访问: https://vercel.com
   - 点击 "Sign Up"
   - 选择 "Continue with GitHub" (推荐)

2. **完成注册**
   - 授权GitHub访问
   - 完成账户设置

#### **3B. 上传项目**

**方式1: 直接上传文件夹 (推荐)**

1. **登录Vercel Dashboard**
   - 进入: https://vercel.com/dashboard

2. **创建新项目**
   - 点击 "New Project"
   - 选择 "Browse All Templates"
   - 点击 "Upload" 选项卡

3. **上传WeDesign项目**
   - 将整个WeDesign项目文件夹拖拽到上传区域
   - 或点击选择文件夹

4. **配置项目设置**
   ```
   Project Name: wedesign-website
   Framework Preset: Create React App
   Root Directory: ./
   Build Command: npm run build
   Output Directory: build
   Install Command: npm install
   ```

5. **点击Deploy**
   - Vercel会自动开始构建和部署

#### **3C. 配置环境变量**

**在Vercel部署完成后:**

1. **进入项目设置**
   - 在Vercel Dashboard中找到您的wedesign-website项目
   - 点击项目名称进入

2. **添加环境变量**
   - 点击 "Settings" 选项卡
   - 点击 "Environment Variables"
   - 逐一添加以下变量:

   ```
   Variable Name: NEXT_PUBLIC_SUPABASE_URL
   Value: https://你的项目ID.supabase.co
   Environment: Production, Preview, Development
   ```

   ```
   Variable Name: NEXT_PUBLIC_SUPABASE_ANON_KEY
   Value: 你的anon密钥
   Environment: Production, Preview, Development
   ```

   ```
   Variable Name: SUPABASE_SERVICE_ROLE_KEY
   Value: 你的service_role密钥
   Environment: Production, Preview, Development
   ```

   ```
   Variable Name: NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY
   Value: 你的pk_密钥
   Environment: Production, Preview, Development
   ```

   ```
   Variable Name: STRIPE_SECRET_KEY
   Value: 你的sk_密钥
   Environment: Production, Preview, Development
   ```

   ```
   Variable Name: NEXT_PUBLIC_SITE_URL
   Value: https://www.wedesign.design
   Environment: Production, Preview, Development
   ```

3. **重新部署**
   - 回到 "Deployments" 选项卡
   - 点击最新部署右侧的 "..." 按钮
   - 选择 "Redeploy"

---

### **第4步: GoDaddy DNS配置 (10分钟)**

#### **4A. 登录GoDaddy**

1. **访问GoDaddy**
   - 打开: https://sso.godaddy.com
   - 输入您的账户和密码登录

2. **进入域名管理**
   - 点击 "My Products"
   - 找到 `wedesign.design` 域名
   - 点击域名后的 "DNS" 或 "Manage DNS" 按钮

#### **4B. 配置DNS记录**

**⚠️ 重要: 先备份现有DNS设置**

1. **截图保存现有DNS记录**
   - 以防需要恢复

2. **删除冲突记录**
   - 删除现有的A记录 (如果有指向其他IP)
   - 删除现有的CNAME记录 (如果有指向其他服务)
   - **保留所有MX记录** (邮件服务)
   - **保留所有TXT记录** (域名验证)

3. **添加新的DNS记录**

   **A记录 (主域名)**
   ```
   Type: A
   Name: @ (或留空)
   Value: 76.76.19.61
   TTL: 600 (10分钟)
   ```

   **CNAME记录 (www子域名)**
   ```
   Type: CNAME
   Name: www
   Points to: cname.vercel-dns.com
   TTL: 600 (10分钟)
   ```

4. **保存更改**
   - 点击 "Save" 或 "Save All Changes"
   - 确认所有更改已保存

---

### **第5步: Vercel域名绑定 (5分钟)**

#### **5A. 添加自定义域名**

1. **回到Vercel项目**
   - 进入您的wedesign-website项目
   - 点击 "Settings" → "Domains"

2. **添加域名**
   - 在 "Add Domain" 输入框中输入: `wedesign.design`
   - 点击 "Add"
   - 等待验证（可能显示警告，这是正常的）

3. **添加www域名**
   - 再次在输入框中输入: `www.wedesign.design`
   - 点击 "Add"

#### **5B. 设置主域名**

1. **配置重定向**
   - 确保 `www.wedesign.design` 设置为主域名
   - `wedesign.design` 应该自动重定向到 `www.wedesign.design`

2. **等待验证**
   - 域名状态应该显示为 "Valid Configuration"
   - 如果显示错误，等待DNS传播（最多48小时）

---

### **第6步: 测试验证 (10分钟)**

#### **6A. DNS传播检查**

1. **使用在线工具检查**
   - 访问: https://www.whatsmydns.net/
   - 输入: `www.wedesign.design`
   - 检查全球DNS传播状态

2. **本地命令行检查** (可选)
   ```bash
   # Windows命令提示符
   nslookup www.wedesign.design

   # 应该解析到Vercel的IP地址
   ```

#### **6B. 网站功能测试**

**当DNS传播完成后 (通常2-6小时):**

1. **访问主要页面**
   - ✅ https://www.wedesign.design/ (首页)
   - ✅ https://www.wedesign.design/logos-design (Logo设计)
   - ✅ https://www.wedesign.design/design-hall (作品展示)
   - ✅ https://www.wedesign.design/about-us (关于我们)
   - ✅ https://www.wedesign.design/blog (博客)

2. **检查HTTPS**
   - 浏览器地址栏应显示锁图标
   - 自动从HTTP重定向到HTTPS

3. **测试核心功能**
   - 页面加载速度
   - 导航功能
   - 移动端适配
   - 用户注册/登录
   - 管理员后台: https://www.wedesign.design/admin

---

## 🎯 **预期时间线**

| 步骤 | 预期用时 | 说明 |
|------|----------|------|
| 获取API密钥 | 10分钟 | 从Supabase和Stripe复制密钥 |
| 配置环境变量 | 5分钟 | 创建.env.local文件 |
| Vercel部署 | 15分钟 | 上传项目并配置 |
| GoDaddy DNS | 10分钟 | 设置A记录和CNAME |
| 域名绑定 | 5分钟 | 在Vercel添加域名 |
| **等待DNS传播** | **2-48小时** | **通常2-6小时** |
| 功能验证 | 10分钟 | 测试所有页面和功能 |

---

## ⚠️ **重要提醒**

### **关于DNS传播时间**
- **最快**: 2-6小时
- **最慢**: 48小时
- **全球不同地区传播时间不同**

### **常见问题处理**
1. **如果网站无法访问**
   - 等待更长时间让DNS传播
   - 清除浏览器缓存
   - 尝试使用手机数据访问

2. **如果显示SSL错误**
   - 等待Vercel自动配置SSL证书
   - 在Vercel Dashboard中刷新域名设置

3. **如果功能异常**
   - 检查Vercel环境变量配置
   - 查看Vercel构建日志是否有错误

---

## 🎉 **完成确认**

### **部署成功的标志**
- ✅ Vercel项目显示 "Ready" 状态
- ✅ 域名状态显示 "Valid Configuration"
- ✅ https://www.wedesign.design 可以正常访问
- ✅ 所有页面加载正常
- ✅ SSL证书有效 (浏览器显示锁图标)

### **您的网站将具备**
- 🌐 专业域名: www.wedesign.design
- 🔒 自动HTTPS和SSL证书
- ⚡ 全球CDN加速
- 💳 完整支付系统
- 👥 用户管理功能
- 🛡️ 管理员后台
- 📱 移动端优化

---

## 📞 **需要帮助时**

### **遇到问题联系我**
请提供以下信息以获得快速帮助:
1. 您当前执行到哪一步
2. 遇到的具体错误信息
3. 错误发生的时间
4. 截图 (如果有错误页面)

### **常用检查工具**
- DNS传播: https://www.whatsmydns.net/
- SSL检查: https://www.ssllabs.com/ssltest/
- 网站速度: https://gtmetrix.com/

---

**🚀 现在开始第1步：获取Supabase和Stripe API密钥！**

**几小时后，您的WeDesign网站将在www.wedesign.design正式上线！** ✨