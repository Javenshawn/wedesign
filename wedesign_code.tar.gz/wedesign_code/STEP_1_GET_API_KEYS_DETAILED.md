# 🔑 第1步：获取API密钥 - 详细操作指导
## 为WeDesign网站域名绑定准备必要的API密钥

---

## 📋 **预计用时：10-15分钟**

### **您将获取的密钥：**
- ✅ Supabase项目URL
- ✅ Supabase匿名公开密钥 (anon key)
- ✅ Supabase服务角色密钥 (service_role key)
- ✅ Stripe发布密钥 (publishable key)
- ✅ Stripe私密密钥 (secret key)

---

## 🗃️ **准备工作 (1分钟)**

### **打开记事本或文本编辑器**
在开始前，请打开一个文本编辑器用于保存获取的密钥：
- **Windows**: 记事本 (Notepad)
- **Mac**: 文本编辑 (TextEdit)
- **在线**: 任何文本编辑器

**创建一个新文档，标题为：WeDesign API密钥**

---

## 🔵 **步骤A：获取Supabase密钥 (5-7分钟)**

### **A1. 访问Supabase Dashboard**

1. **打开浏览器**
   - 在地址栏输入: https://supabase.com/dashboard
   - 按 Enter 键访问

2. **登录您的账户**
   - 如果未登录，点击 "Sign In"
   - 输入您的邮箱和密码
   - 点击 "Sign In" 登录

### **A2. 选择WeDesign项目**

1. **在项目列表中找到您的WeDesign项目**
   - 项目名称可能是 "wedesign"、"WeDesign"、"logo-design" 或类似名称
   - 如果您有多个项目，选择用于WeDesign网站的那个

2. **点击项目名称**
   - 进入项目的主Dashboard

### **A3. 获取项目URL**

1. **在项目Dashboard中查看**
   - 您会看到项目URL显示在页面上方
   - 格式类似：`https://xxxxxxxxxxx.supabase.co`

2. **复制项目URL**
   - 选中完整的URL
   - 复制 (Ctrl+C 或 Cmd+C)

3. **保存到记事本**
   ```
   === WeDesign API密钥 ===
   
   SUPABASE_URL=https://你复制的项目ID.supabase.co
   ```

### **A4. 获取API密钥**

1. **点击左侧菜单中的 "Settings"**
   - 在左侧导航栏找到齿轮图标的 "Settings"
   - 点击进入设置页面

2. **点击 "API"**
   - 在Settings页面中，找到并点击 "API" 选项
   - 这会显示所有API密钥

### **A5. 复制anon密钥**

1. **找到 "anon public" 密钥**
   - 在API页面中，找到标题为 "anon public" 的部分
   - 这是一个很长的字符串，以 `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9` 开头

2. **点击复制按钮**
   - 在密钥右侧有一个复制图标
   - 点击复制整个密钥

3. **保存到记事本**
   ```
   SUPABASE_URL=https://你的项目ID.supabase.co
   SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...你复制的完整密钥
   ```

### **A6. 复制service_role密钥**

1. **找到 "service_role" 密钥**
   - 在同一个API页面中，向下滚动找到 "service_role" 部分
   - 这也是一个很长的字符串，以 `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9` 开头

2. **点击复制按钮**
   - 点击service_role密钥右侧的复制图标

3. **保存到记事本**
   ```
   SUPABASE_URL=https://你的项目ID.supabase.co
   SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
   SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...你复制的service_role密钥
   ```

---

## 💳 **步骤B：获取Stripe密钥 (5-7分钟)**

### **B1. 访问Stripe Dashboard**

1. **打开新标签页**
   - 在浏览器中打开新标签页
   - 在地址栏输入: https://dashboard.stripe.com
   - 按 Enter 键访问

2. **登录Stripe账户**
   - 如果未登录，点击 "Sign in"
   - 输入您的Stripe账户邮箱和密码
   - 完成登录

### **B2. 进入API密钥页面**

1. **点击左侧菜单中的 "Developers"**
   - 在左侧导航栏找到 "Developers" 选项
   - 点击展开开发者菜单

2. **点击 "API keys"**
   - 在Developers子菜单中点击 "API keys"
   - 这会显示您的API密钥页面

### **B3. 确认环境模式**

1. **查看页面右上角的环境切换器**
   - 您会看到 "Test mode" 或 "Live mode"
   - **对于测试**: 使用 "Test mode"
   - **对于生产**: 使用 "Live mode"

2. **为初始测试，建议先使用 Test mode**

### **B4. 复制Publishable key**

1. **找到 "Publishable key"**
   - 在API keys页面中，找到 "Publishable key" 部分
   - 这个密钥以 `pk_test_` (测试模式) 或 `pk_live_` (生产模式) 开头

2. **点击 "Reveal live key" 或显示按钮**
   - 密钥可能被隐藏，点击显示按钮
   - 然后点击复制图标

3. **保存到记事本**
   ```
   SUPABASE_URL=https://你的项目ID.supabase.co
   SUPABASE_ANON_KEY=eyJhbGciOiJI...
   SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJI...
   
   STRIPE_PUBLISHABLE_KEY=pk_test_你复制的发布密钥
   ```

### **B5. 复制Secret key**

1. **找到 "Secret key"**
   - 在同一页面中，找到 "Secret key" 部分
   - 这个密钥以 `sk_test_` (测试模式) 或 `sk_live_` (生产模式) 开头

2. **点击 "Reveal live key" 或显示按钮**
   - Secret key通常是隐藏的
   - 点击显示，然后复制

3. **保存到记事本**
   ```
   SUPABASE_URL=https://你的项目ID.supabase.co
   SUPABASE_ANON_KEY=eyJhbGciOiJI...
   SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJI...
   
   STRIPE_PUBLISHABLE_KEY=pk_test_你的发布密钥
   STRIPE_SECRET_KEY=sk_test_你复制的私密密钥
   ```

---

## ✅ **验证您的密钥格式**

### **确认您获取的密钥格式正确：**

**Supabase密钥应该是这样的：**
```
SUPABASE_URL=https://abcdefghijklmnop.supabase.co
SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZi...
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZi...
```

**Stripe密钥应该是这样的：**
```
STRIPE_PUBLISHABLE_KEY=pk_test_51xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
STRIPE_SECRET_KEY=sk_test_51xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

**或者对于生产环境：**
```
STRIPE_PUBLISHABLE_KEY=pk_live_51xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
STRIPE_SECRET_KEY=sk_live_51xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

---

## 🔒 **安全提醒**

### **重要安全注意事项：**

⚠️ **SUPABASE_SERVICE_ROLE_KEY 和 STRIPE_SECRET_KEY 是高度敏感的**
- 这些密钥拥有完全的数据库和支付访问权限
- 绝不要分享或公开这些密钥
- 不要将它们提交到Git仓库

✅ **SUPABASE_ANON_KEY 和 STRIPE_PUBLISHABLE_KEY 可以安全暴露**
- 这些是公开密钥，设计为在前端使用
- 它们有内置的安全限制

---

## 📝 **最终密钥清单**

### **在进入下一步前，确认您有以下5个密钥：**

```bash
# 必须有的5个密钥:
SUPABASE_URL=https://你的项目.supabase.co
SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIs...
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIs...
STRIPE_PUBLISHABLE_KEY=pk_test_或pk_live_...
STRIPE_SECRET_KEY=sk_test_或sk_live_...
```

### **检查清单：**
- [ ] Supabase URL以 https:// 开头，以 .supabase.co 结尾
- [ ] 两个Supabase密钥都以 eyJhbGciOiJIUzI1NiIs 开头
- [ ] Stripe发布密钥以 pk_test_ 或 pk_live_ 开头
- [ ] Stripe私密密钥以 sk_test_ 或 sk_live_ 开头
- [ ] 所有密钥都已保存在安全的地方

---

## 🎯 **完成第1步后的下一步**

### **恭喜！您已经完成了第1步**

**接下来您需要：**

1. **保持记事本打开** - 您很快就会用到这些密钥
2. **准备进入第2步** - 配置环境变量文件
3. **确保密钥安全** - 不要关闭包含密钥的记事本

### **立即继续第2步**
当您确认所有5个密钥都正确获取后，告诉我：
**"我已经获取了所有5个API密钥，准备进入第2步"**

我将为您提供第2步的详细操作指导：创建和配置.env.local文件。

---

## 🆘 **如果遇到问题**

### **常见问题解决：**

**问题1: 找不到WeDesign项目**
- 确认您登录了正确的Supabase账户
- 检查项目是否在其他组织或团队下
- 项目名称可能与"WeDesign"不完全相同

**问题2: 密钥无法复制**
- 尝试手动选择密钩并复制
- 确保浏览器允许剪贴板访问
- 刷新页面后重试

**问题3: Stripe密钥不可见**
- 确认您有查看API密钥的权限
- 如果是团队账户，可能需要管理员权限
- 尝试切换到Test mode查看测试密钥

**问题4: 密钥格式看起来不对**
- 确认复制了完整的密钥，没有截断
- 检查是否包含了额外的空格或换行
- 重新复制确保格式正确

### **需要帮助时**
如果遇到任何问题，请提供：
1. 您遇到问题的具体步骤
2. 错误信息或看到的情况
3. 您使用的浏览器和操作系统

---

**🚀 现在开始执行第1步：获取您的API密钥！**