# 🔍 Supabase账户验证和WeDesign项目设置指南
## 解决无法在Supabase控制台找到项目的问题

---

## 📋 **问题确认**

### **当前情况分析：**
- ✅ **您的Supabase账户**: `Javen1984@gmail.com`
- ⚠️ **项目中当前配置**: `znmqppppruhlzhqvwtyp` (自动生成的测试项目)
- ❌ **问题**: 在您的个人Supabase控制台中找不到此项目

### **根本原因：**
**项目ID `znmqppppruhlzhqvwtyp` 是Figma Make环境的测试项目，不属于您的个人Supabase账户。**

---

## 🎯 **解决方案：使用您的Supabase账户创建WeDesign项目**

### **步骤1: 验证Supabase账户访问 (2分钟)**

1. **访问Supabase控制台**
   - 打开：https://supabase.com/dashboard
   - 使用 `Javen1984@gmail.com` 登录

2. **确认账户状态**
   - 检查是否能正常登录
   - 查看现有项目列表
   - 确认账户权限正常

### **步骤2: 创建WeDesign专用项目 (5分钟)**

1. **创建新项目**
   ```
   点击 "New Project"
   
   Project details:
   Name: wedesign-production
   Database Password: [创建强密码并保存]
   Region: Southeast Asia (Singapore) [或选择最近的地区]
   Pricing Plan: Free tier (可以后续升级)
   ```

2. **等待项目创建完成**
   - 项目创建需要1-2分钟
   - 完成后会显示项目控制台

### **步骤3: 获取正确的API密钥 (3分钟)**

1. **进入项目设置**
   - 点击左侧菜单中的 "Settings"
   - 点击 "API" 子菜单

2. **复制必需的密钥**
   ```
   Project URL: https://[您的项目ID].supabase.co
   anon public key: eyJhbGciOiJIUzI1NiIs... (复制完整密钥)
   service_role key: eyJhbGciOiJIUzI1NiIs... (复制完整密钥)
   ```

### **步骤4: 设置数据库表结构 (5分钟)**

1. **创建数据库表**
   - 点击左侧菜单 "Database" → "Tables"
   - 使用以下SQL创建基础表结构：

```sql
-- 用户表
CREATE TABLE profiles (
  id UUID REFERENCES auth.users ON DELETE CASCADE PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  full_name TEXT,
  avatar_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 项目表
CREATE TABLE projects (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT,
  package_type TEXT NOT NULL,
  status TEXT DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 订单表
CREATE TABLE orders (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
  amount DECIMAL(10,2) NOT NULL,
  currency TEXT DEFAULT 'USD',
  status TEXT DEFAULT 'pending',
  stripe_payment_intent_id TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 启用行级安全
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

-- 创建安全策略
CREATE POLICY "Users can view own profile" ON profiles
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update own profile" ON profiles
  FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Users can view own projects" ON projects
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can create own projects" ON projects
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view own orders" ON orders
  FOR SELECT USING (auth.uid() = user_id);
```

---

## ⚙️ **更新项目配置文件**

### **步骤5: 更新环境变量配置**

**创建新的 `.env.local` 文件：**

```bash
# ===== WeDesign生产环境配置 =====
# 基于您的个人Supabase账户 (Javen1984@gmail.com)

# ===== Supabase 配置 (您的项目密钥) =====
NEXT_PUBLIC_SUPABASE_URL=https://[您的新项目ID].supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=[您复制的anon密钥]
SUPABASE_SERVICE_ROLE_KEY=[您复制的service_role密钥]
SUPABASE_DB_URL=postgresql://postgres:[您的密码]@db.[您的项目ID].supabase.co:5432/postgres

# ===== Stripe 配置 =====
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_您的发布密钥
STRIPE_SECRET_KEY=sk_test_您的私密密钥

# ===== 网站配置 =====
NEXT_PUBLIC_SITE_URL=https://www.wedesign.design
NEXT_PUBLIC_SITE_NAME="WeDesign - Worldwide Design Best Delivered"
NODE_ENV=production
```

### **步骤6: 更新Supabase客户端配置**

**检查并更新 `/utils/supabase/client.ts`：**

```typescript
import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

export const supabase = createClient(supabaseUrl, supabaseAnonKey)
```

---

## 🔧 **配置认证设置**

### **步骤7: 设置用户认证 (3分钟)**

1. **在Supabase控制台中配置认证**
   - 点击 "Authentication" → "Settings"
   - 启用 "Email confirmations"
   - 配置 "Site URL": `https://www.wedesign.design`

2. **设置邮件模板**
   - 配置注册确认邮件
   - 设置密码重置邮件
   - 测试邮件发送功能

### **步骤8: 配置存储桶 (2分钟)**

1. **创建文件存储桶**
   - 点击 "Storage" → "Buckets"
   - 创建新桶：`project-files`
   - 设置公共访问策略

```sql
-- 存储桶策略
CREATE POLICY "Users can upload project files" ON storage.objects
  FOR INSERT WITH CHECK (auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can view project files" ON storage.objects
  FOR SELECT USING (auth.uid()::text = (storage.foldername(name))[1]);
```

---

## ✅ **验证设置是否正确**

### **步骤9: 测试配置 (5分钟)**

1. **测试数据库连接**
   ```bash
   # 在本地运行
   npm run dev
   ```

2. **测试用户注册流程**
   - 访问 `/login` 页面
   - 尝试注册新用户
   - 检查Supabase控制台中的用户列表

3. **测试数据存储**
   - 创建测试项目
   - 检查数据库中的记录
   - 验证文件上传功能

---

## 🚀 **最终确认清单**

### **完成后您应该能够：**
- ✅ **在您的Supabase控制台看到WeDesign项目**
- ✅ **在Authentication中看到注册用户**
- ✅ **在Database中看到项目数据**
- ✅ **在Storage中看到上传的文件**
- ✅ **本地开发环境正常工作**

---

## 📞 **如果仍然遇到问题**

### **可能的问题和解决方案：**

**问题1: 无法登录Supabase控制台**
- 确认邮箱地址正确：`Javen1984@gmail.com`
- 检查垃圾邮件中的验证邮件
- 尝试重置密码

**问题2: 项目创建失败**
- 检查网络连接
- 尝试不同的地区设置
- 联系Supabase支持

**问题3: API密钥无效**
- 确认复制了完整的密钥
- 检查项目ID是否正确
- 重新生成密钥

**问题4: 数据库连接错误**
- 验证数据库密码
- 检查连接字符串格式
- 确认防火墙设置

---

## 🎯 **立即行动步骤**

### **现在请执行以下操作：**

1. **登录您的Supabase账户**
   - 访问：https://supabase.com/dashboard
   - 使用：`Javen1984@gmail.com`

2. **创建WeDesign项目**
   - 项目名称：`wedesign-production`
   - 选择合适的地区

3. **获取正确的API密钥**
   - 复制项目URL
   - 复制anon密钥
   - 复制service_role密钥

4. **告诉我您的新项目信息**
   - 新的项目ID
   - 任何遇到的问题

### **完成后我将帮助您：**
- 更新项目配置文件
- 设置数据库结构
- 配置认证和存储
- 测试完整功能

---

**🔧 现在开始创建您的个人WeDesign Supabase项目！我会一步步指导您完成整个设置过程！** 🚀