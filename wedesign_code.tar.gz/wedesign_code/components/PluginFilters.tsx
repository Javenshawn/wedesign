import { Input } from "./ui/input";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Search, Filter, Grid, Star } from "lucide-react";
import { categories } from "../types/plugin";

interface PluginFiltersProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  selectedCategory: string;
  onCategoryChange: (category: string) => void;
  showInstalledOnly: boolean;
  onShowInstalledChange: (show: boolean) => void;
}

export function PluginFilters({
  searchQuery,
  onSearchChange,
  selectedCategory,
  onCategoryChange,
  showInstalledOnly,
  onShowInstalledChange
}: PluginFiltersProps) {
  return (
    <div className="space-y-6">
      
      {/* 标题 */}
      <div className="flex items-center gap-3">
        <div className="gradient-gold-soft rounded-lg p-2">
          <Filter className="w-4 h-4 text-white" />
        </div>
        <h3 className="font-heading text-accent-terra">筛选插件</h3>
      </div>

      {/* 搜索框 */}
      <div className="space-y-2">
        <label className="text-sm font-medium text-ink-deep-brown">搜索</label>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="搜索插件名称、开发者..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className="pl-10 input-glass border-glass-border bg-input-background touch-target"
          />
        </div>
      </div>

      {/* 分类筛选 */}
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <Grid className="w-4 h-4 text-accent-terra" />
          <label className="text-sm font-medium text-ink-deep-brown">分类</label>
        </div>
        
        <div className="space-y-2">
          {categories.map((category) => (
            <Button
              key={category}
              variant={selectedCategory === category ? "default" : "ghost"}
              size="sm"
              onClick={() => onCategoryChange(category)}
              className={`w-full justify-start text-left text-sm touch-target ${
                selectedCategory === category 
                  ? 'gradient-gold text-white shadow-gold' 
                  : 'button-glass hover-glass text-ink-soft-brown border-glass-border'
              }`}
            >
              {category}
              {selectedCategory === category && (
                <div className="ml-auto">
                  <div className="w-2 h-2 bg-white rounded-full"></div>
                </div>
              )}
            </Button>
          ))}
        </div>
      </div>

      {/* 其他筛选选项 */}
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <Star className="w-4 h-4 text-accent-terra" />
          <label className="text-sm font-medium text-ink-deep-brown">选项</label>
        </div>
        
        <div className="space-y-2">
          <Button
            variant={showInstalledOnly ? "default" : "ghost"}
            size="sm"
            onClick={() => onShowInstalledChange(!showInstalledOnly)}
            className={`w-full justify-start text-left text-sm touch-target ${
              showInstalledOnly 
                ? 'gradient-gold text-white shadow-gold' 
                : 'button-glass hover-glass text-ink-soft-brown border-glass-border'
            }`}
          >
            仅显示已安装
            {showInstalledOnly && (
              <div className="ml-auto">
                <div className="w-2 h-2 bg-white rounded-full"></div>
              </div>
            )}
          </Button>
        </div>
      </div>

      {/* 快捷筛选 */}
      <div className="space-y-3 pt-4 border-t border-glass-border">
        <label className="text-sm font-medium text-ink-deep-brown">快捷筛选</label>
        <div className="space-y-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              onCategoryChange("全部");
              onSearchChange("");
              onShowInstalledChange(false);
            }}
            className="w-full justify-start text-left text-sm button-glass hover-glass text-ink-soft-brown border-glass-border touch-target"
          >
            清除所有筛选
          </Button>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              onSearchChange("wix");
              onCategoryChange("全部");
            }}
            className="w-full justify-start text-left text-sm button-glass hover-gold text-ink-soft-brown border-glass-border touch-target"
          >
            查看 Wix 插件
          </Button>
        </div>
      </div>
    </div>
  );
}