import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Users, Search, Filter, Plus, Download, Eye, Edit, Trash2, 
  Mail, Phone, MapPin, Calendar, DollarSign, ShoppingBag,
  ChevronDown, ChevronUp, MoreHorizontal, UserPlus, Star
} from 'lucide-react';
import { WeDesignButton } from '../design-system/WeDesignButton';
import { Input } from '../ui/input';
import { Badge } from '../ui/badge';
import { Card } from '../ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../ui/table';
import { Avatar, AvatarImage, AvatarFallback } from '../ui/avatar';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from '../ui/dropdown-menu';
import { AdminSidebar } from './AdminSidebar';
import { AdminHeader } from './AdminHeader';

interface Customer {
  id: string;
  name: string;
  company: string;
  email: string;
  phone: string;
  country: string;
  registeredAt: string;
  source: string;
  status: 'active' | 'inactive' | 'blocked';
  membershipLevel: 'basic' | 'premium' | 'enterprise';
  totalOrders: number;
  totalSpent: number;
  lastLogin: string;
  avatar: string;
}

interface AdminCustomersProps {
  onNavigate: (page: string) => void;
}

export function AdminCustomers({ onNavigate }: AdminCustomersProps) {
  const [currentUser] = useState({ name: 'Sarah Chen', role: 'Super Admin', avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop' });
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [membershipFilter, setMembershipFilter] = useState('all');
  const [sortBy, setSortBy] = useState('registeredAt');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const [selectedCustomers, setSelectedCustomers] = useState<string[]>([]);

  useEffect(() => {
    // Simulate API call
    const timer = setTimeout(() => {
      setCustomers([
        {
          id: '1',
          name: 'Alex Johnson',
          company: 'TechStart Inc.',
          email: 'alex@techstart.com',
          phone: '+1 (555) 123-4567',
          country: 'United States',
          registeredAt: '2024-01-15T10:30:00Z',
          source: 'Website',
          status: 'active',
          membershipLevel: 'premium',
          totalOrders: 8,
          totalSpent: 12450,
          lastLogin: '2024-01-20T14:22:00Z',
          avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop'
        },
        {
          id: '2',
          name: 'Maria Rodriguez',
          company: 'Green Garden Cafe',
          email: 'maria@greengarden.com',
          phone: '+1 (555) 987-6543',
          country: 'Spain',
          registeredAt: '2024-01-12T09:15:00Z',
          source: 'Google Ads',
          status: 'active',
          membershipLevel: 'basic',
          totalOrders: 3,
          totalSpent: 1875,
          lastLogin: '2024-01-19T11:45:00Z',
          avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop'
        },
        {
          id: '3',
          name: 'David Kim',
          company: 'Urban Fashion Co',
          email: 'david@urbanfashion.com',
          phone: '+82 10-1234-5678',
          country: 'South Korea',
          registeredAt: '2024-01-10T16:45:00Z',
          source: 'Referral',
          status: 'active',
          membershipLevel: 'enterprise',
          totalOrders: 15,
          totalSpent: 28900,
          lastLogin: '2024-01-21T08:30:00Z',
          avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop'
        },
        {
          id: '4',
          name: 'Jennifer Chen',
          company: 'MedCare Plus',
          email: 'j.chen@medcareplus.com',
          phone: '+1 (555) 555-0123',
          country: 'Canada',
          registeredAt: '2024-01-08T12:20:00Z',
          source: 'Social Media',
          status: 'inactive',
          membershipLevel: 'basic',
          totalOrders: 1,
          totalSpent: 299,
          lastLogin: '2024-01-15T16:10:00Z',
          avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop'
        }
      ]);
      setLoading(false);
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800 border-green-200';
      case 'inactive': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'blocked': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getMembershipColor = (level: string) => {
    switch (level) {
      case 'enterprise': return 'gradient-gold text-white';
      case 'premium': return 'bg-accent-terra text-white';
      case 'basic': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const filteredCustomers = customers.filter(customer => {
    const matchesSearch = customer.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         customer.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         customer.company.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || customer.status === statusFilter;
    const matchesMembership = membershipFilter === 'all' || customer.membershipLevel === membershipFilter;
    
    return matchesSearch && matchesStatus && matchesMembership;
  });

  const sortedCustomers = [...filteredCustomers].sort((a, b) => {
    let aVal = a[sortBy as keyof Customer];
    let bVal = b[sortBy as keyof Customer];
    
    if (typeof aVal === 'string') aVal = aVal.toLowerCase();
    if (typeof bVal === 'string') bVal = bVal.toLowerCase();
    
    if (sortOrder === 'asc') {
      return aVal < bVal ? -1 : aVal > bVal ? 1 : 0;
    } else {
      return aVal > bVal ? -1 : aVal < bVal ? 1 : 0;
    }
  });

  const handleSort = (field: string) => {
    if (sortBy === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(field);
      setSortOrder('desc');
    }
  };

  const SortableHeader = ({ field, children }: { field: string; children: React.ReactNode }) => (
    <TableHead 
      className="cursor-pointer hover:bg-glass-white transition-colors select-none"
      onClick={() => handleSort(field)}
    >
      <div className="flex items-center gap-2">
        {children}
        {sortBy === field && (
          sortOrder === 'asc' ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />
        )}
      </div>
    </TableHead>
  );

  return (
    <div className="Page_AdminCustomers min-h-screen bg-gradient-to-br from-bg-light-ivory to-bg-light-ivory/50">
      <div className="flex h-screen">
        <AdminSidebar 
          collapsed={sidebarCollapsed}
          onToggle={() => setSidebarCollapsed(!sidebarCollapsed)}
          currentPage="customers"
          onNavigate={onNavigate}
        />

        <div className={`flex-1 flex flex-col overflow-hidden transition-all duration-300 ${sidebarCollapsed ? 'ml-20' : 'ml-80'}`}>
          <AdminHeader user={currentUser} onNavigate={onNavigate} />

          <main className="flex-1 overflow-y-auto p-6 space-y-6">
            {/* Page Header */}
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
              <div>
                <h1 className="text-3xl font-heading font-bold text-gradient-gold-rich mb-2">
                  Customer Management
                </h1>
                <p className="text-ink-soft-brown">
                  Manage and monitor your customer base
                </p>
              </div>
              
              <div className="flex items-center gap-3">
                <WeDesignButton variant="secondary-outline" size="sm">
                  <Download className="w-4 h-4 mr-2" />
                  Export
                </WeDesignButton>
                <WeDesignButton variant="primary-gold" size="sm">
                  <UserPlus className="w-4 h-4 mr-2" />
                  Add Customer
                </WeDesignButton>
              </div>
            </div>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <Card className="glass-card p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 gradient-gold rounded-xl flex items-center justify-center">
                    <Users className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-ink-deep-brown">2,847</p>
                    <p className="text-ink-soft-brown text-sm">Total Customers</p>
                  </div>
                </div>
              </Card>

              <Card className="glass-card p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-green-500 rounded-xl flex items-center justify-center">
                    <Users className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-ink-deep-brown">2,456</p>
                    <p className="text-ink-soft-brown text-sm">Active Customers</p>
                  </div>
                </div>
              </Card>

              <Card className="glass-card p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-blue-500 rounded-xl flex items-center justify-center">
                    <Star className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-ink-deep-brown">1,234</p>
                    <p className="text-ink-soft-brown text-sm">Premium Members</p>
                  </div>
                </div>
              </Card>

              <Card className="glass-card p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-purple-500 rounded-xl flex items-center justify-center">
                    <DollarSign className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-ink-deep-brown">$1.2M</p>
                    <p className="text-ink-soft-brown text-sm">Total Revenue</p>
                  </div>
                </div>
              </Card>
            </div>

            {/* Filters */}
            <Card className="glass-card p-6">
              <div className="flex flex-col lg:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-ink-soft-brown" />
                    <Input
                      placeholder="Search customers..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="input-glass pl-10"
                    />
                  </div>
                </div>

                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-40 glass-effect border-0">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent className="glass-modal">
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                    <SelectItem value="blocked">Blocked</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={membershipFilter} onValueChange={setMembershipFilter}>
                  <SelectTrigger className="w-40 glass-effect border-0">
                    <SelectValue placeholder="Membership" />
                  </SelectTrigger>
                  <SelectContent className="glass-modal">
                    <SelectItem value="all">All Levels</SelectItem>
                    <SelectItem value="basic">Basic</SelectItem>
                    <SelectItem value="premium">Premium</SelectItem>
                    <SelectItem value="enterprise">Enterprise</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </Card>

            {/* Customers Table */}
            <Card className="glass-card p-6">
              {loading ? (
                <div className="space-y-4">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className="flex items-center gap-4 p-4">
                      <div className="w-10 h-10 bg-muted/30 rounded-full animate-pulse"></div>
                      <div className="flex-1 space-y-2">
                        <div className="w-40 h-4 bg-muted/30 rounded animate-pulse"></div>
                        <div className="w-64 h-3 bg-muted/30 rounded animate-pulse"></div>
                      </div>
                      <div className="w-20 h-6 bg-muted/30 rounded animate-pulse"></div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className="border-glass-border">
                        <SortableHeader field="name">Customer</SortableHeader>
                        <SortableHeader field="email">Contact</SortableHeader>
                        <SortableHeader field="country">Location</SortableHeader>
                        <SortableHeader field="status">Status</SortableHeader>
                        <SortableHeader field="membershipLevel">Membership</SortableHeader>
                        <SortableHeader field="totalOrders">Orders</SortableHeader>
                        <SortableHeader field="totalSpent">Spent</SortableHeader>
                        <SortableHeader field="registeredAt">Registered</SortableHeader>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {sortedCustomers.map((customer, index) => (
                        <motion.tr
                          key={customer.id}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: index * 0.05 }}
                          className="border-glass-border hover:bg-glass-white/50 transition-colors"
                        >
                          <TableCell>
                            <div className="flex items-center gap-3">
                              <Avatar className="w-10 h-10">
                                <AvatarImage src={customer.avatar} alt={customer.name} />
                                <AvatarFallback className="gradient-gold text-white">
                                  {customer.name.split(' ').map(n => n[0]).join('')}
                                </AvatarFallback>
                              </Avatar>
                              <div>
                                <p className="font-medium text-ink-deep-brown">{customer.name}</p>
                                <p className="text-sm text-ink-soft-brown">{customer.company}</p>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div>
                              <p className="font-medium text-ink-deep-brown">{customer.email}</p>
                              <p className="text-sm text-ink-soft-brown">{customer.phone}</p>
                            </div>
                          </TableCell>
                          <TableCell>
                            <p className="text-ink-deep-brown">{customer.country}</p>
                          </TableCell>
                          <TableCell>
                            <Badge className={`${getStatusColor(customer.status)} border capitalize`}>
                              {customer.status}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge className={`${getMembershipColor(customer.membershipLevel)} border-0 capitalize`}>
                              {customer.membershipLevel}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <ShoppingBag className="w-4 h-4 text-ink-soft-brown" />
                              <span className="font-medium text-ink-deep-brown">{customer.totalOrders}</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <span className="font-medium text-ink-deep-brown">
                              {formatCurrency(customer.totalSpent)}
                            </span>
                          </TableCell>
                          <TableCell>
                            <p className="text-ink-deep-brown">{formatDate(customer.registeredAt)}</p>
                          </TableCell>
                          <TableCell>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <button className="w-8 h-8 glass-effect rounded-lg flex items-center justify-center hover:shadow-glass transition-all">
                                  <MoreHorizontal className="w-4 h-4 text-ink-soft-brown" />
                                </button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end" className="glass-modal">
                                <DropdownMenuItem>
                                  <Eye className="w-4 h-4 mr-2" />
                                  View Details
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <Edit className="w-4 h-4 mr-2" />
                                  Edit Customer
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <Mail className="w-4 h-4 mr-2" />
                                  Send Message
                                </DropdownMenuItem>
                                <DropdownMenuItem className="text-destructive">
                                  <Trash2 className="w-4 h-4 mr-2" />
                                  Delete Customer
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </motion.tr>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </Card>
          </main>
        </div>
      </div>
    </div>
  );
}