import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Eye, EyeOff, Shield, Lock, User, Smartphone } from 'lucide-react';
import { WeDesignButton } from '../design-system/WeDesignButton';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Checkbox } from '../ui/checkbox';
import { ImageWithFallback } from '../figma/ImageWithFallback';

interface AdminLoginProps {
  onNavigate: (page: string) => void;
}

export function AdminLogin({ onNavigate }: AdminLoginProps) {
  const [showPassword, setShowPassword] = useState(false);
  const [show2FA, setShow2FA] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    twoFactorCode: '',
    rememberMe: false
  });
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<{[key: string]: string}>({});

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrors({});

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      if (!show2FA) {
        setShow2FA(true);
        setLoading(false);
        return;
      }

      // Complete login
      onNavigate('admin-dashboard');
    } catch (error) {
      setErrors({ general: 'Login failed. Please try again.' });
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  return (
    <div className="Page_AdminLogin min-h-screen relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 bg-gradient-to-br from-bg-light-ivory via-bg-light-ivory to-accent-terra/5"></div>
      <div className="absolute top-20 left-20 w-96 h-96 gradient-gold-soft opacity-10 rounded-full blur-3xl"></div>
      <div className="absolute bottom-20 right-20 w-80 h-80 gradient-gold opacity-8 rounded-full blur-3xl"></div>
      
      {/* Admin Header */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="absolute top-8 left-8 flex items-center gap-3 z-10"
      >
        <div className="w-12 h-12 gradient-gold rounded-xl flex items-center justify-center shadow-luxury">
          <Shield className="w-6 h-6 text-white" />
        </div>
        <div>
          <h3 className="text-gradient-gold-rich font-heading font-bold text-xl">WeDesign Admin</h3>
          <p className="text-ink-soft-brown text-sm">Super Administrator Console</p>
        </div>
      </motion.div>

      {/* Main Content */}
      <div className="Container_Content min-h-screen flex items-center justify-center px-4 relative z-10">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.4 }}
          className="w-full max-w-lg"
        >
          {/* Login Card */}
          <div className="glass-modal rounded-3xl p-8 shadow-luxury-lg">
            {/* Header */}
            <div className="text-center mb-8">
              <motion.div 
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
                className="w-20 h-20 gradient-gold rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-gold"
              >
                <Lock className="w-10 h-10 text-white" />
              </motion.div>
              
              <h1 className="text-2xl font-heading font-bold text-gradient-gold-rich mb-2">
                {!show2FA ? 'Admin Login' : 'Two-Factor Authentication'}
              </h1>
              <p className="text-ink-soft-brown">
                {!show2FA 
                  ? 'Access the WeDesign administration panel' 
                  : 'Enter the 6-digit code from your authenticator app'
                }
              </p>
            </div>

            {/* Login Form */}
            <form onSubmit={handleSubmit} className="space-y-6">
              {!show2FA ? (
                <>
                  {/* Email Field */}
                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-ink-deep-brown font-medium">
                      Email Address
                    </Label>
                    <div className="relative">
                      <User className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-ink-soft-brown" />
                      <Input
                        id="email"
                        type="email"
                        placeholder="admin@wedesign.com"
                        value={formData.email}
                        onChange={(e) => handleInputChange('email', e.target.value)}
                        className="input-glass pl-12 h-14 text-base"
                        required
                      />
                    </div>
                    {errors.email && (
                      <p className="text-destructive text-sm">{errors.email}</p>
                    )}
                  </div>

                  {/* Password Field */}
                  <div className="space-y-2">
                    <Label htmlFor="password" className="text-ink-deep-brown font-medium">
                      Password
                    </Label>
                    <div className="relative">
                      <Lock className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-ink-soft-brown" />
                      <Input
                        id="password"
                        type={showPassword ? 'text' : 'password'}
                        placeholder="Enter your admin password"
                        value={formData.password}
                        onChange={(e) => handleInputChange('password', e.target.value)}
                        className="input-glass pl-12 pr-12 h-14 text-base"
                        required
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-4 top-1/2 transform -translate-y-1/2 text-ink-soft-brown hover:text-accent-terra transition-colors"
                      >
                        {showPassword ? (
                          <EyeOff className="w-5 h-5" />
                        ) : (
                          <Eye className="w-5 h-5" />
                        )}
                      </button>
                    </div>
                    {errors.password && (
                      <p className="text-destructive text-sm">{errors.password}</p>
                    )}
                  </div>

                  {/* Remember Me */}
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="remember"
                      checked={formData.rememberMe}
                      onCheckedChange={(checked) => handleInputChange('rememberMe', checked as boolean)}
                    />
                    <Label htmlFor="remember" className="text-ink-soft-brown text-sm cursor-pointer">
                      Keep me signed in for 30 days
                    </Label>
                  </div>
                </>
              ) : (
                /* 2FA Code Field */
                <div className="space-y-4">
                  <div className="text-center mb-6">
                    <div className="w-16 h-16 bg-accent-terra/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                      <Smartphone className="w-8 h-8 text-accent-terra" />
                    </div>
                    <p className="text-ink-soft-brown text-sm">
                      Check your authenticator app for the 6-digit verification code
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="twoFactorCode" className="text-ink-deep-brown font-medium">
                      Verification Code
                    </Label>
                    <Input
                      id="twoFactorCode"
                      type="text"
                      placeholder="000000"
                      value={formData.twoFactorCode}
                      onChange={(e) => handleInputChange('twoFactorCode', e.target.value.replace(/\D/g, '').slice(0, 6))}
                      className="input-glass h-14 text-center text-2xl tracking-widest font-mono"
                      maxLength={6}
                      required
                    />
                  </div>

                  <button
                    type="button"
                    onClick={() => setShow2FA(false)}
                    className="text-accent-terra text-sm hover:text-accent-gold-rich transition-colors"
                  >
                    ← Back to login
                  </button>
                </div>
              )}

              {/* Error Message */}
              {errors.general && (
                <div className="bg-destructive/10 border border-destructive/20 rounded-xl p-4">
                  <p className="text-destructive text-sm">{errors.general}</p>
                </div>
              )}

              {/* Submit Button */}
              <WeDesignButton
                type="submit"
                variant="primary-gold"
                size="lg"
                className="w-full h-14 text-base"
                disabled={loading}
              >
                {loading ? (
                  <div className="flex items-center gap-2">
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    {!show2FA ? 'Signing In...' : 'Verifying...'}
                  </div>
                ) : (
                  !show2FA ? 'Sign In to Admin Panel' : 'Verify & Continue'
                )}
              </WeDesignButton>
            </form>

            {/* Footer */}
            {!show2FA && (
              <div className="mt-8 pt-6 border-t border-glass-border text-center">
                <p className="text-ink-soft-brown text-sm mb-4">
                  Forgot your password or need access?
                </p>
                <button 
                  onClick={() => onNavigate('home')}
                  className="text-accent-terra hover:text-accent-gold-rich transition-colors text-sm font-medium"
                >
                  Contact System Administrator
                </button>
              </div>
            )}
          </div>

          {/* Security Notice */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="mt-6 text-center"
          >
            <div className="glass-effect rounded-2xl p-4">
              <div className="flex items-center justify-center gap-2 text-ink-soft-brown text-sm">
                <Shield className="w-4 h-4" />
                <span>Secure admin access protected by SSL encryption</span>
              </div>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
}