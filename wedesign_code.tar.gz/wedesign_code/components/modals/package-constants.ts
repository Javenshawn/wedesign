import { Sparkles, Zap, Crown } from 'lucide-react';

export const packages = [
  {
    name: "Economy",
    icon: Sparkles,
    price: 199,
    originalPrice: 299,
    features: [
      "3 Original Logo Concepts",
      "2 Revision Rounds", 
      "High-Resolution Files (PNG, JPG)",
      "Basic Brand Guidelines",
      "7-Day Delivery",
      "Email Support"
    ],
    isPopular: false,
    description: "Perfect for startups and small businesses"
  },
  {
    name: "Business",
    icon: Zap,
    price: 399,
    originalPrice: 599,
    features: [
      "5 Original Logo Concepts",
      "Unlimited Revisions",
      "High-Resolution Files (PNG, JPG, SVG, PDF)",
      "Complete Brand Guidelines",
      "Business Card Design",
      "Social Media Kit",
      "3-Day Rush Delivery",
      "Priority Support"
    ],
    isPopular: true,
    description: "Most popular choice for growing businesses"
  },
  {
    name: "Private Jet",
    icon: Crown,
    price: 799,
    originalPrice: 1199,
    features: [
      "10 Original Logo Concepts",
      "Unlimited Revisions",
      "All File Formats + Source Files",
      "Premium Brand Guidelines",
      "Complete Stationery Suite",
      "Social Media & Web Kit",
      "Trademark Research",
      "24-Hour Rush Delivery",
      "Dedicated Account Manager",
      "1-on-1 Design Consultation"
    ],
    isPopular: false,
    description: "Ultimate package for premium brands"
  }
];