import { AdminLogin } from '../admin/AdminLogin';

interface PageAdminLoginProps {
  onNavigate: (page: string) => void;
}

export function Page_AdminLogin({ onNavigate }: PageAdminLoginProps) {
  return <AdminLogin onNavigate={onNavigate} />;
}