import React, { useState } from 'react';
import { Eye, EyeOff, Mail, Lock, User, CheckCircle, XCircle, ArrowLeft } from 'lucide-react';
import { authAPI, handleApiError } from '../../utils/supabase/client';
import weDesignLogo from 'figma:asset/8c46f7864dc2c42f443da12ca2dd22f48b86a8cf.png';

interface Page_LoginProps {
  onNavigate?: (page: string) => void;
}

export function Page_Login({ onNavigate }: Page_LoginProps) {
  const [isSignUp, setIsSignUp] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    fullName: '',
    confirmPassword: ''
  });
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const validateForm = () => {
    if (!formData.email || !formData.password) {
      setMessage({ type: 'error', text: 'Email and password are required' });
      return false;
    }

    if (isSignUp) {
      if (!formData.fullName) {
        setMessage({ type: 'error', text: 'Full name is required' });
        return false;
      }
      if (formData.password !== formData.confirmPassword) {
        setMessage({ type: 'error', text: 'Passwords do not match' });
        return false;
      }
      if (formData.password.length < 6) {
        setMessage({ type: 'error', text: 'Password must be at least 6 characters' });
        return false;
      }
    }

    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setMessage(null);

    if (!validateForm()) return;

    setLoading(true);

    try {
      if (isSignUp) {
        const result = await authAPI.signUp(formData.email, formData.password, formData.fullName);
        setMessage({ 
          type: 'success', 
          text: 'Account created successfully! You can now sign in.' 
        });
        // Switch to login mode
        setIsSignUp(false);
        setFormData(prev => ({ ...prev, fullName: '', confirmPassword: '' }));
      } else {
        const result = await authAPI.signIn(formData.email, formData.password);
        setMessage({ 
          type: 'success', 
          text: 'Welcome back! Redirecting to your dashboard...' 
        });
        
        // Redirect to user dashboard
        setTimeout(() => {
          onNavigate?.('user-portal');
        }, 1500);
      }
    } catch (error: any) {
      setMessage({ 
        type: 'error', 
        text: handleApiError(error)
      });
    } finally {
      setLoading(false);
    }
  };

  const toggleMode = () => {
    setIsSignUp(!isSignUp);
    setMessage(null);
    setFormData({
      email: '',
      password: '',
      fullName: '',
      confirmPassword: ''
    });
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden">
      {/* Back to Home button */}
      <div className="absolute top-4 left-4 md:top-6 md:left-6 z-10">
        <button
          onClick={() => onNavigate?.('home')}
          className="flex items-center gap-3 px-4 py-3 md:px-6 md:py-3 bg-white/80 backdrop-blur-xl border border-white/20 rounded-2xl text-gray-700 hover:text-[#B6652E] hover:bg-white/90 transition-all duration-200 shadow-lg hover:shadow-xl"
        >
          <ArrowLeft className="w-5 h-5" />
          <span className="hidden sm:inline font-medium">Back to Home</span>
        </button>
      </div>

      {/* WeDesign Logo area */}
      <div className="absolute top-4 right-4 md:top-6 md:right-6 z-10">
        <button
          onClick={() => onNavigate?.('home')}
          className="p-3 bg-white/80 backdrop-blur-xl border border-white/20 rounded-xl hover:bg-white/90 transition-all duration-200"
        >
          <img 
            src={weDesignLogo} 
            alt="WeDesign - Worldwide Design, Well Delivered" 
            className="h-8 w-auto object-contain"
          />
        </button>
      </div>

      {/* Background decoration */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#B6652E] via-[#D17A42] to-[#FFB84D] opacity-10"></div>
      <div className="absolute top-20 left-10 w-32 h-32 rounded-full bg-[#FFB84D] opacity-20 blur-xl"></div>
      <div className="absolute bottom-20 right-10 w-48 h-48 rounded-full bg-[#B6652E] opacity-20 blur-xl"></div>

      <div className="relative w-full max-w-md">
        {/* Login card */}
        <div className="backdrop-blur-xl bg-white/80 rounded-3xl p-8 shadow-2xl border border-white/20">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center mb-6">
              <img 
                src={weDesignLogo} 
                alt="WeDesign - Worldwide Design, Well Delivered" 
                className="h-14 sm:h-16 w-auto object-contain"
              />
            </div>
            <h1 className="text-2xl font-bold text-gray-900">
              {isSignUp ? 'Create Account' : 'Welcome Back'}
            </h1>
            <p className="text-gray-600 mt-2">
              {isSignUp 
                ? 'Join WeDesign and start your logo journey' 
                : 'Sign in to your WeDesign account'
              }
            </p>
          </div>

          {/* Message alert */}
          {message && (
            <div className={`flex items-center gap-3 p-4 rounded-xl mb-6 ${
              message.type === 'success' 
                ? 'bg-green-50 text-green-700 border border-green-200' 
                : 'bg-red-50 text-red-700 border border-red-200'
            }`}>
              {message.type === 'success' ? (
                <CheckCircle className="w-5 h-5 flex-shrink-0" />
              ) : (
                <XCircle className="w-5 h-5 flex-shrink-0" />
              )}
              <span className="text-sm">{message.text}</span>
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Full name (signup only) */}
            {isSignUp && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Full Name
                </label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    name="fullName"
                    value={formData.fullName}
                    onChange={handleInputChange}
                    className="w-full pl-11 pr-4 py-3 rounded-xl border border-gray-300 focus:border-[#B6652E] focus:ring-2 focus:ring-[#B6652E]/20 transition-all backdrop-blur-sm bg-white/50"
                    placeholder="Enter your full name"
                    required={isSignUp}
                  />
                </div>
              </div>
            )}

            {/* Email */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Email Address
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  className="w-full pl-11 pr-4 py-3 rounded-xl border border-gray-300 focus:border-[#B6652E] focus:ring-2 focus:ring-[#B6652E]/20 transition-all backdrop-blur-sm bg-white/50"
                  placeholder="Enter your email"
                  required
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Password
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  name="password"
                  value={formData.password}
                  onChange={handleInputChange}
                  className="w-full pl-11 pr-11 py-3 rounded-xl border border-gray-300 focus:border-[#B6652E] focus:ring-2 focus:ring-[#B6652E]/20 transition-all backdrop-blur-sm bg-white/50"
                  placeholder="Enter your password"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            {/* Confirm password (signup only) */}
            {isSignUp && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Confirm Password
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    name="confirmPassword"
                    value={formData.confirmPassword}
                    onChange={handleInputChange}
                    className="w-full pl-11 pr-4 py-3 rounded-xl border border-gray-300 focus:border-[#B6652E] focus:ring-2 focus:ring-[#B6652E]/20 transition-all backdrop-blur-sm bg-white/50"
                    placeholder="Confirm your password"
                    required={isSignUp}
                  />
                </div>
              </div>
            )}

            {/* Submit button */}
            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 px-4 bg-gradient-to-r from-[#B6652E] to-[#FFB84D] text-white rounded-xl font-medium hover:shadow-lg transform hover:-translate-y-0.5 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
            >
              {loading ? (
                <div className="flex items-center justify-center gap-2">
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  {isSignUp ? 'Creating Account...' : 'Signing In...'}
                </div>
              ) : (
                isSignUp ? 'Create Account' : 'Sign In'
              )}
            </button>
          </form>

          {/* Toggle mode */}
          <div className="mt-6 text-center">
            <p className="text-gray-600">
              {isSignUp ? 'Already have an account?' : "Don't have an account?"}
              <button
                onClick={toggleMode}
                className="ml-2 font-medium text-[#B6652E] hover:text-[#FFB84D] transition-colors"
              >
                {isSignUp ? 'Sign In' : 'Sign Up'}
              </button>
            </p>
          </div>

          {/* Quick return to homepage link */}
          <div className="mt-4 text-center">
            <button
              onClick={() => onNavigate?.('home')}
              className="text-sm text-gray-500 hover:text-[#B6652E] transition-colors"
            >
              Or browse our design showcase →
            </button>
          </div>
        </div>

        {/* Footer info */}
        <div className="text-center mt-6">
          <p className="text-sm text-gray-500">
            By continuing, you agree to WeDesign's Terms of Service and Privacy Policy
          </p>
        </div>
      </div>
    </div>
  );
}