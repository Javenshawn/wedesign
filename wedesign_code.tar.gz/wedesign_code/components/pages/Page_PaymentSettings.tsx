import React, { useState, useEffect } from 'react';
import { 
  CreditCard, DollarSign, Shield, CheckCircle, AlertCircle, 
  Copy, Eye, EyeOff, Settings, Globe, Zap, TrendingUp,
  ArrowLeft
} from 'lucide-react';

interface PaymentSettingsProps {
  onNavigate?: (page: string) => void;
}

interface PaymentSettings {
  stripePublishableKey: string;
  stripeSecretKey: string;
  webhookSecret: string;
  accountId: string;
  businessName: string;
  businessEmail: string;
  currency: string;
  isTestMode: boolean;
  isConnected: boolean;
}

export function Page_PaymentSettings({ onNavigate }: PaymentSettingsProps) {
  const [settings, setSettings] = useState<PaymentSettings>({
    stripePublishableKey: '',
    stripeSecretKey: '',
    webhookSecret: '',
    accountId: '',
    businessName: '',
    businessEmail: '',
    currency: 'USD',
    isTestMode: true,
    isConnected: false
  });

  const [showSecrets, setShowSecrets] = useState({
    publishableKey: false,
    secretKey: false,
    webhookSecret: false
  });

  const [isSaving, setIsSaving] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'success' | 'error'>('idle');

  const currencies = [
    { code: 'USD', name: 'US Dollar ($)', symbol: '$' },
    { code: 'EUR', name: 'Euro (€)', symbol: '€' },
    { code: 'GBP', name: 'British Pound (£)', symbol: '£' },
    { code: 'CAD', name: 'Canadian Dollar (C$)', symbol: 'C$' },
    { code: 'AUD', name: 'Australian Dollar (A$)', symbol: 'A$' },
    { code: 'JPY', name: 'Japanese Yen (¥)', symbol: '¥' },
    { code: 'CNY', name: 'Chinese Yuan (¥)', symbol: '¥' }
  ];

  const handleInputChange = (field: keyof PaymentSettings, value: string | boolean) => {
    setSettings(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const toggleSecretVisibility = (field: keyof typeof showSecrets) => {
    setShowSecrets(prev => ({
      ...prev,
      [field]: !prev[field]
    }));
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    // You can add toast notification here
  };

  const validateStripeKey = (key: string, type: 'publishable' | 'secret') => {
    if (type === 'publishable') {
      return key.startsWith('pk_test_') || key.startsWith('pk_live_');
    } else {
      return key.startsWith('sk_test_') || key.startsWith('sk_live_');
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    setSaveStatus('idle');

    try {
      // Validate required fields
      if (!settings.stripePublishableKey || !settings.stripeSecretKey) {
        throw new Error('Stripe keys are required');
      }

      if (!validateStripeKey(settings.stripePublishableKey, 'publishable')) {
        throw new Error('Invalid Stripe publishable key format');
      }

      if (!validateStripeKey(settings.stripeSecretKey, 'secret')) {
        throw new Error('Invalid Stripe secret key format');
      }

      // Simulate saving to backend
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      setSettings(prev => ({ ...prev, isConnected: true }));
      setSaveStatus('success');
    } catch (error) {
      console.error('Save error:', error);
      setSaveStatus('error');
    } finally {
      setIsSaving(false);
    }
  };

  const handleTestConnection = async () => {
    if (!settings.stripePublishableKey || !settings.stripeSecretKey) {
      setSaveStatus('error');
      return;
    }

    setIsSaving(true);
    try {
      // Simulate testing Stripe connection
      await new Promise(resolve => setTimeout(resolve, 1500));
      setSettings(prev => ({ ...prev, isConnected: true }));
      setSaveStatus('success');
    } catch (error) {
      setSaveStatus('error');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="Page_PaymentSettings min-h-screen bg-gradient-to-br from-[#FAFAF8] to-[#F5F3ED]">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Page title and back button */}
        <div className="mb-8">
          <div className="flex items-center gap-4 mb-6">
            <button
              onClick={() => onNavigate?.('user-portal')}
              className="flex items-center gap-2 px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors rounded-lg hover:bg-white/50"
            >
              <ArrowLeft className="w-5 h-5" />
              <span>Back to Dashboard</span>
            </button>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#B6652E] to-[#FFB84D] flex items-center justify-center">
              <CreditCard className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Payment Settings</h1>
              <p className="text-gray-600">Configure your payment methods and Stripe integration</p>
            </div>
          </div>
        </div>

        {/* Connection status */}
        <div className="mb-8">
          <div className={`backdrop-blur-xl rounded-2xl p-6 border ${
            settings.isConnected 
              ? 'bg-green-50/80 border-green-200 text-green-800'
              : 'bg-yellow-50/80 border-yellow-200 text-yellow-800'
          }`}>
            <div className="flex items-center gap-3">
              {settings.isConnected ? (
                <CheckCircle className="w-6 h-6 text-green-600" />
              ) : (
                <AlertCircle className="w-6 h-6 text-yellow-600" />
              )}
              <div>
                <h3 className="font-semibold">
                  {settings.isConnected ? 'Stripe Connected' : 'Stripe Not Connected'}
                </h3>
                <p className="text-sm">
                  {settings.isConnected 
                    ? 'Your payment system is configured and ready to accept orders'
                    : 'Please configure your Stripe account information to start accepting customer payments'
                  }
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Main settings area */}
          <div className="lg:col-span-2 space-y-6">
            
            {/* Stripe API Configuration */}
            <div className="backdrop-blur-xl bg-white/80 rounded-2xl p-6 border border-white/20">
              <div className="flex items-center gap-3 mb-6">
                <Shield className="w-6 h-6 text-[#B6652E]" />
                <h2 className="text-xl font-semibold text-gray-900">Stripe API Configuration</h2>
              </div>

              <div className="space-y-6">
                {/* Test mode toggle */}
                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                  <div>
                    <h4 className="font-medium text-gray-900">Test Mode</h4>
                    <p className="text-sm text-gray-600">Enable test mode for development and testing</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      className="sr-only peer"
                      checked={settings.isTestMode}
                      onChange={(e) => handleInputChange('isTestMode', e.target.checked)}
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-[#B6652E]/20 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#B6652E]"></div>
                  </label>
                </div>

                {/* Publishable Key */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Stripe Publishable Key *
                  </label>
                  <div className="relative">
                    <input
                      type={showSecrets.publishableKey ? 'text' : 'password'}
                      value={settings.stripePublishableKey}
                      onChange={(e) => handleInputChange('stripePublishableKey', e.target.value)}
                      className="w-full px-4 py-3 pr-20 rounded-xl border border-gray-300 focus:border-[#B6652E] focus:ring-2 focus:ring-[#B6652E]/20 bg-white/90"
                      placeholder={settings.isTestMode ? 'pk_test_...' : 'pk_live_...'}
                    />
                    <div className="absolute right-2 top-1/2 transform -translate-y-1/2 flex gap-1">
                      <button
                        type="button"
                        onClick={() => toggleSecretVisibility('publishableKey')}
                        className="p-2 text-gray-400 hover:text-gray-600"
                      >
                        {showSecrets.publishableKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                      {settings.stripePublishableKey && (
                        <button
                          type="button"
                          onClick={() => copyToClipboard(settings.stripePublishableKey)}
                          className="p-2 text-gray-400 hover:text-gray-600"
                        >
                          <Copy className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">
                    Get this key from your Stripe Dashboard
                  </p>
                </div>

                {/* Secret Key */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Stripe Secret Key *
                  </label>
                  <div className="relative">
                    <input
                      type={showSecrets.secretKey ? 'text' : 'password'}
                      value={settings.stripeSecretKey}
                      onChange={(e) => handleInputChange('stripeSecretKey', e.target.value)}
                      className="w-full px-4 py-3 pr-20 rounded-xl border border-gray-300 focus:border-[#B6652E] focus:ring-2 focus:ring-[#B6652E]/20 bg-white/90"
                      placeholder={settings.isTestMode ? 'sk_test_...' : 'sk_live_...'}
                    />
                    <div className="absolute right-2 top-1/2 transform -translate-y-1/2 flex gap-1">
                      <button
                        type="button"
                        onClick={() => toggleSecretVisibility('secretKey')}
                        className="p-2 text-gray-400 hover:text-gray-600"
                      >
                        {showSecrets.secretKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                      {settings.stripeSecretKey && (
                        <button
                          type="button"
                          onClick={() => copyToClipboard(settings.stripeSecretKey)}
                          className="p-2 text-gray-400 hover:text-gray-600"
                        >
                          <Copy className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                  <p className="text-xs text-red-500 mt-1">
                    ⚠️ Keep this key secure and never expose it in frontend code
                  </p>
                </div>

                {/* Webhook Secret */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Webhook Secret (Optional)
                  </label>
                  <div className="relative">
                    <input
                      type={showSecrets.webhookSecret ? 'text' : 'password'}
                      value={settings.webhookSecret}
                      onChange={(e) => handleInputChange('webhookSecret', e.target.value)}
                      className="w-full px-4 py-3 pr-20 rounded-xl border border-gray-300 focus:border-[#B6652E] focus:ring-2 focus:ring-[#B6652E]/20 bg-white/90"
                      placeholder="whsec_..."
                    />
                    <div className="absolute right-2 top-1/2 transform -translate-y-1/2 flex gap-1">
                      <button
                        type="button"
                        onClick={() => toggleSecretVisibility('webhookSecret')}
                        className="p-2 text-gray-400 hover:text-gray-600"
                      >
                        {showSecrets.webhookSecret ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                      {settings.webhookSecret && (
                        <button
                          type="button"
                          onClick={() => copyToClipboard(settings.webhookSecret)}
                          className="p-2 text-gray-400 hover:text-gray-600"
                        >
                          <Copy className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">
                    Used to verify the security of Stripe webhook events
                  </p>
                </div>
              </div>
            </div>

            {/* Business Information */}
            <div className="backdrop-blur-xl bg-white/80 rounded-2xl p-6 border border-white/20">
              <div className="flex items-center gap-3 mb-6">
                <Settings className="w-6 h-6 text-[#B6652E]" />
                <h2 className="text-xl font-semibold text-gray-900">Business Information</h2>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Business Name
                  </label>
                  <input
                    type="text"
                    value={settings.businessName}
                    onChange={(e) => handleInputChange('businessName', e.target.value)}
                    className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-[#B6652E] focus:ring-2 focus:ring-[#B6652E]/20 bg-white/90"
                    placeholder="WeDesign Studio"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Business Email
                  </label>
                  <input
                    type="email"
                    value={settings.businessEmail}
                    onChange={(e) => handleInputChange('businessEmail', e.target.value)}
                    className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-[#B6652E] focus:ring-2 focus:ring-[#B6652E]/20 bg-white/90"
                    placeholder="hello@wedesign.com"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Default Currency
                  </label>
                  <select
                    value={settings.currency}
                    onChange={(e) => handleInputChange('currency', e.target.value)}
                    className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-[#B6652E] focus:ring-2 focus:ring-[#B6652E]/20 bg-white/90"
                  >
                    {currencies.map((currency) => (
                      <option key={currency.code} value={currency.code}>
                        {currency.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Stripe Account ID
                  </label>
                  <input
                    type="text"
                    value={settings.accountId}
                    onChange={(e) => handleInputChange('accountId', e.target.value)}
                    className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:border-[#B6652E] focus:ring-2 focus:ring-[#B6652E]/20 bg-white/90"
                    placeholder="acct_..."
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    For multi-account scenarios (optional)
                  </p>
                </div>
              </div>
            </div>

            {/* Action buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <button
                onClick={handleTestConnection}
                disabled={isSaving || !settings.stripePublishableKey || !settings.stripeSecretKey}
                className="flex-1 px-6 py-3 bg-white border border-[#B6652E] text-[#B6652E] rounded-xl hover:bg-[#B6652E]/5 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSaving ? 'Testing...' : 'Test Connection'}
              </button>
              
              <button
                onClick={handleSave}
                disabled={isSaving || !settings.stripePublishableKey || !settings.stripeSecretKey}
                className="flex-1 px-6 py-3 bg-gradient-to-r from-[#B6652E] to-[#FFB84D] text-white rounded-xl hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSaving ? 'Saving...' : 'Save Settings'}
              </button>
            </div>

            {/* Status message */}
            {saveStatus !== 'idle' && (
              <div className={`p-4 rounded-xl ${
                saveStatus === 'success' 
                  ? 'bg-green-50 text-green-800 border border-green-200'
                  : 'bg-red-50 text-red-800 border border-red-200'
              }`}>
                <div className="flex items-center gap-2">
                  {saveStatus === 'success' ? (
                    <CheckCircle className="w-5 h-5" />
                  ) : (
                    <AlertCircle className="w-5 h-5" />
                  )}
                  <span className="font-medium">
                    {saveStatus === 'success' ? 'Settings saved successfully!' : 'Save failed, please check your configuration'}
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* Sidebar - Help and stats */}
          <div className="space-y-6">
            {/* Setup guide */}
            <div className="backdrop-blur-xl bg-white/80 rounded-2xl p-6 border border-white/20">
              <h3 className="font-semibold text-gray-900 mb-4">Setup Guide</h3>
              <div className="space-y-4 text-sm">
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-[#B6652E] text-white flex items-center justify-center flex-shrink-0 text-xs">1</div>
                  <div>
                    <p className="font-medium">Create Stripe Account</p>
                    <p className="text-gray-600">Visit stripe.com to register a merchant account</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-[#B6652E] text-white flex items-center justify-center flex-shrink-0 text-xs">2</div>
                  <div>
                    <p className="font-medium">Get API Keys</p>
                    <p className="text-gray-600">Find the API Keys section in your Dashboard</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-[#B6652E] text-white flex items-center justify-center flex-shrink-0 text-xs">3</div>
                  <div>
                    <p className="font-medium">Configure Webhook</p>
                    <p className="text-gray-600">Set up payment success and failure notifications</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-[#B6652E] text-white flex items-center justify-center flex-shrink-0 text-xs">4</div>
                  <div>
                    <p className="font-medium">Test Payments</p>
                    <p className="text-gray-600">Use test card numbers for verification</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Payment statistics */}
            <div className="backdrop-blur-xl bg-white/80 rounded-2xl p-6 border border-white/20">
              <h3 className="font-semibold text-gray-900 mb-4">Payment Statistics</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-green-600" />
                    <span className="text-sm text-gray-600">Monthly Revenue</span>
                  </div>
                  <span className="font-semibold">$12,450</span>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <DollarSign className="w-4 h-4 text-blue-600" />
                    <span className="text-sm text-gray-600">Pending</span>
                  </div>
                  <span className="font-semibold">$2,340</span>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Zap className="w-4 h-4 text-yellow-600" />
                    <span className="text-sm text-gray-600">Success Rate</span>
                  </div>
                  <span className="font-semibold">98.5%</span>
                </div>
              </div>
            </div>

            {/* Support links */}
            <div className="backdrop-blur-xl bg-white/80 rounded-2xl p-6 border border-white/20">
              <h3 className="font-semibold text-gray-900 mb-4">Need Help?</h3>
              <div className="space-y-3">
                <a
                  href="https://stripe.com/docs"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-sm text-[#B6652E] hover:text-[#FFB84D] transition-colors"
                >
                  <Globe className="w-4 h-4" />
                  Stripe Official Documentation
                </a>
                
                <a
                  href="mailto:support@wedesign.com"
                  className="flex items-center gap-2 text-sm text-[#B6652E] hover:text-[#FFB84D] transition-colors"
                >
                  <Shield className="w-4 h-4" />
                  Contact Technical Support
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}