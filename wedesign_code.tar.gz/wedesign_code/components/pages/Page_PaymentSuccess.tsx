import React, { useState, useEffect } from 'react';
import { 
  CheckCircle, Download, Mail, Calendar, CreditCard, 
  ArrowRight, Copy, Printer, Share2 
} from 'lucide-react';

interface PaymentSuccessProps {
  paymentId?: string;
  onNavigate?: (page: string) => void;
}

interface PaymentDetails {
  id: string;
  amount: number;
  currency: string;
  status: string;
  packageName: string;
  projectName: string;
  customerEmail: string;
  paymentMethod: {
    type: string;
    card?: {
      brand: string;
      last4: string;
    };
  };
  createdAt: string;
  estimatedDelivery: string;
  receiptUrl: string;
}

export function Page_PaymentSuccess({ paymentId, onNavigate }: PaymentSuccessProps) {
  const [paymentDetails, setPaymentDetails] = useState<PaymentDetails | null>(null);
  const [loading, setLoading] = useState(true);
  const [emailSent, setEmailSent] = useState(false);

  useEffect(() => {
    // Simulate loading payment details
    setTimeout(() => {
      setPaymentDetails({
        id: paymentId || `pi_${Date.now()}`,
        amount: 399,
        currency: 'USD',
        status: 'succeeded',
        packageName: 'Business Class',
        projectName: 'Tech Startup Logo',
        customerEmail: 'customer@example.com',
        paymentMethod: {
          type: 'card',
          card: {
            brand: 'visa',
            last4: '4242'
          }
        },
        createdAt: new Date().toISOString(),
        estimatedDelivery: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString(), // 2 days later
        receiptUrl: '#'
      });
      setLoading(false);
    }, 1000);
  }, [paymentId]);

  const handleSendReceipt = async () => {
    setEmailSent(true);
    // Simulate sending email
    setTimeout(() => {
      setEmailSent(false);
    }, 3000);
  };

  const copyPaymentId = () => {
    if (paymentDetails) {
      navigator.clipboard.writeText(paymentDetails.id);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getCurrencySymbol = (currency: string) => {
    const symbols: Record<string, string> = {
      'USD': '$',
      'EUR': '€',
      'GBP': '£',
      'CNY': '¥',
      'JPY': '¥'
    };
    return symbols[currency] || '$';
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#FAFAF8] to-[#F5F3ED] flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-[#B6652E] border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading payment details...</p>
        </div>
      </div>
    );
  }

  if (!paymentDetails) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#FAFAF8] to-[#F5F3ED] flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <span className="text-red-600 text-2xl">!</span>
          </div>
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Payment Information Not Found</h2>
          <p className="text-gray-600 mb-6">Unable to find payment details, please contact customer service</p>
          <button
            onClick={() => onNavigate?.('home')}
            className="px-6 py-3 bg-gradient-to-r from-[#B6652E] to-[#FFB84D] text-white rounded-xl hover:shadow-lg transition-all"
          >
            Return to Home
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="Page_PaymentSuccess min-h-screen bg-gradient-to-br from-[#FAFAF8] to-[#F5F3ED]">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        
        {/* Success notification */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-green-100 rounded-full mb-6">
            <CheckCircle className="w-10 h-10 text-green-600" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Payment Successful!</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Thank you for choosing WeDesign! We have received your order, and our designers will start creating your custom logo within 3 hours.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Main content */}
          <div className="lg:col-span-2 space-y-6">
            
            {/* Order details */}
            <div className="backdrop-blur-xl bg-white/90 rounded-2xl p-6 border border-white/20">
              <h2 className="text-xl font-semibold text-gray-900 mb-6">Order Details</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-medium text-gray-900 mb-3">Project Information</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Project Name</span>
                      <span className="font-medium">{paymentDetails.projectName}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Service Package</span>
                      <span className="font-medium">{paymentDetails.packageName}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Estimated Delivery</span>
                      <span className="font-medium text-green-600">
                        {formatDate(paymentDetails.estimatedDelivery)}
                      </span>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="font-medium text-gray-900 mb-3">Payment Information</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Payment Method</span>
                      <div className="flex items-center gap-2">
                        <CreditCard className="w-4 h-4 text-gray-400" />
                        <span className="font-medium">
                          {paymentDetails.paymentMethod.card?.brand.toUpperCase()} 
                          ****{paymentDetails.paymentMethod.card?.last4}
                        </span>
                      </div>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Payment Amount</span>
                      <span className="font-semibold text-[#B6652E]">
                        {getCurrencySymbol(paymentDetails.currency)}{paymentDetails.amount}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Payment Time</span>
                      <span className="font-medium">
                        {formatDate(paymentDetails.createdAt)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Payment ID */}
              <div className="mt-6 pt-6 border-t border-gray-200">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-sm text-gray-600">Payment ID: </span>
                    <span className="font-mono text-sm font-medium">{paymentDetails.id}</span>
                  </div>
                  <button
                    onClick={copyPaymentId}
                    className="flex items-center gap-2 px-3 py-2 text-sm text-gray-600 hover:text-gray-800 transition-colors"
                  >
                    <Copy className="w-4 h-4" />
                    Copy
                  </button>
                </div>
              </div>
            </div>

            {/* Next steps */}
            <div className="backdrop-blur-xl bg-white/90 rounded-2xl p-6 border border-white/20">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">What Happens Next?</h2>
              
              <div className="space-y-4">
                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 rounded-full bg-[#B6652E] text-white flex items-center justify-center flex-shrink-0 text-sm font-medium">1</div>
                  <div>
                    <h3 className="font-medium text-gray-900">Project Initiation (Within 1 hour)</h3>
                    <p className="text-sm text-gray-600 mt-1">
                      Our project manager will review your design requirements and assign a professional design team.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 rounded-full bg-[#B6652E] text-white flex items-center justify-center flex-shrink-0 text-sm font-medium">2</div>
                  <div>
                    <h3 className="font-medium text-gray-900">Design Begins (Within 3 hours)</h3>
                    <p className="text-sm text-gray-600 mt-1">
                      Our designers will start creating your logo concepts. You can track progress in your user dashboard.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 rounded-full bg-[#B6652E] text-white flex items-center justify-center flex-shrink-0 text-sm font-medium">3</div>
                  <div>
                    <h3 className="font-medium text-gray-900">Initial Delivery (Within 48 hours)</h3>
                    <p className="text-sm text-gray-600 mt-1">
                      You will receive multiple logo design options and can choose your favorite for revisions.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 rounded-full bg-[#B6652E] text-white flex items-center justify-center flex-shrink-0 text-sm font-medium">4</div>
                  <div>
                    <h3 className="font-medium text-gray-900">Refinement & Revisions</h3>
                    <p className="text-sm text-gray-600 mt-1">
                      We'll make revisions based on your feedback until you're completely satisfied.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            
            {/* Quick actions */}
            <div className="backdrop-blur-xl bg-white/90 rounded-2xl p-6 border border-white/20">
              <h3 className="font-semibold text-gray-900 mb-4">Quick Actions</h3>
              
              <div className="space-y-3">
                <button
                  onClick={() => onNavigate?.('user-portal')}
                  className="w-full flex items-center justify-between px-4 py-3 bg-gradient-to-r from-[#B6652E] to-[#FFB84D] text-white rounded-xl hover:shadow-lg transition-all"
                >
                  <span>View Project Progress</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <button
                  onClick={handleSendReceipt}
                  disabled={emailSent}
                  className="w-full flex items-center justify-between px-4 py-3 border border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 transition-colors disabled:opacity-50"
                >
                  <span>{emailSent ? 'Sent' : 'Email Receipt'}</span>
                  <Mail className="w-4 h-4" />
                </button>

                <button
                  onClick={() => window.print()}
                  className="w-full flex items-center justify-between px-4 py-3 border border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 transition-colors"
                >
                  <span>Print Receipt</span>
                  <Printer className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Customer support */}
            <div className="backdrop-blur-xl bg-white/90 rounded-2xl p-6 border border-white/20">
              <h3 className="font-semibold text-gray-900 mb-4">Need Help?</h3>
              
              <div className="space-y-3 text-sm">
                <div>
                  <p className="text-gray-600 mb-2">Customer Support Email</p>
                  <a 
                    href="mailto:support@wedesign.com"
                    className="text-[#B6652E] hover:text-[#FFB84D] transition-colors"
                  >
                    support@wedesign.com
                  </a>
                </div>

                <div>
                  <p className="text-gray-600 mb-2">Online Support</p>
                  <p className="text-gray-800">Monday - Friday 9:00 AM - 6:00 PM</p>
                </div>

                <div>
                  <p className="text-gray-600 mb-2">Emergency Contact</p>
                  <p className="text-gray-800">+1 (555) 123-4567</p>
                </div>
              </div>
            </div>

            {/* Recommended services */}
            <div className="backdrop-blur-xl bg-white/90 rounded-2xl p-6 border border-white/20">
              <h3 className="font-semibold text-gray-900 mb-4">More Services</h3>
              
              <div className="space-y-4">
                <div className="p-4 bg-gradient-to-r from-[#B6652E]/10 to-[#FFB84D]/10 rounded-xl">
                  <h4 className="font-medium text-gray-900 mb-2">Brand Identity Design</h4>
                  <p className="text-sm text-gray-600 mb-3">
                    Complete brand visual identity system design
                  </p>
                  <span className="text-sm text-[#B6652E] font-medium">Learn More →</span>
                </div>

                <div className="p-4 bg-gradient-to-r from-[#B6652E]/10 to-[#FFB84D]/10 rounded-xl">
                  <h4 className="font-medium text-gray-900 mb-2">Website Design</h4>
                  <p className="text-sm text-gray-600 mb-3">
                    Responsive business website design and development
                  </p>
                  <span className="text-sm text-[#B6652E] font-medium">Learn More →</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}