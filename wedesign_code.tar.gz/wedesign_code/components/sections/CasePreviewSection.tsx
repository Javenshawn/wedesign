import { WeDesignCaseCard } from "../design-system/WeDesignCaseCard";
import { WeDesignButton } from "../design-system/WeDesignButton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Input } from "../ui/input";
import { Search, ArrowRight } from "lucide-react";

const mockCases = [
  {
    image: "https://images.unsplash.com/photo-1572044162444-ad60f128bdea?w=400&h=400&fit=crop",
    title: "Modern Tech Startup",
    industry: "Technology",
    tags: ["Minimalist", "Blue", "Professional"]
  },
  {
    image: "https://images.unsplash.com/photo-1515378791036-0648a814c963?w=400&h=400&fit=crop",
    title: "Organic Restaurant",
    industry: "Food & Beverage",
    tags: ["Organic", "Green", "Natural"]
  },
  {
    image: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1f?w=400&h=400&fit=crop",
    title: "Healthcare Clinic",
    industry: "Healthcare",
    tags: ["Medical", "Trust", "Clean"]
  },
  {
    image: "https://images.unsplash.com/photo-1533750349088-cd871a92f312?w=400&h=400&fit=crop",
    title: "Fashion Boutique",
    industry: "Fashion",
    tags: ["Elegant", "Luxury", "Pink"]
  },
  {
    image: "https://images.unsplash.com/photo-1555421689-491a97ff2040?w=400&h=400&fit=crop",
    title: "Fitness Studio",
    industry: "Fitness",
    tags: ["Dynamic", "Energy", "Orange"]
  },
  {
    image: "https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=400&h=400&fit=crop",
    title: "Law Firm",
    industry: "Legal",
    tags: ["Professional", "Trust", "Navy"]
  }
];

export function Section_CasePreview() {
  return (
    <section className="Section_CasePreview py-20 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="font-heading text-2xl md:text-3xl font-bold text-ink-deep-brown mb-4 tracking-tight">
            Featured Design Cases
          </h2>
          <p className="font-body text-lg md:text-xl text-ink-soft-brown max-w-2xl mx-auto leading-relaxed">
            Explore our portfolio of successful brand identities across various industries.
          </p>
        </div>

        {/* FilterBar */}
        <div className="FilterBar flex flex-col md:flex-row gap-4 mb-12">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                placeholder="Search designs..."
                className="Input_Search pl-10 bg-white border-border"
              />
            </div>
          </div>
          
          <Select>
            <SelectTrigger className="Select_Industry w-full md:w-48 bg-white border-border">
              <SelectValue placeholder="Industry" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Industries</SelectItem>
              <SelectItem value="technology">Technology</SelectItem>
              <SelectItem value="food">Food & Beverage</SelectItem>
              <SelectItem value="healthcare">Healthcare</SelectItem>
              <SelectItem value="fashion">Fashion</SelectItem>
              <SelectItem value="fitness">Fitness</SelectItem>
              <SelectItem value="legal">Legal</SelectItem>
            </SelectContent>
          </Select>

          <Select>
            <SelectTrigger className="Select_Color w-full md:w-48 bg-white border-border">
              <SelectValue placeholder="Color Theme" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Colors</SelectItem>
              <SelectItem value="blue">Blue</SelectItem>
              <SelectItem value="green">Green</SelectItem>
              <SelectItem value="red">Red</SelectItem>
              <SelectItem value="purple">Purple</SelectItem>
              <SelectItem value="orange">Orange</SelectItem>
              <SelectItem value="black">Black</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Masonry_CaseCards */}
        <div className="Masonry_CaseCards grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {mockCases.map((case_, index) => (
            <WeDesignCaseCard
              key={index}
              {...case_}
              className="Card_Case"
            />
          ))}
        </div>

        <div className="text-center">
          <WeDesignButton
            variant="secondary-outline"
            size="lg"
            className="flex items-center gap-2 mx-auto"
          >
            View All Cases
            <ArrowRight className="w-5 h-5" />
          </WeDesignButton>
        </div>
      </div>
    </section>
  );
}