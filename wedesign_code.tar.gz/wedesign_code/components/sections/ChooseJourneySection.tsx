import { Rocket, Building, Users, RotateCcw, ArrowRight } from 'lucide-react';

const journeys = [
  {
    id: 'startup',
    title: 'Startup',
    description: 'Perfect for new businesses launching their brand identity',
    icon: <Rocket className="w-8 h-8" />,
    features: ['Fast turnaround', 'Budget-friendly', 'Modern designs'],
    color: 'from-blue-500 to-blue-600',
    popular: false
  },
  {
    id: 'business',
    title: 'Business',
    description: 'Established companies looking to enhance their brand',
    icon: <Building className="w-8 h-8" />,
    features: ['Professional quality', 'Multiple concepts', 'Brand guidelines'],
    color: 'from-green-500 to-green-600',
    popular: true
  },
  {
    id: 'creator',
    title: 'Creator',
    description: 'Personal brands, influencers, and content creators',
    icon: <Users className="w-8 h-8" />,
    features: ['Personal touch', 'Social media ready', 'Unique style'],
    color: 'from-purple-500 to-purple-600',
    popular: false
  },
  {
    id: 'rebrand',
    title: 'Rebrand',
    description: 'Complete brand makeover for existing businesses',
    icon: <RotateCcw className="w-8 h-8" />,
    features: ['Full analysis', 'Strategic approach', 'Complete package'],
    color: 'from-orange-500 to-orange-600',
    popular: false
  }
];

interface ChooseJourneySectionProps {
  onSelectJourney?: (journeyId: string) => void;
}

export function Section_ChooseJourney({ onSelectJourney }: ChooseJourneySectionProps) {
  return (
    <section className="Section_ChooseJourney py-20 bg-gradient-to-b from-muted/20 to-white">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="mb-6">Choose Your Design Journey</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Every business is unique. Select the path that best fits your brand's story and goals.
          </p>
        </div>

        {/* Journey Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {journeys.map((journey) => (
            <div 
              key={journey.id}
              className="Journey_Card group relative bg-white rounded-3xl p-8 shadow-luxury hover:shadow-luxury-lg transition-all duration-300 cursor-pointer border-2 border-transparent hover:border-accent-terra/20"
              onClick={() => onSelectJourney?.(journey.id)}
            >
              {/* Popular Badge */}
              {journey.popular && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <div className="gradient-gold text-white px-4 py-1 rounded-full text-sm font-medium">
                    Most Popular
                  </div>
                </div>
              )}

              {/* Icon */}
              <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${journey.color} flex items-center justify-center text-white mb-6 group-hover:scale-110 transition-transform`}>
                {journey.icon}
              </div>

              {/* Content */}
              <div className="space-y-4">
                <h3 className="text-2xl font-bold text-ink-deep-brown">
                  {journey.title}
                </h3>

                <p className="text-muted-foreground">
                  {journey.description}
                </p>

                {/* Features */}
                <ul className="space-y-2">
                  {journey.features.map((feature, index) => (
                    <li key={index} className="text-sm text-muted-foreground flex items-center gap-2">
                      <div className="w-1.5 h-1.5 gradient-gold rounded-full"></div>
                      {feature}
                    </li>
                  ))}
                </ul>

                {/* CTA */}
                <div className="pt-4">
                  <div className="flex items-center justify-between text-accent-terra font-medium group-hover:text-accent-terra/80 transition-colors">
                    <span>Get Started</span>
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              </div>

              {/* Hover Outline */}
              <div className="absolute inset-0 rounded-3xl border-2 border-accent-terra opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"></div>
            </div>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-16">
          <div className="inline-flex items-center gap-4 bg-white rounded-2xl p-6 shadow-luxury">
            <div>
              <h4 className="font-semibold text-ink-deep-brown mb-1">Not sure which path to choose?</h4>
              <p className="text-sm text-muted-foreground">Our design consultants can help guide you</p>
            </div>
            <button className="px-6 py-2 gradient-gold text-white rounded-xl font-medium hover:scale-105 transition-transform">
              Get Advice
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}