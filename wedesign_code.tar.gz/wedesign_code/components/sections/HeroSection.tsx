import { WeDesignButton } from "../design-system/WeDesignButton";
import { Badge } from "../ui/badge";
import { ImageWithFallback } from "../figma/ImageWithFallback";
import { Play, ArrowRight, Sparkles } from "lucide-react";

interface HeroSectionProps {
  onGetStarted: () => void;
}

export function HeroSection({ onGetStarted }: HeroSectionProps) {
  return (
    <section className="Container_Hero min-h-screen flex items-center py-20">
      <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        
        {/* Container_Text */}
        <div className="Container_Text space-y-8">
          <div className="space-y-6">
            <Badge className="gradient-gold text-white px-4 py-2 text-sm font-medium inline-flex items-center gap-2">
              <Sparkles className="w-4 h-4" />
              Premium Logo Design Service
            </Badge>
            
            <div className="space-y-4">
              <h1 className="text-5xl lg:text-6xl font-extrabold text-ink-deep-brown leading-tight tracking-tight">
                Professional
                <span className="text-gradient-gold block">Logo Design</span>
                That Builds Brands
              </h1>
              
              <p className="text-xl text-muted-foreground leading-relaxed max-w-2xl">
                Get stunning, memorable logos crafted by expert designers. 
                From concept to completion in 24-72 hours with unlimited revisions.
              </p>
            </div>
          </div>

          <div className="Offer_Bar gradient-gold p-4 rounded-lg text-white">
            <div className="flex items-center justify-between">
              <div>
                <span className="font-semibold">Limited Time:</span>
                <span className="ml-2">50% off all packages this week</span>
              </div>
              <Badge className="bg-white/20 text-white">
                Ends Soon
              </Badge>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4">
            <WeDesignButton
              variant="primary-gold"
              size="lg"
              className="Button_StartNow flex items-center gap-2"
              onClick={onGetStarted}
            >
              Start Your Project
              <ArrowRight className="w-5 h-5" />
            </WeDesignButton>
            
            <WeDesignButton
              variant="secondary-outline"
              size="lg"
              className="Button_ViewCases flex items-center gap-2"
            >
              <Play className="w-5 h-5" />
              View Our Work
            </WeDesignButton>
          </div>

          <div className="flex items-center gap-8 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span>15+ designers online</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
              <span>24/7 support</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
              <span>100% satisfaction</span>
            </div>
          </div>
        </div>

        {/* Container_Image */}
        <div className="Container_Image">
          <div className="relative">
            <div className="absolute inset-0 gradient-gold rounded-3xl blur-3xl opacity-20"></div>
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1626785774573-4b799315345d?w=600&h=600&fit=crop"
              alt="Professional Logo Design"
              className="relative z-10 w-full h-[500px] object-cover rounded-3xl shadow-luxury-lg"
            />
            
            {/* Floating elements */}
            <div className="absolute top-10 -left-4 z-20">
              <div className="bg-white p-4 rounded-xl shadow-luxury">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 gradient-gold rounded-full"></div>
                  <div>
                    <div className="text-xs text-muted-foreground">Just completed</div>
                    <div className="text-sm font-semibold">Tech Startup Logo</div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="absolute bottom-10 -right-4 z-20">
              <div className="bg-white p-4 rounded-xl shadow-luxury">
                <div className="text-center">
                  <div className="text-2xl font-bold text-gradient-gold">4.9</div>
                  <div className="text-xs text-muted-foreground">Average Rating</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}