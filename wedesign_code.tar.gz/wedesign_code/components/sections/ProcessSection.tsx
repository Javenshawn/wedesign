import { Badge } from "../ui/badge";
import { ImageWithFallback } from "../figma/ImageWithFallback";
import { Package, FileText, CreditCard, Palette } from "lucide-react";

const processSteps = [
  {
    icon: <Package className="w-8 h-8" />,
    title: "Choose Package",
    description: "Select the perfect package for your needs - Economy, Business, or Private Jet."
  },
  {
    icon: <FileText className="w-8 h-8" />,
    title: "Submit Brief",
    description: "Tell us about your brand, style preferences, and vision through our simple form."
  },
  {
    icon: <CreditCard className="w-8 h-8" />,
    title: "Secure Payment",
    description: "Complete your payment safely and get instant confirmation of your order."
  },
  {
    icon: <Palette className="w-8 h-8" />,
    title: "Design Begins",
    description: "Our expert designers start creating your unique logo within 2 hours."
  }
];

export function ProcessSection() {
  return (
    <section className="Section_Carousel py-20 bg-bg-light-ivory">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          
          {/* Container_Video */}
          <div className="Container_Video">
            <div className="relative">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=600&h=400&fit=crop"
                alt="How WeDesign Works"
                className="w-full h-80 object-cover rounded-2xl shadow-luxury-lg"
              />
              <div className="absolute inset-0 bg-black/40 rounded-2xl flex items-center justify-center">
                <div className="bg-white/90 p-4 rounded-full">
                  <div className="w-16 h-16 gradient-gold rounded-full flex items-center justify-center">
                    <div className="w-0 h-0 border-l-8 border-r-0 border-t-6 border-b-6 border-l-white border-t-transparent border-b-transparent ml-1"></div>
                  </div>
                </div>
              </div>
              <Badge className="absolute bottom-4 right-4 bg-white/90 text-ink-deep-brown">
                3:24 min
              </Badge>
            </div>
          </div>

          {/* Container_List */}
          <div className="Container_List space-y-8">
            <div className="text-center lg:text-left">
              <h2 className="text-4xl font-bold text-ink-deep-brown mb-4">
                How WeDesign Works
              </h2>
              <p className="text-xl text-muted-foreground">
                Get your professional logo in 4 simple steps
              </p>
            </div>

            <div className="space-y-6">
              {processSteps.map((step, index) => (
                <div key={index} className="flex items-start gap-4">
                  <div className="flex-shrink-0">
                    <div className="w-16 h-16 gradient-gold rounded-full flex items-center justify-center text-white">
                      {step.icon}
                    </div>
                  </div>
                  <div className="flex-1">
                    <h4 className="text-xl font-semibold text-ink-deep-brown mb-2">
                      {index + 1}. {step.title}
                    </h4>
                    <p className="text-muted-foreground">
                      {step.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}