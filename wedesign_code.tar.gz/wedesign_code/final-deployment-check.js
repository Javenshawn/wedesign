// WeDesign 最终部署检查脚本
const fs = require('fs');
const path = require('path');

console.log('🚀 WeDesign 最终部署准备检查');
console.log('================================');

// 1. 检查核心组件架构
console.log('\n📦 核心架构检查:');

const coreComponents = {
  '入口文件': ['App.tsx'],
  '页面组件': [
    'components/pages/HomePage.tsx',
    'components/pages/LogosDesignPage.tsx',
    'components/pages/DesignHallPage.tsx',
    'components/pages/AboutUsPage.tsx',
    'components/pages/Page_Blog.tsx'
  ],
  '管理员系统': [
    'components/admin/AdminLogin.tsx',
    'components/admin/AdminDashboard.tsx',
    'components/admin/AdminCustomers.tsx',
    'components/admin/AdminSEO.tsx'
  ],
  '设计系统': [
    'components/design-system/WeDesignButton.tsx'
  ],
  '工具库': [
    'utils/routing-config.ts',
    'utils/seo-utils.ts',
    'utils/analytics-utils.ts',
    'utils/supabase/client.ts'
  ]
};

let architectureOK = true;
Object.entries(coreComponents).forEach(([category, files]) => {
  console.log(`\n  ${category}:`);
  files.forEach(file => {
    const exists = fs.existsSync(path.join(__dirname, file));
    console.log(`    ${exists ? '✅' : '❌'} ${file}`);
    if (!exists) architectureOK = false;
  });
});

// 2. 检查数据库配置
console.log('\n💾 数据库配置检查:');
const supabaseClientPath = path.join(__dirname, 'utils/supabase/client.ts');
if (fs.existsSync(supabaseClientPath)) {
  const content = fs.readFileSync(supabaseClientPath, 'utf8');
  
  console.log('  ✅ Supabase 客户端文件存在');
  
  if (content.includes('authAPI')) {
    console.log('  ✅ 认证 API 已配置');
  }
  
  if (content.includes('projectsAPI')) {
    console.log('  ✅ 项目 API 已配置');
  }
  
  if (content.includes('blogAPI')) {
    console.log('  ✅ 博客 API 已配置');
  }
  
  if (content.includes('回退到模拟')) {
    console.log('  ✅ 包含回退机制（适合演示）');
  }
} else {
  console.log('  ❌ Supabase 客户端文件缺失');
  architectureOK = false;
}

// 3. 检查路由系统
console.log('\n🗺️  路由系统检查:');
const routingPath = path.join(__dirname, 'utils/routing-config.ts');
if (fs.existsSync(routingPath)) {
  const routingContent = fs.readFileSync(routingPath, 'utf8');
  
  if (routingContent.includes('admin-login')) {
    console.log('  ✅ 管理员路由已配置');
  }
  
  if (routingContent.includes('hiddenHeaderPages')) {
    console.log('  ✅ 页面显示规则已配置');
  }
  
  console.log('  ✅ 路由系统完整');
} else {
  console.log('  ❌ 路由配置文件缺失');
  architectureOK = false;
}

// 4. 检查样式系统
console.log('\n🎨 样式系统检查:');
const stylesPath = path.join(__dirname, 'styles/globals.css');
if (fs.existsSync(stylesPath)) {
  const stylesContent = fs.readFileSync(stylesPath, 'utf8');
  
  const criticalStyles = [
    'gradient-gold',
    'glass-card',
    'accent-terra',
    'font-heading',
    'font-body',
    'touch-target'
  ];
  
  let stylesOK = true;
  criticalStyles.forEach(style => {
    if (stylesContent.includes(style)) {
      console.log(`  ✅ ${style} 样式已定义`);
    } else {
      console.log(`  ❌ ${style} 样式缺失`);
      stylesOK = false;
    }
  });
  
  if (stylesOK) {
    console.log('  ✅ WeDesign 设计系统完整');
  }
} else {
  console.log('  ❌ 全局样式文件缺失');
  architectureOK = false;
}

// 5. 检查SEO系统
console.log('\n🔍 SEO 系统检查:');
const seoPath = path.join(__dirname, 'utils/seo-keywords-data.ts');
const seoUtilsPath = path.join(__dirname, 'utils/seo-utils.ts');

if (fs.existsSync(seoPath)) {
  console.log('  ✅ SEO 关键词数据库存在');
  
  const seoContent = fs.readFileSync(seoPath, 'utf8');
  if (seoContent.includes('keywordCategories')) {
    console.log('  ✅ 关键词分类数据完整');
  }
  
  if (seoContent.includes('generateKeywordData')) {
    console.log('  ✅ 关键词生成器已配置');
  }
}

if (fs.existsSync(seoUtilsPath)) {
  console.log('  ✅ SEO 工具库存在');
}

// 6. 检查环境配置
console.log('\n⚙️  环境配置检查:');
const envExamplePath = path.join(__dirname, '.env.example');
if (fs.existsSync(envExamplePath)) {
  console.log('  ✅ 环境变量模板存在');
  
  const envContent = fs.readFileSync(envExamplePath, 'utf8');
  const requiredVars = [
    'VITE_SUPABASE_URL',
    'VITE_SUPABASE_ANON_KEY', 
    'VITE_STRIPE_PUBLISHABLE_KEY',
    'VITE_GA_MEASUREMENT_ID'
  ];
  
  requiredVars.forEach(varName => {
    if (envContent.includes(varName)) {
      console.log(`  ✅ ${varName} 模板存在`);
    } else {
      console.log(`  ⚠️  ${varName} 模板缺失`);
    }
  });
} else {
  console.log('  ❌ .env.example 文件缺失');
}

// 7. 检查构建配置
console.log('\n🔧 构建配置检查:');
const buildFiles = ['package.json', 'vite.config.ts', 'vercel.json'];
buildFiles.forEach(file => {
  const exists = fs.existsSync(path.join(__dirname, file));
  console.log(`  ${exists ? '✅' : '❌'} ${file}`);
});

// 8. 功能特性检查
console.log('\n🌟 功能特性检查:');
const features = [
  { name: '主页设计', file: 'components/pages/HomePage.tsx' },
  { name: 'Logo设计页', file: 'components/pages/LogosDesignPage.tsx' },
  { name: '设计大厅', file: 'components/pages/DesignHallPage.tsx' },
  { name: '关于我们', file: 'components/pages/AboutUsPage.tsx' },
  { name: '博客系统', file: 'components/pages/Page_Blog.tsx' },
  { name: '用户登录', file: 'components/pages/Page_Login.tsx' },
  { name: '用户门户', file: 'components/pages/Page_UserPortal.tsx' },
  { name: '支付系统', file: 'components/pages/Page_Checkout.tsx' },
  { name: '管理员登录', file: 'components/admin/AdminLogin.tsx' },
  { name: '管理员仪表板', file: 'components/admin/AdminDashboard.tsx' },
  { name: '客户管理', file: 'components/admin/AdminCustomers.tsx' },
  { name: 'SEO管理', file: 'components/admin/AdminSEO.tsx' }
];

features.forEach(feature => {
  const exists = fs.existsSync(path.join(__dirname, feature.file));
  console.log(`  ${exists ? '✅' : '❌'} ${feature.name}`);
});

// 最终评估
console.log('\n📊 最终评估:');
console.log('================================');

if (architectureOK) {
  console.log('🎉 WeDesign 项目已准备好部署！');
  console.log('\n✅ 系统完整性: 优秀');
  console.log('✅ 组件架构: 完整');
  console.log('✅ 设计系统: 完整');
  console.log('✅ 管理员后台: 完整');
  console.log('✅ SEO系统: 完整');
  console.log('✅ 数据库集成: 完整');
  
  console.log('\n🚀 推荐部署步骤:');
  console.log('1. 复制 .env.example 到 .env 并配置实际密钥');
  console.log('2. npm run build - 构建项目');
  console.log('3. 部署到 Vercel');
  console.log('4. 绑定自定义域名');
  console.log('5. 配置 Stripe 生产环境');
  
  console.log('\n🔑 访问信息:');
  console.log('• 主网站: https://your-domain.com');
  console.log('• 管理员后台: https://your-domain.com/admin-login');
  console.log('• 用户登录: https://your-domain.com/login');
  
  console.log('\n📈 特性亮点:');
  console.log('• 完整的Logo设计业务流程');
  console.log('• 强大的管理员后台系统');
  console.log('• SEO优化与关键词管理');
  console.log('• 响应式设计 + 毛玻璃效果');
  console.log('• 集成支付系统 (Stripe)');
  console.log('• 用户认证与项目管理');
  console.log('• 博客内容管理系统');
  
} else {
  console.log('⚠️  项目需要修复后才能部署');
  console.log('\n请检查上述标记为 ❌ 的项目并修复');
}

console.log('\nWeDesign 部署检查完成！');