# WeDesign Typography System Guidelines

## Typography Hierarchy

### Font Families
* **Headlines (H1-H3)**: Playfair Display - A modern serif font that balances elegance and professionalism, perfect for luxury branding
* **Body Text & UI**: Inter - Clean, highly legible sans-serif for optimal readability across all devices

### Font Size Guidelines
* **H1 (Page Titles)**: 
  - Mobile: 2.25rem (36px)
  - Tablet: 2.75rem (44px) 
  - Desktop: 3rem (48px)
* **H2 (Section Headers)**: 
  - Mobile: 1.875rem (30px)
  - Tablet+: 2.25rem (36px)
* **H3 (Subsection Titles)**: 
  - Mobile: 1.5rem (24px)
  - Tablet+: 1.75rem (28px)
* **H4 (Component Titles)**: 1.375rem (22px)
* **H5 (Small Headers)**: 1.125rem (18px)
* **H6 (Tiny Headers)**: 1rem (16px)
* **Body Text**: 1rem (16px)
* **Lead Text**: 1.125rem-1.25rem (18px-20px) responsive
* **Small Text**: 0.875rem (14px)

### Font Weight Guidelines
* **Headings**: 
  - H1: font-extrabold (800) for maximum impact
  - H2: font-bold (700) for section headers
  - H3: font-semibold (600) for subsection titles
  - H4-H6: font-semibold (600) for component titles
* **Body**: font-normal (400) for regular text, font-medium (500) for emphasis

### Letter Spacing (Tracking)
* **Large Headlines (H1)**: -0.02em (tighter spacing for impact)
* **Section Headers (H2)**: -0.01em (slightly tighter)
* **Smaller Headings (H3)**: -0.005em (subtle adjustment)

### Usage Rules
1. **Never override default typography** unless specifically required by design
2. **Use CSS variables** for consistency: `var(--font-heading)` and `var(--font-body)`
3. **Add tracking classes** for large headlines: `tracking-tight` or `tracking-tighter`
4. **Maintain hierarchy**: H1 > H2 > H3 > H4 in visual weight
5. **Use utility classes**: `.font-heading`, `.font-body`, `.heading-luxury` when needed

### Color System
* **Primary Text**: `text-ink-deep-brown` (#301F0F)
* **Secondary Text**: `text-muted-foreground` for less important content
* **Accent Text**: `text-gradient-gold` for highlights and important elements

## Component Guidelines

### WeDesign Components
* All custom components should respect the typography system
* Use explicit font-family CSS variables when needed: `style={{ fontFamily: 'var(--font-heading)' }}`
* Maintain consistent spacing and sizing across all components

### Button Typography
* Use `font-medium` for button text
* Size variations: sm (text-sm), md (text-base), lg (text-lg)
* Always use Inter font family for UI elements

## Implementation Notes
* The typography system is defined in `/styles/globals.css`
* Default HTML elements automatically use the correct fonts when no Tailwind classes override them
* Use Tailwind classes sparingly for typography - rely on semantic HTML when possible

## Mobile-First Design Guidelines

### Touch-Friendly Design
* **Minimum Touch Target**: 44px × 44px for all interactive elements
* **Button Heights**: sm (36px), md (44px), lg (48px)
* **Spacing**: Minimum 8px between touch targets
* **Form Elements**: Minimum 48px height for inputs and selects
* **Touch Target Class**: Use `touch-target` utility class for minimum sizing
* **Touch Area Class**: Use `touch-area` for proper padding around interactive elements

### Responsive Spacing
* **Mobile**: Compact padding (1rem), reduced gaps (0.75rem)
* **Tablet**: Medium padding (1.5rem), standard gaps (1rem)
* **Desktop**: Full padding (2rem), expanded gaps (1.5rem)
* **Responsive Padding**: Use `responsive-padding` utility class
* **Section Spacing**: Use `section-mobile` for consistent section padding

### Content Adaptation
* **Text Stacking**: Use flex-col on mobile, flex-row on larger screens
* **Grid Adaptation**: 1 column mobile → 2 columns tablet → 3 columns desktop
* **Navigation**: Collapsible mobile menu with touch-friendly 48px buttons

### Layout Patterns
* **Sections**: Use `.section-mobile` for responsive section padding
* **Cards**: Minimum 44px height, responsive padding
* **Modals**: Full-width on mobile with responsive breakpoints
* **Forms**: Stack form fields vertically on mobile

### Performance Considerations
* **Images**: Use responsive images with proper sizes
* **Interactions**: Optimize for touch vs hover states
* **Loading**: Consider mobile network speeds
* **Accessibility**: Ensure keyboard navigation works on all devices

## Component Naming Standards

### Page Components
* **Pattern**: `Page_[Name]` (e.g., `Page_Home`, `Page_AboutUs`)
* **Structure**: Always wrap content in responsive containers
* **Layout**: Use Container_Desktop → Container_Tablet → Container_Mobile hierarchy

### Section Components  
* **Pattern**: `Section_[Name]` (e.g., `Section_Hero`, `Section_Pricing`)
* **Spacing**: Use `section-mobile` for consistent responsive padding
* **Content**: Wrap in `Container_Content` with `max-w-7xl mx-auto responsive-padding`

### Layout Containers
* **Desktop**: `Container_Desktop` with `max-w-screen-2xl mx-auto`
* **Tablet**: `Container_Tablet` for tablet-specific adaptations
* **Mobile**: `Container_Mobile` for mobile-first content
* **Content**: `Container_Content` for section content with responsive padding

### Interactive Elements
* **Buttons**: `Button_[Purpose]` (e.g., `Button_StartNow`, `Button_Login`)
* **Inputs**: `Input_[Field]` (e.g., `Input_LogoSearch`, `Input_Email`) 
* **Selects**: `Select_[Type]` (e.g., `Select_Industry`, `Select_Color`)
* **Cards**: `Card_[Type]` (e.g., `Card_Logo`, `Card_Pricing`)

### Content Elements
* **Icons**: `Icon_[Name]` (e.g., `Icon_Search`, `Icon_Filter`)
* **Images**: `Image_[Purpose]` (e.g., `Image_Logo`, `Image_Hero`)
* **Text**: `Text_[Role]` (e.g., `Text_Title`, `Text_Description`)
* **Labels**: `Label_[Field]` for form field labels

### Modal Components
* **Pattern**: `Modal_[Type]` (e.g., `Modal_StartProject`, `Modal_Login`)
* **Content**: Use `Container_ModalContent` for main modal body
* **Structure**: Maintain consistent header, content, footer structure

## Responsive Structure Standards

### Auto Layout Equivalent Pattern
```jsx
<div className="Page_[Name]">
  <div className="Container_Desktop max-w-screen-2xl mx-auto">
    <div className="Container_Tablet">
      <div className="Container_Mobile">
        <Section_[Name] />
        // Additional sections...
      </div>
    </div>
  </div>
</div>
```

### Grid System
* **Mobile**: `grid-cols-1` (single column stacking)
* **Tablet**: `md:grid-cols-2` (two column layout)
* **Desktop**: `lg:grid-cols-3` or `xl:grid-cols-4` (multi-column)
* **Gaps**: Use consistent spacing - `gap-4`, `gap-6`, `gap-8`

### Flexbox Patterns
* **Mobile**: `flex flex-col` (vertical stacking)
* **Tablet+**: `sm:flex-row` (horizontal layout)
* **Alignment**: Use `items-center`, `justify-between`, `justify-center`
* **Wrap**: Use `flex-wrap` when content might overflow

## Wix Studio Compatibility

### Layout Requirements
* **No Absolute Positioning**: Use flex/grid layouts exclusively
* **Auto Layout Structure**: Maintain proper parent/child relationships
* **Responsive Constraints**: Use relative units and responsive classes
* **Touch Optimization**: Ensure all interactive elements meet 44px minimum

### Export Readiness
* **Clean Hierarchy**: Page → Section → Container → Element structure
* **Consistent Naming**: Follow established patterns for all components
* **Responsive Design**: Mobile-first approach with progressive enhancement
* **Component Isolation**: Each component should be self-contained and reusable
<!--

System Guidelines

Use this file to provide the AI with rules and guidelines you want it to follow.
This template outlines a few examples of things you can add. You can add your own sections and format it to suit your needs

TIP: More context isn't always better. It can confuse the LLM. Try and add the most important rules you need

# General guidelines

Any general rules you want the AI to follow.
For example:

* Only use absolute positioning when necessary. Opt for responsive and well structured layouts that use flexbox and grid by default
* Refactor code as you go to keep code clean
* Keep file sizes small and put helper functions and components in their own files.

--------------

# Design system guidelines
Rules for how the AI should make generations look like your company's design system

Additionally, if you select a design system to use in the prompt box, you can reference
your design system's components, tokens, variables and components.
For example:

* Use a base font-size of 14px
* Date formats should always be in the format “Jun 10”
* The bottom toolbar should only ever have a maximum of 4 items
* Never use the floating action button with the bottom toolbar
* Chips should always come in sets of 3 or more
* Don't use a dropdown if there are 2 or fewer options

You can also create sub sections and add more specific details
For example:


## Button
The Button component is a fundamental interactive element in our design system, designed to trigger actions or navigate
users through the application. It provides visual feedback and clear affordances to enhance user experience.

### Usage
Buttons should be used for important actions that users need to take, such as form submissions, confirming choices,
or initiating processes. They communicate interactivity and should have clear, action-oriented labels.

### Variants
* Primary Button
  * Purpose : Used for the main action in a section or page
  * Visual Style : Bold, filled with the primary brand color
  * Usage : One primary button per section to guide users toward the most important action
* Secondary Button
  * Purpose : Used for alternative or supporting actions
  * Visual Style : Outlined with the primary color, transparent background
  * Usage : Can appear alongside a primary button for less important actions
* Tertiary Button
  * Purpose : Used for the least important actions
  * Visual Style : Text-only with no border, using primary color
  * Usage : For actions that should be available but not emphasized
-->
