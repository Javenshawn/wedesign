import React from 'react';
import ReactDOM from 'react-dom/client';

// Import the root App component and global styles. Vite will resolve these relative paths.
import App from './App';
import './styles/globals.css';

// Locate the root DOM element defined in index.html
const rootElement = document.getElementById('root');

if (!rootElement) {
  throw new Error('Root element not found');
}

// Create a React root and render the App component
ReactDOM.createRoot(rootElement).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);