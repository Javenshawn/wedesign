#!/usr/bin/env node

console.log('🔧 WeDesign Environment Setup Helper');
console.log('====================================\n');

console.log('This guide will help you gather the required API keys for deployment.\n');

console.log('📋 REQUIRED ENVIRONMENT VARIABLES:\n');

console.log('🗄️  SUPABASE CONFIGURATION:');
console.log('   Get these from: https://supabase.com → Your Project → Settings → API');
console.log('   ┌─────────────────────────────────────────────────────────────┐');
console.log('   │ VITE_SUPABASE_URL=https://your-project-id.supabase.co      │');
console.log('   │ VITE_SUPABASE_ANON_KEY=eyJ...your_anon_key                 │');
console.log('   │ SUPABASE_SERVICE_ROLE_KEY=eyJ...your_service_role_key      │');
console.log('   └─────────────────────────────────────────────────────────────┘\n');

console.log('💳 STRIPE CONFIGURATION:');
console.log('   Get these from: https://dashboard.stripe.com → Developers → API Keys');
console.log('   ┌─────────────────────────────────────────────────────────────┐');
console.log('   │ VITE_STRIPE_PUBLISHABLE_KEY=pk_live_...your_publishable_key │');
console.log('   │ STRIPE_SECRET_KEY=sk_live_...your_secret_key                │');
console.log('   └─────────────────────────────────────────────────────────────┘\n');

console.log('⚠️  IMPORTANT NOTES:');
console.log('   • For PRODUCTION: Use LIVE keys (pk_live_, sk_live_)');
console.log('   • For TESTING: Use TEST keys (pk_test_, sk_test_)');
console.log('   • Never commit these keys to GitHub');
console.log('   • Add them as Environment Variables in Vercel Dashboard\n');

console.log('📝 VERCEL DEPLOYMENT STEPS:');
console.log('   1. Create GitHub repository');
console.log('   2. Import to Vercel');
console.log('   3. Add environment variables in Vercel Dashboard');
console.log('   4. Deploy');
console.log('   5. Configure Supabase CORS settings');
console.log('   6. Configure Stripe webhooks\n');

console.log('🔍 VERIFICATION CHECKLIST:');
console.log('   ✓ Supabase URL starts with "https://" and ends with ".supabase.co"');
console.log('   ✓ Supabase keys start with "eyJ"');
console.log('   ✓ Stripe publishable key starts with "pk_live_" or "pk_test_"');
console.log('   ✓ Stripe secret key starts with "sk_live_" or "sk_test_"');
console.log('   ✓ All keys are properly set in Vercel Environment Variables\n');

console.log('📖 For detailed step-by-step instructions, see:');
console.log('   → COMPLETE_DEPLOYMENT_STEPS.md\n');

console.log('🚀 Ready to deploy? Run these commands:');
console.log('   1. node cleanup-project.js          # Clean up project');
console.log('   2. node verify-deployment-ready.js  # Verify readiness');
console.log('   3. Follow COMPLETE_DEPLOYMENT_STEPS.md');