import { useState } from "react";
import { WeDesignButton } from "./WeDesignButton";
import { Upload, X, FileText, Image } from "lucide-react";
import { cn } from "../ui/utils";

interface WeDesignFileUploadProps {
  label: string;
  accept?: string;
  onFileSelect: (file: File | null) => void;
  className?: string;
}

export function WeDesignFileUpload({
  label,
  accept = "image/*,.pdf,.doc,.docx",
  onFileSelect,
  className
}: WeDesignFileUploadProps) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isDragOver, setIsDragOver] = useState(false);

  const handleFileSelect = (file: File) => {
    setSelectedFile(file);
    onFileSelect(file);
  };

  const handleFileRemove = () => {
    setSelectedFile(null);
    onFileSelect(null);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      handleFileSelect(files[0]);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const getFileIcon = (fileName: string) => {
    const extension = fileName.split('.').pop()?.toLowerCase();
    const imageExts = ['jpg', 'jpeg', 'png', 'gif', 'svg', 'webp'];
    return imageExts.includes(extension || '') ? Image : FileText;
  };

  return (
    <div className={cn("space-y-2", className)}>
      <label className="text-ink-deep-brown font-medium text-sm">{label}</label>
      
      {selectedFile ? (
        <div className="bg-white rounded-lg p-3 border border-border">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {(() => {
                const IconComponent = getFileIcon(selectedFile.name);
                return <IconComponent className="w-5 h-5 text-accent-terra" />;
              })()}
              <div>
                <p className="font-medium text-ink-deep-brown text-sm">{selectedFile.name}</p>
                <p className="text-xs text-muted-foreground">
                  {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                </p>
              </div>
            </div>
            <button
              onClick={handleFileRemove}
              className="w-6 h-6 rounded-full bg-muted hover:bg-destructive hover:text-white flex items-center justify-center transition-colors duration-200"
            >
              <X className="w-3 h-3" />
            </button>
          </div>
        </div>
      ) : (
        <div
          className={cn(
            "border border-dashed rounded-lg p-4 text-center transition-all duration-200 bg-white",
            isDragOver ? "border-accent-terra bg-accent-terra/5" : "border-border hover:border-accent-terra/50"
          )}
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
        >
          <div className={cn(
            "w-10 h-10 rounded-full mx-auto mb-2 flex items-center justify-center transition-colors duration-200",
            isDragOver ? "gradient-gold" : "bg-muted"
          )}>
            <Upload className={cn("w-5 h-5", isDragOver ? "text-white" : "text-muted-foreground")} />
          </div>
          
          <div className="space-y-2">
            <div>
              <p className="font-medium text-ink-deep-brown text-sm mb-1">
                {isDragOver ? "Drop your file here" : "Upload Reference File"}
              </p>
              <p className="text-xs text-muted-foreground">
                Drag and drop or click to browse
              </p>
            </div>
            
            <WeDesignButton
              variant="secondary-outline"
              size="sm"
              onClick={() => {
                const input = document.createElement('input');
                input.type = 'file';
                input.accept = accept;
                input.onchange = (e) => {
                  const file = (e.target as HTMLInputElement).files?.[0];
                  if (file) handleFileSelect(file);
                };
                input.click();
              }}
              className="mx-auto"
            >
              Browse Files
            </WeDesignButton>
          </div>
          
          <p className="text-xs text-muted-foreground mt-2 pt-2 border-t border-border">
            PNG, JPG, PDF, DOC (up to 10MB)
          </p>
        </div>
      )}
    </div>
  );
}