/*
 * Temporary Footer component for WeDesign
 *
 * The previous version of this project included a comprehensive Footer
 * implementation in ``components/layout/Footer.tsx``. However, the latest
 * code export omitted this file which resulted in build errors when
 * ``App.tsx`` attempted to import it. To restore buildability and keep
 * the application functional, we provide a simplified Footer component
 * here. You can expand upon this placeholder later with the full
 * implementation from your earlier codebase or redesign it to suit your
 * needs. See ``wedesign_code_backup/components/layout/Footer.tsx`` for
 * reference on the original design.
 */

interface FooterProps {
  /**
   * Called when a navigation link is clicked. Receives the target page
   * identifier (e.g. 'home' or 'about-us').
   */
  onNavigate: (page: string) => void;
}

// A very simple footer that renders a few navigation links and credits.
export function Footer({ onNavigate }: FooterProps) {
  return (
    <footer className="py-8 border-t border-glass-border bg-bg-light-ivory/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <nav className="mb-4 space-x-4">
          <button
            className="text-sm text-muted-foreground hover:text-accent-terra transition-colors"
            onClick={() => onNavigate('home')}
          >
            Home
          </button>
          <button
            className="text-sm text-muted-foreground hover:text-accent-terra transition-colors"
            onClick={() => onNavigate('logos-design')}
          >
            Logo Design
          </button>
          <button
            className="text-sm text-muted-foreground hover:text-accent-terra transition-colors"
            onClick={() => onNavigate('about-us')}
          >
            About Us
          </button>
          <button
            className="text-sm text-muted-foreground hover:text-accent-terra transition-colors"
            onClick={() => onNavigate('design-hall')}
          >
            Design Hall
          </button>
          <button
            className="text-sm text-muted-foreground hover:text-accent-terra transition-colors"
            onClick={() => onNavigate('blog')}
          >
            Blog
          </button>
        </nav>
        <p className="text-xs text-muted-foreground">
          © {new Date().getFullYear()} WeDesign. All rights reserved.
        </p>
      </div>
    </footer>
  );
}