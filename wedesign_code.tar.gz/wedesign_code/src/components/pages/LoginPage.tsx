import { useState } from 'react';
import { Eye, EyeOff, ArrowRight, Mail, Lock } from 'lucide-react';
import { WeDesignButton } from '../design-system/WeDesignButton';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Checkbox } from '../ui/checkbox';

interface LoginPageProps {
  onLogin: (userData: { email: string; name: string; avatar?: string }) => void;
  onNavigate: (page: string) => void;
}

export function Page_Login({ onLogin, onNavigate }: LoginPageProps) {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    rememberMe: false
  });
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    // Simulate authentication delay
    setTimeout(() => {
      // Mock successful login
      onLogin({
        email: formData.email,
        name: formData.email.split('@')[0],
        avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&face'
      });
      setIsLoading(false);
      onNavigate('home');
    }, 1500);
  };

  const handleDemoLogin = () => {
    onLogin({
      email: 'demo@wedesign.com',
      name: 'Demo User',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&face'
    });
    onNavigate('home');
  };

  return (
    <div className="Page_Login min-h-screen bg-gradient-to-br from-bg-light-ivory to-white">
      <div className="flex items-center justify-center min-h-screen py-12 px-6">
        <div className="max-w-md w-full">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="inline-block p-4 gradient-gold rounded-2xl mb-4">
              <Lock className="w-8 h-8 text-white" />
            </div>
            <h1 className="mb-4">Welcome Back</h1>
            <p className="text-muted-foreground">
              Sign in to your WeDesign account to track your projects and access your designs.
            </p>
          </div>

          {/* Login Form */}
          <div className="bg-white rounded-2xl shadow-luxury-lg p-8 border border-border">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Email Field */}
              <div className="space-y-2">
                <Label htmlFor="email" className="text-ink-deep-brown font-medium">
                  Email Address
                </Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    id="email"
                    type="email"
                    placeholder="your@email.com"
                    value={formData.email}
                    onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                    className="pl-10 h-12 bg-muted/30 border border-border focus:border-accent-terra focus:ring-2 focus:ring-accent-terra/20"
                    required
                  />
                </div>
              </div>

              {/* Password Field */}
              <div className="space-y-2">
                <Label htmlFor="password" className="text-ink-deep-brown font-medium">
                  Password
                </Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="Enter your password"
                    value={formData.password}
                    onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
                    className="pl-10 pr-10 h-12 bg-muted/30 border border-border focus:border-accent-terra focus:ring-2 focus:ring-accent-terra/20"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground hover:text-accent-terra"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Remember Me & Forgot Password */}
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="remember"
                    checked={formData.rememberMe}
                    onCheckedChange={(checked) => 
                      setFormData(prev => ({ ...prev, rememberMe: checked as boolean }))
                    }
                  />
                  <Label htmlFor="remember" className="text-sm text-muted-foreground cursor-pointer">
                    Remember me
                  </Label>
                </div>
                <button
                  type="button"
                  className="text-sm text-accent-terra hover:text-accent-terra/80 transition-colors"
                >
                  Forgot password?
                </button>
              </div>

              {/* Submit Button */}
              <WeDesignButton
                type="submit"
                variant="primary-gold"
                size="lg"
                className="w-full h-12"
                disabled={isLoading}
              >
                {isLoading ? (
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    Signing in...
                  </div>
                ) : (
                  <>
                    Sign In <ArrowRight className="w-4 h-4 ml-2" />
                  </>
                )}
              </WeDesignButton>
            </form>

            {/* Divider */}
            <div className="relative my-6">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-border"></div>
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white text-muted-foreground">Or try our demo</span>
              </div>
            </div>

            {/* Demo Login */}
            <WeDesignButton
              variant="secondary-outline"
              size="lg"
              className="w-full h-12"
              onClick={handleDemoLogin}
            >
              Demo Login
            </WeDesignButton>

            {/* Sign Up Link */}
            <div className="text-center mt-6">
              <p className="text-sm text-muted-foreground">
                Don't have an account?{' '}
                <button
                  type="button"
                  className="text-accent-terra hover:text-accent-terra/80 font-medium transition-colors"
                >
                  Create Account
                </button>
              </p>
            </div>
          </div>

          {/* Additional Info */}
          <div className="text-center mt-8">
            <p className="text-xs text-muted-foreground">
              By signing in, you agree to our{' '}
              <button className="text-accent-terra hover:text-accent-terra/80 transition-colors">
                Terms of Service
              </button>{' '}
              and{' '}
              <button className="text-accent-terra hover:text-accent-terra/80 transition-colors">
                Privacy Policy
              </button>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}