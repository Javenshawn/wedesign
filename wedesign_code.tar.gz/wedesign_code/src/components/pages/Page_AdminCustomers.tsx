import { AdminCustomers } from '../admin/AdminCustomers';

interface PageAdminCustomersProps {
  onNavigate: (page: string) => void;
}

export function Page_AdminCustomers({ onNavigate }: PageAdminCustomersProps) {
  return <AdminCustomers onNavigate={onNavigate} />;
}