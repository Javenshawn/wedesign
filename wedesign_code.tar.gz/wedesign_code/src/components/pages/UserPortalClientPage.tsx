import { useState } from 'react';
import { 
  LayoutDashboard, 
  Package, 
  Files, 
  MessageCircle, 
  Settings, 
  Download, 
  Eye, 
  Clock,
  CheckCircle,
  AlertCircle,
  User,
  Send,
  Paperclip,
  Smile
} from 'lucide-react';
import { WeDesignButton } from '../design-system/WeDesignButton';
import { Progress } from '../ui/progress';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';
import { Avatar } from '../ui/avatar';
import { Label } from '../ui/label';

interface Order {
  id: string;
  orderNumber: string;
  logoName: string;
  status: 'In Progress' | 'Review' | 'Completed' | 'Revision';
  progress: number;
  timeLeft: string;
  packageType: string;
  designer: string;
  createdAt: string;
  files?: { name: string; url: string; type: string }[];
}

interface ChatMessage {
  id: string;
  sender: 'client' | 'designer';
  message: string;
  timestamp: string;
  avatar?: string;
  files?: { name: string; url: string; preview?: string }[];
}

const sampleOrders: Order[] = [
  {
    id: '1',
    orderNumber: 'WD-2024-0847',
    logoName: 'TechFlow Solutions Logo',
    status: 'In Progress',
    progress: 75,
    timeLeft: '18h 42m',
    packageType: 'Business',
    designer: 'Sarah Chen',
    createdAt: '2024-01-15',
    files: []
  },
  {
    id: '2',
    orderNumber: 'WD-2024-0832',
    logoName: 'Urban Coffee Logo',
    status: 'Completed',
    progress: 100,
    timeLeft: 'Delivered',
    packageType: 'Economy',
    designer: 'Marcus Rodriguez',
    createdAt: '2024-01-10',
    files: [
      { name: 'urban-coffee-logo-final.ai', url: '#', type: 'ai' },
      { name: 'urban-coffee-logo-png.png', url: '#', type: 'png' },
      { name: 'brand-guidelines.pdf', url: '#', type: 'pdf' }
    ]
  },
  {
    id: '3',
    orderNumber: 'WD-2024-0821',
    logoName: 'Fitness Plus Logo',
    status: 'Review',
    progress: 95,
    timeLeft: '2 days',
    packageType: 'Private Jet',
    designer: 'Emily Thompson',
    createdAt: '2024-01-05',
    files: [
      { name: 'fitness-plus-concept-v2.ai', url: '#', type: 'ai' },
      { name: 'fitness-plus-preview.jpg', url: '#', type: 'jpg' }
    ]
  }
];

const sampleChatMessages: ChatMessage[] = [
  {
    id: '1',
    sender: 'designer',
    message: 'Hi! I\'ve started working on your TechFlow Solutions logo. I have a few initial concepts ready for your review.',
    timestamp: '2024-01-15 10:30 AM',
    avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=40&h=40&fit=crop&face'
  },
  {
    id: '2',
    sender: 'designer',
    message: 'Here are the first three concept directions. Let me know which style resonates with you the most.',
    timestamp: '2024-01-15 10:32 AM',
    avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=40&h=40&fit=crop&face',
    files: [
      { name: 'concept-1-modern.jpg', url: '#', preview: 'https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=200&h=150&fit=crop' },
      { name: 'concept-2-minimal.jpg', url: '#', preview: 'https://images.unsplash.com/photo-1558655146-9f40138edfeb?w=200&h=150&fit=crop' }
    ]
  },
  {
    id: '3',
    sender: 'client',
    message: 'These look great! I really like concept 2 - the minimal approach. Can we explore that direction further with perhaps a bit more color?',
    timestamp: '2024-01-15 2:45 PM'
  },
  {
    id: '4',
    sender: 'designer',
    message: 'Absolutely! I\'ll refine concept 2 with some color variations. Give me a few hours and I\'ll have some new options for you.',
    timestamp: '2024-01-15 3:15 PM',
    avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=40&h=40&fit=crop&face'
  }
];

export function Page_UserPortal() {
  const [activeSection, setActiveSection] = useState<'dashboard' | 'orders' | 'files' | 'messages' | 'settings'>('dashboard');
  const [selectedOrderId, setSelectedOrderId] = useState<string>('1');
  const [newMessage, setNewMessage] = useState('');
  const [chatMessages, setChatMessages] = useState(sampleChatMessages);

  const sidebarItems = [
    { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard className="w-5 h-5" /> },
    { id: 'orders', label: 'My Orders', icon: <Package className="w-5 h-5" /> },
    { id: 'files', label: 'Files', icon: <Files className="w-5 h-5" /> },
    { id: 'messages', label: 'Messages', icon: <MessageCircle className="w-5 h-5" /> },
    { id: 'settings', label: 'Account Settings', icon: <Settings className="w-5 h-5" /> }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Completed':
        return 'text-green-600 bg-green-100';
      case 'In Progress':
        return 'text-blue-600 bg-blue-100';
      case 'Review':
        return 'text-yellow-600 bg-yellow-100';
      case 'Revision':
        return 'text-orange-600 bg-orange-100';
      default:
        return 'text-gray-600 bg-gray-100';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'Completed':
        return <CheckCircle className="w-4 h-4" />;
      case 'In Progress':
        return <Clock className="w-4 h-4" />;
      case 'Review':
        return <Eye className="w-4 h-4" />;
      case 'Revision':
        return <AlertCircle className="w-4 h-4" />;
      default:
        return <Clock className="w-4 h-4" />;
    }
  };

  const handleSendMessage = () => {
    if (newMessage.trim()) {
      const message: ChatMessage = {
        id: (chatMessages.length + 1).toString(),
        sender: 'client',
        message: newMessage,
        timestamp: new Date().toLocaleString()
      };
      setChatMessages([...chatMessages, message]);
      setNewMessage('');
    }
  };

  const renderDashboard = () => (
    <div className="Container_Dashboard space-y-8">
      <div className="Container_WelcomeHeader">
        <h2 className="mb-2">Welcome back!</h2>
        <p className="text-ink-soft-brown">Here's what's happening with your logo projects.</p>
      </div>

      {/* Quick Stats */}
      <div className="Grid_QuickStats grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="Card_Stat glass-card rounded-2xl p-6 hover:shadow-glass-lg transition-all duration-300">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 gradient-gold-soft rounded-full flex items-center justify-center">
              <Package className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="text-2xl font-bold text-ink-deep-brown">{sampleOrders.length}</div>
              <div className="text-sm text-muted-foreground">Total Orders</div>
            </div>
          </div>
        </div>

        <div className="Card_Stat glass-card rounded-2xl p-6 hover:shadow-glass-lg transition-all duration-300">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-blue-500/90 rounded-full flex items-center justify-center">
              <Clock className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="text-2xl font-bold text-ink-deep-brown">
                {sampleOrders.filter(o => o.status === 'In Progress').length}
              </div>
              <div className="text-sm text-muted-foreground">In Progress</div>
            </div>
          </div>
        </div>

        <div className="Card_Stat glass-card rounded-2xl p-6 hover:shadow-glass-lg transition-all duration-300">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-green-500/90 rounded-full flex items-center justify-center">
              <CheckCircle className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="text-2xl font-bold text-ink-deep-brown">
                {sampleOrders.filter(o => o.status === 'Completed').length}
              </div>
              <div className="text-sm text-muted-foreground">Completed</div>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Orders */}
      <div className="Container_RecentOrders glass-card rounded-2xl p-6 hover:shadow-glass-lg transition-all duration-300">
        <h3 className="mb-6">Recent Orders</h3>
        <div className="space-y-4">
          {sampleOrders.slice(0, 3).map((order) => (
            <div key={order.id} className="Card_OrderSummary flex items-center justify-between p-4 glass-effect rounded-xl hover:shadow-glass transition-all duration-300">
              <div className="flex items-center gap-4">
                <div className={`px-3 py-1 rounded-full text-xs font-medium flex items-center gap-1 glass-effect ${getStatusColor(order.status)}`}>
                  {getStatusIcon(order.status)}
                  {order.status}
                </div>
                <div>
                  <div className="font-medium text-ink-deep-brown">{order.logoName}</div>
                  <div className="text-sm text-muted-foreground">{order.orderNumber}</div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-sm font-medium">{order.progress}% Complete</div>
                <div className="text-xs text-muted-foreground">{order.timeLeft} remaining</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderOrders = () => (
    <div className="Container_Orders space-y-8">
      <h2>My Orders</h2>

      <div className="Grid_Orders grid grid-cols-1 lg:grid-cols-2 gap-6">
        {sampleOrders.map((order) => (
          <div key={order.id} className="Card_Order glass-card rounded-2xl p-6 hover:shadow-glass-lg transition-all duration-300">
            <div className="Container_OrderHeader flex items-start justify-between mb-4">
              <div>
                <h4 className="font-semibold text-ink-deep-brown">{order.logoName}</h4>
                <p className="text-sm text-muted-foreground">{order.orderNumber}</p>
              </div>
              <div className={`px-3 py-1 rounded-full text-xs font-medium flex items-center gap-1 glass-effect ${getStatusColor(order.status)}`}>
                {getStatusIcon(order.status)}
                {order.status}
              </div>
            </div>

            <div className="Container_OrderDetails space-y-4">
              <div className="Container_Progress">
                <div className="flex justify-between text-sm mb-2">
                  <span>Progress</span>
                  <span>{order.progress}%</span>
                </div>
                <Progress value={order.progress} className="h-2" />
              </div>

              <div className="flex justify-between text-sm">
                <span>Designer:</span>
                <span className="font-medium">{order.designer}</span>
              </div>

              <div className="flex justify-between text-sm">
                <span>Package:</span>
                <span className="font-medium">{order.packageType}</span>
              </div>

              <div className="flex justify-between text-sm">
                <span>Time Remaining:</span>
                <span className="font-medium">{order.timeLeft}</span>
              </div>

              <div className="Container_OrderActions pt-4 flex gap-2">
                {order.status === 'Completed' && order.files && order.files.length > 0 && (
                  <WeDesignButton variant="primary-gold" size="sm" className="flex-1">
                    <Download className="w-4 h-4 mr-2" />
                    Download
                  </WeDesignButton>
                )}
                {order.status === 'Review' && (
                  <WeDesignButton variant="secondary-outline" size="sm" className="flex-1">
                    <Eye className="w-4 h-4 mr-2" />
                    Review
                  </WeDesignButton>
                )}
                <WeDesignButton variant="secondary-outline" size="sm" className="flex-1">
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Chat
                </WeDesignButton>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderFiles = () => (
    <div className="Container_Files space-y-8">
      <h2>Files</h2>
      
      {sampleOrders.filter(order => order.files && order.files.length > 0).map((order) => (
        <div key={order.id} className="Container_OrderFiles glass-card rounded-2xl p-6 hover:shadow-glass-lg transition-all duration-300">
          <h3 className="mb-4">{order.logoName}</h3>
          <div className="Grid_Files grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {order.files?.map((file, index) => (
              <div key={index} className="Card_File glass-effect rounded-xl p-4 hover:shadow-glass transition-all duration-300">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 gradient-gold-soft rounded-lg flex items-center justify-center">
                    <Files className="w-5 h-5 text-white" />
                  </div>
                  <div className="flex-1">
                    <div className="font-medium text-sm">{file.name}</div>
                    <div className="text-xs text-muted-foreground uppercase">{file.type}</div>
                  </div>
                  <WeDesignButton variant="secondary-outline" size="sm">
                    <Download className="w-4 h-4" />
                  </WeDesignButton>
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );

  const renderMessages = () => (
    <div className="Container_Messages space-y-8">
      <h2>Messages</h2>

      <div className="Container_ChatWindow glass-card rounded-2xl overflow-hidden hover:shadow-glass-lg transition-all duration-300">
        {/* Chat Header */}
        <div className="Container_ChatHeader p-6 border-b border-glass-border glass-effect">
          <div className="flex items-center gap-3">
            <Avatar className="w-10 h-10">
              <img src="https://images.unsplash.com/photo-1494790108755-2616b612b786?w=40&h=40&fit=crop&face" alt="Sarah Chen" />
            </Avatar>
            <div>
              <h4 className="font-semibold">Sarah Chen</h4>
              <p className="text-sm text-muted-foreground">Designer • TechFlow Solutions Logo</p>
            </div>
          </div>
        </div>

        {/* Chat Messages */}
        <div className="Container_ChatMessages p-6 max-h-96 overflow-y-auto">
          <div className="space-y-4">
            {chatMessages.map((message) => (
              <div key={message.id} className={`Message_Container flex gap-3 ${message.sender === 'client' ? 'flex-row-reverse' : ''}`}>
                {message.sender === 'designer' && (
                  <Avatar className="w-8 h-8">
                    <img src={message.avatar} alt="Designer" />
                  </Avatar>
                )}
                
                <div className={`Message_Content max-w-xs lg:max-w-md ${message.sender === 'client' ? 'text-right' : ''}`}>
                  <div className={`Message_Bubble p-3 rounded-2xl ${
                    message.sender === 'client' 
                      ? 'gradient-gold-soft text-white' 
                      : 'glass-effect text-ink-deep-brown'
                  }`}>
                    <p className="text-sm">{message.message}</p>
                    
                    {message.files && (
                      <div className="mt-2 space-y-2">
                        {message.files.map((file, index) => (
                          <div key={index} className="glass-effect-strong rounded-lg p-2">
                            {file.preview ? (
                              <img src={file.preview} alt={file.name} className="w-full h-20 object-cover rounded mb-1" />
                            ) : null}
                            <p className="text-xs">{file.name}</p>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">{message.timestamp}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Chat Input */}
        <div className="Container_ChatInput p-6 border-t border-glass-border glass-effect">
          <div className="flex gap-3">
            <Input
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              placeholder="Type your message..."
              className="Input_ChatMessage flex-1 input-glass"
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
            />
            <WeDesignButton variant="secondary-outline" size="sm">
              <Paperclip className="w-4 h-4" />
            </WeDesignButton>
            <WeDesignButton variant="secondary-outline" size="sm">
              <Smile className="w-4 h-4" />
            </WeDesignButton>
            <WeDesignButton variant="primary-gold" size="sm" onClick={handleSendMessage}>
              <Send className="w-4 h-4" />
            </WeDesignButton>
          </div>
        </div>
      </div>
    </div>
  );

  const renderSettings = () => (
    <div className="Container_Settings space-y-8">
      <h2>Account Settings</h2>

      <div className="Container_SettingsForm glass-card rounded-2xl p-6 space-y-6 hover:shadow-glass-lg transition-all duration-300">
        <div className="Section_ProfileInfo">
          <h4 className="mb-4">Profile Information</h4>
          <div className="Grid_ProfileFields grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="Field_FullName">
              <Label className="text-sm font-medium mb-2 block">Full Name</Label>
              <Input defaultValue="John Doe" className="input-glass" />
            </div>
            <div className="Field_Email">
              <Label className="text-sm font-medium mb-2 block">Email</Label>
              <Input defaultValue="john@example.com" className="input-glass" />
            </div>
          </div>
        </div>

        <div className="Section_Notifications">
          <h4 className="mb-4">Notifications</h4>
          <div className="space-y-3">
            <div className="Notification_Setting flex items-center justify-between p-3 glass-effect rounded-lg">
              <span className="text-sm">Project updates</span>
              <input type="checkbox" defaultChecked className="rounded" />
            </div>
            <div className="Notification_Setting flex items-center justify-between p-3 glass-effect rounded-lg">
              <span className="text-sm">Designer messages</span>
              <input type="checkbox" defaultChecked className="rounded" />
            </div>
            <div className="Notification_Setting flex items-center justify-between p-3 glass-effect rounded-lg">
              <span className="text-sm">Marketing emails</span>
              <input type="checkbox" className="rounded" />
            </div>
          </div>
        </div>

        <WeDesignButton variant="primary-gold">
          Save Changes
        </WeDesignButton>
      </div>
    </div>
  );

  return (
    <div className="Page_UserPortal min-h-screen bg-bg-light-ivory">
      {/* Background Elements */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 gradient-gold-soft opacity-5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 gradient-gold opacity-3 rounded-full blur-3xl"></div>
      </div>

      <div className="Container_Portal max-w-7xl mx-auto flex relative z-10">
        {/* Sidebar */}
        <aside className="Sidebar_Navigation w-64 glass-navigation shadow-glass-lg p-6 min-h-screen">
          <div className="Container_SidebarHeader mb-8">
            <h3 className="font-bold text-ink-deep-brown">Client Portal</h3>
            <p className="text-sm text-muted-foreground">Manage your logo projects</p>
          </div>

          <nav className="Nav_Sidebar space-y-2">
            {sidebarItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveSection(item.id as any)}
                className={`Nav_Item w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300 text-left touch-target ${
                  activeSection === item.id 
                    ? 'button-glass-primary shadow-glass' 
                    : 'button-glass hover:shadow-glass text-ink-deep-brown'
                }`}
              >
                {item.icon}
                <span className="font-medium">{item.label}</span>
              </button>
            ))}
          </nav>
        </aside>

        {/* Main Content */}
        <main className="Container_MainContent flex-1 p-8">
          {activeSection === 'dashboard' && renderDashboard()}
          {activeSection === 'orders' && renderOrders()}
          {activeSection === 'files' && renderFiles()}
          {activeSection === 'messages' && renderMessages()}
          {activeSection === 'settings' && renderSettings()}
        </main>
      </div>
    </div>
  );
}