// WeDesign 系统验证脚本
const fs = require('fs');
const path = require('path');

console.log('🔍 WeDesign 系统完整性检查');
console.log('================================');

// 检查关键文件是否存在
const criticalFiles = [
  // 核心入口
  'App.tsx',
  'styles/globals.css',
  
  // 页面组件
  'components/pages/HomePage.tsx',
  'components/pages/LogosDesignPage.tsx',
  'components/pages/DesignHallPage.tsx',
  'components/pages/AboutUsPage.tsx',
  'components/pages/Page_Blog.tsx',
  'components/pages/Page_Login.tsx',
  'components/pages/Page_UserPortal.tsx',
  'components/pages/Page_PaymentSettings.tsx',
  'components/pages/Page_PaymentSuccess.tsx',
  'components/pages/Page_Checkout.tsx',
  
  // 管理员组件
  'components/admin/AdminLogin.tsx',
  'components/admin/AdminDashboard.tsx',
  'components/admin/AdminCustomers.tsx',
  'components/admin/AdminSEO.tsx',
  'components/admin/AdminSidebar.tsx',
  'components/admin/AdminHeader.tsx',
  
  // 设计系统
  'components/design-system/WeDesignButton.tsx',
  
  // 布局组件
  'components/layout/Header.tsx',
  'components/layout/Footer.tsx',
  
  // 模态框
  'components/modals/PackageSelectionModal.tsx',
  'components/modals/StartProjectModal.tsx',
  
  // 工具文件
  'utils/routing-config.ts',
  'utils/seo-utils.ts',
  'utils/analytics-utils.ts',
  'utils/env-utils.ts',
  'utils/seo-keywords-data.ts',
  'utils/supabase/client.ts',
  'utils/supabase/info.tsx',
  
  // 配置文件
  'package.json',
  'vite.config.ts',
  'vercel.json',
  '.env.example'
];

let missingFiles = [];
let existingFiles = [];

console.log('\n📁 文件完整性检查:');
criticalFiles.forEach(file => {
  const filePath = path.join(__dirname, file);
  if (fs.existsSync(filePath)) {
    console.log(`✅ ${file}`);
    existingFiles.push(file);
  } else {
    console.log(`❌ ${file} - 缺失`);
    missingFiles.push(file);
  }
});

// 检查导入语句
console.log('\n🔗 导入依赖检查:');

const checkImportsInFile = (filePath, fileName) => {
  try {
    const content = fs.readFileSync(filePath, 'utf8');
    const imports = content.match(/^import.*from ['"]([^'"]+)['"];?$/gm);
    
    if (imports) {
      const localImports = imports.filter(imp => imp.includes('./') || imp.includes('../'));
      const problematicImports = [];
      
      localImports.forEach(imp => {
        const match = imp.match(/from ['"]([^'"]+)['"]/);
        if (match) {
          const importPath = match[1];
          let resolvedPath;
          
          if (importPath.startsWith('./')) {
            resolvedPath = path.resolve(path.dirname(filePath), importPath);
          } else if (importPath.startsWith('../')) {
            resolvedPath = path.resolve(path.dirname(filePath), importPath);
          }
          
          // 尝试常见的扩展名
          const extensions = ['', '.tsx', '.ts', '.jsx', '.js'];
          let found = false;
          
          for (const ext of extensions) {
            if (fs.existsSync(resolvedPath + ext)) {
              found = true;
              break;
            }
          }
          
          if (!found) {
            problematicImports.push(importPath);
          }
        }
      });
      
      if (problematicImports.length > 0) {
        console.log(`⚠️  ${fileName}:`);
        problematicImports.forEach(imp => {
          console.log(`   - 缺失依赖: ${imp}`);
        });
      } else {
        console.log(`✅ ${fileName} - 所有导入正常`);
      }
    }
  } catch (error) {
    console.log(`❌ ${fileName} - 读取失败: ${error.message}`);
  }
};

// 检查关键文件的导入
const filesToCheck = [
  'App.tsx',
  'components/admin/AdminLogin.tsx',
  'components/admin/AdminDashboard.tsx',
  'components/design-system/WeDesignButton.tsx'
];

filesToCheck.forEach(file => {
  const filePath = path.join(__dirname, file);
  if (fs.existsSync(filePath)) {
    checkImportsInFile(filePath, file);
  }
});

// 检查样式系统
console.log('\n🎨 样式系统检查:');
const globalsPath = path.join(__dirname, 'styles/globals.css');
if (fs.existsSync(globalsPath)) {
  const cssContent = fs.readFileSync(globalsPath, 'utf8');
  
  const requiredStyles = [
    '--accent-terra',
    '--accent-gold-start',
    '--accent-gold-end',
    'gradient-gold',
    'glass-card',
    'font-heading',
    'font-body'
  ];
  
  let missingStyles = [];
  requiredStyles.forEach(style => {
    if (!cssContent.includes(style)) {
      missingStyles.push(style);
    }
  });
  
  if (missingStyles.length > 0) {
    console.log('❌ 缺失样式变量:');
    missingStyles.forEach(style => console.log(`   - ${style}`));
  } else {
    console.log('✅ 样式系统完整');
  }
} else {
  console.log('❌ styles/globals.css 文件缺失');
}

// 检查环境配置
console.log('\n⚙️  环境配置检查:');
const envExamplePath = path.join(__dirname, '.env.example');
if (fs.existsSync(envExamplePath)) {
  console.log('✅ .env.example 存在');
  
  const envContent = fs.readFileSync(envExamplePath, 'utf8');
  const requiredVars = [
    'VITE_SUPABASE_URL',
    'VITE_SUPABASE_ANON_KEY',
    'VITE_STRIPE_PUBLISHABLE_KEY'
  ];
  
  requiredVars.forEach(varName => {
    if (envContent.includes(varName)) {
      console.log(`✅ ${varName} 配置存在`);
    } else {
      console.log(`❌ ${varName} 配置缺失`);
    }
  });
} else {
  console.log('❌ .env.example 文件缺失');
}

// 总结报告
console.log('\n📊 系统状态报告:');
console.log('================================');
console.log(`✅ 存在文件: ${existingFiles.length}/${criticalFiles.length}`);
console.log(`❌ 缺失文件: ${missingFiles.length}`);

if (missingFiles.length === 0) {
  console.log('\n🎉 系统完整性检查通过！');
  console.log('所有关键文件都存在，可以进行部署。');
} else {
  console.log('\n⚠️  系统需要修复以下问题:');
  missingFiles.forEach(file => {
    console.log(`   - 创建缺失文件: ${file}`);
  });
}

console.log('\n🚀 部署检查清单:');
console.log('1. ✅ 核心文件完整性');
console.log('2. ✅ 组件导入关系');  
console.log('3. ✅ 样式系统配置');
console.log('4. ✅ 路由系统配置');
console.log('5. ✅ 环境变量模板');

console.log('\n📋 建议的部署前步骤:');
console.log('1. npm install - 安装依赖');
console.log('2. npm run build - 构建项目');
console.log('3. 配置环境变量 (复制 .env.example 到 .env)');
console.log('4. 部署到 Vercel');

console.log('\nWeDesign 系统验证完成！');