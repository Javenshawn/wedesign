/**
 * 跨平台环境变量访问工具
 * 适用于 Figma Make、Vercel、Next.js、Vite 等多种环境
 */

/**
 * 安全获取环境变量
 * @param key 环境变量键名
 * @param defaultValue 默认值
 * @returns 环境变量值或默认值
 */
export function getEnvVar(key: string, defaultValue?: string): string | undefined {
  try {
    // 1. 检查浏览器环境的全局变量
    if (typeof window !== 'undefined') {
      // Figma Make 或其他自定义环境
      const windowEnv = (window as any).__ENV__ || (window as any).ENV;
      if (windowEnv && windowEnv[key]) {
        return windowEnv[key];
      }
      
      // 检查是否有配置对象注入
      const config = (window as any).__APP_CONFIG__;
      if (config && config[key]) {
        return config[key];
      }
    }

    // 2. Node.js 环境 (服务端渲染等)
    if (typeof process !== 'undefined' && process.env) {
      const value = process.env[key];
      if (value) return value;
    }

    // 3. Vite 环境 (import.meta.env)
    if (typeof globalThis !== 'undefined') {
      const importMeta = (globalThis as any).importMeta;
      if (importMeta && importMeta.env && importMeta.env[key]) {
        return importMeta.env[key];
      }
    }

    // 4. 检查其他可能的环境变量存储位置
    if (typeof globalThis !== 'undefined') {
      const globalEnv = (globalThis as any).env || (globalThis as any).ENV;
      if (globalEnv && globalEnv[key]) {
        return globalEnv[key];
      }
    }

    // 5. 返回默认值
    return defaultValue;
  } catch (error) {
    console.warn(`Failed to get environment variable "${key}":`, error);
    return defaultValue;
  }
}

/**
 * 获取所有相关的环境变量键名
 * 用于处理不同环境下的键名变化
 */
export function getEnvVarWithFallbacks(baseKey: string, defaultValue?: string): string | undefined {
  const variations = [
    baseKey,
    `NEXT_PUBLIC_${baseKey}`,
    `VITE_${baseKey}`,
    `REACT_APP_${baseKey}`,
    baseKey.replace('NEXT_PUBLIC_', '').replace('VITE_', '').replace('REACT_APP_', '')
  ];

  for (const key of variations) {
    const value = getEnvVar(key);
    if (value) return value;
  }

  return defaultValue;
}

/**
 * 检查是否为生产环境
 */
export function isProduction(): boolean {
  try {
    const nodeEnv = getEnvVar('NODE_ENV', 'development');
    const hostname = typeof window !== 'undefined' ? window.location.hostname : '';
    
    return (
      nodeEnv === 'production' ||
      hostname === 'www.wedesign.design' ||
      hostname === 'wedesign.design' ||
      hostname.includes('.vercel.app') ||
      hostname.includes('.netlify.app')
    );
  } catch (error) {
    return false;
  }
}

/**
 * 检查是否为开发环境
 */
export function isDevelopment(): boolean {
  try {
    const nodeEnv = getEnvVar('NODE_ENV', 'development');
    const hostname = typeof window !== 'undefined' ? window.location.hostname : '';
    
    return (
      nodeEnv === 'development' ||
      hostname === 'localhost' ||
      hostname === '127.0.0.1' ||
      hostname.startsWith('192.168.') ||
      hostname.includes('figma.com')
    );
  } catch (error) {
    return true; // 默认为开发环境更安全
  }
}

/**
 * 获取当前域名
 */
export function getCurrentDomain(): string {
  try {
    if (typeof window !== 'undefined') {
      return window.location.hostname;
    }
    return '';
  } catch (error) {
    return '';
  }
}

/**
 * WeDesign 特定的环境变量获取器
 */
export const weDesignEnv = {
  // Supabase 配置
  supabaseUrl: () => getEnvVarWithFallbacks('SUPABASE_URL'),
  supabaseAnonKey: () => getEnvVarWithFallbacks('SUPABASE_ANON_KEY'),
  supabaseServiceRoleKey: () => getEnvVar('SUPABASE_SERVICE_ROLE_KEY'),

  // Stripe 配置
  stripePublishableKey: () => getEnvVarWithFallbacks('STRIPE_PUBLISHABLE_KEY'),
  stripeSecretKey: () => getEnvVar('STRIPE_SECRET_KEY'),

  // Google Analytics 配置
  gaId: () => getEnvVarWithFallbacks('GA_MEASUREMENT_ID'),

  // 网站配置
  siteUrl: () => getEnvVar('NEXT_PUBLIC_SITE_URL', 'https://www.wedesign.design'),
  siteName: () => getEnvVar('NEXT_PUBLIC_SITE_NAME', 'WeDesign - Worldwide Design Best Delivered'),

  // 环境判断
  isProduction,
  isDevelopment,
  getCurrentDomain,
};

/**
 * 调试函数 - 在开发时使用
 */
export function debugEnvironment(): void {
  if (isDevelopment()) {
    console.log('Environment Debug Info:', {
      hostname: getCurrentDomain(),
      isProduction: isProduction(),
      isDevelopment: isDevelopment(),
      supabaseUrl: weDesignEnv.supabaseUrl() ? '✅ Set' : '❌ Missing',
      stripeKey: weDesignEnv.stripePublishableKey() ? '✅ Set' : '❌ Missing',
      gaId: weDesignEnv.gaId() ? '✅ Set' : '❌ Missing',
    });
  }
}

export default weDesignEnv;