export interface SEOConfig {
  title: string;
  description: string;
  canonical: string;
  keywords: string;
}

export const seoConfig: Record<string, SEOConfig> = {
  'home': {
    title: 'WeDesign - Worldwide Design Best Delivered | Professional Logo Design Services',
    description: 'Professional logo design services with luxury quality and worldwide delivery. Transform your brand with our expert design team and get stunning logos delivered fast.',
    canonical: 'https://www.wedesign.design/',
    keywords: 'logo design, professional logo, brand design, luxury design, logo services, worldwide design'
  },
  'logos-design': {
    title: 'Professional Logo Design Services - Premium Logo Creation | WeDesign',
    description: 'Get premium logo design services from our expert team. Choose from multiple packages and get high-quality logos with fast delivery and unlimited revisions.',
    canonical: 'https://www.wedesign.design/logos-design',
    keywords: 'logo design services, premium logo, professional logo design, custom logo, logo packages'
  },
  'design-hall': {
    title: 'Logo Design Portfolio - Stunning Design Showcase | WeDesign',
    description: 'Explore our extensive portfolio of professional logo designs. See real examples of our work across industries and get inspired for your next project.',
    canonical: 'https://www.wedesign.design/design-hall',
    keywords: 'logo portfolio, design showcase, logo examples, design gallery, logo inspiration'
  },
  'about-us': {
    title: 'About WeDesign - Professional Design Team & Company Story',
    description: 'Learn about WeDesign\'s mission to deliver worldwide design excellence. Meet our professional team and discover our commitment to quality logo design.',
    canonical: 'https://www.wedesign.design/about-us',
    keywords: 'about wedesign, design team, company story, professional designers, design agency'
  },
  'blog': {
    title: 'Design Blog - Logo Design Tips & Brand Insights | WeDesign',
    description: 'Get expert insights on logo design, branding tips, and design trends. Learn from our professional designers and improve your brand knowledge.',
    canonical: 'https://www.wedesign.design/blog',
    keywords: 'design blog, logo design tips, branding insights, design trends, brand strategy'
  }
};