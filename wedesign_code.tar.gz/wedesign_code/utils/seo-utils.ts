import { seoConfig, SEOConfig } from './seo-config';

/**
 * Updates or creates a meta tag with the specified name/property and content
 * @param name - The meta tag name or property
 * @param content - The content value
 * @param property - Whether this is a property attribute (for Open Graph tags)
 */
const updateMetaTag = (name: string, content: string, property = false) => {
  const selector = property ? `meta[property="${name}"]` : `meta[name="${name}"]`;
  let meta = document.querySelector(selector) as HTMLMetaElement;
  
  if (!meta) {
    meta = document.createElement('meta');
    if (property) {
      meta.setAttribute('property', name);
    } else {
      meta.setAttribute('name', name);
    }
    document.head.appendChild(meta);
  }
  
  meta.setAttribute('content', content);
};

/**
 * Updates the page SEO information based on the current page
 * @param currentPage - The current page identifier
 */
export const updatePageSEO = (currentPage: string) => {
  const config = seoConfig[currentPage as keyof typeof seoConfig] || seoConfig.home;
  
  // Update page title
  document.title = config.title;
  
  // Update basic SEO tags
  updateMetaTag('description', config.description);
  updateMetaTag('keywords', config.keywords);
  
  // Update Open Graph tags
  updateMetaTag('og:title', config.title, true);
  updateMetaTag('og:description', config.description, true);
  updateMetaTag('og:url', config.canonical, true);
  updateMetaTag('og:type', 'website', true);
  updateMetaTag('og:site_name', 'WeDesign', true);
  updateMetaTag('og:image', 'https://www.wedesign.design/wedesign-og-image.png', true);
  
  // Update Twitter Card tags
  updateMetaTag('twitter:card', 'summary_large_image');
  updateMetaTag('twitter:title', config.title);
  updateMetaTag('twitter:description', config.description);
  updateMetaTag('twitter:image', 'https://www.wedesign.design/wedesign-og-image.png');
  
  // Update canonical URL
  let canonicalLink = document.querySelector("link[rel='canonical']") as HTMLLinkElement;
  if (!canonicalLink) {
    canonicalLink = document.createElement('link');
    canonicalLink.rel = 'canonical';
    document.head.appendChild(canonicalLink);
  }
  canonicalLink.href = config.canonical;
  
  // Update structured data (JSON-LD)
  updateStructuredData();
};

/**
 * Updates the structured data (JSON-LD) for the page
 */
const updateStructuredData = () => {
  const structuredData = {
    "@context": "https://schema.org",
    "@type": "Organization",
    "name": "WeDesign",
    "description": "Professional logo design services with worldwide delivery",
    "url": "https://www.wedesign.design",
    "logo": "https://www.wedesign.design/wedesign-logo.png",
    "contactPoint": {
      "@type": "ContactPoint",
      "contactType": "customer service",
      "url": "https://www.wedesign.design/about-us"
    },
    "sameAs": [
      "https://www.facebook.com/wedesign",
      "https://www.instagram.com/wedesign",
      "https://www.linkedin.com/company/wedesign"
    ]
  };
  
  let jsonLd = document.querySelector('script[type="application/ld+json"]');
  if (!jsonLd) {
    jsonLd = document.createElement('script');
    jsonLd.type = 'application/ld+json';
    document.head.appendChild(jsonLd);
  }
  jsonLd.textContent = JSON.stringify(structuredData);
};