#!/usr/bin/env node

const fs = require('fs');
const path = require('path');

console.log('🧹 WeDesign 项目完整清理');
console.log('移除所有 Wix Studio 和冗余文件');
console.log('========================================\n');

// 要删除的所有文件（包括原清理脚本 + Wix 文件）
const filesToRemove = [
  // 所有冗余指南文件
  'API_KEYS_CHECKLIST.md',
  'COMPLETE_SUPABASE_SETUP_GUIDE.md',
  'CONFIGURE_YOUR_SUPABASE_PROJECT.md',
  'CONTINUE_STRIPE_AND_DEPLOYMENT.md',
  'CREATE_SUPABASE_PROJECT_FOR_WEDESIGN.md',
  'DEPLOYMENT_EXECUTION_GUIDE.md',
  'DOMAIN_BINDING_GUIDE.md',
  'EXPORT_CHECKLIST.md',
  'EXPORT_EXECUTION_GUIDE.md',
  'EXPORT_READY_REPORT.md',
  'GODADDY_DOMAIN_BINDING_GUIDE.md',
  'PREPARATION_CHECKLIST.md',
  'QUICK_CONFIG_TEST.md',
  'START_DOMAIN_BINDING_NOW.md',
  'STEP_1_GET_API_KEYS_DETAILED.md',
  'STEP_2_GET_STRIPE_KEYS_DETAILED.md',
  'STRIPE_ACTUAL_CONSOLE_API_KEY_GUIDE.md',
  'STRIPE_COMPLETE_SETUP_GUIDE.md',
  'STRIPE_CONFIG_VERIFICATION.md',
  'STRIPE_CORRECT_KEYS_GUIDE.md',
  'STRIPE_FINAL_VERIFICATION.md',
  'STRIPE_KEYS_CONFIGURATION_GUIDE.md',
  'STRIPE_KEYS_SETUP_GUIDE.md',
  'STRIPE_KEY_FORMAT_VALIDATOR.md',
  'STRIPE_LIVE_KEY_CONFIGURATION_GUIDE.md',
  'STRIPE_LIVE_VERIFICATION_CHECKLIST.md',
  'STRIPE_MODE_SWITCHER_DETAILED_LOCATION_GUIDE.md',
  'STRIPE_MODE_SWITCHER_VISUAL_CHECKLIST.md',
  'STRIPE_PUBLISHABLE_KEY_STEP_BY_STEP_GUIDE.md',
  'STRIPE_QUICK_TEST_GUIDE.md',
  'STRIPE_SANDBOX_MODE_LOCATION_GUIDE.md',
  'STRIPE_SANDBOX_QUICK_CHECKLIST.md',
  'STRIPE_SCREENSHOT_SPECIFIC_GUIDE.md',
  'STRIPE_VISUAL_NAVIGATION_GUIDE.md',
  'STRUCTURE_AUDIT_REPORT.md',
  'SUPABASE_ACCOUNT_VERIFICATION_AND_SETUP.md',
  'SUPABASE_PROJECT_CREATION_CHECKLIST.md',
  'UPDATE_SUPABASE_CONFIG.md',
  'VERCEL_CONSOLE_SPECIFIC_GUIDE.md',
  'VERCEL_DEPLOYMENT_EXECUTION.md',
  'VERCEL_DEPLOYMENT_GUIDE.md',
  'VERCEL_VISUAL_NEXT_JS_SELECTION.md',
  'WEBSITE_MODIFICATION_GUIDE.md',
  
  // Wix Studio 相关文件
  'WIX_STUDIO_EXPORT_GUIDE.md',
  'VISUAL_EXPORT_LOCATION_GUIDE.md',
  'FIGMA_MAKE_EXPORT_GUIDE.md',
  
  // 中文文件
  '管理员后台访问指南.md',
  '网站修改指南.md',
  
  // 未使用的组件文件
  'components/PluginCard.tsx',
  'components/PluginFilters.tsx',
  'components/PluginManager.tsx',
  'components/TestModalPage.tsx',
  'components/pages/PluginsPage.tsx',
  'components/pages/UXAuditBoard.tsx',
  'types/plugin.ts',
  
  // Next.js 配置（Vite 项目不需要）
  'next.config.js',
];

let removedCount = 0;
let notFoundCount = 0;

console.log('📁 删除冗余文件：');

// 删除文件
filesToRemove.forEach(file => {
  const filePath = path.join(process.cwd(), file);
  if (fs.existsSync(filePath)) {
    try {
      if (fs.lstatSync(filePath).isDirectory()) {
        fs.rmSync(filePath, { recursive: true, force: true });
      } else {
        fs.unlinkSync(filePath);
      }
      console.log(`✅ 已删除: ${file}`);
      removedCount++;
    } catch (error) {
      console.log(`❌ 删除失败 ${file}: ${error.message}`);
    }
  } else {
    console.log(`⚪ 不存在: ${file}`);
    notFoundCount++;
  }
});

// 清理 Guidelines.md 中的 Wix Studio 内容
console.log('\n📝 清理 Guidelines.md 文件：');
const guidelinesPath = path.join(process.cwd(), 'Guidelines.md');
if (fs.existsSync(guidelinesPath)) {
  try {
    let content = fs.readFileSync(guidelinesPath, 'utf8');
    
    // 检查是否包含 Wix 内容
    if (content.toLowerCase().includes('wix')) {
      // 删除 Wix Studio Compatibility 整个部分
      const wixSectionRegex = /## Wix Studio Compatibility[\s\S]*?(?=(?:##|$))/g;
      const updatedContent = content.replace(wixSectionRegex, '');
      
      // 删除任何剩余的 wix 相关引用
      const cleanedContent = updatedContent
        .replace(/\* \*\*Export Readiness\*\*:.*wix.*\n/gi, '')
        .replace(/\* \*\*Wix Studio.*\n/gi, '')
        .replace(/- Clean hierarchy for Wix export.*\n/gi, '')
        .replace(/- Wix Studio ready structure.*\n/gi, '')
        .replace(/.*wix.*export.*\n/gi, '')
        .replace(/.*Wix.*export.*\n/gi, '');
      
      fs.writeFileSync(guidelinesPath, cleanedContent, 'utf8');
      console.log('✅ 已清理 Guidelines.md 中的 Wix Studio 内容');
      removedCount++;
    } else {
      console.log('✅ Guidelines.md 中没有 Wix 内容');
    }
  } catch (error) {
    console.log(`❌ 清理 Guidelines.md 失败: ${error.message}`);
  }
} else {
  console.log('⚠️  Guidelines.md 文件不存在');
}

// 检查并清理其他文件中的 Wix 引用
console.log('\n🔍 检查其他文件中的 Wix 引用：');
const filesToCheck = [
  'README.md',
  'COMPLETE_DEPLOYMENT_STEPS.md',
  'DEPLOY_TO_GITHUB_VERCEL.md'
];

let wixReferencesFound = 0;

filesToCheck.forEach(file => {
  const filePath = path.join(process.cwd(), file);
  if (fs.existsSync(filePath)) {
    try {
      let content = fs.readFileSync(filePath, 'utf8');
      const originalContent = content;
      
      // 删除包含 Wix 的行（但保留有用的内容）
      const lines = content.split('\n');
      const filteredLines = lines.filter(line => {
        const lowerLine = line.toLowerCase();
        // 删除明确提到 Wix Studio 的行，但保留可能有其他用途的行
        return !(lowerLine.includes('wix studio') || 
                lowerLine.includes('wix export') ||
                lowerLine.includes('export to wix'));
      });
      
      content = filteredLines.join('\n');
      
      if (content !== originalContent) {
        fs.writeFileSync(filePath, content, 'utf8');
        console.log(`✅ 已清理 ${file} 中的 Wix 引用`);
        wixReferencesFound++;
      } else {
        console.log(`✓ ${file} 中没有找到需要删除的 Wix 引用`);
      }
    } catch (error) {
      console.log(`❌ 检查 ${file} 失败: ${error.message}`);
    }
  } else {
    console.log(`⚪ ${file} 不存在`);
  }
});

// 验证关键文件存在
console.log('\n📋 验证项目结构：');
const criticalFiles = [
  'App.tsx',
  'package.json',
  'vite.config.ts',
  'vercel.json',
  'styles/globals.css',
  'components/layout/Header.tsx',
  'components/layout/Footer.tsx',
  '项目部署指南.md'
];

let missingCritical = 0;
criticalFiles.forEach(file => {
  const filePath = path.join(process.cwd(), file);
  if (fs.existsSync(filePath)) {
    console.log(`✅ ${file}`);
  } else {
    console.log(`❌ 缺失关键文件: ${file}`);
    missingCritical++;
  }
});

// 显示清理结果
console.log('\n' + '='.repeat(60));
console.log('📊 清理完成统计');
console.log('='.repeat(60));

console.log(`✅ 成功删除文件: ${removedCount}`);
console.log(`⚪ 文件不存在: ${notFoundCount}`);
console.log(`🔍 Wix 引用清理: ${wixReferencesFound}`);
console.log(`❌ 缺失关键文件: ${missingCritical}`);

if (missingCritical === 0) {
  console.log('\n🎉 项目清理完成！您的 WeDesign 项目现在是：');
  console.log('   ✅ 完全独立的 React + Vite 应用');
  console.log('   ✅ 移除了所有 Wix Studio 依赖');
  console.log('   ✅ 删除了冗余的配置文件');
  console.log('   ✅ 保留了所有核心功能');
  console.log('   ✅ 准备好进行 GitHub + Vercel 部署');
} else {
  console.log('\n⚠️  发现缺失关键文件，请检查项目完整性');
}

console.log('\n📝 下一步：');
console.log('1. 运行: node 验证部署准备.js');
console.log('2. 按照 项目部署指南.md 进行部署');
console.log('3. 设置 GitHub 仓库');
console.log('4. 在 Vercel 中配置环境变量');

console.log('\n🌟 您的高端 Logo 设计平台已准备好上线！');